@charset "UTF-8";
.van-toast[data-v-d06787cb] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-d06787cb] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-d06787cb] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-d06787cb] {
    height: 80%;
}

.hot_container .platform[data-v-d06787cb],
.hot_container .popular[data-v-d06787cb] {
    margin-bottom: 0.34667rem;
}

.hot_container .platform .title[data-v-d06787cb],
.hot_container .popular .title[data-v-d06787cb] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.21333rem;
}

.hot_container .platform .title span[data-v-d06787cb],
.hot_container .popular .title span[data-v-d06787cb] {
    font-size: 0.32rem;
    line-height: 0.4rem;
}

.hot_container .platform .list[data-v-d06787cb],
.hot_container .popular .list[data-v-d06787cb] {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 0.18667rem;
}

.hot_container .platform .list>div[data-v-d06787cb],
.hot_container .popular .list>div[data-v-d06787cb] {
    width: 2.21333rem;
}

.hot_container .platform .list .item[data-v-d06787cb],
.hot_container .popular .list .item[data-v-d06787cb] {
    position: relative;
    width: 2.21333rem;
    height: 2.21333rem;
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    box-shadow: var(--BoxShadowColor-9), var(--BoxShadowColor-20);
    border-radius: 0.21333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.16rem;
}

.hot_container .platform .list .item img[data-v-d06787cb],
.hot_container .popular .list .item img[data-v-d06787cb] {
    width: 2rem;
    height: 2rem;
    border-radius: 0.21333rem;
}

.hot_container .platform .list .item .hot_bage[data-v-d06787cb],
.hot_container .popular .list .item .hot_bage[data-v-d06787cb] {
    position: absolute;
    right: -0.08rem;
    top: -0.10667rem;
    width: 0.50667rem;
    height: 0.48rem;
}

.hot_container .platform .list .win-odds[data-v-d06787cb],
.hot_container .popular .list .win-odds[data-v-d06787cb] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 0.48rem;
    background: var(--bg_color_L2);
    color: var(--text_color_L1);
    width: 100%;
    border-radius: 0.13333rem;
    font-size: 0.29333rem;
    overflow: hidden;
    margin-top: 0.08rem;
    margin-bottom: 0.13333rem;
    position: relative;
}

.hot_container .platform .list .win-odds span[data-v-d06787cb],
.hot_container .popular .list .win-odds span[data-v-d06787cb] {
    position: relative;
    z-index: 1;
    display: block;
    height: 100%;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    line-height: 0.53333rem;
    color: var(--darkTextW, var(--text_color_L1));
}

.hot_container .platform .list .win-odds span[data-v-d06787cb]:first-child,
.hot_container .popular .list .win-odds span[data-v-d06787cb]:first-child {
    padding-left: 0.13333rem;
}

.hot_container .platform .list .win-odds span[data-v-d06787cb]:last-child,
.hot_container .popular .list .win-odds span[data-v-d06787cb]:last-child {
    text-align: right;
    padding-right: 0.13333rem;
}

.hot_container .platform .list .win-odds .win-p[data-v-d06787cb],
.hot_container .popular .list .win-odds .win-p[data-v-d06787cb] {
    background: var(--darkLight, var(--main-color));
    position: absolute;
    left: 0;
    height: 100%;
}

html:lang(ar) .hot_container .platform .list .win-odds .win-p[data-v-d06787cb],
html:lang(ar) .hot_container .popular .list .win-odds .win-p[data-v-d06787cb] {
    left: unset;
    right: 0;
}

.hot_container .pupularAll .list>div[data-v-d06787cb] {
    width: 2.88rem;
}

.hot_container .pupularAll .list .item[data-v-d06787cb] {
    width: 2.88rem;
    height: 2.88rem;
}

.hot_container .pupularAll .list .item img[data-v-d06787cb] {
    width: 2.66667rem;
    height: 2.66667rem;
}

.hot_container .look_all[data-v-d06787cb] {
    width: 100%;
    height: 1.06667rem;
    border: 0.01333rem solid var(--main-color);
    border-radius: 0.53333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background-color: var(--bg_color_L2);
    font-size: 0.34667rem;
    color: var(--main-color);
}

.hot_container .look_all img[data-v-d06787cb] {
    width: 0.64rem;
    height: 0.64rem;
    margin-right: 0.18667rem;
}

.gameRec[data-v-d06787cb],
.hotGames[data-v-d06787cb] {
    width: 0.48rem;
    height: 0.48rem;
    margin-right: 0.16rem;
}

[data-v-d06787cb] .hotGames g path {
    fill: var(--colorText-26);
}

.van-toast[data-v-860d7030] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-860d7030] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-860d7030] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-860d7030] {
    height: 80%;
}

.minGame_container[data-v-860d7030] {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 0.45333rem;
    margin-bottom: 0.4rem;
}

.onlineGamesItem[data-v-860d7030] {
    width: 3.25333rem;
    height: 3.25333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background: var(--main_gradient-color2);
    grid-gap: 0.18667rem;
}

.onlineGamesItem .fish_img[data-v-860d7030] {
    width: 3.2rem;
    height: 3.2rem;
}

.onlineGamesItem .min_game_img[data-v-860d7030] {
    width: 3.25333rem;
    height: 3.25333rem;
}

.all_game[data-v-860d7030] {
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 0.34667rem;
}

.all_game .onlineGamesItem[data-v-860d7030] {
    width: 2.88rem;
    height: 2.88rem;
    border-radius: 0.26667rem;
}

.all_game .onlineGamesItem .fish_img[data-v-860d7030] {
    width: 2.82667rem;
    height: 2.82667rem;
    border-radius: 0.26667rem;
}

.all_game .onlineGamesItem .min_game_img[data-v-860d7030] {
    width: 2.88rem;
    height: 2.88rem;
}

.van-toast[data-v-acaadf81] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-acaadf81] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-acaadf81] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-acaadf81] {
    height: 80%;
}

.lotterySlotItem[data-v-acaadf81] {
    position: relative;
    width: 100%;
    height: 2.26667rem;
    text-align: end;
    background: var(--bg_color_L3);
    margin-bottom: 0.26667rem;
    border-radius: 0.53333rem;
}

.lotterySlotItem img[data-v-acaadf81] {
    height: 100%;
}

.lotterySlotItem span[data-v-acaadf81] {
    position: absolute;
    top: 0.26667rem;
    left: 0.4rem;
    color: var(--text_color_L1);
    white-space: break-spaces;
    font-weight: 700;
    font-size: 0.46667rem;
}

.lotterySlotItem h4[data-v-acaadf81] {
    color: var(--text_color_L2);
    font-weight: 400;
    font-size: 0.29333rem;
    position: absolute;
    bottom: 0.26667rem;
    left: 0.4rem;
    white-space: pre-wrap;
    text-align: left;
    line-height: 0.46667rem;
    opacity: 0.7;
}

.van-toast[data-v-1153e4fd] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-1153e4fd] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-1153e4fd] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-1153e4fd] {
    height: 80%;
}

.lotterySlotItem__container[data-v-1153e4fd] {
    width: 100%;
    height: -webkit-fit-content;
    height: fit-content;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    color: var(--textW);
    margin-bottom: 0.26667rem;
    position: relative;
    border-radius: 0.10667rem;
    overflow: hidden;
}

.lotterySlotItem__container .title[data-v-1153e4fd] {
    width: 100%;
    position: absolute;
    z-index: 2;
    bottom: 0;
    left: 0;
    border-radius: 0.10667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    padding-bottom: 0.08rem;
}

.lotterySlotItem__container .title .tit[data-v-1153e4fd] {
    text-align: center;
    font-size: 0.29333rem;
}

.lotterySlotItem__container .game_img[data-v-1153e4fd] {
    width: 100%;
    height: auto;
    object-fit: contain;
    position: relative;
    top: 0;
    left: 0;
    z-index: 1;
}

.van-toast[data-v-54337c48] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-54337c48] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-54337c48] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-54337c48] {
    height: 80%;
}

.onlineGamesItem__container[data-v-54337c48] {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 0.21333rem;
    margin-bottom: 0.82667rem;
}

.onlineGamesItem__container .item[data-v-54337c48] {
    width: 3.36rem;
    height: 4.26667rem;
    background: var(--main_gradient-color2);
    border-radius: 0.26667rem;
}

.onlineGamesItem__container .item .gameImg[data-v-54337c48] {
    width: 3.36rem;
    height: 4.26667rem;
    border-radius: 0.26667rem;
}

.allGame[data-v-54337c48] {
    grid-template-columns: repeat(3, 1fr);
}

.allGame .item[data-v-54337c48],
.allGame .item .gameImg[data-v-54337c48] {
    width: 2.96rem;
    height: 3.73333rem;
}

.van-toast[data-v-0d36c546] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-0d36c546] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-0d36c546] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-0d36c546] {
    height: 80%;
}

.WinRate[data-v-0d36c546] {
    width: 6.96rem;
    height: 1.70667rem;
    margin-bottom: 0.4rem;
}

.WinRate img[data-v-0d36c546] {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.van-toast[data-v-1b7d97f8] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-1b7d97f8] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-1b7d97f8] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-1b7d97f8] {
    height: 80%;
}

.slot_list .slot_item[data-v-1b7d97f8] {
    margin-bottom: 0.61333rem;
}

.slot_list .slot_item .slot_title[data-v-1b7d97f8] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    font-size: 0.4rem;
    font-weight: 700;
    color: var(--darkTextW, var(--text_color_L1));
    margin-bottom: 0.21333rem;
}

.slot_list .slot_item .slot_title svg[data-v-1b7d97f8] {
    height: 0.64rem;
    font-size: 0.90667rem;
    vertical-align: middle;
    color: var(--main-color);
}

.slot_list .slot_item .slot_img_box[data-v-1b7d97f8] {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 0.24rem;
    margin-bottom: 0.4rem;
}

.slot_list .slot_item .slot_img_box img[data-v-1b7d97f8] {
    width: 2.90667rem;
    height: 3.92rem;
    border-radius: 0.10667rem;
}

.slot_list .slot_item .all_slot[data-v-1b7d97f8] {
    margin: auto;
    width: 3.84rem;
    height: 0.8rem;
    background: var(--main_gradient-color);
    box-shadow: 0 0.04rem 0.08rem 0.01333rem #00000029;
    border-radius: 0.4rem;
    line-height: 0.8rem;
    color: #fff;
    text-align: center;
    font-size: 0.32rem;
}

.van-toast[data-v-df3cc798] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-df3cc798] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-df3cc798] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-df3cc798] {
    height: 80%;
}

.gameListGrid__container[data-v-df3cc798] {
    position: -webkit-sticky;
    position: sticky;
    top: 2.45333rem;
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: inline-flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    width: 7.3852rem;
    height: -webkit-min-content;
    height: min-content;
    padding-left: 0.26667rem;
}

.gameListGrid__container-gameRec[data-v-df3cc798] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.22173rem;
    font-size: 0.32rem;
    font-weight: 700;
}

.gameListGrid__container-gameRec svg[data-v-df3cc798] {
    width: 0.48387rem;
    height: 0.48387rem;
    margin-right: 0.11147rem;
}

.gameListGrid__container-gameRec[data-v-df3cc798] .hotGames g path {
    fill: var(--colorText-26);
}

.gameListGrid__container-wrapper[data-v-df3cc798] {
    display: grid;
    gap: 0.2rem 0.26667rem;
    padding-left: 0.13333rem;
}

.gameListGrid__container-wrapper__item[data-v-df3cc798] {
    position: relative;
    width: 3.28rem;
    height: 2.13333rem;
}

.gameListGrid__container-wrapper__item img[data-v-df3cc798] {
    width: 100%;
    height: 100%;
}

.gameListGrid__container-wrapper__item .hotBadge[data-v-df3cc798] {
    position: absolute;
    top: -0.10667rem;
    right: -0.10667rem;
    width: 0.51653rem;
    height: 0.48013rem;
}

.gameListGrid__container-wrapper__item.hot[data-v-df3cc798] {
    width: 2.21747rem;
    height: 2.21747rem;
}

.look_all[data-v-df3cc798] {
    width: 100%;
    height: 1.06667rem;
    border: 0.01333rem solid var(--main-color);
    border-radius: 0.53333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background-color: var(--bg_color_L2);
    font-size: 0.34667rem;
    color: var(--main-color);
}

.look_all img[data-v-df3cc798] {
    width: 0.64rem;
    height: 0.64rem;
    margin-right: 0.18667rem;
}

.all_container[data-v-df3cc798] {
    width: 100%;
    padding-left: 0;
}

.skeleton_hot[data-v-df3cc798] {
    width: 100%;
    height: 100%;
    margin-right: 0.16rem;
}

.skeleton_hot .hot_tit[data-v-df3cc798] {
    width: 100%;
    height: 0.48rem;
    margin-bottom: 0.21333rem;
}

.skeleton_hot .hot_list[data-v-df3cc798] {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 0.18667rem;
    margin-bottom: 0.34667rem;
}

.skeleton_hot .hot_list div[data-v-df3cc798] {
    width: 2.21333rem;
    height: 2.21333rem;
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    box-shadow: var(--BoxShadowColor-9), var(--BoxShadowColor-20);
    border-radius: 0.21333rem;
    margin-bottom: 0.16rem;
}

.skeleton_other[data-v-df3cc798] {
    width: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.skeleton_other div[data-v-df3cc798] {
    width: 100%;
    height: 2.66667rem;
    border-radius: 0.53333rem;
    background: var(--main_gradient-color2);
    box-shadow: var(--BoxShadowColor-20), var(--BoxShadowColor-25);
    margin-bottom: 0.26667rem;
}

.skeleton_slot[data-v-df3cc798] {
    width: 100%;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 0.21333rem;
}

.skeleton_slot div[data-v-df3cc798] {
    width: 3.36rem;
    height: 4.26667rem;
    background: var(--main_gradient-color2);
    box-shadow: var(--BoxShadowColor-9), var(--BoxShadowColor-20);
    border-radius: 0.26667rem;
}

.skeleton_flash[data-v-df3cc798] {
    width: 100%;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 0.45333rem;
    margin-bottom: 0.4rem;
}

.skeleton_flash div[data-v-df3cc798] {
    width: 3.25333rem;
    height: 3.25333rem;
    background: var(--main_gradient-color2);
    box-shadow: var(--BoxShadowColor-9), var(--BoxShadowColor-20);
    border-radius: 0.26667rem;
}

.otherGame[data-v-df3cc798] {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 0.26667rem;
}

[data-v-df3cc798] .van-skeleton {
    padding: 0;
}

.van-toast[data-v-e4c17073] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-e4c17073] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-e4c17073] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-e4c17073] {
    height: 80%;
}

.gamesList__container[data-v-e4c17073] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    padding: 0 0.32rem;
}

.gamesList__container-title[data-v-e4c17073] {
    margin-top: 0.34667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.32rem;
    color: var(--darkTextW, var(--text_color_L1));
    font-size: 0.4rem;
    font-weight: 600;
}

.gamesList__container-title[data-v-e4c17073]:before {
    content: "";
    display: block;
    width: 0.08rem;
    height: 0.4rem;
    background: var(--darkLight2, var(--main-color));
    margin-right: 0.13333rem;
}

.gamesList__container-list[data-v-e4c17073] {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    justify-items: center;
    gap: 0.41333rem 0.26667rem;
}

.gamesList__container-list__item[data-v-e4c17073] {
    width: 2.88rem;
    min-height: 2.13333rem;
    max-height: 3.46667rem;
    background: var(--main_gradient-color2);
    border-radius: 0.53333rem;
    position: relative;
}

.gamesList__container-list__item .lottery_text[data-v-e4c17073] {
    color: var(--textW);
    font-size: 0.4rem;
    font-weight: 9.33333rem;
    position: absolute;
    top: 0.37333rem;
    left: 0.26667rem;
}

html:lang(ar) .gamesList__container-list__item .lottery_text[data-v-e4c17073] {
    left: unset;
    right: 0.26667rem;
}

.gamesList__container-list__item .item_default[data-v-e4c17073] {
    width: 100%;
    height: 100%;
    border-radius: 0.53333rem;
    object-fit: fill !important;
}

.gamesList__container-list__item .item_img[data-v-e4c17073] {
    height: 2rem;
    object-fit: cover;
    position: absolute;
    border-radius: 0.53333rem;
    left: 0.26667rem;
}

html:lang(ar) .gamesList__container-list__item .item_img[data-v-e4c17073] {
    left: unset;
    right: 0.26667rem;
}

.gamesList__container-list__item .lottery_img[data-v-e4c17073] {
    max-width: 2rem;
    height: 2rem;
    object-fit: cover;
    position: absolute;
    border-radius: 0.53333rem;
    right: 0.26667rem;
}

.gamesList__container-list__item .logo_img[data-v-e4c17073] {
    position: absolute;
    top: 0.13333rem;
    right: 0.37333rem;
    width: 1.30667rem;
}

.gamesList__container-other[data-v-e4c17073] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-top: 0.26667rem;
    color: var(--text_color_L2);
    font-size: 0.32rem;
    font-weight: 500;
    cursor: pointer;
}

.gamesList__container-other__item[data-v-e4c17073] {
    width: 100%;
    height: 2.66667rem;
}

.fun-tab-item {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.fun-tab-item__wrap {
    position: relative;
}

.fun-tab-item__badge {
    position: absolute;
    top: 0.05333rem;
    right: -0.13333rem;
    padding: 0 0.05333rem;
    min-width: 0.10667rem;
    height: 0.18667rem;
    font-size: 0.12rem;
    line-height: 0.18667rem;
    color: #fff;
    background: #ff411c;
    white-space: nowrap;
    border-radius: 1.33333rem;
    -webkit-transform: translate(50%, -50%);
    transform: translate(50%, -50%);
    text-align: center;
}

.fun-tab-bar-wrap {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: nowrap;
    flex-wrap: nowrap;
    -webkit-box-align: stretch;
    -webkit-align-items: stretch;
    align-items: stretch;
    min-height: 0.66667rem;
    background: var(--bg_color_L2);
}

.fun-tab-bar .fun-tab-item {
    -webkit-box-flex: 1;
    -webkit-flex: 1 1;
    flex: 1 1;
    font-size: 0.16rem;
}

.fun-tab-bar .fun-tab-item__badge {
    top: 0.02667rem;
    right: 0;
}

.fun-tabs {
    overflow: hidden;
    position: relative;
    width: 100%;
    background: var(--bg_color_L1);
}

.fun-tabs__tab-list {
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: nowrap;
    flex-wrap: nowrap;
    min-width: 100%;
    width: -webkit-min-content;
    width: min-content;
}

.fun-tabs__active-line {
    position: absolute;
    bottom: 0.04rem;
    left: 0;
    width: 0.4rem;
    height: 0.04rem;
    border-radius: 0.05333rem;
}

.fun-tabs .fun-tab-item {
    padding: 0.13333rem 0.05333rem;
    font-size: 0.18667rem;
    text-align: center;
    white-space: nowrap;
}

.van-toast[data-v-0a9bf0c5] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-0a9bf0c5] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-0a9bf0c5] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-0a9bf0c5] {
    height: 80%;
}

.allGames__container[data-v-0a9bf0c5] {
    overflow: hidden;
}

.allGames__container .alGames__container-sticky[data-v-0a9bf0c5] {
    padding: 0 0.32rem;
}

.allGames__container[data-v-0a9bf0c5] .van-nav-bar {
    background-color: var(--bg_color_L2);
}

.allGames__container[data-v-0a9bf0c5] .van-nav-bar .van-nav-bar__content .van-nav-bar__left .van-icon {
    color: var(--text_color_L1);
}

.allGames__container .tabs[data-v-0a9bf0c5] {
    background: transparent;
}

.allGames__container .tab_item[data-v-0a9bf0c5] {
    width: 2.53333rem;
    height: 1.33333rem;
    margin-inline: 0.06667rem;
    padding: 0;
    color: var(--text_color_L2) !important;
    border-radius: 0.13333rem;
    background: var(--bg_color_L2);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.allGames__container .tab_item img[data-v-0a9bf0c5] {
    height: 0.66667rem;
}

.allGames__container .tab_item span[data-v-0a9bf0c5] {
    font-size: 0.32rem;
}

.allGames__container .tab_active[data-v-0a9bf0c5] {
    color: var(--text_color_L4) !important;
    background: var(--main_gradient-color);
}

.allGames__container[data-v-0a9bf0c5] .fun-tabs .fun-tab-item {
    padding: 0.18667rem 0;
}

.allGames__container-tabBar[data-v-0a9bf0c5] {
    padding-inline: 0.32rem;
}

.allGames__container-tabBar[data-v-0a9bf0c5] .van-tabs__nav--card {
    height: 1.86667rem;
    margin: 0;
}

.allGames__container-tabBar[data-v-0a9bf0c5] .van-tabs__nav--card .van-tab--card {
    width: 2.53333rem;
    height: 1.33333rem;
    margin-inline: 0.06667rem;
    padding: 0;
    color: var(--text_color_L2) !important;
    border-radius: 0.13333rem;
    background: var(--bgDark-2, var(--bg_color_L2));
    box-shadow: var(--BoxShadowColor-42);
}

.allGames__container-tabBar[data-v-0a9bf0c5] .van-tabs__nav--card .van-tab--card>span {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    width: 100%;
    height: 100%;
}

.allGames__container-tabBar[data-v-0a9bf0c5] .van-tabs__nav--card .van-tab--card>span img {
    width: 0.66667rem;
    height: auto;
}

.allGames__container-tabBar[data-v-0a9bf0c5] .van-tabs__nav--card .van-tab--card>span span {
    font-size: 0.32rem;
}

.allGames__container-tabBar[data-v-0a9bf0c5] .van-tabs__nav--card .van-tab--card.van-tab--active {
    color: var(--textW) !important;
    background: var(--main_gradient-color);
    box-shadow: var(--BoxShadowColor-42);
}

.allGames__container-list[data-v-0a9bf0c5] {
    height: calc(100vh - 3.09334rem);
    overflow: auto;
}

.van-toast[data-v-22e2ba37] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-22e2ba37] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-22e2ba37] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-22e2ba37] {
    height: 80%;
}

.lotteryGamesList__container[data-v-22e2ba37] {
    width: 4.34667rem;
    height: 2.13333rem;
}

.lotteryGamesList__container-item[data-v-22e2ba37] {
    width: 100%;
    height: 100%;
    position: relative;
}

.lotteryGamesList__container-item img[data-v-22e2ba37] {
    width: 100%;
}

.lotteryGamesList__container-item__time[data-v-22e2ba37] {
    position: absolute;
    bottom: 0.4rem;
    left: 0.53333rem;
    width: 1.17333rem;
    height: 0.48rem;
    color: #ff6e68;
    font-size: 0.32rem;
    text-align: center;
    line-height: 0.48rem;
    border-radius: 9rem;
    background: var(--bg_color_L2);
}

html:lang(ar) .lotteryGamesList__container-item__time[data-v-22e2ba37] {
    right: 0.53333rem;
    left: unset;
}

.van-toast[data-v-147ae92c] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-147ae92c] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-147ae92c] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-147ae92c] {
    height: 80%;
}

.lotteryGames__container[data-v-147ae92c] {
    overflow: hidden;
}

.lotteryGames__container[data-v-147ae92c] .van-nav-bar {
    background-color: var(--bg_color_L2);
}

.lotteryGames__container[data-v-147ae92c] .van-nav-bar .van-nav-bar__content .van-nav-bar__left .van-icon {
    color: var(--text_color_L1);
}

.lotteryGames__container-tabBar[data-v-147ae92c] {
    padding-inline: 0.16rem;
}

.lotteryGames__container-tabBar[data-v-147ae92c] .van-tabs__nav--card {
    height: 0.98667rem;
    margin: 0;
}

.lotteryGames__container-tabBar[data-v-147ae92c] .van-tabs__nav--card .van-tab--card {
    width: 2.53333rem;
    height: 0.8rem;
    margin-right: 0.13333rem;
    color: var(--text_color_L2) !important;
    font-size: 0.34667rem;
    border-radius: 9rem;
    background: var(--bgDark-2, var(--bg_color_L2));
    box-shadow: var(--BoxShadowColor-42);
}

.lotteryGames__container-tabBar[data-v-147ae92c] .van-tabs__nav--card .van-tab--card.van-tab--active {
    color: #fff !important;
    background: var(--main_gradient-color);
    box-shadow: var(--BoxShadowColor-42);
}

.lotteryGames__container-tabBar[data-v-147ae92c] .van-tabs__nav--card .van-tab--card:last-of-type {
    display: none;
}

.lotteryGames__container-timeTab[data-v-147ae92c] {
    padding-inline: 0.16rem;
}

.lotteryGames__container-timeTab[data-v-147ae92c] .van-tabs__nav .van-tab {
    color: var(--text_color_L2) !important;
}

.lotteryGames__container-timeTab[data-v-147ae92c] .van-tabs__nav .van-tab.van-tab--active {
    color: var(--main-color) !important;
}

.lotteryGames__container-timeTab[data-v-147ae92c] .van-tabs__nav .van-tab:last-of-type {
    display: none;
}

.lotteryGames__container-list[data-v-147ae92c] {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    justify-items: center;
    grid-auto-rows: 2.13333rem;
    height: calc(100vh - 4.05333rem);
    margin-top: 0.66667rem;
    overflow: scroll;
}

:root {
    --van-tabs-card-height: auto;
}

.van-toast[data-v-0ffc3892] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-0ffc3892] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-0ffc3892] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-0ffc3892] {
    height: 80%;
}

.onlineGames__container[data-v-0ffc3892] {
    overflow: hidden;
}

.onlineGames__container[data-v-0ffc3892] .navbar .navbar__content .navbar__content-center span {
    opacity: 1;
    -webkit-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
}

.onlineGames__container[data-v-0ffc3892] .navbar .navbar__content .navbar__content-center span.active {
    opacity: 0;
}

.onlineGames__container[data-v-0ffc3892] .navbar .navbar__content .navbar__content-center input {
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translate(0, -50%);
    transform: translateY(-50%);
    width: 0.13333rem;
    height: 0.93333rem;
    padding: 0.06667rem;
    padding: 0.2rem 0 0.2rem 1.46667rem;
    font-size: 0.37333rem;
    font-weight: 400;
    border: none;
    border-radius: 0.46667rem;
    background-color: var(--bg_color_L2);
    color: var(--text_color_L1);
    opacity: 0;
    -webkit-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
}

.onlineGames__container[data-v-0ffc3892] .navbar .navbar__content .navbar__content-center input.active {
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    width: 6.42667rem;
    opacity: 1;
}

.onlineGames__container[data-v-0ffc3892] .navbar .navbar__content .navbar__content-center input::-webkit-input-placeholder {
    color: var(--text_color_L3);
    font-size: 0.32rem;
    position: relative;
}

.onlineGames__container[data-v-0ffc3892] .navbar .navbar__content .navbar__content-center input::placeholder {
    color: var(--text_color_L3);
    font-size: 0.32rem;
    position: relative;
}

.onlineGames__container[data-v-0ffc3892] .navbar .navbar__content .navbar__content-right {
    width: 0.77333rem;
}

.onlineGames__container[data-v-0ffc3892] .navbar .navbar__content .navbar__content-right svg {
    font-size: 0.64rem;
    -webkit-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
    color: var(--main-color);
}

.onlineGames__container[data-v-0ffc3892] .navbar .navbar__content .navbar__content-right svg.active {
    -webkit-transform: translateX(-6.8rem) translateY(0.02667rem);
    transform: translate(-6.8rem) translateY(0.02667rem);
}

.onlineGames__container[data-v-0ffc3892] .navbar .navbar__content .navbar__content-right span {
    position: absolute;
    -webkit-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    line-height: 0.53333rem;
    white-space: nowrap;
    display: none;
}

.onlineGames__container[data-v-0ffc3892] .navbar .navbar__content .navbar__content-right span.active {
    display: initial;
    top: 0.13333rem;
    right: 0;
}

.onlineGames__container[data-v-0ffc3892] .fun-tabs {
    background-color: transparent;
    padding-bottom: 0.26667rem;
}

.onlineGames__container[data-v-0ffc3892] .fun-tabs .fun-tab-item {
    width: 2.93333rem;
    height: 0.8rem;
    color: var(--text_color_L2);
    text-align: center;
    font-style: normal;
    font-weight: 400;
    line-height: 0.34667rem;
    background: var(--bg_color_L2);
    margin-right: 0.26667rem;
    border-radius: 0.53333rem;
}

.onlineGames__container[data-v-0ffc3892] .fun-tabs .fun-tab-item span {
    font-size: 0.32rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    display: block;
    padding: 0 0.05333rem;
    width: 100%;
}

.onlineGames__container[data-v-0ffc3892] .fun-tabs .fun-tab-item:last-child {
    margin-right: 0;
}

.onlineGames__container[data-v-0ffc3892] .fun-tabs .fun-tab-item.activeClassName {
    background: var(--main_gradient-color);
}

.onlineGames__container[data-v-0ffc3892] .fun-tabs .fun-tab-item.activeClassName span {
    color: var(--text_color_L4) !important;
}

.onlineGames__container-tabBar[data-v-0ffc3892] {
    padding-inline: 0.32rem;
}

.onlineGames__container-tabBar[data-v-0ffc3892] .van-tabs__nav {
    padding-top: 0.37333rem;
    background: var(--bg_color_L1);
}

.onlineGames__container-tabBar[data-v-0ffc3892] .van-tabs__nav--card {
    height: 1.86667rem;
    margin: 0;
    border: none;
    background: var(--bg_color_L1);
}

.onlineGames__container-tabBar[data-v-0ffc3892] .van-tabs__nav--card .van-tab--card {
    width: 2.53333rem;
    height: 1.33333rem;
    margin-right: 0.2rem;
    padding: 0;
    color: var(--text_color_L2) !important;
    border-radius: 0.13333rem;
    background-color: var(--bg_color_L2);
    border: none;
}

.onlineGames__container-tabBar[data-v-0ffc3892] .van-tabs__nav--card .van-tab--card>span {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    width: 100%;
    height: 100%;
}

.onlineGames__container-tabBar[data-v-0ffc3892] .van-tabs__nav--card .van-tab--card>span img {
    max-height: 55%;
    max-width: 55%;
}

.onlineGames__container-tabBar[data-v-0ffc3892] .van-tabs__nav--card .van-tab--card.van-tab--active {
    color: var(--text_color_L4) !important;
    background: var(--main_gradient-color);
}

.onlineGames__container-list[data-v-0ffc3892] {
    margin: auto;
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 0.53333rem 0.26667rem;
    padding-bottom: 0.26667rem;
}

.onlineGames__container-list__item[data-v-0ffc3892] {
    width: 2.89333rem;
    height: auto;
    border-radius: 0.06667rem;
    padding-bottom: 0.26667rem;
}

.onlineGames__container-list__item img[data-v-0ffc3892] {
    width: 2.89333rem;
    height: 100%;
    object-fit: cover;
    border-radius: 0.06667rem;
}

.onlineGames__container-list__item span[data-v-0ffc3892] {
    width: 100%;
    height: 0.77333rem;
    font-size: 0.32rem;
    text-align: center;
    word-break: break-all;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    padding-inline: 0.26667rem;
    overflow: hidden;
    color: var(--text_color_L2);
}

.onlineGames__container-list.miniGames[data-v-0ffc3892] {
    height: calc(100vh - 1.6rem);
}

.onlineGames__container .gameIcon[data-v-0ffc3892] {
    width: 1.33333rem;
    height: 0.66667rem;
}

.van-toast[data-v-ffb14677] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-ffb14677] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-ffb14677] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-ffb14677] {
    height: 80%;
}

.luckyWinners__container>h1[data-v-ffb14677] {
    position: relative;
    margin-bottom: 0.34667rem;
    padding-left: 0.26667rem;
    font-size: 0.48rem;
    font-weight: 700;
    color: var(--darkTextW, var(--text_color_L1));
}

.luckyWinners__container>h1[data-v-ffb14677]:before {
    content: "";
    position: absolute;
    top: 50%;
    left: 0;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    width: 0.08rem;
    height: 0.4rem;
    background: var(--bgcolor-65);
}

.luckyWinners__container-wrapper[data-v-ffb14677] {
    height: 8.66667rem;
    overflow: hidden;
}

.luckyWinners__container-wrapper__item[data-v-ffb14677] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 100%;
    height: 1.6rem;
    margin-bottom: 0.13333rem;
    padding: 0.26667rem 0.24rem;
    border-radius: 0.13333rem;
    background: var(--darkBg, var(--bg_color_L2));
}

.luckyWinners__container-wrapper__item-img[data-v-ffb14677] {
    margin-right: 0.17333rem;
}

.luckyWinners__container-wrapper__item-img img[data-v-ffb14677] {
    width: 1.06667rem;
    height: 1.06667rem;
    border-radius: 50%;
}

.luckyWinners__container-wrapper__item-info[data-v-ffb14677] {
    width: 2.24rem;
    margin-right: 0.21333rem;
}

.luckyWinners__container-wrapper__item-info h1[data-v-ffb14677] {
    color: var(--darkTextW, var(--text_color_L1));
    font-size: 0.32rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
}

.luckyWinners__container-wrapper__item-info span[data-v-ffb14677] {
    color: var(--text_color_L2);
    font-size: 0.29333rem;
}

.luckyWinners__container-wrapper__item-winType[data-v-ffb14677] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 1.68rem;
    height: 1.09333rem;
    margin-right: 0.22667rem;
    position: relative;
}

.luckyWinners__container-wrapper__item-winType img[data-v-ffb14677] {
    width: 100%;
    height: 100%;
    background: var(--main_gradient-color2);
    border-radius: 0.21333rem;
    box-shadow: var(--BoxShadowColor-20);
    object-fit: cover;
}

.luckyWinners__container-wrapper__item-winType span[data-v-ffb14677] {
    display: inline-block;
    width: 0.74667rem;
    font-weight: 700;
    font-size: 0.21333rem;
    color: #fff;
    position: absolute;
    left: 0.2rem;
    top: 0.16rem;
    word-break: keep-all;
}

.luckyWinners__container-wrapper__item-winAmount[data-v-ffb14677] {
    text-align: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.luckyWinners__container-wrapper__item-winAmount h1[data-v-ffb14677] {
    color: var(--text_color_L1);
    font-size: 0.34667rem;
    font-weight: 600;
    margin-bottom: 0.13333rem;
}

.luckyWinners__container-wrapper__item-winAmount span[data-v-ffb14677] {
    color: var(--text_color_L2);
    font-size: 0.32rem;
}

.van-toast[data-v-74b37c48] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-74b37c48] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-74b37c48] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-74b37c48] {
    height: 80%;
}

.mainContainer[data-v-74b37c48] {
    height: auto;
    margin: 0.13333rem;
}

.mainContainer_profitContainer[data-v-74b37c48] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    height: 1.68rem;
    border-radius: 0.13333rem;
    background: #22272f;
    margin-top: 0.13333rem;
}

.mainContainer_profitContainer_medal[data-v-74b37c48] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 1.2rem;
    height: 1.38667rem;
    margin-left: 0.2rem;
}

.mainContainer_profitContainer_medal img[data-v-74b37c48] {
    width: 0.96rem;
    height: 1.33333rem;
}

.mainContainer_profitContainer_medal span[data-v-74b37c48] {
    margin-top: -0.13333rem;
    width: 0.96rem;
    height: 0.96rem;
}

.mainContainer_profitContainer_medal .numberMedal[data-v-74b37c48] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    width: 0.96rem;
    height: 0.96rem;
    background: url(./imgs/MedalNumber.png) no-repeat center center;
    margin-top: 0.2rem;
    color: #7b8fae;
    font-family: Jost;
    font-size: 0.48rem;
    font-weight: 600;
}

.mainContainer_profitContainer_img[data-v-74b37c48] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-left: 0.26667rem;
    width: 1.17333rem;
    height: 1.17333rem;
    border-radius: 50%;
    border: 0.04rem solid rgba(215, 143, 67, 0.1);
}

.mainContainer_profitContainer_img img[data-v-74b37c48] {
    padding: 0.06667rem;
    width: 1.17333rem;
    height: 1.17333rem;
    border-radius: 50%;
}

.mainContainer_profitContainer_title[data-v-74b37c48] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    height: 1.33333rem;
    padding: 0.2rem;
    color: #dce0e6;
    font-family: Inter;
    font-size: 0.34667rem;
    font-weight: 500;
    letter-spacing: -0.00693rem;
}

.mainContainer_profitContainer_amount[data-v-74b37c48] {
    padding: 0.2rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    width: 100%;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
    color: var(--Red-400, #fea800);
    font-size: 0.37333rem;
    font-weight: 500;
    font-family: Inter;
}

.van-toast[data-v-e152b4a0] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-e152b4a0] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-e152b4a0] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-e152b4a0] {
    height: 80%;
}

.originalmainContainer[data-v-e152b4a0] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 0.96rem;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0 0.21333rem;
    background: #141b26;
}

.originalmainContainer .backSvg[data-v-e152b4a0] {
    background-image: url(/assets/svg/backButton-eadf8686.svg);
    background-repeat: no-repeat;
    background-position: center;
    width: 1.12rem;
    height: 100%;
}

.originalmainContainer_title[data-v-e152b4a0] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.13333rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    letter-spacing: -0.0048rem;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.GameContainer[data-v-e152b4a0] {
    height: auto;
    padding: 0.26667rem;
}

.GameContainer_games[data-v-e152b4a0] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    height: auto;
    gap: 0.21333rem;
}

.GameContainer_games>img[data-v-e152b4a0] {
    width: calc((100% - 0.42667rem) / 3);
    height: auto;
}

.WinningContainer[data-v-e152b4a0] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.26667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: -0.0048rem;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    margin-top: -0.2rem;
}

.WinningContainer[data-v-e152b4a0]:before {
    content: "";
    display: block;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    width: 0.33333rem;
    height: 0.34667rem;
    background-image: url(/assets/svg/Group20225-a3b6092b.svg);
    background-position: left;
    background-repeat: no-repeat;
}

.profitRanking[data-v-e152b4a0] {
    padding: 0.09333rem;
    border-radius: 0.16rem;
    background: #141b26;
    -webkit-backdrop-filter: blur(1.09333rem);
    backdrop-filter: blur(1.09333rem);
}

.van-toast[data-v-9d069a04] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-9d069a04] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-9d069a04] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-9d069a04] {
    height: 80%;
}

.originalmainContainer[data-v-9d069a04] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 0.96rem;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0 0.21333rem;
    background: #141b26;
}

.originalmainContainer .backSvg[data-v-9d069a04] {
    background-image: url(/assets/svg/backButton-eadf8686.svg);
    background-repeat: no-repeat;
    background-position: center;
    width: 1.12rem;
    height: 100%;
}

.originalmainContainer_title[data-v-9d069a04] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.13333rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    letter-spacing: -0.0048rem;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.GameContainer[data-v-9d069a04] {
    height: auto;
    padding: 0.26667rem;
}

.GameContainer_games[data-v-9d069a04] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    height: auto;
    gap: 0.21333rem;
}

.GameContainer_games>img[data-v-9d069a04] {
    width: calc((100% - 0.42667rem) / 3);
    height: auto;
}

.WinningContainer[data-v-9d069a04] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.26667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: -0.0048rem;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
}

.WinningContainer[data-v-9d069a04]:before {
    content: "";
    display: block;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    width: 0.33333rem;
    height: 0.34667rem;
    background-image: url(/assets/svg/Group20225-a3b6092b.svg);
    background-position: left;
    background-repeat: no-repeat;
}

.Winningdata[data-v-9d069a04] {
    padding: 0.22667rem;
}

.profitRanking[data-v-9d069a04] {
    padding: 0.09333rem;
    border-radius: 0.16rem;
    background: #141b26;
    -webkit-backdrop-filter: blur(1.09333rem);
    backdrop-filter: blur(1.09333rem);
}

.van-toast[data-v-50e7ebdb] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-50e7ebdb] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-50e7ebdb] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-50e7ebdb] {
    height: 80%;
}

.fish_game[data-v-50e7ebdb] {
    padding: 0.32rem;
}

.fish_game .fish_list[data-v-50e7ebdb] {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 0.32rem;
    margin-bottom: 0.82667rem;
}

.fish_game .fish_list .gameImg[data-v-50e7ebdb] {
    width: 2.88rem;
    height: 2.88rem;
}

.van-toast[data-v-3490866d] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-3490866d] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-3490866d] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-3490866d] {
    height: 80%;
}

.originalmainContainer[data-v-3490866d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 0.96rem;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0 0.21333rem;
    background: #141b26;
}

.originalmainContainer .backSvg[data-v-3490866d] {
    background-image: url(/assets/svg/backButton-eadf8686.svg);
    background-repeat: no-repeat;
    background-position: center;
    width: 1.12rem;
    height: 100%;
}

.originalmainContainer_title[data-v-3490866d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.13333rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    letter-spacing: -0.0048rem;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.GameContainer[data-v-3490866d] {
    height: auto;
    padding: 0.26667rem;
}

.GameContainer_games[data-v-3490866d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    height: auto;
    gap: 0.21333rem;
}

.GameContainer_games>img[data-v-3490866d] {
    width: calc((100% - 0.42667rem) / 3);
    height: auto;
}

.WinningContainer[data-v-3490866d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.26667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: -0.0048rem;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    margin-top: -0.2rem;
}

.WinningContainer[data-v-3490866d]:before {
    content: "";
    display: block;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    width: 0.33333rem;
    height: 0.34667rem;
    background-image: url(/assets/svg/Group20225-a3b6092b.svg);
    background-position: left;
    background-repeat: no-repeat;
}

.Winningdata[data-v-3490866d] {
    padding: 0.22667rem;
}

.profitRanking[data-v-3490866d] {
    padding: 0.09333rem;
    border-radius: 0.16rem;
    background: #141b26;
    -webkit-backdrop-filter: blur(1.09333rem);
    backdrop-filter: blur(1.09333rem);
}

.van-toast[data-v-127acf74] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-127acf74] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-127acf74] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-127acf74] {
    height: 80%;
}

.originalmainContainer[data-v-127acf74] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 0.96rem;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0 0.21333rem;
    background: #141b26;
}

.originalmainContainer .backSvg[data-v-127acf74] {
    background-image: url(/assets/svg/backButton-eadf8686.svg);
    background-repeat: no-repeat;
    background-position: center;
    width: 1.12rem;
    height: 100%;
}

.originalmainContainer_title[data-v-127acf74] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.13333rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    letter-spacing: -0.0048rem;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.GameContainer[data-v-127acf74] {
    height: auto;
    padding: 0.26667rem;
}

.GameContainer_games[data-v-127acf74] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    height: auto;
    gap: 0.21333rem;
}

.GameContainer_games>img[data-v-127acf74] {
    width: calc((100% - 0.42667rem) / 3);
    height: auto;
}

.WinningContainer[data-v-127acf74] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.26667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: -0.0048rem;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    margin-top: -0.2rem;
}

.WinningContainer[data-v-127acf74]:before {
    content: "";
    display: block;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    width: 0.33333rem;
    height: 0.34667rem;
    background-image: url(/assets/svg/Group20225-a3b6092b.svg);
    background-position: left;
    background-repeat: no-repeat;
}

.van-toast[data-v-b8ad632c] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-b8ad632c] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-b8ad632c] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-b8ad632c] {
    height: 80%;
}

.topContainer[data-v-b8ad632c] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 0.96rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0.14667rem 0.21333rem;
    background: var(--Card, #141b26);
}

.topContainer .backSvg[data-v-b8ad632c] {
    background-image: url(/assets/svg/backButton-eadf8686.svg);
    background-repeat: no-repeat;
    background-position: center;
    width: 1.12rem;
    height: 100%;
}

.topContainer .title[data-v-b8ad632c] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.13333rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    letter-spacing: -0.0048rem;
    background: var( --Text-effects, linear-gradient(180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%));
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.lotteryBanner[data-v-b8ad632c] {
    height: 4.16rem;
    padding: 0.22667rem;
}

.lotteryBanner .banner[data-v-b8ad632c] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
    height: 4rem;
    border-radius: 0.16rem;
    background: url(/assets/png/LotteryBanner-2edb1124.png), lightgray 0 -0.11107rem/100% 99.782% no-repeat;
}

.lotteryBanner .banner .insideBanner[data-v-b8ad632c] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    height: 1.36rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    background: rgba(98, 47, 0, 0.7);
    -webkit-backdrop-filter: blur(0.05333rem);
    backdrop-filter: blur(0.05333rem);
    border-bottom-left-radius: 0.16rem;
    border-bottom-right-radius: 0.16rem;
}

.lotteryBanner .banner .insideBanner .Firstbanner[data-v-b8ad632c] {
    height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    gap: 0.2rem;
    margin-left: 0.16rem;
}

.lotteryBanner .banner .insideBanner .Firstbanner .line[data-v-b8ad632c] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    border-radius: 0.42667rem;
    background: #ffcb9a;
    width: 0.08rem;
    margin-top: 0.06667rem;
    height: 0.33333rem;
}

.lotteryBanner .banner .insideBanner .Firstbanner .insideFirstbanner[data-v-b8ad632c] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    height: 1.06667rem;
    color: var(--Light-blue-0, #fff);
    font-family: Inter;
    font-size: 0.42667rem;
    font-weight: 600;
    line-height: 0.48rem;
}

.lotteryBanner .banner .insideBanner .Firstbanner .insideFirstbanner span[data-v-b8ad632c]:last-of-type {
    color: var(--Light-blue-0, #fff);
    font-family: Inter;
    font-size: 0.32rem;
    font-weight: 400;
    line-height: 0.4rem;
}

.lotteryBanner .banner .insideBanner .Lastbanner[data-v-b8ad632c] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: start;
    -webkit-align-items: flex-start;
    align-items: flex-start;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-right: 0.26667rem;
    gap: 0.08rem;
}

.lotteryBanner .banner .insideBanner .Lastbanner .btnLottery[data-v-b8ad632c] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.16rem 0.26667rem;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    gap: 0.13333rem;
    border-radius: 0.16rem;
    background: #ffe1d4;
    color: #723b23;
    font-family: Inter;
    font-size: 0.32rem;
    font-style: italic;
    font-weight: 600;
    text-align: center;
}

.MainContainer[data-v-b8ad632c] {
    padding: 0.26667rem;
    margin-top: 0.13333rem;
}

.MainContainer .insideMainContainer[data-v-b8ad632c] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    height: 2.77333rem;
    margin-bottom: -0.46667rem;
    background: var(--Card, #141b26);
    border-radius: 0.21333rem;
    overflow: hidden;
}

.MainContainer .insideMainContainer img[data-v-b8ad632c] {
    padding: 0.13333rem;
    height: 100%;
    border-radius: 0.10667rem;
}

.MainContainer .insideMainContainer .Typo[data-v-b8ad632c] {
    width: 8rem;
    max-width: 8rem;
    padding: 0.2rem 0.2rem 0.02667rem;
}

.MainContainer .insideMainContainer .Typo span[data-v-b8ad632c]:first-of-type {
    color: var(--Grey-100, #cfcfcf);
    font-size: 0.4rem;
    font-family: Inter;
    font-weight: 600;
}

.MainContainer .insideMainContainer .Typo pre[data-v-b8ad632c] {
    margin-top: 0.13333rem;
    color: #fff;
    font-family: Inter;
    font-weight: 400;
    line-height: 0.45333rem;
}

.MainContainer .insideMainContainer .Typo p[data-v-b8ad632c] {
    color: var(--Red-400, #fea800);
    font-size: 0.32rem;
    font-weight: 400;
    line-height: 0.22667rem;
}

.MainContainer .insideMainContainer .Typo span[data-v-b8ad632c]:last-of-type {
    color: var(--Darker-text, #596679);
    font-size: 0.29333rem;
    font-weight: 400;
    line-height: 0.34667rem;
    font-family: Inter;
}

.MainContainer .insideMainContainer .GoBtn[data-v-b8ad632c] {
    width: 1.66667rem;
    right: 0;
    border-radius: 0.10667rem;
    background: url(/assets/svg/Go-ebc6176d.svg);
    background-repeat: no-repeat;
    background-position: bottom;
    background-size: 1.2rem 0.88rem;
    margin-bottom: -0.13333rem;
}

.WinningContainer[data-v-b8ad632c] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0.22667rem;
    background: var( --Text-effects, linear-gradient(180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%));
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: -0.0048rem;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    margin-top: -0.2rem;
}

.WinningContainer[data-v-b8ad632c]:before {
    content: "";
    display: block;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    width: 0.33333rem;
    height: 0.34667rem;
    background-image: url(/assets/svg/Group20225-a3b6092b.svg);
    background-position: left;
    background-repeat: no-repeat;
}

.Winningdata[data-v-b8ad632c] {
    padding: 0.22667rem;
}

.profitRanking[data-v-b8ad632c] {
    padding: 0.09333rem;
    border-radius: 0.16rem;
    background: #141b26;
    -webkit-backdrop-filter: blur(1.09333rem);
    backdrop-filter: blur(1.09333rem);
}

.van-toast[data-v-8084bf25] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-8084bf25] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-8084bf25] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-8084bf25] {
    height: 80%;
}

.sysMessage__container[data-v-8084bf25] {
    font-family: Inter, sans-serif;
    padding: 0.32rem;
}

.sysMessage__container[data-v-8084bf25] .navbar .navbar__content .navbar__content-right {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.sysMessage__container[data-v-8084bf25] .navbar .navbar__content .navbar__content-right svg {
    width: 0.58667rem;
    height: 0.58667rem;
    margin-right: 0.06667rem;
}

.sysMessage__container[data-v-8084bf25] .navbar .navbar__content .navbar__content-right span {
    color: var(--text_color_L2);
    font-size: 0.32rem;
}

.sysMessage__container-msgWrapper[data-v-8084bf25] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    gap: 0.32rem;
    overflow: hidden;
    overflow-y: scroll;
}

.sysMessage__container-msgWrapper__item[data-v-8084bf25] {
    padding: 0.26667rem;
    border-radius: 0.06667rem;
    background: var(--bg_color_L2);
}

.sysMessage__container-msgWrapper__item-title[data-v-8084bf25] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    color: var(--text_color_L1);
}

.sysMessage__container-msgWrapper__item-title>div[data-v-8084bf25] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-align-content: center;
    align-content: center;
}

.sysMessage__container-msgWrapper__item-title .svg[data-v-8084bf25] {
    width: 0.64rem;
    height: 0.64rem;
}

.sysMessage__container-msgWrapper__item-title .svg[data-v-8084bf25]:last-of-type {
    width: 0.48rem;
    height: 0.48rem;
    margin-left: auto;
}

.sysMessage__container-msgWrapper__item-title span[data-v-8084bf25] {
    margin-left: 0.09333rem;
    font-size: 0.4rem;
    font-weight: 600;
}

.sysMessage__container-msgWrapper__item-time[data-v-8084bf25] {
    margin-block: 0.10667rem 0.37333rem;
    color: var(--text_color_L3);
    font-size: 0.32rem;
    font-weight: 400;
}

.sysMessage__container-msgWrapper__item-content[data-v-8084bf25] {
    color: var(--text_color_L2);
    font-size: 0.32rem;
    font-weight: 400;
    word-break: break-word;
}

.sysMessage__container-msgWrapper__item+div[data-v-8084bf25] {
    margin-top: 0.32rem;
}

.sysMessage__container-empty[data-v-8084bf25] {
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
}

.van-toast[data-v-c9357f63] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-c9357f63] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-c9357f63] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-c9357f63] {
    height: 80%;
}

.originalmainContainer[data-v-c9357f63] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 0.96rem;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0 0.21333rem;
    background: #141b26;
}

.originalmainContainer .backSvg[data-v-c9357f63] {
    background-image: url(/assets/svg/backButton-eadf8686.svg);
    background-repeat: no-repeat;
    background-position: center;
    width: 1.12rem;
    height: 100%;
}

.originalmainContainer_title[data-v-c9357f63] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.13333rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    letter-spacing: -0.0048rem;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.GameContainer[data-v-c9357f63] {
    height: auto;
    padding: 0.26667rem;
}

.GameContainer_games[data-v-c9357f63] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    height: auto;
    gap: 0.21333rem;
}

.GameContainer_games>img[data-v-c9357f63] {
    width: calc((100% - 0.42667rem) / 3);
    height: auto;
}

.WinningContainer[data-v-c9357f63] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.26667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: -0.0048rem;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    margin-top: -0.2rem;
}

.WinningContainer[data-v-c9357f63]:before {
    content: "";
    display: block;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    width: 0.33333rem;
    height: 0.34667rem;
    background-image: url(/assets/svg/Group20225-a3b6092b.svg);
    background-position: left;
    background-repeat: no-repeat;
}

.Winningdata[data-v-c9357f63] {
    padding: 0.22667rem;
}

.profitRanking[data-v-c9357f63] {
    padding: 0.09333rem;
    border-radius: 0.16rem;
    background: #141b26;
    -webkit-backdrop-filter: blur(1.09333rem);
    backdrop-filter: blur(1.09333rem);
}

.van-toast[data-v-dbfeadbc] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-dbfeadbc] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-dbfeadbc] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-dbfeadbc] {
    height: 80%;
}

.topContainer[data-v-dbfeadbc] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 0.96rem;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0 0.21333rem;
    background: #141b26;
}

.topContainer .backSvg[data-v-dbfeadbc] {
    background-image: url(/assets/svg/backButton-eadf8686.svg);
    background-repeat: no-repeat;
    background-position: center;
    width: 1.12rem;
    height: 100%;
}

.topContainer .title[data-v-dbfeadbc] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.13333rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    letter-spacing: -0.0048rem;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.slot_list[data-v-dbfeadbc] {
    padding: 0.26667rem 0.32rem;
}

.slot_list .awardbox[data-v-dbfeadbc] {
    margin-bottom: 0.64rem;
}

.slot_list .awardbox .title[data-v-dbfeadbc] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background: var( --Text-effects, linear-gradient(180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%));
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    margin-bottom: 0.26667rem;
}

.slot_list .awardbox .title img[data-v-dbfeadbc] {
    width: 0.64rem;
    height: 0.64rem;
    margin-right: 0.16rem;
}

.slot_list .awardbox .award_tip[data-v-dbfeadbc] {
    color: #d3dae4;
    font-size: 0.37333rem;
    font-style: normal;
    font-weight: 400;
    font-family: Inter;
    line-height: 0.48rem;
}

.slot_list .awardbox .list[data-v-dbfeadbc] {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    margin-bottom: 0.16rem;
    gap: 0.2rem;
}

.slot_list .awardbox .big_prize[data-v-dbfeadbc] {
    width: 2.98667rem;
    height: 3.73333rem;
    position: relative;
    margin-top: 0.2rem;
    border-radius: 0.21333rem;
}

.slot_list .awardbox .big_prize .bg[data-v-dbfeadbc] {
    position: absolute;
    top: 0;
    left: 0;
    width: 2.98667rem;
    height: 3.73333rem;
    border-radius: 0.21333rem;
    background-repeat: no-repeat;
    background-size: 2.98667rem 3.73333rem;
    background-position: center;
    z-index: 1;
}

.slot_list .awardbox .big_prize .info[data-v-dbfeadbc] {
    width: 100%;
    height: 0.90667rem;
    position: absolute;
    bottom: 0.10667rem;
    z-index: 3;
    -webkit-backdrop-filter: blur(0.02667rem);
    backdrop-filter: blur(0.02667rem);
}

.slot_list .awardbox .big_prize .info .text[data-v-dbfeadbc] {
    margin-top: 0.13333rem;
    margin-left: 0.21333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: start;
    -webkit-align-items: flex-start;
    align-items: flex-start;
}

.slot_list .awardbox .big_prize .info .text .tit[data-v-dbfeadbc] {
    font-size: 0.26667rem;
    font-weight: 400;
    font-family: Inter;
    color: var(--off-white-texts, #f4f9ff);
    max-height: 0.4rem;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}

.slot_list .awardbox .big_prize .info .text .multiple[data-v-dbfeadbc] {
    position: relative;
    z-index: 3;
    color: #fff;
    padding: 0.05333rem 0.10667rem;
    border: 0.01333rem solid #fff;
    font-family: Inter;
    border-radius: 0.08rem;
    font-size: 0.21333rem;
    margin-right: 0.21333rem;
    font-weight: 500;
}

.slot_list .awardbox .big_prize .info .award[data-v-dbfeadbc] {
    font-size: 0.32rem;
    color: #fea800;
    font-family: Inter;
    font-weight: 400;
    margin-left: 0.2rem;
}

.slot_list .awardbox .big_prize .bottom[data-v-dbfeadbc] {
    position: absolute;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    bottom: 0;
    left: 0;
    height: 1.09333rem;
    z-index: 3;
    width: 100%;
    border: 0.01333rem solid red;
    background: #141c26;
}

.slot_list .awardbox .big_prize .bottom .foot[data-v-dbfeadbc] {
    position: relative;
    color: #fff;
    font-weight: 500;
    font-size: 0.26667rem;
    text-align: center;
}

.slot_list .awardbox .big_prize .bottom .amount[data-v-dbfeadbc] {
    position: relative;
    color: #fecc21;
    font-size: 0.26667rem;
    text-align: center;
}

.slot_list .awardbox .big_prize[data-v-dbfeadbc]:after {
    content: "";
    display: block;
    width: 2.98667rem;
    height: 1.12rem;
    position: absolute;
    bottom: 0;
    left: 0;
    z-index: 2;
    background: -webkit-linear-gradient( top, rgba(22, 35, 56, 0) -105.45%, #162338 75.17%);
    background: linear-gradient( 180deg, rgba(22, 35, 56, 0) -105.45%, #162338 75.17%);
    border-bottom-left-radius: 0.21333rem;
    border-bottom-right-radius: 0.21333rem;
    margin-bottom: -0.06667rem;
}

.slot_list .awardbox .look_more[data-v-dbfeadbc] {
    width: 5.33333rem;
    height: 0.88rem;
    border-radius: 0.42667rem;
    text-align: center;
    line-height: 0.88rem;
    font-family: Inter;
    color: var(--Grey-White, #e4e7ed);
    font-size: 0.32rem;
    font-style: italic;
    font-weight: 600;
    background: var( --Gradient-1, linear-gradient(93deg, #374992 7.38%, #4675d2 94.48%));
    margin: auto;
}

.slot_list .Slot_game[data-v-dbfeadbc] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    gap: 0.06667rem;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    background: var( --Text-effects, linear-gradient(180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%));
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    font-family: Inter;
    margin-bottom: 0.13333rem;
}

.slot_list .Slot_game[data-v-dbfeadbc]:before {
    content: "";
    display: block;
    height: 0.53333rem;
    width: 0.88rem;
    background: url(/assets/svg/SlotGame-5cbc2f18.svg) no-repeat;
}

.slot_list .GameContainer[data-v-dbfeadbc] {
    height: auto;
}

.slot_list .GameContainer_games[data-v-dbfeadbc] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    height: auto;
    gap: 0.21333rem;
}

.slot_list .GameContainer_games>img[data-v-dbfeadbc] {
    width: calc((100% - 0.42667rem) / 3);
    height: auto;
}

.slot_list .WinningContainer[data-v-dbfeadbc] {
    margin-top: 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: -0.0048rem;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
}

.slot_list .WinningContainer[data-v-dbfeadbc]:before {
    content: "";
    display: block;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    width: 0.33333rem;
    height: 0.34667rem;
    background-image: url(/assets/svg/Group20225-a3b6092b.svg);
    background-position: left;
    background-repeat: no-repeat;
}

.slot_list .profitRanking[data-v-dbfeadbc] {
    margin-top: 0.26667rem;
    padding: 0.09333rem;
    border-radius: 0.16rem;
    background: #141b26;
    -webkit-backdrop-filter: blur(1.09333rem);
    backdrop-filter: blur(1.09333rem);
}

.van-toast[data-v-f8ca9d4e] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-f8ca9d4e] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-f8ca9d4e] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-f8ca9d4e] {
    height: 80%;
}

.originalmainContainer[data-v-f8ca9d4e] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 0.96rem;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0 0.21333rem;
    background: #141b26;
}

.originalmainContainer .backSvg[data-v-f8ca9d4e] {
    background-image: url(/assets/svg/backButton-eadf8686.svg);
    background-repeat: no-repeat;
    background-position: center;
    width: 1.12rem;
    height: 100%;
}

.originalmainContainer_title[data-v-f8ca9d4e] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.13333rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    letter-spacing: -0.0048rem;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.GameContainer[data-v-f8ca9d4e] {
    height: auto;
    padding: 0.26667rem;
}

.GameContainer_games[data-v-f8ca9d4e] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    height: auto;
    gap: 0.21333rem;
}

.GameContainer_games>img[data-v-f8ca9d4e] {
    width: calc((100% - 0.42667rem) / 3);
    height: auto;
}

.WinningContainer[data-v-f8ca9d4e] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.26667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: -0.0048rem;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
}

.WinningContainer[data-v-f8ca9d4e]:before {
    content: "";
    display: block;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    width: 0.33333rem;
    height: 0.34667rem;
    background-image: url(/assets/svg/Group20225-a3b6092b.svg);
    background-position: left;
    background-repeat: no-repeat;
}

.Winningdata[data-v-f8ca9d4e] {
    padding: 0.22667rem;
}

.profitRanking[data-v-f8ca9d4e] {
    padding: 0.09333rem;
    border-radius: 0.16rem;
    background: #141b26;
    -webkit-backdrop-filter: blur(1.09333rem);
    backdrop-filter: blur(1.09333rem);
}

.van-toast[data-v-bc67dde2] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-bc67dde2] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-bc67dde2] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-bc67dde2] {
    height: 80%;
}

.game-iframe[data-v-bc67dde2] {
    width: 100%;
    height: 100vh;
}

.game-iframe .close[data-v-bc67dde2] {
    position: fixed;
    z-index: 100;
    top: 0.4rem;
    left: 0.4rem;
}

.game-iframe .close img[data-v-bc67dde2] {
    width: 0.8rem;
    height: 0.8rem;
}

.game-iframe iframe[data-v-bc67dde2] {
    display: block;
    border: 0;
    width: 100%;
    height: 100%;
}

.van-toast[data-v-1115ff02] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-1115ff02] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-1115ff02] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-1115ff02] {
    height: 80%;
}

.x-4d-head[data-v-1115ff02] {
    display: block;
    padding-top: 0.13333rem;
    background: var(--bg_color_L2);
}

.x-4d-head .time[data-v-1115ff02] {
    text-align: center;
    height: 0.72rem;
    line-height: 0.72rem;
    max-width: 60%;
    margin: 0 auto 0.34667rem;
    font-size: 0.37333rem;
    color: #fff;
    border-top: 0.01333rem solid #fff;
    border-bottom: 0.01333rem solid #fff;
    position: relative;
}

.x-4d-head .time[data-v-1115ff02]:after,
.x-4d-head .time[data-v-1115ff02]:before {
    position: absolute;
    top: -0.02667rem;
    content: "";
    height: 0.72rem;
    width: 0.25333rem;
}

.x-4d-head .time[data-v-1115ff02]:after {
    left: -0.25333rem;
    background: url(/assets/svg/arr-left-bfe1fd7a.svg) no-repeat left top;
    background-size: cover;
}

.x-4d-head .time[data-v-1115ff02]:before {
    right: -0.25333rem;
    background: url(/assets/svg/arr-right-2572fbc2.svg) no-repeat left top;
    background-size: cover;
}

.x-4d-head .time .menu[data-v-1115ff02] {
    position: absolute;
    top: 0.72rem;
    left: 0;
    background: #fff;
    color: var(--text_color_L1);
    width: 100%;
    border-radius: 0.13333rem;
    border: 0.01333rem solid var(--text_color_L1);
    font-size: 0.37333rem;
    line-height: 0.93333rem;
    z-index: 99;
}

.x-4d-head .time .menu h3[data-v-1115ff02] {
    height: 0.93333rem;
    color: var(--text_color_L4);
    background-color: #f6f6f6;
}

.x-4d-head .time .menu ul li[data-v-1115ff02] {
    height: 0.93333rem;
    color: var(--text_color_L2);
}

.x-4d-head .time .menu ul li.active[data-v-1115ff02] {
    color: var(--text_color_L4);
    background: var(--main-color);
}

.x-4d-head .main[data-v-1115ff02] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    position: relative;
    min-height: 3.73333rem;
    padding: 0;
}

.x-4d-head .main .item[data-v-1115ff02] {
    width: 20%;
}

.x-4d-head .main .item .box[data-v-1115ff02] {
    height: 1.6rem;
    width: 1.6rem;
    overflow: hidden;
    text-align: center;
    margin: 0 auto;
    font-size: 0.53333rem;
    color: #fff;
    margin-bottom: 0.16rem;
    border-radius: 1.6rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.x-4d-head .main .item .box .img[data-v-1115ff02] {
    display: block;
    width: 100%;
    height: 100%;
    border-radius: 80%;
    background-color: #fff;
    -webkit-filter: grayscale(100%);
    filter: grayscale(100%);
}

.x-4d-head .main .item .box.active[data-v-1115ff02] {
    background: var(--main_gradient-color2);
}

.x-4d-head .main .item .box.active .img[data-v-1115ff02] {
    -webkit-filter: grayscale(0%);
    filter: grayscale(0%);
}

.van-toast[data-v-40039812] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-40039812] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-40039812] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-40039812] {
    height: 80%;
}

.betType[data-v-40039812] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.betType .title[data-v-40039812] {
    font-size: 0.42667rem;
    margin-bottom: 0.13333rem;
    font-weight: 400;
    position: relative;
    height: 0.48rem;
    line-height: 0.48rem;
    padding-left: 0.26667rem;
    color: var(--text_color_L1);
}

.betType .title[data-v-40039812]:after {
    position: absolute;
    top: 0;
    left: 0;
    content: "";
    display: block;
    width: 0.08rem;
    height: 0.4rem;
    background-color: var(--main-color);
    border-radius: 0.06667rem;
}

.betType-list[data-v-40039812],
.betType .flex[data-v-40039812] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: -0.21333rem;
    width: 100%;
    padding: 0;
}

.betType-list .item[data-v-40039812],
.betType .flex .item[data-v-40039812] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    width: calc(33.3% - 0.21333rem);
    background: var(--bg_color_L3);
    height: 0.93333rem;
    border-radius: 0.13333rem;
    margin-bottom: 0.16rem;
    margin-right: 0.21333rem;
    text-align: center;
    font-size: 0.37333rem;
    color: var(--text_color_L2);
    overflow: hidden;
}

.betType-list .item.action[data-v-40039812],
.betType .flex .item.action[data-v-40039812] {
    background: var(--main_gradient-color);
    color: var(--text_color_L1);
}

.van-toast[data-v-42192c16] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-42192c16] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-42192c16] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-42192c16] {
    height: 80%;
}

.howPay .title[data-v-42192c16] {
    font-size: 0.42667rem;
    margin-bottom: 0.13333rem;
    font-weight: 400;
    position: relative;
    height: 0.48rem;
    line-height: 0.48rem;
    padding-left: 0.26667rem;
    color: var(--text_color_L1);
}

.howPay .title[data-v-42192c16]:after {
    position: absolute;
    top: 0;
    left: 0;
    content: "";
    display: block;
    width: 0.08rem;
    height: 0.4rem;
    background-color: var(--main-color);
    border-radius: 0.06667rem;
}

.howPay-list[data-v-42192c16],
.howPay .flex[data-v-42192c16] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    padding: 0;
}

.howPay-list .item[data-v-42192c16],
.howPay .flex .item[data-v-42192c16] {
    width: calc(50% - 0.09333rem);
    text-align: center;
    border: 0.01333rem solid var(--text_color_L2);
    border-radius: 0.13333rem;
    margin-bottom: 0.16rem;
    font-size: 0.37333rem;
    position: relative;
    overflow: hidden;
    background: var(--bg_color_L3);
}

.howPay-list .item[data-v-42192c16]:active:before,
.howPay .flex .item[data-v-42192c16]:active:before {
    opacity: 0;
}

.howPay-list .item .icon[data-v-42192c16],
.howPay .flex .item .icon[data-v-42192c16] {
    position: absolute;
    right: 0;
    bottom: 0;
    height: 0.53333rem;
    width: 0.6rem;
    text-align: right;
    background-image: -webkit-linear-gradient( 135deg, var(--main-color) 50%, rgba(255, 255, 255, 0) 50%);
    background-image: linear-gradient( 315deg, var(--main-color) 50%, rgba(255, 255, 255, 0) 50%);
    color: #fff;
    line-height: 0.8rem;
}

.howPay-list .item.action[data-v-42192c16],
.howPay .flex .item.action[data-v-42192c16] {
    border-color: var(--main-color);
    color: var(--main-color);
}

.van-toast[data-v-1c2e9816] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-1c2e9816] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-1c2e9816] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-1c2e9816] {
    height: 80%;
}

.betAmount .title[data-v-1c2e9816] {
    font-size: 0.42667rem;
    margin-bottom: 0.13333rem;
    font-weight: 400;
    position: relative;
    height: 0.48rem;
    line-height: 0.48rem;
    padding-left: 0.26667rem;
    color: var(--text_color_L1);
}

.betAmount .title[data-v-1c2e9816]:after {
    position: absolute;
    top: 0;
    left: 0;
    content: "";
    display: block;
    width: 0.08rem;
    height: 0.4rem;
    background-color: var(--main-color);
    border-radius: 0.06667rem;
}

.betAmount-list[data-v-1c2e9816] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.betAmount-list .item[data-v-1c2e9816] {
    width: calc(16.6666666667% - 0.16rem);
    height: 0.93333rem;
    line-height: 0.93333rem;
    background-color: var(--bg_color_L3);
    text-align: center;
    border-radius: 0.13333rem;
    font-size: 0.37333rem;
    font-weight: 700;
    color: var(--text_color_L2);
}

.betAmount-list .item.active[data-v-1c2e9816] {
    background: var(--norm_green-color);
    color: #fff;
}

.van-toast[data-v-f88540df] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-f88540df] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-f88540df] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-f88540df] {
    height: 80%;
}

.select[data-v-f88540df] {
    margin-top: 0.4rem;
    margin: 0 -0.32rem;
}

.select .tab[data-v-f88540df] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    height: 1.06667rem;
}

.select .tab li[data-v-f88540df] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    width: calc(25% - 0.05333rem);
    height: 1.06667rem;
    text-align: center;
    background-color: var(--bg_color_L3);
    border-radius: 0.13333rem 0.13333rem 0 0;
    color: var(--text_color_L2);
}

.select .tab li.active[data-v-f88540df] {
    background: var(--main-color);
    color: #fff;
}

.select .numList[data-v-f88540df] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    background-color: var(--bg_color_L2);
    border-radius: 0 0 0.13333rem 0.13333rem;
    margin-top: 0.26667rem;
}

.select .numList ul[data-v-f88540df] {
    width: 25%;
    text-align: center;
}

.select .numList ul li[data-v-f88540df] {
    margin: 0 auto 0.26667rem;
    height: 1.46667rem;
    width: 1.46667rem;
    line-height: 1.46667rem;
    background: url(/assets/svg/nbg-dba06970.svg) no-repeat center center;
    background-size: cover;
    color: var(--text_color_L2);
    font-size: 0.66667rem;
    font-style: normal;
    font-weight: 700;
}

.select .numList ul li.action[data-v-f88540df] {
    color: var(--norm_red-color);
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
}

.van-toast[data-v-fd9536f0] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-fd9536f0] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-fd9536f0] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-fd9536f0] {
    height: 80%;
}

.foot[data-v-fd9536f0] {
    position: fixed;
    bottom: 0;
    left: auto;
    height: 1.6rem;
    width: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    text-align: center;
    font-size: 0.32rem;
    max-width: 10rem;
    background-color: var(--bg_color_L2);
}

.foot .item[data-v-fd9536f0]:first-child {
    border-right: 0.01333rem solid var(--Dividing-line_color);
}

.foot .item[data-v-fd9536f0] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    background-color: var(--bg_color_L2);
    color: var(--text_color_L1);
}

.foot .item.bet[data-v-fd9536f0] {
    line-height: 0.66667rem;
    font-size: 0.42667rem;
    font-weight: 700;
    background: var(--bg_color_L3);
    color: var(--text_color_L1);
}

.foot .item.bet.active[data-v-fd9536f0] {
    background-color: var(--main-color);
    color: #fff;
}

.foot .item>span[data-v-fd9536f0] {
    font-size: 0.4rem;
    font-weight: 700;
    color: var(--norm_red-color);
}

.van-toast[data-v-3557dd80] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-3557dd80] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-3557dd80] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-3557dd80] {
    height: 80%;
}

.x-bet[data-v-3557dd80] {
    padding: 0.32rem;
}

.x-bet-sub[data-v-3557dd80] {
    text-align: center;
    color: var(--text_color_L1);
    font-size: 0.42667rem;
    position: relative;
    height: 0.8rem;
    line-height: 0.8rem;
}

.x-bet-sub .clear[data-v-3557dd80] {
    position: absolute;
    right: 0;
    top: 0;
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.x-bet-sub .clear .icon[data-v-3557dd80] {
    color: var(--main-color);
    font-size: 0.4rem;
}

.x-bet-maxbet[data-v-3557dd80] {
    text-align: center;
}

.x-bet-maxbet .tip[data-v-3557dd80] {
    color: #ff7172;
    display: inline-block;
    padding: 0 0.26667rem;
    height: 0.66667rem;
    line-height: 0.66667rem;
    border: 0.01333rem solid #ff7172;
    border-radius: 0.66667rem;
}

.x-bet-title[data-v-3557dd80] {
    font-size: 0.37333rem;
    color: var(--text_color_L1);
    margin-bottom: 0.13333rem;
}

.x-bet-lottery .box[data-v-3557dd80] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.x-bet-lottery .box .item[data-v-3557dd80] {
    height: 0.82667rem;
    line-height: 0.82667rem;
    text-align: center;
    color: var(--textW);
    font-size: 0.53333rem;
    width: 0.82667rem;
    margin: 0 0.05333rem;
    border-radius: 0.82667rem;
    background-color: #ffbd9f;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.x-bet-lottery .box .item .img[data-v-3557dd80] {
    width: 0.66667rem;
    height: 0.66667rem;
    display: block;
}

.x-bet-type .box[data-v-3557dd80] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    text-align: center;
    margin-right: -0.13333rem;
}

.x-bet-type .box .item[data-v-3557dd80] {
    width: calc(25% - 0.13333rem);
    margin: 0 0.13333rem 0.13333rem 0;
    height: 0.8rem;
    line-height: 0.8rem;
    border: 0.01333rem solid var(--text_color_L2);
    border-radius: 0.13333rem;
    color: var(--text_color_L2);
}

.x-bet-type .x-bet-title[data-v-3557dd80] {
    color: var(--text_color_L2);
    margin: 0.26667rem 0 0.13333rem;
}

.x-bet-multiple[data-v-3557dd80] {
    margin-top: 0.4rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.x-bet-multiple .tit[data-v-3557dd80] {
    font-size: 0.37333rem;
    color: var(--text_color_L2);
}

.x-bet-multiple .box[data-v-3557dd80] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.x-bet-multiple .box .li[data-v-3557dd80] {
    width: 0.66667rem;
    height: 0.66667rem;
    font-size: 0.4rem;
    font-weight: 600;
    color: #fff;
    text-align: center;
    border-radius: 0.66667rem;
    background: var(--bg_color_L3);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.x-bet-multiple .box .digit[data-v-3557dd80] {
    height: 0.66667rem;
    border-radius: 0.66667rem;
    width: 2.4rem;
    padding: 0;
    margin: 0 0.06667rem;
    background: var(--bg_color_L3);
}

.x-bet-multiple .box .digit[data-v-3557dd80] .van-field__control {
    text-align: center;
}

.x-bet .multiple-list[data-v-3557dd80] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
}

.x-bet .multiple-list .box[data-v-3557dd80] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 0.8rem;
    line-height: 0.8rem;
    margin: 0.4rem 0;
}

.x-bet .multiple-list .box .item[data-v-3557dd80] {
    text-align: center;
    min-width: 1.2rem;
    border: 0.01333rem solid var(--text_color_L2);
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
    margin: 0 0.05333rem;
}

.x-bet .multiple-list .box .item.active[data-v-3557dd80] {
    border: none;
    background: var(--norm_green-color);
    color: var(--text_color_L1);
}

.x-bet-list[data-v-3557dd80] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.x-bet-list .item[data-v-3557dd80] {
    height: 0.8rem;
    line-height: 0.8rem;
    background-color: var(--bg_color_L3);
    margin-bottom: 0.16rem;
    padding: 0 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.x-bet-list .item .lab[data-v-3557dd80] {
    min-width: 2.66667rem;
    color: var(--text_color_L2);
    font-size: 0.34667rem;
}

.x-bet-list .item .number[data-v-3557dd80] {
    font-size: 0.4rem;
    font-weight: 400;
    color: var(--norm_red-color);
}

.x-bet-list .item .balance[data-v-3557dd80],
.x-bet-list .item .amount[data-v-3557dd80] {
    font-weight: 400;
    font-size: 0.37333rem;
    color: var(--text_color_L1);
}

.x-bet-list .item .amount[data-v-3557dd80] {
    color: var(--norm_secondary-color);
}

.x-bet-wallet[data-v-3557dd80] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    margin-top: 0.16rem;
}

.x-bet-wallet .tip[data-v-3557dd80] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    color: var(--norm_red-color);
    font-size: 0.29333rem;
}

.x-bet-wallet .tip img[data-v-3557dd80] {
    height: 0.4rem;
    width: 0.4rem;
    display: block;
    margin-right: 0.13333rem;
}

.x-bet-wallet .txt[data-v-3557dd80] {
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.x-bet-agree[data-v-3557dd80] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    font-size: 0.32rem;
    margin-top: 0.26667rem;
}

.x-bet-agree .txt[data-v-3557dd80] {
    color: var(--norm_red-color);
}

.x-bet-foot[data-v-3557dd80] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 1.6rem;
    line-height: 1.6rem;
    text-align: center;
    font-size: 0.45333rem;
}

.x-bet-foot .cancel[data-v-3557dd80] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    background-color: var(--bg_color_L3);
    color: var(--text_color_L2);
    font-weight: 400;
}

.x-bet-foot .bet[data-v-3557dd80] {
    -webkit-box-flex: 1.5;
    -webkit-flex: 1.5;
    flex: 1.5;
    background-color: var(--main-color);
    color: var(--text_color_L4);
    font-weight: 700;
}

.van-toast[data-v-d0caa9aa] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-d0caa9aa] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-d0caa9aa] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-d0caa9aa] {
    height: 80%;
}

.x-bet[data-v-d0caa9aa] {
    padding: 0;
}

.x-bet-box[data-v-d0caa9aa] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.x-bet-box .item[data-v-d0caa9aa] {
    width: calc(50% - 0.13333rem);
    border: 0.01333rem solid var(--text_color_L2);
    text-align: center;
    height: 1.46667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    border-radius: 0.13333rem;
}

.x-bet-box .item .pay[data-v-d0caa9aa] {
    color: var(--main-color);
    font-size: 0.32rem;
}

.x-bet-box .item .num[data-v-d0caa9aa] {
    font-size: 0.48rem;
    color: var(--main-color);
    font-weight: 600;
}

.x-bet-box .item .txt[data-v-d0caa9aa] {
    margin-top: 0.06667rem;
    font-size: 0.37333rem;
    color: var(--text_color_L2);
}

.x-bet-pay[data-v-d0caa9aa] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 0.8rem;
    line-height: 0.8rem;
    border: 0.01333rem solid var(--text_color_L2);
    color: var(--text_color_L2);
    border-radius: 0.13333rem;
    padding: 0 0.26667rem;
}

.x-bet-pay .x-bet-title[data-v-d0caa9aa] {
    font-size: 0.37333rem;
    font-weight: 400;
}

.x-bet-pay .name[data-v-d0caa9aa] {
    margin: 0 0.26667rem;
    color: var(--main-color);
    font-size: 0.32rem;
    font-weight: 500;
}

.x-bet-dupleList[data-v-d0caa9aa] {
    max-height: 4.73333rem;
    overflow-y: auto;
    margin: 0.32rem 0;
}

.x-bet-dupleList .box[data-v-d0caa9aa] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.x-bet-dupleList .box .sub[data-v-d0caa9aa] {
    color: var(--text_color_L2);
    font-size: 0.42667rem;
    min-width: 2.4rem;
}

.x-bet-dupleList .box .digits[data-v-d0caa9aa] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 100%;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.26667rem;
}

.x-bet-dupleList .box .digits .list[data-v-d0caa9aa] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    width: 100%;
}

.x-bet-dupleList .box .digits .list .num[data-v-d0caa9aa] {
    width: 20%;
}

.x-bet-dupleList .box .digits .list .num .item[data-v-d0caa9aa] {
    margin: 0 auto;
    text-align: center;
    height: 0.93333rem;
    width: 0.93333rem;
    line-height: 0.93333rem;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
    color: var(--norm_red-color);
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 700;
}

.van-toast[data-v-fd6be9e5] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-fd6be9e5] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-fd6be9e5] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-fd6be9e5] {
    height: 80%;
}

.resultBox .r123[data-v-fd6be9e5] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    gap: 0.13333rem;
}

.resultBox .r123 .r[data-v-fd6be9e5] {
    width: 33.3333333333%;
    background: var(--bg_color_L3);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    gap: 0.13333rem;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0.2rem 0;
    border-radius: 0.13333rem;
}

.resultBox .r123 .r .num[data-v-fd6be9e5] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    gap: 0.04rem;
}

.resultBox .r123 .r .num span[data-v-fd6be9e5] {
    display: block;
    background: var(--norm_red-color);
    border-radius: 50%;
    width: 0.53333rem;
    height: 0.53333rem;
    text-align: center;
    line-height: 0.53333rem;
    color: #fff;
    font-size: 0.37333rem;
    font-weight: 700;
}

.resultBox .r123 .r p[data-v-fd6be9e5] {
    color: var(--text_color_L2);
    font-size: 0.37333rem;
}

.resultBox .title[data-v-fd6be9e5] {
    border-radius: 0.13333rem;
    background-color: var(--bg_color_L3);
    margin: 0.26667rem 0;
    color: var(--main-color);
    font-size: 0.37333rem;
    font-weight: 700;
    text-align: center;
    padding: 0.2rem 0;
}

.resultBox .rOther[data-v-fd6be9e5] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.09333rem;
}

.resultBox .rOther span[data-v-fd6be9e5] {
    width: calc(20% - 0.09333rem);
    background: var(--bg_color_L3);
    color: var(--text_color_L1);
    font-size: 0.4rem;
    font-weight: 700;
    border-radius: 0.13333rem;
    text-align: center;
    padding: 0.13333rem 0;
    margin-bottom: 0.06667rem;
}

.van-toast[data-v-aec2245d] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-aec2245d] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-aec2245d] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-aec2245d] {
    height: 80%;
}

.gameBox[data-v-aec2245d] {
    margin-top: 0.32rem;
}

.gameBox>div[data-v-aec2245d] {
    background: var(--bg_color_L2);
    border-radius: 0.13333rem;
}

.gameBox .items .itemBox.active[data-v-aec2245d] {
    border-radius: 0.13333rem;
    border: 0.01333rem solid var(--main-color);
}

.gameBox .items .itemBox.active .item[data-v-aec2245d] {
    border-bottom: none;
    padding: 0.4rem 0.26667rem 0;
}

.gameBox .items .state1[data-v-aec2245d] {
    color: var(--norm_bule-color);
}

.gameBox .items .state2[data-v-aec2245d] {
    color: var(--norm_red-color);
}

.gameBox .items .state3[data-v-aec2245d] {
    color: var(--norm_green-color);
}

.gameBox .items .state4[data-v-aec2245d],
.gameBox .items .state5[data-v-aec2245d] {
    color: var(--text_color_L1);
}

.gameBox .items .state6[data-v-aec2245d] {
    color: var(--norm_secondary-color);
}

.gameBox .items .green[data-v-aec2245d] {
    color: var(--norm_green-color);
}

.gameBox .items .red[data-v-aec2245d] {
    color: var(--norm_red-color);
}

.gameBox .items .item[data-v-aec2245d] {
    padding: 0.4rem 0.26667rem;
    border-bottom: 0.01333rem solid var(--Dividing-line_color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.gameBox .items .item>div[data-v-aec2245d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    gap: 0.13333rem;
}

.gameBox .items .item .name[data-v-aec2245d] {
    font-size: 0.37333rem;
    color: var(--text_color_L1);
}

.gameBox .items .item .name.bold[data-v-aec2245d] {
    font-size: 0.4rem;
    font-weight: 700;
}

.gameBox .items .item .time[data-v-aec2245d] {
    color: var(--text_color_L2);
    font-size: 0.32rem;
}

.gameBox .items .item .state[data-v-aec2245d] {
    font-size: 0.37333rem;
}

.gameBox .items .item .amount[data-v-aec2245d] {
    font-size: 0.4rem;
    font-weight: 700;
}

.gameBox .items .info[data-v-aec2245d] {
    margin: 0.13333rem 0.26667rem 0.26667rem;
    border-top: solid 0.01333rem var(--Dividing-line_color);
    padding-top: 0.26667rem;
}

.gameBox .items .info .order .li[data-v-aec2245d] {
    display: -webkit-box;
    display: -webkit-flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    color: var(--text_color_L2);
    display: flex;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.gameBox .items .info .order .li>span .svg[data-v-aec2245d] {
    width: 0.33333rem;
    height: 0.33333rem;
    margin-right: 0.33333rem;
}

.gameBox .items .info .order .li .numTit[data-v-aec2245d] {
    color: var(--text_color_L2);
    font-size: 0.37333rem;
}

.gameBox .items .info .order .li .copy[data-v-aec2245d] {
    color: var(--text_color_L1);
}

.gameBox .items .info .order .li .copy .svg2[data-v-aec2245d] {
    width: 0.32rem;
    height: 0.32rem;
}

.gameBox .items .info .order .li .otherTip[data-v-aec2245d] {
    color: var(--text_color_L1);
}

.gameBox .items .info .order .li:first-child>span .svg1[data-v-aec2245d] {
    width: 0.33333rem;
    height: 0.33333rem;
    margin-right: 0.33333rem;
}

.gameBox .items .info .order .line[data-v-aec2245d] {
    height: 0.2rem;
    border-left: dashed 0.01333rem var(--main-color);
    margin-left: 0.13333rem;
}

.gameBox .items .info .order .type[data-v-aec2245d] {
    padding: 0.26667rem 0 0.26667rem 0.46667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.09333rem;
}

.gameBox .items .info .order .type>span[data-v-aec2245d] {
    background: var(--bg_color_L3);
    width: calc(33.3333333333% - 0.09333rem);
    text-align: center;
    color: var(--text_color_L2);
    font-size: 0.29333rem;
    border-radius: 0.13333rem;
    padding: 0.13333rem 0;
    margin-bottom: 0.06667rem;
}

.gameBox .items .info .order .num[data-v-aec2245d] {
    border-left: dashed 0.01333rem var(--main-color);
    margin-left: 0.13333rem;
}

.gameBox .items .info .order .num>span[data-v-aec2245d] {
    width: auto;
    padding: 0.13333rem 0.26667rem;
    color: var(--text_color_L2);
}

.gameBox .items .info .order .select[data-v-aec2245d] {
    padding: 0.26667rem 0 0.26667rem 0.46667rem;
}

.gameBox .items .info .order .select>div[data-v-aec2245d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    margin-bottom: 0.13333rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.gameBox .items .info .order .select>div h6[data-v-aec2245d] {
    width: 1.46667rem;
    color: var(--text_color_L2);
}

.gameBox .items .info .order .select>div .n[data-v-aec2245d] {
    width: calc(100% - 1.46667rem);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    gap: 0.13333rem;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.gameBox .items .info .order .select>div .n span[data-v-aec2245d] {
    border-radius: 0.08rem;
    background: var(--bg_color_L3);
    padding: 0.02667rem 0.18667rem;
    text-align: center;
    color: var(--text_color_L1);
    font-size: 0.29333rem;
}

.gameBox .items .info .order .line1[data-v-aec2245d] {
    margin: 0.26667rem -0.29333rem;
    background-color: var(--bg_color_L2);
    height: 0.57333rem;
    overflow: hidden;
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.gameBox .items .info .order .line1>p[data-v-aec2245d] {
    width: 85%;
    border-bottom: 0.01333rem dashed var(--Dividing-line_color);
}

.gameBox .items .info .order .line1[data-v-aec2245d]:after,
.gameBox .items .info .order .line1[data-v-aec2245d]:before {
    content: "";
    display: block;
    width: 0.53333rem;
    height: 0.53333rem;
    border-radius: 0.53333rem;
    border: 0.01333rem solid var(--main-color);
    position: absolute;
    top: 0;
}

.gameBox .items .info .order .line1[data-v-aec2245d]:after {
    left: -0.26667rem;
}

html:lang(ar) .gameBox .items .info .order .line1[data-v-aec2245d]:after {
    right: -0.26667rem;
    left: unset;
}

.gameBox .items .info .order .line1[data-v-aec2245d]:before {
    right: -0.26667rem;
}

html:lang(ar) .gameBox .items .info .order .line1[data-v-aec2245d]:before {
    left: -0.26667rem;
    right: unset;
}

.gameBox .items .info .order .stateInfo[data-v-aec2245d] {
    font-size: 0.34667rem;
}

.gameBox .items .info .order .amountInfo[data-v-aec2245d] {
    font-weight: 700;
    color: var(text_color_L1);
}

.gameBox .items .info .reTitle[data-v-aec2245d] {
    color: var(--text_color_L1);
    font-size: 0.4rem;
    font-weight: 700;
    margin: 0.26667rem 0;
}

.gameBox .items .btn[data-v-aec2245d] {
    margin: 0.66667rem 0 0.53333rem;
    background: var(--main_gradient-color);
    border-radius: 0.66667rem;
    color: var(--text_color_L4);
    font-size: 0.4rem;
    font-weight: 700;
    text-align: center;
    padding: 0.13333rem 0;
}

.gameBox .foot[data-v-aec2245d] {
    padding: 0.13333rem 0;
    margin-top: 0.4rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    gap: 0.66667rem;
}

.gameBox .foot .page[data-v-aec2245d] {
    color: var(--text_color_L2);
}

.gameBox .foot .previous[data-v-aec2245d],
.gameBox .foot .next[data-v-aec2245d] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background-color: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.gameBox .foot .previous.disabled[data-v-aec2245d],
.gameBox .foot .next.disabled[data-v-aec2245d] {
    background: var(--bg_color_L3);
    pointer-events: none;
    color: #7f7f7f;
}

.gameBox .foot .previous.disabled[data-v-aec2245d] .van-icon,
.gameBox .foot .next.disabled[data-v-aec2245d] .van-icon {
    color: var(--saveTextColor-7);
}

.gameBox .foot .previous[data-v-aec2245d] .van-icon,
.gameBox .foot .next[data-v-aec2245d] .van-icon {
    color: var(--text_color_L4);
}

.van-toast[data-v-e3178c7d] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-e3178c7d] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-e3178c7d] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-e3178c7d] {
    height: 80%;
}

.gamelist[data-v-e3178c7d] {
    margin-top: 0.4rem;
    padding: 0 0.32rem;
}

.gamelist .tab[data-v-e3178c7d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 1.06667rem;
    line-height: 1.06667rem;
    background-color: var(--bg_color_L3);
    border-radius: 0.13333rem;
    font-size: 0.42667rem;
    color: var(--text_color_L2);
    overflow: hidden;
}

.gamelist .tab>div[data-v-e3178c7d] {
    width: 50%;
    text-align: center;
}

.gamelist .tab>div.active[data-v-e3178c7d] {
    color: var(--text_color_L4);
    background: var(--main_gradient-color);
    box-shadow: var(--BoxShadowColor-27);
}

.gamelist .con[data-v-e3178c7d] {
    position: relative;
    margin-top: 0.26667rem;
    padding: 0.26667rem 0.13333rem;
    border-radius: 0.13333rem;
}

.gamelist .con .more[data-v-e3178c7d] {
    border-radius: 0.13333rem;
    border: 0.01333rem solid var(--main-color);
    padding: 0 0.26667rem;
    position: absolute;
    height: 0.8rem;
    right: 0.13333rem;
    color: var(--main-color);
    font-size: 0.32rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    gap: 0.13333rem;
}

.gamelist .con .more svg[data-v-e3178c7d] {
    width: 0.42667rem;
    height: 0.42667rem;
}

.gamelist .con .items .head[data-v-e3178c7d] {
    background: var(--bg_color_L3);
    text-align: center;
    margin: 1.33333rem 0 0.26667rem;
    padding-bottom: 0.13333rem;
    border-radius: 0.13333rem;
}

.gamelist .con .items .head img[data-v-e3178c7d] {
    width: 1.43543rem;
    height: 1.43543rem;
    margin-top: -0.66667rem;
    border-radius: 50%;
    overflow: hidden;
}

.gamelist .con .items .head h1[data-v-e3178c7d] {
    color: var(--text_color_L1);
    font-size: 0.4rem;
    font-weight: 700;
    margin: 0.13333rem 0;
}

.gamelist .con .items .head p[data-v-e3178c7d] {
    font-size: 0.34667rem;
    color: var(--text_color_L2);
}

[data-v-e3178c7d] .gameBox {
    margin-top: 1.06667rem;
}

.van-toast[data-v-c4174cb0] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-c4174cb0] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-c4174cb0] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-c4174cb0] {
    height: 80%;
}

.mb30[data-v-c4174cb0] {
    margin-bottom: 0.4rem;
}

.x-4d[data-v-c4174cb0] {
    width: 100%;
    min-height: 100vh;
    padding-bottom: 1.86667rem;
}

.x-4d-more[data-v-c4174cb0] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.x-4d-more .svg[data-v-c4174cb0] {
    display: block;
    height: 0.64rem;
    width: 0.64rem;
    margin-left: 0.2rem;
}

.x-4d-body[data-v-c4174cb0] {
    padding: 0.26667rem 0.32rem 0;
}

.x-4d-tab[data-v-c4174cb0] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 1.06667rem;
    line-height: 1.06667rem;
    background-color: var(--bg_color_L3);
    border-radius: 0.13333rem;
    font-size: 0.42667rem;
    color: var(--text_color_L2);
    overflow: hidden;
}

.x-4d-tab>div[data-v-c4174cb0] {
    width: 50%;
    text-align: center;
}

.x-4d-tab>div.active[data-v-c4174cb0] {
    color: var(--text_color_L4);
    background: var(--main_gradient-color);
    box-shadow: 0 0.10667rem 0.21333rem #d0d0ed5c;
}

.x-4d-content[data-v-c4174cb0] {
    background-color: var(--bg_color_L2);
    padding: 0.26667rem;
    margin-top: 0.26667rem;
    border-radius: 0.13333rem;
}

.x-4d-content .enter[data-v-c4174cb0] {
    position: relative;
    margin-bottom: 0.4rem;
}

.x-4d-content .enter .input[data-v-c4174cb0] {
    height: 1.06667rem;
    line-height: 1.06667rem;
    width: 100%;
    background-color: var(--bg_color_L3);
    border-radius: 1.06667rem;
    padding: 0 1.06667rem 0 0.26667rem;
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.x-4d-content .enter .input.fz24[data-v-c4174cb0] {
    font-size: 0.56rem;
}

.x-4d-content .enter .input[data-v-c4174cb0]::-webkit-input-placeholder {
    color: var(--main_gradient-color);
}

.x-4d-content .enter .input[data-v-c4174cb0]::placeholder {
    color: var(--main_gradient-color);
}

.x-4d-content .enter .btn[data-v-c4174cb0] {
    position: absolute;
    right: 0;
    top: 0;
    height: 1.06667rem;
    width: 2.4rem;
    border-radius: 0 1.06667rem 1.06667rem 0;
    border: none;
    background: -webkit-linear-gradient( 352deg, transparent 0.2rem, var(--main-color) 0);
    background: linear-gradient(98deg, transparent 0.2rem, var(--main-color) 0);
    color: #fff;
    font-size: 0.42667rem;
    font-weight: 600;
}

.x-4d-gamelist[data-v-c4174cb0] {
    margin-top: 0.4rem;
    padding: 0 0.32rem;
}

.x-4d-prompt[data-v-c4174cb0] {
    border: 0.01333rem solid var(--borderColor-5);
}

.x-4d-prompt .box[data-v-c4174cb0] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    font-size: 0.48rem;
    color: var(--text_color_L1);
    font-weight: 600;
    background: var(--bg_color_L3);
}

.x-4d-prompt .box .svg[data-v-c4174cb0] {
    width: 1.09333rem;
    height: 1.09333rem;
    display: block;
    margin-right: 0.26667rem;
}

.x-4d .PreSaleRule[data-v-c4174cb0] {
    width: 7.04rem;
}

.x-4d .PreSaleRule .head[data-v-c4174cb0] {
    height: 1.2rem;
    line-height: 1.2rem;
    color: #fff;
    font-size: 0.4rem;
    text-align: center;
    background: var(--main_gradient-color);
}

.x-4d .PreSaleRule .body[data-v-c4174cb0] {
    max-height: 8rem;
    overflow-y: auto;
    padding: 0.4rem;
    font-size: 0.32rem;
    line-height: 0.8rem;
    color: var(--text_color_L2);
}

.x-4d .PreSaleRule .body[data-v-c4174cb0] p {
    margin-bottom: 0.2rem;
    line-height: 0.53333rem;
}

.x-4d .PreSaleRule .foot[data-v-c4174cb0] {
    height: 1.86667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.x-4d .PreSaleRule .foot .btn[data-v-c4174cb0] {
    width: 60%;
    background: var(--main_gradient-color);
    border-radius: 0.53333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    font-size: 0.37333rem;
    color: #fff;
}

.van-toast[data-v-d1d6b410] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-d1d6b410] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-d1d6b410] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-d1d6b410] {
    height: 80%;
}

.LR[data-v-d1d6b410] {
    padding: 0.4rem 0.26667rem;
}

.LR .lotterys[data-v-d1d6b410] {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    grid-gap: 0.26667rem;
}

.LR .lotterys .main[data-v-d1d6b410] {
    margin: auto;
    width: 1.6rem;
    height: 1.6rem;
    border-radius: 1.06667rem;
    background: var(--bg_color_L2);
}

.LR .lotterys .main img[data-v-d1d6b410] {
    width: 100%;
    height: 1.6rem;
    border-radius: 50%;
    overflow: hidden;
    object-fit: cover !important;
    background-color: #fff;
    -webkit-filter: grayscale(100%);
    filter: grayscale(100%);
}

.LR .lotterys .main.active[data-v-d1d6b410] {
    background: var(--main_gradient-color2);
}

.LR .lotterys .main.active img[data-v-d1d6b410] {
    -webkit-filter: grayscale(0%);
    filter: grayscale(0%);
}

.LR .date[data-v-d1d6b410] {
    margin: 0.53333rem 0 0.4rem;
    height: 1.17333rem;
    background: var(--main_gradient-color);
    border-radius: 0.66667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.LR .date .dateBox[data-v-d1d6b410] {
    border-top: 0.01333rem solid var(--text_color_L4);
    border-bottom: 0.01333rem solid var(--text_color_L4);
    position: relative;
    height: 0.73333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 60%;
}

.LR .date .dateBox svg[data-v-d1d6b410] {
    width: 0.26667rem;
    height: 0.72rem;
}

.LR .date .dateBox svg[data-v-d1d6b410]:nth-child(1) {
    margin-left: -0.26667rem;
}

.LR .date .dateBox svg[data-v-d1d6b410]:last-child {
    margin-right: -0.26667rem;
    -webkit-transform: rotate(180deg);
    transform: rotate(180deg);
}

.LR .date .dateBox[data-v-d1d6b410] .ar-searchbar__selector {
    color: var(--textW);
    font-size: 0.37333rem;
    font-weight: 500;
}

.LR .date .dateBox[data-v-d1d6b410] .ar-searchbar__selector>div {
    background: transparent;
    box-shadow: none;
}

.LR .result[data-v-d1d6b410] {
    padding: 0.26667rem;
    background: var(--bg_color_L2);
    border-radius: 0.13333rem;
}

.LR .result h1[data-v-d1d6b410] {
    font-size: 0.4rem;
    font-weight: 700;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    gap: 0.13333rem;
    margin-bottom: 0.26667rem;
    color: var(--text_color_L1);
}

.LR .result h1[data-v-d1d6b410]:before {
    content: "";
    display: block;
    width: 0.08rem;
    height: 0.4rem;
    background-color: var(--main-color);
}

.LR[data-v-d1d6b410] .van-calendar__selected-day {
    border: 0.01333rem solid var(--main-color);
    color: var(--main-color);
    background: none;
}

.van-toast[data-v-789ad0bd] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-789ad0bd] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-789ad0bd] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-789ad0bd] {
    height: 80%;
}

.oddsBox[data-v-789ad0bd] {
    padding: 0 0.26667rem 0.4rem;
}

.oddsBox .items[data-v-789ad0bd] {
    margin-bottom: 0.66667rem;
}

.oddsBox .items .title[data-v-789ad0bd] {
    min-height: 0.82667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    color: var(--text_color_L4);
    font-size: 0.42667rem;
    font-weight: 600;
    position: relative;
}

.oddsBox .items .title .words[data-v-789ad0bd] {
    position: absolute;
}

.oddsBox .items .title .odd[data-v-789ad0bd] {
    height: 0.93333rem;
    width: 9.36rem;
}

.oddsBox .items .tabHead[data-v-789ad0bd] {
    margin-top: 0.26667rem;
    background: var(--sheet_nva_color);
    border-radius: 0.13333rem 0.13333rem 0 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    min-height: 1.06667rem;
}

.oddsBox .items .tabHead span[data-v-789ad0bd] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: #fff;
    font-size: 0.4rem;
    font-weight: 700;
    text-align: center;
}

.oddsBox .items .tabHead span[data-v-789ad0bd]:not(:last-of-type) {
    border-right: 0.01333rem solid var(--borderColor-5);
}

.oddsBox .items .tabHead.h2 span[data-v-789ad0bd] {
    font-size: 0.32rem;
}

.oddsBox .items .tabCon1[data-v-789ad0bd] {
    box-shadow: var(--BoxShadowColor-9);
    border-radius: 0 0 0.13333rem 0.13333rem;
    overflow: hidden;
    margin-bottom: 0.4rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.oddsBox .items .tabCon1>div[data-v-789ad0bd] {
    width: 50%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.oddsBox .items .tabCon1>div[data-v-789ad0bd]:not(:last-of-type) {
    border-right: 0.01333rem solid var(--gray-color-1);
}

.oddsBox .items .tabCon1 .item[data-v-789ad0bd] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.oddsBox .items .tabCon1 .item>div[data-v-789ad0bd] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: var(--text_color_L1);
    font-size: 0.34667rem;
    min-height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
}

.oddsBox .items .tabCon1 .item>div[data-v-789ad0bd]:not(:last-of-type) {
    border-right: 0.01333rem solid var(--gray-color-1);
}

.oddsBox .items .tabCon1 .item>div[data-v-789ad0bd]:nth-child(2n) {
    font-size: 0.37333rem;
    font-weight: 500;
}

.oddsBox .items .tabCon1 .item[data-v-789ad0bd]:nth-child(n) {
    background-color: var(--textW);
}

.oddsBox .items .tabCon1 .item[data-v-789ad0bd]:nth-child(2n) {
    background-color: var(--sheet_detail_bg_color);
}

.oddsBox .items .tabCon1.c2[data-v-789ad0bd] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.oddsBox .items .tabCon1.c2 .itemR[data-v-789ad0bd] {
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    width: 100%;
}

.oddsBox .items .tabCon1.c2 .itemR>div[data-v-789ad0bd] {
    font-size: 0.37333rem;
    font-weight: 500;
}

.oddsBox .items .tabCon1.c2 .itemR>div[data-v-789ad0bd]:first-of-type {
    color: var(--main-color);
    font-size: 0.32rem;
}

.oddsBox .items .tabCon2[data-v-789ad0bd] {
    box-shadow: var(--BoxShadowColor-9);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    border-radius: 0 0 0.13333rem 0.13333rem;
    overflow: hidden;
}

.oddsBox .items .tabCon2>div[data-v-789ad0bd] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    min-height: 1.06667rem;
    font-weight: 500;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.oddsBox .items .tabCon2>div[data-v-789ad0bd]:nth-child(n) {
    background-color: var(--textW);
}

.oddsBox .items .tabCon2>div[data-v-789ad0bd]:nth-child(2n) {
    background-color: var(--sheet_detail_bg_color);
}

.van-toast[data-v-fa33b84e] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-fa33b84e] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-fa33b84e] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-fa33b84e] {
    height: 80%;
}

.playBox[data-v-fa33b84e] {
    height: 100vb;
}

.playBox .con[data-v-fa33b84e] {
    background: var(--bg_color_L2);
    box-shadow: var(--BoxShadowColor-9);
    padding: 0.26667rem;
    margin: 0 0.4rem;
    border-radius: 0.13333rem;
    min-height: 100%;
}

.playBox .con h1[data-v-fa33b84e] {
    color: var(--main-color);
    font-size: 0.42667rem;
    margin: 0.13333rem 0;
}

.playBox .con h1 .icon[data-v-fa33b84e] {
    margin-right: 0.06667rem;
}

.playBox .con .tip[data-v-fa33b84e] {
    color: var(--text_color_L2);
    font-size: 0.34667rem;
    padding-left: 0.53333rem;
    margin-bottom: 0.66667rem;
}

.playBox .con .txt[data-v-fa33b84e] {
    border: 0.01333rem solid var(--gray-color-1);
    border-radius: 0.26667rem;
    padding: 0.26667rem 0.53333rem;
    color: var(--text_color_L2);
}

.playBox .con .txt>div[data-v-fa33b84e] {
    margin-bottom: 0.26667rem;
}

.playBox .con .txt .num[data-v-fa33b84e] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.13333rem;
}

.playBox .con .txt .num span[data-v-fa33b84e] {
    border-radius: 0.08rem;
    background: var(--bg_color_L3);
    padding: 0.06667rem 0.2rem;
    color: var(--text_color_L2);
    font-size: 0.34667rem;
}

[data-v-fa33b84e] .red {
    color: var(--norm_red-color);
}

[data-v-fa33b84e] .van-tabs,
[data-v-fa33b84e] .van-tabs .van-tabs__content {
    height: calc(100% - 1.6rem);
}

[data-v-fa33b84e] .van-tabs .van-tabs__content .van-tab__panel {
    height: 100%;
}

[data-v-fa33b84e] .van-tabs__wrap {
    margin: 0.26667rem 0;
    height: 1.06667rem;
    line-height: 1.06667rem;
}

[data-v-fa33b84e] .van-tabs__wrap .van-tabs__nav {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--bg_color_L2);
    border: 0.01333rem solid var(--textW);
    border-radius: 0.13333rem;
    overflow: hidden;
}

[data-v-fa33b84e] .van-tabs__wrap .van-tab--card {
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-right: none;
    min-width: 2.66667rem;
}

[data-v-fa33b84e] .van-tabs__wrap .van-tab--active {
    border-radius: 0.13333rem;
    background: var(--main_gradient-color2);
    border-right: 0.01333rem solid var(--walletBgColor-1);
    color: var(--textW);
    font-weight: 700;
}

.van-toast[data-v-34a342e1] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-34a342e1] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-34a342e1] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-34a342e1] {
    height: 80%;
}

.MG[data-v-34a342e1] {
    padding: 0.4rem 0.26667rem;
}

.MG[data-v-34a342e1] .ar-searchbar__selector {
    width: 100%;
}

.van-toast[data-v-7dd1adab] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-7dd1adab] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-7dd1adab] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-7dd1adab] {
    height: 80%;
}

.Wallet__C[data-v-7dd1adab] {
    padding: 0.48rem 0.34667rem 0;
    position: relative;
}

.Wallet__C[data-v-7dd1adab]:before {
    content: "";
    display: block;
    width: 100%;
    height: 7.66667rem;
    background: var(--light-main_gradient-color, var(--bg_color_L2));
    border-radius: 0 0 1.53333rem 1.53333rem;
    position: absolute;
    z-index: 0;
    top: 0;
    left: 0;
}

html:lang(ar) .Wallet__C[data-v-7dd1adab]:before {
    left: unset;
    right: 0;
}

.Wallet__C-balance[data-v-7dd1adab] {
    min-height: 3.57333rem;
    background-color: var(--bg_color_L3);
    background-image: url(/assets/png/walletbg-f5c62a26.png);
    background-repeat: no-repeat;
    background-size: contain;
    border-radius: 0.53333rem;
    padding: 0.46667rem 0.54667rem 0.4rem;
    position: relative;
    z-index: 0;
}

.Wallet__C-balance-l1[data-v-7dd1adab] {
    min-height: 0.58667rem;
    line-height: 0.58667rem;
    text-align: center;
    font-weight: 700;
    font-size: 0.48rem;
    color: var(--darkTextW, var(--text_color_L1));
    overflow: hidden;
}

.Wallet__C-balance-l1>div[data-v-7dd1adab] {
    position: relative;
    word-break: break-all;
    pointer-events: none;
    width: -webkit-fit-content;
    width: fit-content;
    margin: auto;
}

.Wallet__C-balance-l1>div[data-v-7dd1adab]:after {
    content: "";
    display: block;
    position: absolute;
    right: -1.33333rem;
    top: 0;
    width: 0.48rem;
    height: 0.48rem;
    background-image: url(/assets/png/refireshIcon-2bc1b49f.png);
    background-position: center;
    background-repeat: no-repeat;
    background-size: 0.48rem;
    pointer-events: auto;
}

.Wallet__C-balance-l2[data-v-7dd1adab] {
    height: 0.53333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: space-evenly;
    -webkit-justify-content: space-evenly;
    justify-content: space-evenly;
    margin-top: 0.18667rem;
    font-size: 0.34667rem;
    color: var(--text_color_L1);
}

.Wallet__C-balance-l2>div[data-v-7dd1adab] {
    padding-left: 0.66667rem;
    background-image: url(/assets/png/wallet-3f0340b6.png);
    background-position: 0 0;
    background-repeat: no-repeat;
    background-size: 0.53333rem;
}

.Wallet__C-balance-l3[data-v-7dd1adab] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    margin-top: 0.46667rem;
}

.Wallet__C-balance-l3>div[data-v-7dd1adab] {
    width: 3.46667rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    background: var(--norm_red-color);
    border-radius: 0.53333rem;
    font-weight: 600;
    font-size: 0.4rem;
    color: #fff;
    text-align: center;
}

.Wallet__C-balance-l3>div+div[data-v-7dd1adab] {
    background: var(--norm_green-color);
}

.van-toast[data-v-17d56002] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-17d56002] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-17d56002] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-17d56002] {
    height: 80%;
}

.GameList__C[data-v-17d56002] {
    height: 2.4rem;
    width: calc(100% - 0.69333rem);
    background: var(--bg_color_L3);
    border-radius: 0.26667rem;
    position: relative;
    margin: 0.34667rem auto 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameList__C-item[data-v-17d56002] {
    width: 25%;
    height: 100%;
    position: relative;
    z-index: 2;
    text-align: center;
}

.GameList__C-item>div[data-v-17d56002] {
    height: 100%;
    line-height: 0.4rem;
    font-size: 0.32rem;
    margin: auto;
    color: var(--text_color_L2);
    padding-top: 1.44rem;
    background-image: url(/assets/png/time-5d4e96a3.png);
    background-size: 1.17333rem;
    background-position: center 0.18667rem;
    background-repeat: no-repeat;
}

.GameList__C-item.active[data-v-17d56002] {
    background: var(--main_gradient-color2);
    border-radius: 0.26667rem;
}

.GameList__C-item.active>div[data-v-17d56002] {
    color: var(--text_color_L4);
    background-image: url(/assets/png/time_a-714e9b6a.png);
}

.van-toast[data-v-0bba67ea] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-0bba67ea] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-0bba67ea] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-0bba67ea] {
    height: 80%;
}

.TimeLeft__C-PreSale[data-v-0bba67ea] {
    width: 7.04rem;
}

.TimeLeft__C-PreSale-head[data-v-0bba67ea] {
    height: 1.2rem;
    line-height: 1.2rem;
    color: var(--text_color_L4);
    font-size: 0.4rem;
    text-align: center;
    background: var(--main_gradient-color);
}

.TimeLeft__C-PreSale-body[data-v-0bba67ea] {
    max-height: 8rem;
    overflow-y: auto;
    color: var(--text_color_L1);
    padding: 0.4rem;
    font-size: 0.32rem;
    line-height: 0.8rem;
}

.TimeLeft__C-PreSale-body[data-v-0bba67ea] p {
    margin-bottom: 0.2rem;
    line-height: 0.53333rem;
    color: var(--text_color_L1);
    word-break: break-all;
}

.TimeLeft__C-PreSale-foot[data-v-0bba67ea] {
    height: 1.86667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background: var(--bg_color_L2);
}

.TimeLeft__C-PreSale-foot-btn[data-v-0bba67ea] {
    width: 60%;
    background: var(--main_gradient-color);
    border-radius: 0.53333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    font-size: 0.37333rem;
    color: #fff;
}

.van-toast[data-v-69f351dd] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-69f351dd] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-69f351dd] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-69f351dd] {
    height: 80%;
}

.FDTL__C[data-v-69f351dd] {
    width: calc(100% - 0.69333rem);
    margin: 0.34667rem auto 0;
    background-color: var(--darkBg, var(--bg_color_L2));
    background-repeat: no-repeat;
    background-size: cover;
    background-position: 0.01333rem center;
    padding: 0.42667rem 0.29333rem 0.45333rem;
    border-radius: 0.26667rem 0.26667rem 0 0;
}

.FDTL__C-rule[data-v-69f351dd] {
    height: 0.61333rem;
    width: 2.93333rem;
    font-size: 0.29333rem;
    text-align: center;
    border: 0.01333rem solid var(--main-color);
    border-radius: 0.8rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    color: var(--darkLight, var(--main-color));
    margin-left: 0.4rem;
    gap: 0.06667rem;
}

.FDTL__C-rule svg[data-v-69f351dd] {
    color: var(--secondary);
    height: 0.42667rem;
    width: 0.42667rem;
}

.FDTL__C-l1[data-v-69f351dd] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 0.61333rem;
    color: var(--text_color_L2);
    font-size: 0.32rem;
}

.FDTL__C-l1 .left[data-v-69f351dd] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 0.61333rem;
}

.FDTL__C-l1>div[data-v-69f351dd]:not(.left) {
    -webkit-align-self: flex-start;
    align-self: flex-start;
}

.FDTL__C-l2[data-v-69f351dd] {
    height: 0.8rem;
    line-height: 0.8rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    font-weight: 700;
    font-size: 0.53333rem;
    color: var(--text_color_L1);
}

.FDTL__C-l3[data-v-69f351dd] {
    height: 3.09333rem;
    margin-top: 0.48rem;
    background: #00b977;
    border-radius: 0.18667rem;
    position: relative;
    padding: 0.26667rem;
}

.FDTL__C-l3[data-v-69f351dd]:after,
.FDTL__C-l3[data-v-69f351dd]:before {
    content: "";
    display: block;
    width: 0.13333rem;
    height: 0.69333rem;
    position: absolute;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    z-index: 0;
    background: #008b59;
}

.FDTL__C-l3[data-v-69f351dd]:before {
    border-radius: 0.13333rem 0 0 0.13333rem;
    left: -0.13333rem;
}

.FDTL__C-l3[data-v-69f351dd]:after {
    border-radius: 0 0.13333rem 0.13333rem 0;
    right: -0.13333rem;
}

.FDTL__C-l3 .box[data-v-69f351dd] {
    background: #003c26;
    border-radius: 0.13333rem;
    height: 100%;
    width: 100%;
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0.13333rem;
}

.FDTL__C-l3 .box[data-v-69f351dd]:after,
.FDTL__C-l3 .box[data-v-69f351dd]:before {
    position: absolute;
    width: 0;
    height: 0;
    border-top: 0.18667rem solid transparent;
    border-bottom: 0.18667rem solid transparent;
    content: "";
    z-index: 3;
}

.FDTL__C-l3 .box[data-v-69f351dd]:before {
    left: 0;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    border-right: 0.53333rem solid transparent;
    border-left: 0.53333rem solid #00b977;
}

.FDTL__C-l3 .box[data-v-69f351dd]:after {
    right: 0;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    border-left: 0.53333rem solid transparent;
    border-right: 0.53333rem solid #00b977;
}

.FDTL__C-l3 .box .slot-column[data-v-69f351dd] {
    display: inline-block;
    width: calc((100% - 0.53333rem) / 5);
    height: 100%;
    border-radius: 0.10667rem;
    overflow: hidden;
    background: #727272;
    vertical-align: bottom;
    position: relative;
    text-align: center;
}

@-webkit-keyframes slotScroll-69f351dd {
    0% {
        -webkit-transform: translateY(-1.44rem);
        transform: translateY(-1.44rem);
    }
    to {
        -webkit-transform: translateY(-42.66667rem);
        transform: translateY(-29.33333rem);
    }
}

@keyframes slotScroll-69f351dd {
    0% {
        -webkit-transform: translateY(-1.44rem);
        transform: translateY(-1.44rem);
    }
    to {
        -webkit-transform: translateY(-42.66667rem);
        transform: translateY(-29.33333rem);
    }
}

.FDTL__C-l3 .box .slot-column .slot-transform[data-v-69f351dd] {
    -webkit-transform: translateY(-2.73333rem);
    transform: translateY(-2.73333rem);
}

.FDTL__C-l3 .box .slot-column .slot-transform.slot-scroll[data-v-69f351dd] {
    -webkit-animation: slotScroll-69f351dd 3s cubic-bezier(0.65, 0.02, 0.65, 1.06);
    animation: slotScroll-69f351dd 3s cubic-bezier(0.65, 0.02, 0.65, 1.06);
    -webkit-animation-fill-mode: forwards;
    animation-fill-mode: forwards;
}

.FDTL__C-l3 .box .slot-column .slot-transform.slot-scroll.transform1[data-v-69f351dd] {
    -webkit-animation-delay: 0.12s;
    animation-delay: 0.12s;
}

.FDTL__C-l3 .box .slot-column .slot-transform.slot-scroll.transform2[data-v-69f351dd] {
    -webkit-animation-delay: 0.24s;
    animation-delay: 0.24s;
}

.FDTL__C-l3 .box .slot-column .slot-transform.slot-scroll.transform3[data-v-69f351dd] {
    -webkit-animation-delay: 0.36s;
    animation-delay: 0.36s;
}

.FDTL__C-l3 .box .slot-column .slot-transform.slot-scroll.transform4[data-v-69f351dd] {
    -webkit-animation-delay: 0.48s;
    animation-delay: 0.48s;
}

.FDTL__C-l3 .box .slot-column .slot-transform.transform0 .slot-num[data-v-69f351dd] {
    background: #17b15e;
    color: #fff;
}

.FDTL__C-l3 .box .slot-column .slot-transform .slot-num[data-v-69f351dd] {
    width: 1.46667rem;
    height: 1.46667rem;
    line-height: 1.46667rem;
    background: #e1e1ec;
    border-radius: 50%;
    font-size: 0.8rem;
    color: var(--text_color_L2);
    font-weight: 700;
    margin: 0 auto 0.10667rem;
}

.FDTL__C-time[data-v-69f351dd] {
    height: 0.8rem;
    line-height: 0.8rem;
    bottom: 0.29333rem;
    right: 0.32rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

html:lang(ar) .FDTL__C-time[data-v-69f351dd] {
    direction: ltr;
}

.FDTL__C-time>div[data-v-69f351dd] {
    background: var(--bg_color_L3);
    border-radius: 0.13333rem;
    color: var(--main-color);
    font-weight: 700;
    font-size: 0.48rem;
    text-align: center;
    padding: 0 0.13333rem;
    background-position: center;
    background-size: 100% 100%;
    background-repeat: no-repeat;
}

.FDTL__C-time>div[notime][data-v-69f351dd] {
    background-color: transparent !important;
}

.FDTL__C-time>div+div[data-v-69f351dd] {
    margin-left: 0.12rem;
}

.van-toast[data-v-baf77bdf] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-baf77bdf] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-baf77bdf] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-baf77bdf] {
    height: 80%;
}

.FDB__C-nav[data-v-baf77bdf] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    border-bottom: 0.01333rem solid var(--Dividing-line_color);
}

.FDB__C-nav>div[data-v-baf77bdf] {
    width: 1.06667rem;
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--button_dis_color);
    font-size: 0.48rem;
    font-weight: 700;
    color: #fff;
    border-radius: 0.25333rem 0.25333rem 0 0;
    position: relative;
    margin-right: 0.26667rem;
    text-align: center;
}

.FDB__C-nav>div[data-v-baf77bdf]:last-child {
    font-size: 0.42667rem;
}

.FDB__C-nav>div.active[data-v-baf77bdf] {
    background: var(--main-color);
    color: var(--text_color_L4);
}

.FDB__C-nav>div.active[data-v-baf77bdf]:after {
    background: -webkit-radial-gradient( 100% 0, circle, var(--bg_color_L2) 0.26667rem, var(--main-color) 0.26667rem);
    background: radial-gradient( circle at 100% 0, var(--bg_color_L2) 0.26667rem, var(--main-color) 0.26667rem);
}

.FDB__C-nav>div[data-v-baf77bdf]:after {
    content: "";
    width: 0.26667rem;
    height: 0.26667rem;
    position: absolute;
    bottom: 0;
    right: -0.26667rem;
    z-index: 9;
    background: var(--linerGradient-70);
}

html:lang(ar) .FDB__C-nav>div[data-v-baf77bdf]:after {
    left: -0.26667rem;
    right: unset;
}

.FDB__C-H[data-v-baf77bdf] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 0.88rem;
    line-height: 0.88rem;
    margin-top: 0.32rem;
    font-size: 0.37333rem;
    color: #fff;
}

.FDB__C-H>div[data-v-baf77bdf] {
    width: calc((100% - 1.36rem) / 4);
    height: 100%;
    background: var(--button_dis_color);
    border-radius: 0.13333rem;
    padding: 0 0.16rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.FDB__C-H>div.active[data-v-baf77bdf] {
    color: #fff;
}

.FDB__C-H>div.active[data-v-baf77bdf]:nth-child(1) {
    background: var(--norm_secondary-color);
}

.FDB__C-H>div.active[data-v-baf77bdf]:nth-child(2) {
    background: var(--norm_bule-color);
}

.FDB__C-H>div.active[data-v-baf77bdf]:nth-child(3) {
    background: var(--norm_red-color);
}

.FDB__C-H>div.active[data-v-baf77bdf]:nth-child(4) {
    background: var(--norm_Purple-color);
}

.FDB__C-Num[data-v-baf77bdf] {
    padding: 0.34667rem 0 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    height: 3.33333rem;
}

.FDB__C-Num>div[data-v-baf77bdf] {
    width: 20%;
    height: 50%;
}

.FDB__C-Num>div .round[data-v-baf77bdf] {
    width: 0.88rem;
    height: 0.88rem;
    border: 0.01333rem solid var(--text_color_L3);
    border-radius: 50%;
    color: var(--text_color_L3);
    font-size: 0.37333rem;
    text-align: center;
    line-height: 0.88rem;
    margin: auto;
}

.FDB__C-Num>div .rate[data-v-baf77bdf] {
    line-height: 0.32rem;
    font-size: 0.32rem;
    color: var(--text_color_L2);
    text-align: center;
}

.FDB__C-Num>div.active .round[data-v-baf77bdf] {
    background: var(--main-color);
    border: 0.01333rem solid var(--main-color);
    color: #fff;
}

.van-toast[data-v-7181abf7] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-7181abf7] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-7181abf7] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-7181abf7] {
    height: 80%;
}

.Betting__Popup-body[data-v-7181abf7] {
    padding: 0.50667rem 0.34667rem 0.53333rem;
}

.Betting__Popup-body-line[data-v-7181abf7] {
    font-size: 0.42667rem;
    color: var(--text_color_L1);
    height: 0.74667rem;
    line-height: 0.74667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Betting__Popup-body-line-list[data-v-7181abf7] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Betting__Popup-body-line-item[data-v-7181abf7] {
    padding: 0 0.21333rem;
    background: var(--bg_color_L3);
    color: var(--text_color_L2);
    border-radius: 0.08rem;
}

.Betting__Popup-body-line-item+div[data-v-7181abf7] {
    margin-left: 0.16rem;
}

.Betting__Popup-body-line+div[data-v-7181abf7] {
    margin-top: 0.4rem;
}

.Betting__Popup-body-line-btnL[data-v-7181abf7] {
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.Betting__Popup-body-line[data-v-7181abf7]:last-child {
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    justify-content: flex-start;
}

.Betting__Popup-foot[data-v-7181abf7] {
    height: 0.96rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    text-align: center;
    line-height: 0.96rem;
    font-size: 0.37333rem;
}

.Betting__Popup-foot-c[data-v-7181abf7] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    background: var(--bg_color_L3);
    color: var(--text_color_L2);
}

.Betting__Popup-foot-s[data-v-7181abf7] {
    -webkit-box-flex: 2;
    -webkit-flex: 2;
    flex: 2;
    background: var(--main-color);
    color: var(--text_color_L4);
}

.Betting__Popup-btn[data-v-7181abf7] {
    width: 0.74667rem;
    height: 0.74667rem;
    pointer-events: none;
    text-align: center;
    font-size: 0.66667rem;
    padding: 0;
    background: var(--button_dis_color);
    color: var(--button_dis_color);
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    border-radius: 0.08rem;
}

.Betting__Popup-input[data-v-7181abf7] {
    padding: 0.02667rem 0.26667rem;
    width: 2.10667rem;
    margin: 0 0.16rem;
    background-color: var(--bg_color_L1);
    color: var(--text_color_L4);
}

.Betting__Popup-input[data-v-7181abf7]:after {
    content: none;
}

.Betting__Popup-input[data-v-7181abf7] .van-field__control {
    text-align: center;
    font-size: 0.37333rem;
    line-height: 0.72rem;
}

.Betting__Popup-agree[data-v-7181abf7] {
    padding-left: 0.8rem;
    background-image: url(/assets/png/agree-b-47b8f86d.png);
    background-repeat: no-repeat;
    background-position: left center;
    background-size: 0.64rem;
    font-size: 0.32rem;
    color: var(--colorText-3);
}

html:lang(ar) .Betting__Popup-agree[data-v-7181abf7] {
    background-position: right center;
}

.Betting__Popup-agree.active[data-v-7181abf7] {
    background-image: url(/assets/png/agree-a-32b06ce9.png);
}

.Betting__Popup-preSaleShow[data-v-7181abf7] {
    margin-left: 0.34667rem;
    font-size: 0.32rem;
    color: var(--norm_red-color);
}

.Betting__Popup-PreSale[data-v-7181abf7] {
    width: 7.04rem;
}

.Betting__Popup-PreSale-head[data-v-7181abf7] {
    height: 1.2rem;
    line-height: 1.2rem;
    color: var(--text_color_L4);
    font-size: 0.4rem;
    text-align: center;
    background: var(--main_gradient-color);
}

.Betting__Popup-PreSale-body[data-v-7181abf7] {
    max-height: 8rem;
    overflow-y: auto;
    color: var(--text_color_L1);
    padding: 0.4rem;
    font-size: 0.32rem;
    line-height: 0.8rem;
}

.Betting__Popup-PreSale-body[data-v-7181abf7] p {
    margin-bottom: 0.2rem;
    line-height: 0.53333rem;
}

.Betting__Popup-PreSale-foot[data-v-7181abf7] {
    height: 1.86667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.Betting__Popup-PreSale-foot-btn[data-v-7181abf7] {
    width: 60%;
    background: var(--main_gradient-color);
    border-radius: 0.53333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    font-size: 0.37333rem;
    color: var(--text_color_L4);
}

.bgcolor[data-v-7181abf7] {
    pointer-events: all;
    color: var(--text_color_L4);
    background: var(--main-color);
}

.van-toast[data-v-28e57f6a] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-28e57f6a] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-28e57f6a] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-28e57f6a] {
    height: 80%;
}

.FDB__C[data-v-28e57f6a] {
    width: calc(100% - 0.69333rem);
    margin: auto;
    background-color: var(--darkBg, var(--bg_color_L2));
    padding: 0.34667rem 0.34667rem 0;
    position: relative;
}

.FDB__C-mark[data-v-28e57f6a] {
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    position: absolute;
    z-index: 99;
    top: 0;
    left: 0;
    color: var(--main-color);
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

html:lang(ar) .FDB__C-mark[data-v-28e57f6a] {
    direction: ltr;
}

.FDB__C-mark>div[data-v-28e57f6a] {
    display: inline-block;
    border-radius: 0.4rem;
    padding: 0 0.4rem;
    background-color: var(--bg_color_L3);
    font-weight: 700;
    font-size: 3.73333rem;
}

.FDB__C-mark>div+div[data-v-28e57f6a] {
    margin-left: 1.04rem;
}

.van-toast[data-v-72f81e71] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-72f81e71] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-72f81e71] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-72f81e71] {
    height: 80%;
}

.RecordNav__C[data-v-72f81e71] {
    width: calc(100% - 0.69333rem);
    height: 0.96rem;
    line-height: 0.96rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    margin: 0.32rem auto 0;
}

.RecordNav__C>div[data-v-72f81e71] {
    width: calc((100% - 0.50667rem) / 3);
    height: 100%;
    background: var(--bg_color_L2);
    border-radius: 0.21333rem;
    font-size: 0.37333rem;
    color: var(--text_color_L2);
    text-align: center;
    overflow: hidden;
}

.RecordNav__C>div.active[data-v-72f81e71] {
    background: var(--main_gradient-color, var(--main_gradient-color));
    font-weight: 600;
    color: var(--text_color_L4);
}

.van-toast[data-v-9215aba8] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-9215aba8] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-9215aba8] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-9215aba8] {
    height: 80%;
}

.GameRecord__C[data-v-9215aba8] {
    width: calc(100% - 0.69333rem);
    margin: 0.48rem auto 0;
    text-align: center;
    font-size: 0.32rem;
}

.GameRecord__C-head[data-v-9215aba8] {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--sheet_nva_color);
    border-radius: 0.13333rem 0.13333rem 0 0;
    font-weight: 700;
    font-size: 0.34667rem;
    color: #fff;
}

.GameRecord__C-body[data-v-9215aba8] {
    line-height: 1.06667rem;
    color: var(--darkTextW, var(--text_color_L1));
}

.GameRecord__C-body-empty[data-v-9215aba8] {
    height: 5.33333rem;
}

.GameRecord__C-body>div[data-v-9215aba8] {
    background: var(--darkBg, var(--bg_color_L2));
    color: var(--text_color_L1);
}

.GameRecord__C-body>div+div[data-v-9215aba8] {
    border-top: 0.01333rem solid var(--bgDark-2, var(--gray-color-1));
}

.GameRecord__C-body-premium[data-v-9215aba8] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 100%;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.GameRecord__C-body-premium>div[data-v-9215aba8] {
    width: 0.53333rem;
    height: 0.53333rem;
    background-repeat: no-repeat;
    background-size: 0.53333rem;
    background-position: center;
}

.GameRecord__C-body-premium .n1[data-v-9215aba8] {
    background-image: url(/assets/png/n1-584b8878.png);
}

.GameRecord__C-body-premium .n2[data-v-9215aba8] {
    background-image: url(/assets/png/n2-447499dc.png);
}

.GameRecord__C-body-premium .n3[data-v-9215aba8] {
    background-image: url(/assets/png/n3-1432a6bd.png);
}

.GameRecord__C-body-premium .n4[data-v-9215aba8] {
    background-image: url(/assets/png/n4-9d453819.png);
}

.GameRecord__C-body-premium .n5[data-v-9215aba8] {
    background-image: url(/assets/png/n5-09b70e91.png);
}

.GameRecord__C-body-premium .n6[data-v-9215aba8] {
    background-image: url(/assets/png/n6-b68c6bb6.png);
}

.GameRecord__C-body .numList[data-v-9215aba8] {
    height: 100%;
    width: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.GameRecord__C-body .numList>.numItem[data-v-9215aba8] {
    width: 0.53333rem;
    height: 0.53333rem;
    border-radius: 50%;
    border: 0.01333rem solid var(--darkLight, var(--text_color_L2));
    text-align: center;
    line-height: 0.53333rem;
    font-size: 0.32rem;
    color: var(--darkLight, var(--text_color_L1));
}

.GameRecord__C-body .numList>.numItem+.numItem[data-v-9215aba8] {
    margin-left: 0.10667rem;
}

.GameRecord__C-body .redNumItem[data-v-9215aba8] {
    border-radius: 50%;
    color: var(--text_color_L4);
    font-size: 0.29333rem;
    text-align: center;
    line-height: 0.53333rem;
    background: var(--main-color);
    padding: 0.12rem;
}

.GameRecord__C-foot[data-v-9215aba8] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    color: var(--text_color_L2);
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.GameRecord__C-foot-previous[data-v-9215aba8],
.GameRecord__C-foot-next[data-v-9215aba8] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot-previous.disabled[data-v-9215aba8],
.GameRecord__C-foot-next.disabled[data-v-9215aba8] {
    background: var(--bg_color_L3);
    pointer-events: none;
}

.GameRecord__C-foot-previous.disabled .GameRecord__C-icon[data-v-9215aba8],
.GameRecord__C-foot-next.disabled .GameRecord__C-icon[data-v-9215aba8] {
    color: var(--text_color_L3);
}

.GameRecord__C-foot-previous .GameRecord__C-icon[data-v-9215aba8],
.GameRecord__C-foot-next .GameRecord__C-icon[data-v-9215aba8] {
    color: var(--text_color_L4);
}

.van-toast[data-v-9d93d892] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-9d93d892] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-9d93d892] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-9d93d892] {
    height: 80%;
}

.Trend__C[data-v-9d93d892] {
    width: calc(100% - 0.69333rem);
    margin: 0.48rem auto 0;
    text-align: center;
    font-size: 0.32rem;
}

.Trend__C-head[data-v-9d93d892] {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--sheet_nva_color);
    border-radius: 0.13333rem 0.13333rem 0 0;
    font-weight: 700;
    font-size: 0.34667rem;
    color: #fff;
}

.Trend__C-body1[data-v-9d93d892] {
    background-color: var(--darkBg, var(--bg_color_L2));
    margin-bottom: 0.50667rem;
    height: 5.33333rem;
    box-shadow: var(--boxShadowColor-35);
    border-radius: 0.26667rem;
    padding: 0.32rem;
}

.Trend__C-body1-line[data-v-9d93d892] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    font-size: 0.34667rem;
    color: var(--text_color_L1);
    height: 0.41333rem;
}

.Trend__C-body1-line>div[data-v-9d93d892]:first-child {
    width: 3.70667rem;
    padding-left: 0.26667rem;
    text-align: left;
}

.Trend__C-body1-line-num[data-v-9d93d892] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    padding-right: 0.2rem;
}

.Trend__C-body1-line-num>div[data-v-9d93d892] {
    width: 0.48rem;
    height: 0.48rem;
    line-height: 0.48rem;
    font-size: 0.34667rem;
    color: var(--text_color_L2);
    text-align: center;
}

.Trend__C-body1-line.lottery .Trend__C-body1-line-num>div[data-v-9d93d892] {
    border-radius: 50%;
    border: 0.01333rem solid var(--LotteryTrendColor);
    color: var(--LotteryTrendColor) !important;
}

.Trend__C-body1-line+.Trend__C-body1-line[data-v-9d93d892] {
    margin-top: 0.26667rem;
}

.Trend__C-body1-line[data-v-9d93d892]:first-child {
    padding-top: 0.34667rem;
    height: 0.76rem;
    padding-left: 0.26667rem;
}

.Trend__C-body1-line-lottery[data-v-9d93d892] {
    height: 0.48rem;
}

.Trend__C-body2[data-v-9d93d892] {
    font-size: 0.32rem;
    background-color: var(--darkBg, var(--bg_color_L2));
}

.Trend__C-body2>div[data-v-9d93d892] {
    height: 1.33333rem;
    padding: 0.45333rem 0.26667rem;
    border-top: 0.01333rem solid var(--gray-color-1);
}

.Trend__C-body2>div.Trend__C-body2-empty[data-v-9d93d892] {
    height: 5.33333rem;
}

.Trend__C-body2-IssueNumber[data-v-9d93d892] {
    color: var(--text_color_L1);
    text-align: left;
}

.Trend__C-body2-Num[data-v-9d93d892] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    position: relative;
    height: 0.42667rem;
}

.Trend__C-body2-Num>div[data-v-9d93d892] {
    width: 0.4rem;
    height: 0.4rem;
    line-height: 0.4rem;
    text-align: center;
    border-radius: 50%;
}

.Trend__C-body2-Num-item[data-v-9d93d892] {
    border: 0.01333rem solid var(--text_color_L3);
    color: var(--text_color_L3);
    margin-right: 0.10667rem;
}

.Trend__C-body2-Num-item.action[data-v-9d93d892] {
    position: relative;
    z-index: 10;
    border: none;
    color: #fff;
    background: var(--norm_red-color);
}

.Trend__C-body2-Num-BS[data-v-9d93d892] {
    color: #fff;
    border: 0.01333rem solid var(--norm_bule-color);
    background-color: var(--norm_bule-color);
    margin-left: 0.16rem;
}

.Trend__C-body2-Num-BS.isB[data-v-9d93d892] {
    border: 0.01333rem solid var(--norm_secondary-color);
    background: var(--norm_secondary-color);
    color: #fff;
}

.Trend__C-body2-Num-OE[data-v-9d93d892] {
    color: var(--norm_Purple-color);
    border: 0.01333rem solid var(--norm_Purple-color);
    margin-left: 0.08rem;
}

.Trend__C-body2-Num-OE.isE[data-v-9d93d892] {
    border: 0.01333rem solid var(--norm_green-color);
    background: var(--norm_green-color);
    color: #fff;
}

.Trend__C-body2 .line-canvas[data-v-9d93d892] {
    position: absolute;
    top: 50%;
    left: 0;
    height: 1.33333rem;
    width: calc(100% - 0.64rem);
    z-index: 9;
}

html:lang(ar) .Trend__C-body2 .line-canvas[data-v-9d93d892] {
    left: unset;
    right: 0;
    -webkit-transform: scaleX(-1);
    transform: scaleX(-1);
}

.Trend__C-foot[data-v-9d93d892] {
    height: 1.86667rem;
    background-color: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    color: var(--darkTextW, var(--text_color_L2));
}

.Trend__C-foot-previous[data-v-9d93d892],
.Trend__C-foot-next[data-v-9d93d892] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.Trend__C-foot-previous.disabled[data-v-9d93d892],
.Trend__C-foot-next.disabled[data-v-9d93d892] {
    background: var(--button_dis_color);
    pointer-events: none;
}

.Trend__C-foot-previous.disabled .Trend__C-icon[data-v-9d93d892],
.Trend__C-foot-next.disabled .Trend__C-icon[data-v-9d93d892] {
    color: var(--text_color_L3);
}

.Trend__C-foot-previous .Trend__C-icon[data-v-9d93d892],
.Trend__C-foot-next .Trend__C-icon[data-v-9d93d892] {
    color: var(--text_color_L4);
}

.Trend__C-nav[data-v-9d93d892] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    border-bottom: 0.01333rem solid var(--Dividing-line_color);
    overflow: hidden;
}

.Trend__C-nav>div[data-v-9d93d892] {
    width: 1.06667rem;
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--bg_color_L3);
    font-size: 0.48rem;
    font-weight: 700;
    color: var(--text_color_L2);
    border-radius: 0.25333rem 0.25333rem 0 0;
    position: relative;
    margin-right: 0.26667rem;
    text-align: center;
    border-radius: 19px 19px 0 0;
}

.Trend__C-nav>div[data-v-9d93d892]:last-child {
    font-size: 0.42667rem;
}

.Trend__C-nav>div.active[data-v-9d93d892] {
    background-color: var(--main-color);
    color: var(--text_color_L4);
}

.Trend__C-nav>div.active[data-v-9d93d892]:after {
    background: -webkit-radial-gradient( 100% 0, circle, var(--bg_color_L2) 0.26667rem, var(--main-color) 0.26667rem);
    background: radial-gradient( circle at 100% 0, var(--bg_color_L2) 0.26667rem, var(--main-color) 0.26667rem);
}

.Trend__C-nav>div.active[data-v-9d93d892]:before {
    content: "";
    width: 0.26667rem;
    height: 0.26667rem;
    position: absolute;
    bottom: 0;
    left: -0.26667rem;
    z-index: 9;
}

html:lang(ar) .Trend__C-nav>div.active[data-v-9d93d892]:before {
    right: -0.26667rem;
    left: unset;
}

.Trend__C-nav>div[data-v-9d93d892]:after {
    content: "";
    width: 0.26667rem;
    height: 0.26667rem;
    position: absolute;
    bottom: 0;
    right: -0.26667rem;
    z-index: 9;
    background: var(--linerGradient-70);
}

html:lang(ar) .Trend__C-nav>div[data-v-9d93d892]:after {
    left: -0.26667rem;
    right: unset;
}

.van-toast[data-v-8bb41fd5] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-8bb41fd5] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-8bb41fd5] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-8bb41fd5] {
    height: 80%;
}

.MyGameRecordList__C[data-v-8bb41fd5] {
    background-color: var(--darkBg, var(--bg_color_L2));
}

.MyGameRecordList__C-empty[data-v-8bb41fd5] {
    height: 5.33333rem;
}

.MyGameRecordList__C-item[data-v-8bb41fd5] {
    height: 1.81333rem;
    padding: 0.37333rem 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecordList__C-item+div[data-v-8bb41fd5] {
    border-top: 0.01333rem solid var(--bg_color_L3);
}

.MyGameRecordList__C-item-l[data-v-8bb41fd5] {
    height: 0.96rem;
    width: 0.96rem;
    line-height: 0.96rem;
    text-align: center;
    border-radius: 0.26667rem;
    color: #fff;
    font-size: 0.64rem;
    margin-right: 0.29333rem;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    overflow: hidden;
}

.MyGameRecordList__C-item-l-red[data-v-8bb41fd5],
.MyGameRecordList__C-item-l-2[data-v-8bb41fd5],
.MyGameRecordList__C-item-l-4[data-v-8bb41fd5],
.MyGameRecordList__C-item-l-6[data-v-8bb41fd5],
.MyGameRecordList__C-item-l-8[data-v-8bb41fd5] {
    background-color: var(--norm_red-color);
}

.MyGameRecordList__C-item-l-violet[data-v-8bb41fd5] {
    background-color: var(--norm_Purple-color);
}

.MyGameRecordList__C-item-l-green[data-v-8bb41fd5],
.MyGameRecordList__C-item-l-1[data-v-8bb41fd5],
.MyGameRecordList__C-item-l-3[data-v-8bb41fd5],
.MyGameRecordList__C-item-l-7[data-v-8bb41fd5],
.MyGameRecordList__C-item-l-9[data-v-8bb41fd5] {
    background-color: var(--norm_green-color);
}

.MyGameRecordList__C-item-l-0[data-v-8bb41fd5] {
    background-image: -webkit-linear-gradient( top left, var(--norm_red-color) 50%, var(--norm_Purple-color) 0) !important;
    background-image: linear-gradient( to bottom right, var(--norm_red-color) 50%, var(--norm_Purple-color) 0) !important;
}

.MyGameRecordList__C-item-l-5[data-v-8bb41fd5] {
    background-image: -webkit-linear-gradient( top left, var(--norm_green-color) 50%, var(--norm_Purple-color) 0) !important;
    background-image: linear-gradient( to bottom right, var(--norm_green-color) 50%, var(--norm_Purple-color) 0) !important;
}

.MyGameRecordList__C-item-l-small[data-v-8bb41fd5] {
    background: var(--norm_bule-color);
    font-size: 0.32rem;
}

.MyGameRecordList__C-item-l-big[data-v-8bb41fd5] {
    background: var(--norm_secondary-color);
    font-size: 0.32rem;
}

.MyGameRecordList__C-item-m[data-v-8bb41fd5] {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
}

.MyGameRecordList__C-item-m-top[data-v-8bb41fd5] {
    height: 0.45333rem;
    line-height: 0.45333rem;
    font-size: 0.37333rem;
    color: var(--darkTextW, var(--text_color_L1));
    margin-bottom: 0.24rem;
}

.MyGameRecordList__C-item-m-bottom[data-v-8bb41fd5] {
    font-size: 0.29333rem;
    color: var(--text_color_L2);
}

.MyGameRecordList__C-item-r[data-v-8bb41fd5] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    font-weight: 500;
    font-size: 0.37333rem;
    height: 0.96rem;
    color: var(--norm_red-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: end;
    -webkit-align-items: flex-end;
    align-items: flex-end;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.MyGameRecordList__C-item-r span[data-v-8bb41fd5] {
    word-wrap: break-word;
    word-break: break-all;
}

.MyGameRecordList__C-item-r div[data-v-8bb41fd5] {
    color: var(--norm_red-color);
    border: 0.01333rem solid var(--norm_red-color);
    border-radius: 0.13333rem;
    height: 0.48rem;
    line-height: 0.48rem;
    font-size: 0.29333rem;
    padding: 0 0.48rem;
    margin-bottom: 0.08rem;
}

.MyGameRecordList__C-item-r.success[data-v-8bb41fd5] {
    color: var(--norm_green-color);
}

.MyGameRecordList__C-item-r.success div[data-v-8bb41fd5] {
    color: var(--norm_green-color);
    border-color: var(--norm_green-color);
}

.MyGameRecordList__C-inlineB[data-v-8bb41fd5] {
    display: inline-block;
}

.MyGameRecordList__C-inlineB+div[data-v-8bb41fd5] {
    margin-left: 0.21333rem;
}

.MyGameRecordList__C-inlineB.big[data-v-8bb41fd5] {
    color: var(--norm_secondary-color);
}

.MyGameRecordList__C-inlineB.small[data-v-8bb41fd5] {
    color: var(--norm_bule-color);
}

.MyGameRecordList__C-inlineB.greenColor[data-v-8bb41fd5] {
    color: var(--norm_green-color);
}

.MyGameRecordList__C-inlineB.redColor[data-v-8bb41fd5] {
    color: var(--norm_red-color);
}

.MyGameRecordList__C-inlineB.purpleColor[data-v-8bb41fd5] {
    color: var(--norm_Purple-color);
}

.MyGameRecordList__C-detail[data-v-8bb41fd5] {
    padding: 0.4rem 0;
    border-bottom: 0.01333rem solid var(--bg_color_L3);
}

.MyGameRecordList__C-detail-text[data-v-8bb41fd5] {
    font-size: 0.53333rem;
    color: var(--darkTextW, var(--text_color_L1));
    margin-bottom: 0.26667rem;
}

.MyGameRecordList__C-detail-line[data-v-8bb41fd5] {
    height: auto;
    line-height: 0.66667rem;
    padding: 0 0.06667rem;
    background-color: var(--bgDark-3, var(--bg_color_L3));
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
    margin-bottom: 0.21333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.MyGameRecordList__C-detail-line>span[data-v-8bb41fd5] {
    color: var(--text_color_L1);
}

.MyGameRecordList__C-detail-line>div[data-v-8bb41fd5] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecordList__C-detail-line img[data-v-8bb41fd5] {
    width: 0.4rem;
    height: 0.4rem;
    margin-left: 0.06667rem;
}

.MyGameRecordList__C-detail-line .red[data-v-8bb41fd5] {
    color: var(--norm_red-color);
}

.MyGameRecordList__C-detail-line .green[data-v-8bb41fd5] {
    color: var(--norm_green-color);
}

.MyGameRecordList__C-detail-line .numList[data-v-8bb41fd5] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 100%;
}

.MyGameRecordList__C-detail-line .numList>div[data-v-8bb41fd5] {
    height: 0.48rem;
    width: 0.48rem;
    text-align: center;
    line-height: 0.48rem;
    border-radius: 50%;
    border: 0.01333rem solid var(--text_color_L1);
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.MyGameRecordList__C-detail-line .numList>div+div[data-v-8bb41fd5] {
    margin: 0.08rem;
}

.MyGameRecordList__C-detail-line .numList>div>div[data-v-8bb41fd5] {
    height: 0.48rem;
    width: 0.48rem;
    background-repeat: no-repeat;
    background-size: 0.48rem;
    background-position: center;
}

.MyGameRecordList__C-detail-line .numList>div>div.n1[data-v-8bb41fd5] {
    background-image: url(/assets/png/n1-584b8878.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n2[data-v-8bb41fd5] {
    background-image: url(/assets/png/n2-447499dc.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n3[data-v-8bb41fd5] {
    background-image: url(/assets/png/n3-1432a6bd.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n4[data-v-8bb41fd5] {
    background-image: url(/assets/png/n4-9d453819.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n5[data-v-8bb41fd5] {
    background-image: url(/assets/png/n5-09b70e91.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n6[data-v-8bb41fd5] {
    background-image: url(/assets/png/n6-b68c6bb6.png);
}

.MyGameRecordList__C-detail-line .numList>div>div+div[data-v-8bb41fd5] {
    margin-left: 0.10667rem;
}

.MyGameRecordList__C-detail-line .line1[data-v-8bb41fd5] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 100%;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.MyGameRecordList__C-detail-line .line1 .num[data-v-8bb41fd5] {
    margin-left: 0.08rem;
    height: 0.48rem;
    min-width: 0.48rem;
    text-align: center;
    line-height: 0.48rem;
    padding: 0 0.06667rem;
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.MyGameRecordList__C-detail-line .line1 .btn[data-v-8bb41fd5] {
    height: 0.53333rem;
    line-height: 0.53333rem;
    border-radius: 0.08rem;
    padding: 0 0.26667rem;
    font-size: 0.32rem;
    margin: 0.05333rem 0.10667rem;
    background-color: var(--bg_color_L3);
}

.MyGameRecordList__C-detail-line .line1 .btn.actionViolet[data-v-8bb41fd5] {
    color: var(--text_color_L1);
    background-color: var(--norm_Purple-color);
}

.MyGameRecordList__C-detail-line .line1 .btn.actionRed[data-v-8bb41fd5] {
    color: var(--text_color_L1);
    background-color: var(--norm_red-color);
}

.MyGameRecordList__C-detail-line .line1 .btn.actionGreen[data-v-8bb41fd5] {
    color: var(--text_color_L1);
    background-color: var(--bgColor-13);
}

.MyGameRecordList__C-detail-line .line1 .btn.actionRedGreen[data-v-8bb41fd5] {
    color: var(--text_color_L1);
    background-color: var(--norm_red-color);
    background-image: var(--linearGradien-21);
}

.MyGameRecordList__C-item-l[data-v-8bb41fd5] {
    background-color: var(--main-color);
}

.MyGameRecordList__C-item-l-O[data-v-8bb41fd5],
.MyGameRecordList__C-item-l-E[data-v-8bb41fd5],
.MyGameRecordList__C-item-l-H[data-v-8bb41fd5],
.MyGameRecordList__C-item-l-L[data-v-8bb41fd5] {
    font-size: 0.32rem;
}

.MyGameRecordList__C-item-l-O[data-v-8bb41fd5] {
    background-color: var(--norm_red-color);
}

.MyGameRecordList__C-item-l-E[data-v-8bb41fd5] {
    background-color: var(--norm_Purple-color);
}

.MyGameRecordList__C-item-l-H[data-v-8bb41fd5] {
    background-color: var(--norm_secondary-color);
}

.MyGameRecordList__C-item-l-L[data-v-8bb41fd5] {
    background-color: var(--norm_bule-color);
}

.MyGameRecordList__C-item-l-0[data-v-8bb41fd5] {
    background: var(--main-color) !important;
}

.MyGameRecordList__C-detail-line .line1[data-v-8bb41fd5] {
    width: auto;
}

.van-toast[data-v-36ddca8e] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-36ddca8e] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-36ddca8e] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-36ddca8e] {
    height: 80%;
}

.MyGameRecord__C[data-v-36ddca8e] {
    width: calc(100% - 0.69333rem);
    margin: 0.32rem auto 0;
}

.MyGameRecord__C-head[data-v-36ddca8e] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
    background-color: var(--darkBg, var(--bg_color_L2));
    padding: 0.32rem 0.32rem 0;
}

.MyGameRecord__C-head-moreB[data-v-36ddca8e] {
    border: 0.01333rem solid var(--main-color);
    height: 0.8rem;
    line-height: 0.8rem;
    border-radius: 0.26667rem;
    padding: 0 0.24rem;
    color: var(--main-color);
    font-size: 0.32rem;
    position: relative;
}

.MyGameRecord__C-head-moreB svg[data-v-36ddca8e] {
    width: 0.4rem;
    height: 0.4rem;
}

.MyGameRecord__C-body[data-v-36ddca8e] {
    background-color: var(--darkBg, var(--bg_color_L2));
    padding: 0 0.32rem;
}

.MyGameRecord__C-body-empty[data-v-36ddca8e] {
    height: 5.33333rem;
}

.MyGameRecord__C-foot[data-v-36ddca8e] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecord__C-foot-page[data-v-36ddca8e] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.MyGameRecord__C-foot-previous[data-v-36ddca8e],
.MyGameRecord__C-foot-next[data-v-36ddca8e] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.MyGameRecord__C-foot-previous.disabled[data-v-36ddca8e],
.MyGameRecord__C-foot-next.disabled[data-v-36ddca8e] {
    background: var(--button_dis_color);
    pointer-events: none;
}

.MyGameRecord__C-foot-previous.disabled .MyGameRecord__C-icon[data-v-36ddca8e],
.MyGameRecord__C-foot-next.disabled .MyGameRecord__C-icon[data-v-36ddca8e] {
    color: var(--text_color_L3);
}

.MyGameRecord__C-foot-previous .MyGameRecord__C-icon[data-v-36ddca8e],
.MyGameRecord__C-foot-next .MyGameRecord__C-icon[data-v-36ddca8e] {
    color: var(--text_color_L4);
}

.van-toast[data-v-f388b770] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-f388b770] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-f388b770] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-f388b770] {
    height: 80%;
}

.FDP__C[data-v-f388b770] {
    height: 1.94667rem;
    width: calc(100% - 0.69333rem);
    margin: 0.34667rem auto 0.29333rem;
    border-radius: 0.26667rem;
    padding: 0.26667rem 0.34667rem;
    background: var(--darkBg, var(--bg_color_L2));
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: start;
    -webkit-align-items: flex-start;
    align-items: flex-start;
}

.FDP__C-text[data-v-f388b770] {
    color: var(--text_color_L2);
    height: 1.33333rem;
    line-height: 0.66667rem;
    font-size: 0.34667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.FDP__C-symbol[data-v-f388b770] {
    width: 0.24rem;
    margin: 0 0.13333rem;
    font-size: 0.34667rem;
    line-height: 0.93333rem;
    color: var(--text_color_L1);
}

.FDP__C-sum[data-v-f388b770] {
    height: 0.93333rem;
    width: 0.93333rem;
    line-height: 0.93333rem;
    background: var(--main-color);
    font-size: 0.34667rem;
    color: var(--text_color_L4);
    border-radius: 50%;
    text-align: center;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
}

.FDP__C-list[data-v-f388b770] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: -webkit-fit-content;
    width: fit-content;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
}

.FDP__C-list>div[data-v-f388b770] {
    width: 0.93333rem;
    height: 100%;
    margin-left: 0.21333rem;
}

.FDP__C-list>div .num[data-v-f388b770] {
    height: 0.93333rem;
    width: 0.93333rem;
    line-height: 0.93333rem;
    background: var(--bg_color_L3);
    font-size: 0.34667rem;
    color: var(--darkTextW, var(--text_color_L1));
    border-radius: 50%;
    text-align: center;
}

.FDP__C-list>div .letter[data-v-f388b770] {
    margin-top: 0.05333rem;
    text-align: center;
    font-size: 0.37333rem;
    color: var(--text_color_L2);
}

.FDP__C>div[data-v-f388b770] {
    height: 0.93333rem;
}

.van-toast[data-v-e05c7c66] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-e05c7c66] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-e05c7c66] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-e05c7c66] {
    height: 80%;
}

.WinningTip__C[data-v-e05c7c66] {
    position: fixed;
    width: 100%;
    height: 100%;
    z-index: 99;
    background-color: #00000080;
    top: 0;
    left: 0;
}

html:lang(ar) .WinningTip__C[data-v-e05c7c66] {
    right: 0;
    left: unset;
}

.WinningTip__C-body[data-v-e05c7c66] {
    position: absolute;
    width: 7.73333rem;
    height: 10.93333rem;
    background-image: url(/assets/png/missningBg-c1f02bcd.png);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
    padding-top: 3.2rem;
}

.WinningTip__C-body.isL[data-v-e05c7c66] {
    background-image: url(/assets/png/missningLBg-ca049a47.png);
}

.WinningTip__C-body.isL .WinningTip__C-body-l1[data-v-e05c7c66],
.WinningTip__C-body.isL .WinningTip__C-body-l2[data-v-e05c7c66],
.WinningTip__C-body.isL .WinningTip__C-body-l3[data-v-e05c7c66],
.WinningTip__C-body.isL .WinningTip__C-body-l4[data-v-e05c7c66] {
    color: #587ba4;
}

.WinningTip__C-body-l1[data-v-e05c7c66] {
    font-weight: 700;
    font-size: 0.64rem;
    text-align: center;
    color: #fff;
    height: 0.77333rem;
    line-height: 0.77333rem;
}

.WinningTip__C-body-l2[data-v-e05c7c66] {
    height: auto;
    color: #fff;
    font-size: 0.29333rem;
    margin-bottom: 0.64rem;
    text-align: center;
}

.WinningTip__C-body-l2 .line1[data-v-e05c7c66] {
    height: auto;
    width: 5.06667rem;
    margin: auto;
    font-size: 0.29333rem;
    color: #fff;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    margin-top: 0.05333rem;
}

.WinningTip__C-body-l2 .line1>div[data-v-e05c7c66] {
    width: 0.82667rem;
    height: 1.44rem;
}

.WinningTip__C-body-l2 .line1>div .title[data-v-e05c7c66] {
    width: 0.72rem;
    height: 0.72rem;
    background: var(--norm_secondary-color);
    border-radius: 50% 50% 0 0;
    font-size: 0.4rem;
    line-height: 0.72rem;
    position: relative;
}

.WinningTip__C-body-l2 .line1>div .title[data-v-e05c7c66]:after {
    content: "";
    width: 0.10667rem;
    height: 0.10667rem;
    position: absolute;
    bottom: 0;
    right: -0.10667rem;
    z-index: 9;
    background: var(--linearGradien-38);
}

.WinningTip__C-body-l2 .line1>div .title.sum[data-v-e05c7c66] {
    font-size: 0.26667rem;
}

.WinningTip__C-body-l2 .line1>div .num[data-v-e05c7c66] {
    width: 0.64rem;
    height: 0.64rem;
    color: #fff;
    border-radius: 50%;
    line-height: 0.64rem;
    text-align: center;
    border: 0.01333rem solid #fff;
    margin: 0.10667rem auto;
}

.WinningTip__C-body-l2 .line2[data-v-e05c7c66] {
    height: 0.58667rem;
    width: 3.57333rem;
    margin: 0.16rem auto 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.WinningTip__C-body-l2 .line2>div[data-v-e05c7c66] {
    height: 0.58667rem;
    line-height: 0.58667rem;
    background: var(--norm_red-color);
    border-radius: 0.13333rem;
    width: 1.33333rem;
    text-align: center;
}

.WinningTip__C-body-l2 .line2>div.yuan[data-v-e05c7c66] {
    width: 0.53333rem;
    height: 0.53333rem;
    line-height: 0.53333rem;
    margin: 0 0.18667rem;
    border-radius: 50%;
}

.WinningTip__C-body-l3[data-v-e05c7c66] {
    height: 1.73333rem;
}

.WinningTip__C-body-l3 .isLose[data-v-e05c7c66] {
    font-weight: 700;
    font-size: 0.64rem;
    line-height: 0.77333rem;
    color: var(--colorText-38);
    text-align: center;
    margin-bottom: 0.34667rem;
    padding-top: 0.26667rem;
}

.WinningTip__C-body-l3 .head[data-v-e05c7c66] {
    height: 0.4rem;
    line-height: 0.4rem;
    font-weight: 700;
    font-size: 0.34667rem;
    color: #fb5b5b;
    text-align: center;
    margin-bottom: 0.10667rem;
}

.WinningTip__C-body-l3 .bonus[data-v-e05c7c66] {
    height: 0.64rem;
    line-height: 0.64rem;
    font-weight: 700;
    font-size: 0.53333rem;
    color: #fb5b5b;
    text-align: center;
    margin-bottom: 0.26667rem;
}

.WinningTip__C-body-l3 .gameDetail[data-v-e05c7c66] {
    height: 0.37333rem;
    line-height: 0.37333rem;
    font-size: 0.29333rem;
    text-align: center;
    color: var(--text_color_L2);
}

.WinningTip__C-body-l4[data-v-e05c7c66] {
    height: 0.64rem;
    line-height: 0.64rem;
    font-size: 0.32rem;
    color: #fff;
    position: absolute;
    left: 0.74667rem;
    bottom: 0.74667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

html:lang(ar) .WinningTip__C-body-l4[data-v-e05c7c66] {
    right: 0.74667rem;
    left: unset;
}

.WinningTip__C-body-l4 .acitveBtn[data-v-e05c7c66] {
    height: 0.56rem;
    width: 0.56rem;
    border-radius: 50%;
    background: var(--winTips);
    border: 0.01333rem solid #fff;
    margin-right: 0.18667rem;
    position: relative;
}

.WinningTip__C-body-l4 .acitveBtn.active[data-v-e05c7c66]:before {
    content: "";
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
    height: 0.24rem;
    width: 0.32rem;
    display: block;
    background-image: url(/assets/png/vector-dc489162.png);
    background-repeat: no-repeat;
    background-size: 0.32rem 0.24rem;
    background-position: center;
}

.WinningTip__C .closeBtn[data-v-e05c7c66] {
    width: 0.8rem;
    height: 0.8rem;
    background-image: url(/assets/png/close-84ce5e6a.png);
    background-repeat: no-repeat;
    background-size: 0.8rem;
    background-position: center;
    position: absolute;
    left: 50%;
    -webkit-transform: translateX(-50%) translateY(100%);
    transform: translate(-50%) translateY(100%);
    bottom: -0.26667rem;
}

.van-toast[data-v-0ac3de13] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-0ac3de13] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-0ac3de13] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-0ac3de13] {
    height: 80%;
}

.chanlongEnter[data-v-0ac3de13] {
    position: fixed;
    z-index: 99;
    width: 1.59333rem;
    height: 1.49333rem;
    background-repeat: no-repeat;
    background-position: center;
    background-size: 1.49333rem;
    background-image: url(/assets/svg/changlong-c0fe638b.svg));
    bottom: 7.26667rem;
    right: 0.4rem;
    box-shadow: 0 0.02667rem 0.48rem #cbcadc8f;
    border-radius: 90%;
}

.changlongEnter[data-v-0ac3de13] {
    position: fixed;
    z-index: 99;
    width: 1.49333rem;
    height: 1.49333rem;
    background-repeat: no-repeat;
    background-position: center;
    background-size: 1.49333rem;
    background-image: url(/assets/svg/changlong-c0fe638a.svg);
    bottom: 4.26667rem;
    right: 0.4rem;
    box-shadow: 0 0.02667rem 0.48rem #cbcadc8f;
    border-radius: 50%;
}

.van-toast[data-v-4f526022] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-4f526022] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-4f526022] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-4f526022] {
    height: 80%;
}

.FD__C[data-v-4f526022] {
    padding-bottom: 0.34667rem;
}

.FD__C-head[data-v-4f526022] {
    height: 1.25333rem;
    background: -webkit-linear-gradient(left, #de2325 0%, #ff504a 100%);
    background: linear-gradient(90deg, #de2325 0%, #ff504a 100%);
    padding: 0 0.34667rem;
    position: relative;
}

.FD__C-head div[data-v-4f526022] {
    background-repeat: no-repeat;
    background-position: center;
}

.FD__C-head-bcak[data-v-4f526022] {
    position: absolute;
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/bcakIcon-b7c1d288.png);
    background-size: 0.64rem;
    left: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
}

.FD__C-head-logo[data-v-4f526022] {
    background: url(/assets/png/headlogo-56515a97.png);
    background-size: 2.98667rem 1.12rem;
    height: 1.12rem;
    width: 2.98667rem;
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
}

.FD__C-head-more[data-v-4f526022] {
    position: absolute;
    width: 1.54667rem;
    height: 0.64rem;
    right: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.FD__C-head-more>div[data-v-4f526022] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/kefu-b361c42f.png);
    background-size: 0.64rem;
}

.FD__C-head-more>div[data-v-4f526022]:last-child {
    background-image: url(/assets/png/voice-62dbf38c.png);
}

.FD__C-head-more>div:last-child.disableVoice[data-v-4f526022] {
    background-image: url(/assets/png/voice-off-633f5ccc.png);
}

.FD__C[data-v-4f526022] .noticeBar__container {
    width: calc(100% - 0.69333rem) !important;
    margin: 0.45333rem auto;
    position: relative;
    z-index: 1;
    top: 0;
}

.van-toast[data-v-8ab0e403] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-8ab0e403] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-8ab0e403] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-8ab0e403] {
    height: 80%;
}

.BettingRecord5D__C-head[data-v-8ab0e403] {
    height: 1.25333rem;
    line-height: 1.25333rem;
    text-align: center;
    background: var(--bg_color_L2);
    position: relative;
    font-weight: 500;
    font-size: 0.48rem;
    color: var(--text_color_L1);
}

.BettingRecord5D__C-head-bcak[data-v-8ab0e403] {
    position: absolute;
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/bcakIcon-b7c1d288.png);
    background-size: 0.64rem;
    left: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
}

.BettingRecord5D__C-list[data-v-8ab0e403] {
    margin: 0.48rem 0 0.4rem;
}

.BettingRecord5D__C-list[data-v-8ab0e403] .MyGameRecordList__C {
    padding: 0 0.32rem;
}

.BettingRecord5D__C-foot[data-v-8ab0e403] {
    height: 1.86667rem;
    background: var(--bg_color_L2);
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.BettingRecord5D__C-foot-page[data-v-8ab0e403] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.BettingRecord5D__C-foot-previous[data-v-8ab0e403],
.BettingRecord5D__C-foot-next[data-v-8ab0e403] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.BettingRecord5D__C-foot-previous.disabled[data-v-8ab0e403],
.BettingRecord5D__C-foot-next.disabled[data-v-8ab0e403] {
    background: var(--button_dis_color);
    pointer-events: none;
}

.BettingRecord5D__C-foot-previous.disabled .BettingRecord5D__C-icon[data-v-8ab0e403],
.BettingRecord5D__C-foot-next.disabled .BettingRecord5D__C-icon[data-v-8ab0e403] {
    color: var(--text_color_L3);
}

.BettingRecord5D__C-foot-previous .BettingRecord5D__C-icon[data-v-8ab0e403],
.BettingRecord5D__C-foot-next .BettingRecord5D__C-icon[data-v-8ab0e403] {
    color: var(--text_color_L4);
}

.BettingRecord5D__C[data-v-8ab0e403] .van-tabs__line {
    background-color: var(--main-color);
}

.BettingRecord5D__C[data-v-8ab0e403] .van-tabs__nav {
    background-color: var(--bg_color_L2);
}

.BettingRecord5D__C[data-v-8ab0e403] .van-tab--active {
    color: var(--text_color_L1);
    font-weight: 500;
}

.van-toast[data-v-a5ef3154] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-a5ef3154] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-a5ef3154] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-a5ef3154] {
    height: 80%;
}

.MyGameRecordList__C[data-v-a5ef3154] {
    background-color: var(--darkBg, var(--bg_color_L2));
}

.MyGameRecordList__C-empty[data-v-a5ef3154] {
    height: 5.33333rem;
}

.MyGameRecordList__C-item[data-v-a5ef3154] {
    height: 1.81333rem;
    padding: 0.37333rem 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecordList__C-item+div[data-v-a5ef3154] {
    border-top: 0.01333rem solid var(--bg_color_L3);
}

.MyGameRecordList__C-item-l[data-v-a5ef3154] {
    height: 0.96rem;
    width: 0.96rem;
    line-height: 0.96rem;
    text-align: center;
    border-radius: 0.26667rem;
    color: #fff;
    font-size: 0.64rem;
    margin-right: 0.29333rem;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    overflow: hidden;
}

.MyGameRecordList__C-item-l-red[data-v-a5ef3154],
.MyGameRecordList__C-item-l-2[data-v-a5ef3154],
.MyGameRecordList__C-item-l-4[data-v-a5ef3154],
.MyGameRecordList__C-item-l-6[data-v-a5ef3154],
.MyGameRecordList__C-item-l-8[data-v-a5ef3154] {
    background-color: var(--norm_red-color);
}

.MyGameRecordList__C-item-l-violet[data-v-a5ef3154] {
    background-color: var(--norm_Purple-color);
}

.MyGameRecordList__C-item-l-green[data-v-a5ef3154],
.MyGameRecordList__C-item-l-1[data-v-a5ef3154],
.MyGameRecordList__C-item-l-3[data-v-a5ef3154],
.MyGameRecordList__C-item-l-7[data-v-a5ef3154],
.MyGameRecordList__C-item-l-9[data-v-a5ef3154] {
    background-color: var(--norm_green-color);
}

.MyGameRecordList__C-item-l-0[data-v-a5ef3154] {
    background-image: -webkit-linear-gradient( top left, var(--norm_red-color) 50%, var(--norm_Purple-color) 0) !important;
    background-image: linear-gradient( to bottom right, var(--norm_red-color) 50%, var(--norm_Purple-color) 0) !important;
}

.MyGameRecordList__C-item-l-5[data-v-a5ef3154] {
    background-image: -webkit-linear-gradient( top left, var(--norm_green-color) 50%, var(--norm_Purple-color) 0) !important;
    background-image: linear-gradient( to bottom right, var(--norm_green-color) 50%, var(--norm_Purple-color) 0) !important;
}

.MyGameRecordList__C-item-l-small[data-v-a5ef3154] {
    background: var(--norm_bule-color);
    font-size: 0.32rem;
}

.MyGameRecordList__C-item-l-big[data-v-a5ef3154] {
    background: var(--norm_secondary-color);
    font-size: 0.32rem;
}

.MyGameRecordList__C-item-m[data-v-a5ef3154] {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
}

.MyGameRecordList__C-item-m-top[data-v-a5ef3154] {
    height: 0.45333rem;
    line-height: 0.45333rem;
    font-size: 0.37333rem;
    color: var(--darkTextW, var(--text_color_L1));
    margin-bottom: 0.24rem;
}

.MyGameRecordList__C-item-m-bottom[data-v-a5ef3154] {
    font-size: 0.29333rem;
    color: var(--text_color_L2);
}

.MyGameRecordList__C-item-r[data-v-a5ef3154] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    font-weight: 500;
    font-size: 0.37333rem;
    height: 0.96rem;
    color: var(--norm_red-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: end;
    -webkit-align-items: flex-end;
    align-items: flex-end;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.MyGameRecordList__C-item-r span[data-v-a5ef3154] {
    word-wrap: break-word;
    word-break: break-all;
}

.MyGameRecordList__C-item-r div[data-v-a5ef3154] {
    color: var(--norm_red-color);
    border: 0.01333rem solid var(--norm_red-color);
    border-radius: 0.13333rem;
    height: 0.48rem;
    line-height: 0.48rem;
    font-size: 0.29333rem;
    padding: 0 0.48rem;
    margin-bottom: 0.08rem;
}

.MyGameRecordList__C-item-r.success[data-v-a5ef3154] {
    color: var(--norm_green-color);
}

.MyGameRecordList__C-item-r.success div[data-v-a5ef3154] {
    color: var(--norm_green-color);
    border-color: var(--norm_green-color);
}

.MyGameRecordList__C-inlineB[data-v-a5ef3154] {
    display: inline-block;
}

.MyGameRecordList__C-inlineB+div[data-v-a5ef3154] {
    margin-left: 0.21333rem;
}

.MyGameRecordList__C-inlineB.big[data-v-a5ef3154] {
    color: var(--norm_secondary-color);
}

.MyGameRecordList__C-inlineB.small[data-v-a5ef3154] {
    color: var(--norm_bule-color);
}

.MyGameRecordList__C-inlineB.greenColor[data-v-a5ef3154] {
    color: var(--norm_green-color);
}

.MyGameRecordList__C-inlineB.redColor[data-v-a5ef3154] {
    color: var(--norm_red-color);
}

.MyGameRecordList__C-inlineB.purpleColor[data-v-a5ef3154] {
    color: var(--norm_Purple-color);
}

.MyGameRecordList__C-detail[data-v-a5ef3154] {
    padding: 0.4rem 0;
    border-bottom: 0.01333rem solid var(--bg_color_L3);
}

.MyGameRecordList__C-detail-text[data-v-a5ef3154] {
    font-size: 0.53333rem;
    color: var(--darkTextW, var(--text_color_L1));
    margin-bottom: 0.26667rem;
}

.MyGameRecordList__C-detail-line[data-v-a5ef3154] {
    height: auto;
    line-height: 0.66667rem;
    padding: 0 0.06667rem;
    background-color: var(--bgDark-3, var(--bg_color_L3));
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
    margin-bottom: 0.21333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.MyGameRecordList__C-detail-line>span[data-v-a5ef3154] {
    color: var(--text_color_L1);
}

.MyGameRecordList__C-detail-line>div[data-v-a5ef3154] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecordList__C-detail-line img[data-v-a5ef3154] {
    width: 0.4rem;
    height: 0.4rem;
    margin-left: 0.06667rem;
}

.MyGameRecordList__C-detail-line .red[data-v-a5ef3154] {
    color: var(--norm_red-color);
}

.MyGameRecordList__C-detail-line .green[data-v-a5ef3154] {
    color: var(--norm_green-color);
}

.MyGameRecordList__C-detail-line .numList>div[data-v-a5ef3154] {
    height: 0.48rem;
    width: 0.48rem;
    text-align: center;
    line-height: 0.48rem;
    border-radius: 50%;
    border: 0.01333rem solid var(--text_color_L1);
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.MyGameRecordList__C-detail-line .numList>div+div[data-v-a5ef3154] {
    margin: 0.08rem;
}

.MyGameRecordList__C-detail-line .numList>div>div[data-v-a5ef3154] {
    height: 0.48rem;
    width: 0.48rem;
    background-repeat: no-repeat;
    background-size: 0.48rem;
    background-position: center;
}

.MyGameRecordList__C-detail-line .numList>div>div.n1[data-v-a5ef3154] {
    background-image: url(/assets/png/n1-584b8878.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n2[data-v-a5ef3154] {
    background-image: url(/assets/png/n2-447499dc.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n3[data-v-a5ef3154] {
    background-image: url(/assets/png/n3-1432a6bd.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n4[data-v-a5ef3154] {
    background-image: url(/assets/png/n4-9d453819.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n5[data-v-a5ef3154] {
    background-image: url(/assets/png/n5-09b70e91.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n6[data-v-a5ef3154] {
    background-image: url(/assets/png/n6-b68c6bb6.png);
}

.MyGameRecordList__C-detail-line .numList>div>div+div[data-v-a5ef3154] {
    margin-left: 0.10667rem;
}

.MyGameRecordList__C-detail-line .line1[data-v-a5ef3154] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 100%;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.MyGameRecordList__C-detail-line .line1 .num[data-v-a5ef3154] {
    margin-left: 0.08rem;
    height: 0.48rem;
    min-width: 0.48rem;
    text-align: center;
    line-height: 0.48rem;
    padding: 0 0.06667rem;
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.MyGameRecordList__C-detail-line .line1 .btn[data-v-a5ef3154] {
    height: 0.53333rem;
    line-height: 0.53333rem;
    border-radius: 0.08rem;
    padding: 0 0.26667rem;
    font-size: 0.32rem;
    margin: 0.05333rem 0.10667rem;
    background-color: var(--bg_color_L3);
}

.MyGameRecordList__C-detail-line .line1 .btn.actionViolet[data-v-a5ef3154] {
    color: var(--text_color_L1);
    background-color: var(--norm_Purple-color);
}

.MyGameRecordList__C-detail-line .line1 .btn.actionRed[data-v-a5ef3154] {
    color: var(--text_color_L1);
    background-color: var(--norm_red-color);
}

.MyGameRecordList__C-detail-line .line1 .btn.actionGreen[data-v-a5ef3154] {
    color: var(--text_color_L1);
    background-color: var(--bgColor-13);
}

.MyGameRecordList__C-detail-line .line1 .btn.actionRedGreen[data-v-a5ef3154] {
    color: var(--text_color_L1);
    background-color: var(--norm_red-color);
    background-image: var(--linearGradien-21);
}

.MyGameRecordList__C-detail-line .numList[data-v-a5ef3154] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 100%;
}

.MyGameRecordList__C-detail-line .numList>div[data-v-a5ef3154] {
    height: 0.48rem;
    width: 0.48rem;
    background-repeat: no-repeat;
    background-size: 0.48rem;
    background-position: center;
    border-radius: 0;
    border: 0;
}

.MyGameRecordList__C-detail-line .numList>div.n1[data-v-a5ef3154] {
    background-image: url(/assets/png/n1-584b8878.png);
}

.MyGameRecordList__C-detail-line .numList>div.n2[data-v-a5ef3154] {
    background-image: url(/assets/png/n2-447499dc.png);
}

.MyGameRecordList__C-detail-line .numList>div.n3[data-v-a5ef3154] {
    background-image: url(/assets/png/n3-1432a6bd.png);
}

.MyGameRecordList__C-detail-line .numList>div.n4[data-v-a5ef3154] {
    background-image: url(/assets/png/n4-9d453819.png);
}

.MyGameRecordList__C-detail-line .numList>div.n5[data-v-a5ef3154] {
    background-image: url(/assets/png/n5-09b70e91.png);
}

.MyGameRecordList__C-detail-line .numList>div.n6[data-v-a5ef3154] {
    background-image: url(/assets/png/n6-b68c6bb6.png);
}

.MyGameRecordList__C-detail-line .numList>div+div[data-v-a5ef3154] {
    margin-left: 0.10667rem;
}

.MyGameRecordList__C-item-l[data-v-a5ef3154] {
    height: 0.96rem;
    width: 0.96rem;
    line-height: normal;
    text-align: center;
    border-radius: 0.26667rem;
    color: #fff;
    font-size: 0.64rem;
    margin-right: 0.29333rem;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    background-color: var(--main-color);
    font-size: 0.32rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    word-wrap: break-word;
    word-break: break-all;
}

.MyGameRecordList__C-item-l-H[data-v-a5ef3154] {
    background-color: var(--norm_secondary-color);
}

.MyGameRecordList__C-item-l-L[data-v-a5ef3154] {
    background-color: var(--norm_bule-color);
}

.MyGameRecordList__C-item-l-O[data-v-a5ef3154] {
    background: var(--norm_red-color);
}

.MyGameRecordList__C-item-l-E[data-v-a5ef3154] {
    background: var(--norm_Purple-color);
}

.MyGameRecordList__C-item-l-num[data-v-a5ef3154] {
    font-size: 0.32rem;
}

.van-toast[data-v-c228f246] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-c228f246] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-c228f246] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-c228f246] {
    height: 80%;
}

.BettingRecordK3__C-head[data-v-c228f246] {
    height: 1.25333rem;
    line-height: 1.25333rem;
    text-align: center;
    background: var(--bg_color_L2);
    position: relative;
    font-weight: 500;
    font-size: 0.48rem;
    color: var(--text_color_L1);
}

.BettingRecordK3__C-head-bcak[data-v-c228f246] {
    position: absolute;
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/bcakIcon-b7c1d288.png);
    background-size: 0.64rem;
    left: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
}

.BettingRecordK3__C-list[data-v-c228f246] {
    margin: 0.48rem 0 0.4rem;
}

.BettingRecordK3__C-list[data-v-c228f246] .MyGameRecordList__C {
    padding: 0 0.32rem;
}

.BettingRecordK3__C-foot[data-v-c228f246] {
    height: 1.86667rem;
    background: var(--bg_color_L2);
    color: var(--text_color_L1);
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.BettingRecordK3__C-foot-page[data-v-c228f246] {
    font-size: 0.32rem;
}

.BettingRecordK3__C-foot-previous[data-v-c228f246],
.BettingRecordK3__C-foot-next[data-v-c228f246] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.BettingRecordK3__C-foot-previous.disabled[data-v-c228f246],
.BettingRecordK3__C-foot-next.disabled[data-v-c228f246] {
    background: var(--button_dis_color);
    pointer-events: none;
}

.BettingRecordK3__C-foot-previous.disabled .BettingRecordK3__C-icon[data-v-c228f246],
.BettingRecordK3__C-foot-next.disabled .BettingRecordK3__C-icon[data-v-c228f246] {
    color: var(--text_color_L2);
}

.BettingRecordK3__C-foot-previous .BettingRecordK3__C-icon[data-v-c228f246],
.BettingRecordK3__C-foot-next .BettingRecordK3__C-icon[data-v-c228f246] {
    color: var(--text_color_L4);
}

.BettingRecordK3__C[data-v-c228f246] .van-tabs__line {
    background-color: var(--main-color);
}

.BettingRecordK3__C[data-v-c228f246] .van-tabs__nav {
    background-color: var(--bg_color_L2);
}

.BettingRecordK3__C[data-v-c228f246] .van-tab--active {
    color: var(--text_color_L1);
    font-weight: 500;
}

.van-toast[data-v-2faec5cb] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-2faec5cb] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-2faec5cb] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-2faec5cb] {
    height: 80%;
}

.MyGameRecordList__C[data-v-2faec5cb] {
    background-color: var(--darkBg, var(--bg_color_L2));
}

.MyGameRecordList__C-empty[data-v-2faec5cb] {
    height: 5.33333rem;
}

.MyGameRecordList__C-item[data-v-2faec5cb] {
    height: 1.81333rem;
    padding: 0.37333rem 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecordList__C-item+div[data-v-2faec5cb] {
    border-top: 0.01333rem solid var(--bg_color_L3);
}

.MyGameRecordList__C-item-l[data-v-2faec5cb] {
    height: 0.96rem;
    width: 0.96rem;
    line-height: 0.96rem;
    text-align: center;
    border-radius: 0.26667rem;
    color: #fff;
    font-size: 0.64rem;
    margin-right: 0.29333rem;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    overflow: hidden;
}

.MyGameRecordList__C-item-l-red[data-v-2faec5cb],
.MyGameRecordList__C-item-l-2[data-v-2faec5cb],
.MyGameRecordList__C-item-l-4[data-v-2faec5cb],
.MyGameRecordList__C-item-l-6[data-v-2faec5cb],
.MyGameRecordList__C-item-l-8[data-v-2faec5cb] {
    background-color: var(--norm_red-color);
}

.MyGameRecordList__C-item-l-violet[data-v-2faec5cb] {
    background-color: var(--norm_Purple-color);
}

.MyGameRecordList__C-item-l-green[data-v-2faec5cb],
.MyGameRecordList__C-item-l-1[data-v-2faec5cb],
.MyGameRecordList__C-item-l-3[data-v-2faec5cb],
.MyGameRecordList__C-item-l-7[data-v-2faec5cb],
.MyGameRecordList__C-item-l-9[data-v-2faec5cb] {
    background-color: var(--norm_green-color);
}

.MyGameRecordList__C-item-l-0[data-v-2faec5cb] {
    background-image: -webkit-linear-gradient( top left, var(--norm_red-color) 50%, var(--norm_Purple-color) 0) !important;
    background-image: linear-gradient( to bottom right, var(--norm_red-color) 50%, var(--norm_Purple-color) 0) !important;
}

.MyGameRecordList__C-item-l-5[data-v-2faec5cb] {
    background-image: -webkit-linear-gradient( top left, var(--norm_green-color) 50%, var(--norm_Purple-color) 0) !important;
    background-image: linear-gradient( to bottom right, var(--norm_green-color) 50%, var(--norm_Purple-color) 0) !important;
}

.MyGameRecordList__C-item-l-small[data-v-2faec5cb] {
    background: var(--norm_bule-color);
    font-size: 0.32rem;
}

.MyGameRecordList__C-item-l-big[data-v-2faec5cb] {
    background: var(--norm_secondary-color);
    font-size: 0.32rem;
}

.MyGameRecordList__C-item-m[data-v-2faec5cb] {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
}

.MyGameRecordList__C-item-m-top[data-v-2faec5cb] {
    height: 0.45333rem;
    line-height: 0.45333rem;
    font-size: 0.37333rem;
    color: var(--darkTextW, var(--text_color_L1));
    margin-bottom: 0.24rem;
}

.MyGameRecordList__C-item-m-bottom[data-v-2faec5cb] {
    font-size: 0.29333rem;
    color: var(--text_color_L2);
}

.MyGameRecordList__C-item-r[data-v-2faec5cb] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    font-weight: 500;
    font-size: 0.37333rem;
    height: 0.96rem;
    color: var(--norm_red-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: end;
    -webkit-align-items: flex-end;
    align-items: flex-end;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.MyGameRecordList__C-item-r span[data-v-2faec5cb] {
    word-wrap: break-word;
    word-break: break-all;
}

.MyGameRecordList__C-item-r div[data-v-2faec5cb] {
    color: var(--norm_red-color);
    border: 0.01333rem solid var(--norm_red-color);
    border-radius: 0.13333rem;
    height: 0.48rem;
    line-height: 0.48rem;
    font-size: 0.29333rem;
    padding: 0 0.48rem;
    margin-bottom: 0.08rem;
}

.MyGameRecordList__C-item-r.success[data-v-2faec5cb] {
    color: var(--norm_green-color);
}

.MyGameRecordList__C-item-r.success div[data-v-2faec5cb] {
    color: var(--norm_green-color);
    border-color: var(--norm_green-color);
}

.MyGameRecordList__C-inlineB[data-v-2faec5cb] {
    display: inline-block;
}

.MyGameRecordList__C-inlineB+div[data-v-2faec5cb] {
    margin-left: 0.21333rem;
}

.MyGameRecordList__C-inlineB.big[data-v-2faec5cb] {
    color: var(--norm_secondary-color);
}

.MyGameRecordList__C-inlineB.small[data-v-2faec5cb] {
    color: var(--norm_bule-color);
}

.MyGameRecordList__C-inlineB.greenColor[data-v-2faec5cb] {
    color: var(--norm_green-color);
}

.MyGameRecordList__C-inlineB.redColor[data-v-2faec5cb] {
    color: var(--norm_red-color);
}

.MyGameRecordList__C-inlineB.purpleColor[data-v-2faec5cb] {
    color: var(--norm_Purple-color);
}

.MyGameRecordList__C-detail[data-v-2faec5cb] {
    padding: 0.4rem 0;
    border-bottom: 0.01333rem solid var(--bg_color_L3);
}

.MyGameRecordList__C-detail-text[data-v-2faec5cb] {
    font-size: 0.53333rem;
    color: var(--darkTextW, var(--text_color_L1));
    margin-bottom: 0.26667rem;
}

.MyGameRecordList__C-detail-line[data-v-2faec5cb] {
    height: auto;
    line-height: 0.66667rem;
    padding: 0 0.06667rem;
    background-color: var(--bgDark-3, var(--bg_color_L3));
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
    margin-bottom: 0.21333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.MyGameRecordList__C-detail-line>span[data-v-2faec5cb] {
    color: var(--text_color_L1);
}

.MyGameRecordList__C-detail-line>div[data-v-2faec5cb] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecordList__C-detail-line img[data-v-2faec5cb] {
    width: 0.4rem;
    height: 0.4rem;
    margin-left: 0.06667rem;
}

.MyGameRecordList__C-detail-line .red[data-v-2faec5cb] {
    color: var(--norm_red-color);
}

.MyGameRecordList__C-detail-line .green[data-v-2faec5cb] {
    color: var(--norm_green-color);
}

.MyGameRecordList__C-detail-line .numList[data-v-2faec5cb] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 100%;
}

.MyGameRecordList__C-detail-line .numList>div[data-v-2faec5cb] {
    height: 0.48rem;
    width: 0.48rem;
    text-align: center;
    line-height: 0.48rem;
    border-radius: 50%;
    border: 0.01333rem solid var(--text_color_L1);
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.MyGameRecordList__C-detail-line .numList>div+div[data-v-2faec5cb] {
    margin: 0.08rem;
}

.MyGameRecordList__C-detail-line .numList>div>div[data-v-2faec5cb] {
    height: 0.48rem;
    width: 0.48rem;
    background-repeat: no-repeat;
    background-size: 0.48rem;
    background-position: center;
}

.MyGameRecordList__C-detail-line .numList>div>div.n1[data-v-2faec5cb] {
    background-image: url(/assets/png/n1-584b8878.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n2[data-v-2faec5cb] {
    background-image: url(/assets/png/n2-447499dc.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n3[data-v-2faec5cb] {
    background-image: url(/assets/png/n3-1432a6bd.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n4[data-v-2faec5cb] {
    background-image: url(/assets/png/n4-9d453819.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n5[data-v-2faec5cb] {
    background-image: url(/assets/png/n5-09b70e91.png);
}

.MyGameRecordList__C-detail-line .numList>div>div.n6[data-v-2faec5cb] {
    background-image: url(/assets/png/n6-b68c6bb6.png);
}

.MyGameRecordList__C-detail-line .numList>div>div+div[data-v-2faec5cb] {
    margin-left: 0.10667rem;
}

.MyGameRecordList__C-detail-line .line1[data-v-2faec5cb] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 100%;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.MyGameRecordList__C-detail-line .line1 .num[data-v-2faec5cb] {
    margin-left: 0.08rem;
    height: 0.48rem;
    min-width: 0.48rem;
    text-align: center;
    line-height: 0.48rem;
    padding: 0 0.06667rem;
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.MyGameRecordList__C-detail-line .line1 .btn[data-v-2faec5cb] {
    height: 0.53333rem;
    line-height: 0.53333rem;
    border-radius: 0.08rem;
    padding: 0 0.26667rem;
    font-size: 0.32rem;
    margin: 0.05333rem 0.10667rem;
    background-color: var(--bg_color_L3);
}

.MyGameRecordList__C-detail-line .line1 .btn.actionViolet[data-v-2faec5cb] {
    color: var(--text_color_L1);
    background-color: var(--norm_Purple-color);
}

.MyGameRecordList__C-detail-line .line1 .btn.actionRed[data-v-2faec5cb] {
    color: var(--text_color_L1);
    background-color: var(--norm_red-color);
}

.MyGameRecordList__C-detail-line .line1 .btn.actionGreen[data-v-2faec5cb] {
    color: var(--text_color_L1);
    background-color: var(--bgColor-13);
}

.MyGameRecordList__C-detail-line .line1 .btn.actionRedGreen[data-v-2faec5cb] {
    color: var(--text_color_L1);
    background-color: var(--norm_red-color);
    background-image: var(--linearGradien-21);
}

.van-toast[data-v-6d173501] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-6d173501] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-6d173501] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-6d173501] {
    height: 80%;
}

.BettingRecordWin__C-head[data-v-6d173501] {
    height: 1.25333rem;
    line-height: 1.25333rem;
    text-align: center;
    background: var(--bg_color_L2);
    position: relative;
    font-weight: 500;
    font-size: 0.48rem;
    color: var(--text_color_L1);
}

.BettingRecordWin__C-head-bcak[data-v-6d173501] {
    position: absolute;
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/bcakIcon-b7c1d288.png);
    background-size: 0.64rem;
    left: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
}

.BettingRecordWin__C-list[data-v-6d173501] {
    margin: 0.48rem 0 0.4rem;
}

.BettingRecordWin__C-list[data-v-6d173501] .MyGameRecordList__C {
    padding: 0 0.32rem;
}

.BettingRecordWin__C-foot[data-v-6d173501] {
    height: 1.86667rem;
    background: var(--bg_color_L2);
    color: var(--text_color_L2);
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.BettingRecordWin__C-foot-page[data-v-6d173501] {
    font-size: 0.32rem;
}

.BettingRecordWin__C-foot-previous[data-v-6d173501],
.BettingRecordWin__C-foot-next[data-v-6d173501] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    color: var(--text_color_L4);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.BettingRecordWin__C-foot-previous.disabled[data-v-6d173501],
.BettingRecordWin__C-foot-next.disabled[data-v-6d173501] {
    background: var(--bg_color_L3);
    pointer-events: none;
}

.BettingRecordWin__C-foot-previous.disabled .BettingRecordWin__C-icon[data-v-6d173501],
.BettingRecordWin__C-foot-next.disabled .BettingRecordWin__C-icon[data-v-6d173501] {
    color: var(--saveTextColor-7);
}

.BettingRecordWin__C-foot-previous .BettingRecordWin__C-icon[data-v-6d173501],
.BettingRecordWin__C-foot-next .BettingRecordWin__C-icon[data-v-6d173501] {
    color: var(--textW);
}

.BettingRecordWin__C[data-v-6d173501] .van-tabs {
    background-color: var(--main-color);
}

.BettingRecordWin__C[data-v-6d173501] .van-tabs .van-tabs__nav {
    background: var(--bg_color_L2);
}

.BettingRecordWin__C[data-v-6d173501] .van-tabs .van-tab--active {
    color: var(--text_color_L1);
}

.BettingRecordWin__C[data-v-6d173501] .van-tabs .van-tabs__line {
    background: var(--main-color);
}

.BettingRecordWin__C[data-v-6d173501] .van-tab--active {
    color: var(text-1);
    font-weight: 500;
}

.BettingRecordWin__C[data-v-6d173501] .MyGameRecordList__C {
    padding: 0 0.32rem;
}

.van-toast[data-v-7bbbf1c1] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-7bbbf1c1] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-7bbbf1c1] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-7bbbf1c1] {
    height: 80%;
}

.BettingRecordWinTrx__C-head[data-v-7bbbf1c1] {
    height: 1.25333rem;
    line-height: 1.25333rem;
    text-align: center;
    background: var(--darkBg, var(--bg_color_L2));
    position: relative;
    font-weight: 500;
    font-size: 0.48rem;
    color: var(--textW);
}

.BettingRecordWinTrx__C-head-bcak[data-v-7bbbf1c1] {
    position: absolute;
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/bcakIcon-b7c1d288.png);
    background-size: 0.64rem;
    left: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
}

.BettingRecordWinTrx__C-list[data-v-7bbbf1c1] {
    margin: 0.48rem 0 0.4rem;
}

.BettingRecordWinTrx__C-list[data-v-7bbbf1c1] .MyGameRecordList__C {
    padding: 0 0.32rem;
}

.BettingRecordWinTrx__C-foot[data-v-7bbbf1c1] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    color: var(--darkTextW, var(--text_color_L1));
}

.BettingRecordWinTrx__C-foot-previous[data-v-7bbbf1c1],
.BettingRecordWinTrx__C-foot-next[data-v-7bbbf1c1] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.BettingRecordWinTrx__C-foot-previous.disabled[data-v-7bbbf1c1],
.BettingRecordWinTrx__C-foot-next.disabled[data-v-7bbbf1c1] {
    background: var(--gray-color-1);
    pointer-events: none;
}

.BettingRecordWinTrx__C-foot-previous.disabled .BettingRecordWinTrx__C-icon[data-v-7bbbf1c1],
.BettingRecordWinTrx__C-foot-next.disabled .BettingRecordWinTrx__C-icon[data-v-7bbbf1c1] {
    color: var(--saveTextColor-7);
}

.BettingRecordWinTrx__C-foot-previous .BettingRecordWinTrx__C-icon[data-v-7bbbf1c1],
.BettingRecordWinTrx__C-foot-next .BettingRecordWinTrx__C-icon[data-v-7bbbf1c1] {
    color: var(--textW);
}

.BettingRecordWinTrx__C[data-v-7bbbf1c1] .van-tabs__line {
    background-color: var(--darkLight, var(--main-color));
}

.BettingRecordWinTrx__C[data-v-7bbbf1c1] .van-tab--active {
    color: var(--darkTextW, var(--colorText-3));
    font-weight: 500;
}

.van-toast[data-v-5ba4aae3] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-5ba4aae3] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-5ba4aae3] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-5ba4aae3] {
    height: 80%;
}

.binguo_info[data-v-5ba4aae3] {
    width: 100%;
    height: 2.66667rem;
    border-radius: 0.26667rem;
    background: #0d4e2f;
    margin-bottom: 0.26667rem;
}

.binguo_info .binguo_award[data-v-5ba4aae3] {
    padding-top: 0.26667rem;
    margin-bottom: 0.18667rem;
}

.binguo_info .binguo_award .main[data-v-5ba4aae3] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.binguo_info .binguo_award .over_tip[data-v-5ba4aae3] {
    padding-top: 0.26667rem;
    height: 1.25333rem;
    width: 100%;
    color: #f9bc36;
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.32rem;
    text-align: center;
}

.binguo_info .binguo_award .current_award[data-v-5ba4aae3],
.binguo_info .binguo_award .award_result[data-v-5ba4aae3],
.binguo_info .binguo_award .award_time[data-v-5ba4aae3] {
    width: 33%;
    height: 1.25333rem;
}

.binguo_info .binguo_award .current_award .tit[data-v-5ba4aae3],
.binguo_info .binguo_award .award_result .tit[data-v-5ba4aae3],
.binguo_info .binguo_award .award_time .tit[data-v-5ba4aae3] {
    padding-top: 0.13333rem;
    color: #fff;
    font-size: 0.29333rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.29333rem;
    margin-bottom: 0.08rem;
    text-align: center;
}

.binguo_info .binguo_award .current_award .current_number[data-v-5ba4aae3],
.binguo_info .binguo_award .award_result .current_number[data-v-5ba4aae3],
.binguo_info .binguo_award .award_time .current_number[data-v-5ba4aae3] {
    color: #fff;
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 500;
    line-height: 0.66667rem;
    text-align: center;
}

.binguo_info .binguo_award .current_award .award_type[data-v-5ba4aae3],
.binguo_info .binguo_award .award_result .award_type[data-v-5ba4aae3],
.binguo_info .binguo_award .award_time .award_type[data-v-5ba4aae3] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    width: 100%;
    height: 0.66667rem;
}

.binguo_info .binguo_award .current_award .award_type div[data-v-5ba4aae3],
.binguo_info .binguo_award .award_result .award_type div[data-v-5ba4aae3],
.binguo_info .binguo_award .award_time .award_type div[data-v-5ba4aae3] {
    width: 0.61333rem;
    height: 0.64rem;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    margin: 0 0.08rem;
}

.binguo_info .binguo_award .award_time[data-v-5ba4aae3] {
    width: 2.45333rem;
    height: 1.25333rem;
    background: url(/assets/png/binguo_time-92498640.png) no-repeat;
    background-size: 100% 100%;
    font-family: digitalDreamFat, sans-serif;
    vertical-align: bottom;
    font-size: 0.53333rem;
    color: #fff;
    line-height: 1.49333rem;
    text-align: center;
    font-style: normal;
    font-weight: 400;
}

.binguo_info .trend[data-v-5ba4aae3] {
    height: 0.66667rem;
    padding: 0 0.13333rem;
    background-color: 0A603E;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.binguo_info .trend .trend_result1[data-v-5ba4aae3] {
    width: 8.16rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    border-radius: 0.13333rem;
    background-color: #0a603e;
    height: 0.66667rem;
}

.binguo_info .trend .trend_result1 .text[data-v-5ba4aae3] {
    width: 1.17333rem;
    margin-left: 0.13333rem;
    color: #5dba47;
    font-size: 0.29333rem;
    font-style: normal;
    font-weight: 400;
}

.binguo_info .trend .trend_result1 .result_list[data-v-5ba4aae3] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 100%;
    height: 0.42667rem;
}

.binguo_info .trend .trend_result1 .result_list .tag[data-v-5ba4aae3] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    width: 0.42667rem;
    height: 0.42667rem;
    margin-left: 0.06667rem;
    text-align: center;
    border-radius: 0.13333rem;
    font-size: 0.29333rem;
    font-style: normal;
    font-weight: 400;
}

.binguo_info .trend .trend_result2[data-v-5ba4aae3] {
    width: 8.16rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 0.66667rem;
}

.binguo_info .trend .trend_result2 .result_list2[data-v-5ba4aae3] {
    width: 1.6rem;
    height: 0.66667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    background: #0a603e;
    border-radius: 0.66667rem;
}

.binguo_info .trend .trend_result2 .result_list2 span[data-v-5ba4aae3] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    width: 0.42667rem;
    height: 0.42667rem;
    margin: 0 0.01333rem;
    text-align: center;
    border-radius: 50%;
    font-size: 0.29333rem;
    font-style: normal;
    font-weight: 400;
}

.binguo_info .trend .trend_img[data-v-5ba4aae3] {
    width: 0.64rem;
    height: 0.64rem;
    background: url(/assets/png/count_icon-841b89c6.png) no-repeat center center;
    background-size: 100% 100%;
}

.small_tag[data-v-5ba4aae3] {
    color: #0b462a;
    background: #fff;
}

.big_tag[data-v-5ba4aae3] {
    color: #fff;
    background: #0b462a;
}

.sum_tag[data-v-5ba4aae3] {
    color: #0b462a;
    background: #f9bc36;
}

.animation_tag[data-v-5ba4aae3] {
    border: 0.01333rem solid #87c7af;
    color: #87c7af;
    -webkit-animation: opacityEl-5ba4aae3 2s infinite;
    animation: opacityEl-5ba4aae3 2s infinite;
}

@-webkit-keyframes opacityEl-5ba4aae3 {
    0% {
        opacity: 0.3;
    }
    50% {
        opacity: 1;
    }
    to {
        opacity: 0.3;
    }
}

@keyframes opacityEl-5ba4aae3 {
    0% {
        opacity: 0.3;
    }
    50% {
        opacity: 1;
    }
    to {
        opacity: 0.3;
    }
}

.van-toast[data-v-88d327d7] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-88d327d7] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-88d327d7] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-88d327d7] {
    height: 80%;
}

.main_desk[data-v-88d327d7] {
    width: 100%;
    padding-top: 0.13333rem;
    overflow: hidden;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.main_desk .alike_box[data-v-88d327d7] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.main_desk .rule_tip[data-v-88d327d7] {
    display: inline-block;
    white-space: wrap;
    color: #5dba47;
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.32rem;
    margin-bottom: 0.32rem;
    position: relative;
    margin: 0 auto 0.32rem;
    pointer-events: none;
    max-width: 8rem;
    text-align: center;
}

.main_desk .rule_tip[data-v-88d327d7]:after {
    content: "";
    position: absolute;
    display: block;
    right: -0.45333rem;
    top: -0.08rem;
    width: 0.42667rem;
    height: 0.42667rem;
    background: url(/assets/png/rule_tip-5d3f81b0.png) no-repeat center center;
    background-size: 0.42667rem 0.42667rem;
    pointer-events: auto;
}

.main_desk .bet_size[data-v-88d327d7] {
    display: grid;
    grid-gap: 0.08rem;
    grid-template-columns: repeat(3, 1fr);
    margin-bottom: 0.13333rem;
}

.main_desk .bet_size .size_item[data-v-88d327d7] {
    height: 2.53333rem;
    border-radius: 0.13333rem;
    border: 0.05333rem solid #158054;
    background-color: #0a603e;
    color: #fff;
    position: relative;
    z-index: 1;
}

.main_desk .bet_size .size_item .hot[data-v-88d327d7] {
    position: absolute;
    right: 0;
    bottom: 0;
    width: 0.48rem;
    height: 0.48rem;
    background: url(/assets/png/hot_top-db35cb37.png) no-repeat right bottom;
    background-size: 0.48rem 0.48rem;
}

.main_desk .bet_size .size_item .head[data-v-88d327d7] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    padding: 0.13333rem;
    color: #acf8da;
    font-size: 0.29333rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.29333rem;
    margin-bottom: 0.13333rem;
}

.main_desk .bet_size .size_item .value[data-v-88d327d7] {
    text-shadow: 0 0.05333rem 0.02667rem rgba(10, 69, 41, 0.5);
    font-size: 0.8rem;
    font-style: normal;
    font-weight: 700;
    line-height: 0.8rem;
    text-align: center;
    margin-bottom: 0.13333rem;
    position: relative;
    z-index: 2;
}

.main_desk .bet_size .size_item .value_2[data-v-88d327d7] {
    color: #f9bc36;
}

.main_desk .bet_size .size_item .value_3[data-v-88d327d7] {
    color: #0b462a;
}

.main_desk .bet_size .size_item .range[data-v-88d327d7] {
    font-size: 0.37333rem;
    font-style: normal;
    font-weight: 500;
    line-height: 0.37333rem;
    text-align: center;
}

.main_desk .bet_size .size_item[data-v-88d327d7]:after {
    content: "";
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    width: 2.4rem;
    height: 100%;
    background: -webkit-radial-gradient( rgba(146, 233, 125, 0.355) 10%, rgba(10, 96, 62, 0.313) 70%);
    background: radial-gradient( rgba(146, 233, 125, 0.355) 10%, rgba(10, 96, 62, 0.313) 70%);
    -webkit-filter: blur(0.13333rem);
    filter: blur(0.13333rem);
    border-radius: 50%;
    z-index: 0;
}

.main_desk .bet_number[data-v-88d327d7] {
    display: grid;
    grid-gap: 0.08rem;
    grid-template-columns: repeat(4, 1fr);
    grid-template-rows: repeat(4, 1fr);
    margin-bottom: 0.32rem;
}

.main_desk .bet_number .item[data-v-88d327d7] {
    width: 2.26667rem;
    height: 2.02667rem;
    -webkit-flex-shrink: 0;
    flex-shrink: 0;
    border-radius: 0.13333rem;
    border: 0.02667rem solid #ffe4a6;
    background: -webkit-radial-gradient( 50% 50%, 50% 50%, #ffeaab 0%, #f8c67d 100%);
    background: radial-gradient(50% 50% at 50% 50%, #ffeaab 0%, #f8c67d 100%);
    box-shadow: 0 0.05333rem 0.05333rem #00000040;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    text-align: center;
    color: #0b462a;
    position: relative;
    margin-bottom: 0.13333rem;
}

.main_desk .bet_number .item .hot[data-v-88d327d7] {
    position: absolute;
    right: 0;
    top: 0;
    width: 0.48rem;
    height: 0.48rem;
    background: url(/assets/png/hot_top-db35cb37.png) no-repeat right top;
    background-size: 0.48rem 0.48rem;
}

.main_desk .bet_number .item .hot2[data-v-88d327d7] {
    position: absolute;
    right: -0.13333rem;
    top: -0.18667rem;
    width: 0.48rem;
    height: 0.48rem;
    background: url(/assets/png/hot_top-db35cb37.png) no-repeat right top;
    background-size: 0.48rem 0.48rem;
}

.main_desk .bet_number .item div[data-v-88d327d7]:nth-child(1) {
    height: 0.34667rem;
    padding-top: 0.13333rem;
    color: #0f6946;
    font-size: 0.34667rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.34667rem;
    margin-bottom: 0.21333rem;
}

.main_desk .bet_number .item div[data-v-88d327d7]:nth-child(2) {
    font-size: 0.64rem;
    font-style: normal;
    font-weight: 700;
    line-height: 0.64rem;
}

.main_desk .bet_number .item div[data-v-88d327d7]:nth-child(3) {
    font-size: 0.29333rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.29333rem;
}

.main_desk .betAll[data-v-88d327d7] {
    grid-gap: 0.05333rem;
    grid-template-columns: repeat(8, 1fr);
    grid-template-rows: repeat(2, 1fr);
}

.main_desk .betAll .item[data-v-88d327d7] {
    width: 1.12rem;
    height: 1.6rem;
}

.main_desk .alike[data-v-88d327d7] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    height: 2.13333rem;
    background: #0f6946;
    border-radius: 0.16rem;
    padding: 0.08rem;
    margin-bottom: 0.32rem;
}

.main_desk .alike .alike_item[data-v-88d327d7] {
    width: 1.33333rem;
    height: 1.86667rem;
    border-radius: 0.08rem;
    font-size: 0.29333rem;
}

.main_desk .alike .alike_item .amount[data-v-88d327d7] {
    height: 0.29333rem;
    margin-bottom: 0.10667rem;
    color: #0b462a;
    text-align: center;
    font-style: normal;
    font-weight: 400;
    line-height: 0.29333rem;
    padding-top: 0.05333rem;
}

.main_desk .alike .alike_item .third_list[data-v-88d327d7] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.main_desk .alike .alike_item .third_list div[data-v-88d327d7] {
    width: 0.56rem !important;
    height: 0.56rem !important;
    line-height: 0.56rem;
    font-size: 0.4rem;
}

.main_desk .alike .alike_item .third_list div .ball2[data-v-88d327d7] {
    width: 0.56rem !important;
    height: 0.56rem !important;
    font-size: 0.4rem;
    line-height: 0.56rem;
}

.main_desk .alike .alike_item[data-v-88d327d7]:nth-child(2n) {
    background: #0a4529;
}

.main_desk .alike .alike_item:nth-child(2n) .amount[data-v-88d327d7] {
    color: #21855e;
}

.main_desk .two_alike .alike_item[data-v-88d327d7],
.main_desk .one_alike .alike_item[data-v-88d327d7] {
    width: 1.54667rem;
}

.main_desk .two_alike>.alike_item>.third_list[data-v-88d327d7] {
    display: block;
}

.main_desk .two_alike>.alike_item>.third_list div[data-v-88d327d7] {
    position: relative;
    width: 0.61333rem;
    height: 0.61333rem;
    font-size: 0.48rem;
    line-height: 0.61333rem;
    z-index: 4;
}

.main_desk .two_alike>.alike_item>.third_list div .ball_hot2[data-v-88d327d7] {
    top: -40%;
    height: 52% !important;
}

.main_desk .two_alike>.alike_item>.third_list div .ball2[data-v-88d327d7] {
    width: 0.61333rem !important;
    height: 0.61333rem !important;
    font-size: 0.4rem;
    line-height: 0.61333rem;
}

.main_desk .two_alike>.alike_item>.third_list div[data-v-88d327d7]:first-child {
    margin-left: 0.29333rem;
}

.main_desk .two_alike>.alike_item>.third_list div[data-v-88d327d7]:last-child {
    float: right;
    margin-right: 0.34667rem;
}

.main_desk .one_alike .alike_item[data-v-88d327d7] {
    position: relative;
}

.main_desk .one_alike .alike_item .third_list div[data-v-88d327d7] {
    position: relative;
    width: 0.93333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    font-size: 0.64rem;
}

.main_desk .ball[data-v-88d327d7] {
    width: 0.93333rem;
    height: 0.93333rem;
    margin: 0.02667rem;
    position: relative;
}

.main_desk .ball .ball2[data-v-88d327d7] {
    width: 0.93333rem;
    height: 0.93333rem;
    position: absolute;
    z-index: 10;
    display: block;
    border-radius: 50%;
    background: -webkit-linear-gradient(286deg, #febc59 14.91%, #ff820b 89.16%);
    background: linear-gradient(164deg, #febc59 14.91%, #ff820b 89.16%);
    box-shadow: 0 0.02667rem 0.05333rem #fff880 inset;
    text-align: center;
    line-height: 0.93333rem;
    color: #0f6946;
    font-size: 0.64rem;
    font-style: normal;
    font-weight: 700;
}

.main_desk .ball[data-v-88d327d7]:after {
    content: "";
    position: absolute;
    top: 24%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    width: 0.4rem;
    height: 0.4rem;
    background: -webkit-radial-gradient( rgba(255, 255, 255, 0.673) 20%, rgba(10, 96, 62, 0.313) 90%);
    background: radial-gradient( rgba(255, 255, 255, 0.673) 20%, rgba(10, 96, 62, 0.313) 90%);
    -webkit-filter: blur(0.05333rem);
    filter: blur(0.05333rem);
    border-radius: 50%;
}

.main_desk .ball_hot2[data-v-88d327d7] {
    top: -32%;
    left: 50%;
    width: 58%;
    height: 46%;
    margin-left: -29%;
    background: url(/assets/png/hot_bg-52030c8d.png) no-repeat center top;
    background-size: 100% auto;
    position: absolute;
    z-index: 1;
}

.rule_tip_header[data-v-88d327d7] {
    margin: auto;
    width: 4.05333rem;
    height: 2.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-justify-content: space-around;
    justify-content: space-around;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-bottom: 0.4rem;
}

.rule_tip_header img[data-v-88d327d7] {
    width: 1.17333rem;
    height: 1.17333rem;
    margin-bottom: 0.13333rem;
}

.rule_tip_dialog[data-v-88d327d7] {
    padding: 0 0.8rem;
}

.rule_tip_dialog .rule_tip_tit[data-v-88d327d7] {
    color: #f9bc36;
    font-size: 0.48rem;
    font-style: normal;
    font-weight: 700;
    line-height: 0.48rem;
    text-align: center;
    margin-bottom: 0.33333rem;
}

.rule_tip_dialog .rule_tip_text[data-v-88d327d7] {
    color: #f9bc36;
    text-align: center;
    font-size: 0.34667rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.56rem;
}

.van-toast[data-v-e3548ddc] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-e3548ddc] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-e3548ddc] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-e3548ddc] {
    height: 80%;
}

.bet_content[data-v-e3548ddc] {
    width: 100%;
    background-color: #0e6946;
    padding: 0 0.32rem;
}

.bet_content .bet_tit[data-v-e3548ddc] {
    padding-top: 0.53333rem;
    text-align: center;
    color: #fff;
    margin-bottom: 0.4rem;
    font-size: 0.48rem;
    font-style: normal;
    font-weight: 700;
    line-height: normal;
}

.bet_content .bet_cnt[data-v-e3548ddc] {
    width: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.61333rem;
}

.bet_content .bet_cnt span[data-v-e3548ddc] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 1.33333rem;
    height: 1.33333rem;
    border-radius: 50%;
    line-height: 1.33333rem;
    text-align: center;
    font-size: 0.64rem;
    font-weight: 700;
    margin: 0 0.08rem;
}

.bet_content .bet_item .bet_item_tit[data-v-e3548ddc] {
    color: #acf8da;
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    margin-bottom: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.bet_content .bet_item .bet_item_tit .bet_step[data-v-e3548ddc] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-justify-content: space-around;
    justify-content: space-around;
    width: 4rem;
}

.bet_content .bet_item .bet_item_tit .bet_step span[data-v-e3548ddc] {
    display: block;
    width: 0.66667rem;
    height: 0.66667rem;
    border-radius: 50%;
    background-color: #cee98c;
    color: #0f6946;
    font-size: 0.72rem;
    line-height: 0.58667rem;
    text-align: center;
}

.bet_content .bet_item .bet_item_tit .bet_step .bet_beishu_input[data-v-e3548ddc] {
    height: 0.66667rem;
    background-color: #038d5a;
    width: 2.4rem;
    font-size: 0.37333rem;
    font-style: normal;
    font-weight: 700;
    border-radius: 0.4rem;
    border: none;
    padding: 0;
    line-height: 0.66667rem;
}

.bet_content .bet_item .bet_item_tit .bet_step[data-v-e3548ddc] .van-cell:after {
    border: none;
}

.bet_content .bet_item .bet_item_tit .bet_step[data-v-e3548ddc] .van-field__control {
    color: #fff;
}

.bet_content .bet_item .bet_money_list[data-v-e3548ddc] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    margin-bottom: 0.48rem;
}

.bet_content .bet_item .bet_money_list div[data-v-e3548ddc] {
    width: 1.73333rem;
    height: 0.93333rem;
    -webkit-flex-shrink: 0;
    flex-shrink: 0;
    background-color: #038d5a;
    border-radius: 0.08rem;
    text-align: center;
    color: #cfe988;
    line-height: 0.93333rem;
    font-size: 0.37333rem;
    font-style: normal;
    font-weight: 500;
}

.bet_content .bet_item .bet_money_list .monyActive[data-v-e3548ddc] {
    background-color: #cee98c;
    color: #0f6946;
}

.bet_content .bet_item .bet_beishu[data-v-e3548ddc] {
    margin-bottom: 0.66667rem;
}

.bet_content .bet_item .bet_beishu div[data-v-e3548ddc] {
    width: 1.46667rem;
    border: 0.00667rem solid #cee98c;
    background-color: #0e6946;
}

.bet_content .bet_info[data-v-e3548ddc] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    border-radius: 0.13333rem;
    height: 0.8rem;
    background: #0f5534;
    margin-bottom: 0.21333rem;
}

.bet_content .bet_info div[data-v-e3548ddc] {
    width: 50%;
}

.bet_content .bet_info .tit[data-v-e3548ddc] {
    color: #acf8da;
    text-align: left;
    font-size: 0.37333rem;
    font-style: normal;
    line-height: 0.53333rem;
    text-indent: 0.32rem;
    position: relative;
}

.bet_content .bet_info .tit[data-v-e3548ddc]:after {
    content: "";
    display: block;
    position: absolute;
    top: 0;
    right: 0;
    width: 0.01333rem;
    height: 0.53333rem;
    background: #0f6946;
}

.bet_content .bet_info div[data-v-e3548ddc]:nth-child(2) {
    text-align: center;
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 700;
    line-height: 0.53333rem;
}

.bet_content .recharge_tip[data-v-e3548ddc] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.37333rem;
}

.bet_content .recharge_tip span[data-v-e3548ddc] {
    color: #f9bc36;
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.48rem;
}

.bet_content .recharge_tip div[data-v-e3548ddc] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    color: #cee98c;
    font-size: 0.29333rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.48rem;
}

.bet_content .recharge_tip div i[data-v-e3548ddc] {
    margin-right: 0.13333rem;
}

.bet_content .apply[data-v-e3548ddc] {
    color: #fff;
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    padding-right: 0.18667rem;
}

.bet_content[data-v-e3548ddc] .van-checkbox__icon--checked .van-icon {
    color: #0e6946;
}

.bet_content .rule[data-v-e3548ddc] {
    color: #cee98c;
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
}

.bet_content .bet_btn_group[data-v-e3548ddc] {
    margin-top: 0.34667rem;
    width: calc(100% + 0.64rem);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 1.6rem;
    margin-left: -0.32rem;
}

.bet_content .bet_btn_group div[data-v-e3548ddc] {
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 400;
    line-height: 1.6rem;
    text-align: center;
    cursor: pointer;
}

.bet_content .bet_btn_group .cancel_btn[data-v-e3548ddc] {
    width: 3.86667rem;
    color: #fff;
    background-color: #038d5a;
}

.bet_content .bet_btn_group .bet_btn[data-v-e3548ddc] {
    width: calc(100% - 3.86667rem);
    background-color: #cee98c;
    color: #0f6946;
}

.bet_content .bet_btn_group .inconformity[data-v-e3548ddc] {
    background-color: #cbcbcb;
    color: #6b6b6b;
}

.small[data-v-e3548ddc] {
    color: #0b462a;
    background-color: #fff;
}

.big[data-v-e3548ddc] {
    color: #fff;
    background-color: #0b462a;
}

.and[data-v-e3548ddc] {
    color: #0b462a;
    background-color: #f9bc36;
}

.van-toast[data-v-a175919f] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-a175919f] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-a175919f] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-a175919f] {
    height: 80%;
}

.container[data-v-a175919f] {
    background-color: var(--LotteryBingoBg);
    border-radius: 0.2rem;
    padding-bottom: 0.32rem;
}

.container .first-paragraph[data-v-a175919f] {
    width: auto;
    height: auto;
}

.container .first-paragraph .first-statement[data-v-a175919f] {
    color: #fff;
    font-size: 0.26667rem;
    font-style: normal;
    font-weight: 400;
    letter-spacing: 0.0032rem;
    padding-top: 0.4rem;
    line-height: 0.4rem;
    text-align: justify;
}

.container .paragraph-two[data-v-a175919f] {
    width: auto;
    height: auto;
}

.container .paragraph-two .paragraph-two-statement[data-v-a175919f] {
    color: #fff;
    font-size: 0.26667rem;
    font-style: normal;
    font-weight: 400;
    letter-spacing: 0.0032rem;
    padding-top: 0.4rem;
    line-height: 0.4rem;
    text-align: justify;
    letter-spacing: 0.008rem;
}

.container .paragraph-three[data-v-a175919f] {
    height: 0.8rem;
}

.container .paragraph-three .paragraph-three-statement[data-v-a175919f] {
    color: #fff;
    font-size: 0.26667rem;
    font-style: normal;
    font-weight: 400;
    letter-spacing: 0.0032rem;
    padding-top: 0.4rem;
    line-height: 0.4rem;
    text-align: justify;
    line-height: 0.32rem;
    letter-spacing: 0;
}

.container .svg-container[data-v-a175919f] {
    width: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    margin-top: 0.66667rem;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.container .svg-container svg[data-v-a175919f] {
    width: 1.6rem;
}

.container .svg-container .first-vector[data-v-a175919f] {
    height: 0.16647rem;
    -webkit-flex-shrink: 0;
    flex-shrink: 0;
}

.container .svg-container .vector-heading[data-v-a175919f] {
    color: var(--colorText-25);
    font-size: 0.37333rem;
    font-style: normal;
    font-weight: 700;
    line-height: 0.37333rem;
    text-align: center;
    margin: 0 0.26667rem;
}

.container .svg-container .vector-two[data-v-a175919f] {
    width: 1.75219rem;
    height: 0.16647rem;
    -webkit-flex-shrink: 0;
    flex-shrink: 0;
}

.container .details-container-one[data-v-a175919f] {
    width: 100%;
    color: #fff;
    border-right: 0.02667rem solid var(--borderColor-11);
    border-bottom: 0.02667rem solid var(--borderColor-11);
    border-left: 0.02667rem solid var(--borderColor-11);
    margin-top: 0.8rem;
    border-radius: 0.2rem 0.2rem 0 0;
    background-color: var(--borderColor-11);
    padding-bottom: 0.4rem;
}

.container .details-container-one .details-container-items[data-v-a175919f] {
    width: 100%;
    height: 0.53333rem;
    background: url(/assets/png/rule_bg-50b5b9c0.png) no-repeat center center;
    background-size: 100% 0.53333rem;
    text-align: center;
    color: var(--LotteryBingoTextColor);
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 700;
    line-height: 0.53333rem;
}

.container .details-container-one .first-heading[data-v-a175919f] {
    color: #fff;
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.32rem;
    margin-left: 0.18667rem;
    margin-top: 0.26667rem;
}

.container .details-container-one .fontBold[data-v-a175919f] {
    font-weight: 700;
}

.container .details-container-one .paragraph-inside-container[data-v-a175919f] {
    margin-top: 0.26667rem;
    width: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0 0.21333rem;
    font-size: 0.32rem;
    font-weight: 400;
}

.container .details-container-one .paragraph-inside-container .paragraph-title[data-v-a175919f] {
    color: #fff;
    line-height: 0.4rem;
    margin-left: 0.13333rem;
    position: relative;
    padding-left: 0.13333rem;
}

.container .details-container-one .paragraph-inside-container .paragraph-title span[data-v-a175919f] {
    font-weight: 700;
}

.container .details-container-one .paragraph-inside-container .paragraph-title[data-v-a175919f]:after {
    content: "";
    position: absolute;
    top: 0;
    left: -0.13333rem;
    display: inline-block;
    width: 0.13333rem;
    height: 0.13333rem;
    -webkit-transform: rotate(45deg);
    transform: rotate(45deg);
    -webkit-flex-shrink: 0;
    flex-shrink: 0;
    border-radius: 0.02667rem;
    background-color: var(--LotteryBingoBg-3);
    margin-top: 0.10667rem;
}

html:lang(ar) .container .details-container-one .paragraph-inside-container .paragraph-title[data-v-a175919f]:after {
    right: -0.13333rem;
    left: unset;
}

.container .details-container-one .paragraph-inside-container .paragraph-body[data-v-a175919f] {
    width: 68%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    color: #fff;
    font-family: Inter;
    font-size: 100%;
    font-style: normal;
    font-weight: 400;
    line-height: 0.32rem;
    -webkit-flex-shrink: 0;
    flex-shrink: 0;
    height: auto;
    text-align: justify;
}

.van-toast[data-v-278561a4] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-278561a4] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-278561a4] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-278561a4] {
    height: 80%;
}

.binguo_container[data-v-278561a4] {
    width: 100%;
    min-height: 100vh;
    background: #0a4529;
    padding: 0.32rem 0.32rem 0;
}

.binguo_container .nav_title[data-v-278561a4] {
    font-size: 0.48rem;
    color: #fff;
    margin-left: 0.4rem;
}

.binguo_container .nav_right[data-v-278561a4] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 100%;
    height: 100%;
}

.binguo_container .nav_right .binguo_explain[data-v-278561a4] {
    background: url(/assets/png/icon-0d01ace2.png) no-repeat center center;
}

.binguo_container .nav_right .binguo_money_look[data-v-278561a4] {
    background: url(/assets/png/lock_money-47931447.png) no-repeat center center;
}

.binguo_container .nav_right .binguo_money_hidden[data-v-278561a4] {
    background: url(/assets/png/hidden_money-4d2f0151.png) no-repeat center center;
}

.binguo_container .nav_right .binguo_count1[data-v-278561a4] {
    background: url(/assets/png/record-5001454f.png) no-repeat center center;
}

.binguo_container .nav_right .binguo_money[data-v-278561a4],
.binguo_container .nav_right .binguo_explain[data-v-278561a4],
.binguo_container .nav_right .binguo_count1[data-v-278561a4] {
    width: 0.64rem;
    height: 0.64rem;
    margin-left: 0.26667rem;
    background-size: contain;
}

.binguo_container .binguo_btn_group[data-v-278561a4] {
    width: 7.2rem;
    height: 0.93333rem;
    margin: auto;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    border-radius: 0.26667rem;
    overflow: hidden;
    margin-bottom: 0.26667rem;
}

.binguo_container .binguo_btn_group div[data-v-278561a4] {
    width: 50%;
    background-color: #116946;
    color: #fff;
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.93333rem;
    text-align: center;
}

.binguo_container .binguo_btn_group .active_btn[data-v-278561a4] {
    background: #5dba47;
}

.binguo_container .over_dialog_tip[data-v-278561a4] {
    color: #f9bc36;
    font-size: 0.48rem;
    font-style: normal;
    font-weight: 700;
    line-height: 0.48rem;
}

.binguo_container .binguo_tip[data-v-278561a4] {
    width: 2.13333rem;
    height: 2.13333rem;
}

.binguo_container[data-v-278561a4] .dialog__container {
    background: #0e6946;
}

.binguo_container[data-v-278561a4] .dialog__container .dialog__container-footer button {
    background: -webkit-linear-gradient(top, #cee98c 0%, #5dba47 100%);
    background: linear-gradient(180deg, #cee98c 0%, #5dba47 100%);
    border: none;
    box-shadow: 0 0.05333rem #308f20;
}

.binguo_container .playerRule[data-v-278561a4] {
    height: 7.04rem;
    width: 94%;
    margin: auto;
    overflow: scroll;
    margin-bottom: 0.4rem;
}

.binguo_container .rule_dialog[data-v-278561a4] .dialog__container-title {
    height: 1.2rem;
    margin-top: -0.53333rem;
    width: calc(100% + 0.53333rem);
    border-radius: 0.26667rem 0.26667rem 0 0;
    background: -webkit-linear-gradient(top, #13ab62 0%, #168055 100%);
    background: linear-gradient(180deg, #13ab62 0%, #168055 100%);
    text-align: center;
    line-height: 1.2rem;
    color: #fff;
    font-size: 0.4rem;
}

.van-toast[data-v-44316bfe] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-44316bfe] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-44316bfe] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-44316bfe] {
    height: 80%;
}

.binguo_count_tab[data-v-44316bfe] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 100%;
    height: 1.33333rem;
    border-radius: 0.16rem;
    background-color: #0f6946;
    margin-bottom: 0.34667rem;
}

.binguo_count_tab .item[data-v-44316bfe] {
    color: #fff;
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.4rem;
    text-align: center;
    padding: 0 0.66667rem;
    -webkit-transition: opacity 0.3s ease;
    transition: opacity 0.3s ease;
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.binguo_count_tab .active[data-v-44316bfe] {
    background-color: #5dba47;
    border-radius: 0.16rem;
    color: #fff;
    opacity: 1;
}

.binguo_count_tab .item[data-v-44316bfe]:not(.active) {
    opacity: 0.8;
}

.van-toast[data-v-ca8cfc1e] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-ca8cfc1e] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-ca8cfc1e] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-ca8cfc1e] {
    height: 80%;
}

.cuTable[data-v-ca8cfc1e] {
    width: var(--ca8cfc1e-tabWidth);
    overflow: auto;
    border-top-left-radius: 0.16rem;
    border-top-right-radius: 0.16rem;
    margin: auto;
    height: var(--ca8cfc1e-tabHeight);
}

table[data-v-ca8cfc1e] {
    max-height: 16rem;
    margin: auto;
    border-spacing: 0;
    position: relative;
}

.t-table_border table[data-v-ca8cfc1e] {
    width: 100%;
    margin: auto;
    border-spacing: 0;
}

.t-table_border .tab_header[data-v-ca8cfc1e] {
    width: 100%;
    position: -webkit-sticky;
    position: sticky;
    top: -0.01333rem;
    z-index: 12;
    height: 0.8rem;
    -webkit-transform: translate3d(0, 0, 0);
    transform: translateZ(0);
    height: 1.33333rem;
}

.t-table_border .tab_body[data-v-ca8cfc1e] {
    height: var(--ca8cfc1e-rowHeight);
}

.t-table_border table tr>th[data-v-ca8cfc1e] {
    border: 0.01333rem solid var(--LotteryBingoTextColor);
    padding: 0.05333rem;
    text-align: center;
    vertical-align: middle;
}

.t-table_border table tr>th[data-v-ca8cfc1e]:nth-child(2n) {
    border-right: none;
    border-left: none;
}

.t-table_border table tr>th[data-v-ca8cfc1e]:last-child(2n) {
    border-right: 0.01333rem solid var(--LotteryBingoTextColor);
}

.t-table_border table tr>th[data-v-ca8cfc1e]:first-child {
    border-left: none;
}

.t-table_border table tr>td[data-v-ca8cfc1e] {
    border: 0.01333rem solid var(--LotteryBingoTextColor);
    border-top: none;
    padding: 0.05333rem;
    text-align: center;
    vertical-align: middle;
}

.t-table_border table tr>td[data-v-ca8cfc1e]:nth-child(2n) {
    border-right: none;
    border-left: none;
}

.t-table_border table tr>td[data-v-ca8cfc1e]:first-child {
    border-left: none;
}

.default_cell[data-v-ca8cfc1e] {
    text-align: var(--ca8cfc1e-align);
    background: var(--ca8cfc1e-rowBgColor);
    height: 100%;
    box-sizing: border-box;
}

.default_header_cell[data-v-ca8cfc1e] {
    text-align: var(--ca8cfc1e-align);
    color: var(--ca8cfc1e-hColor);
    background: var(--ca8cfc1e-hBgColor);
    height: 100%;
}

.tab_default_cell[data-v-ca8cfc1e] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 100%;
}

.bodyClass[data-v-ca8cfc1e] {
    color: var(--textW);
}

.noBorder[data-v-ca8cfc1e] {
    border: none !important;
}

.van-toast[data-v-cd38c622] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-cd38c622] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-cd38c622] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-cd38c622] {
    height: 80%;
}

.bingtip_count_title[data-v-cd38c622] {
    text-align: center;
    color: #5dba47;
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.4rem;
    margin-bottom: 0.34667rem;
}

.small[data-v-cd38c622] {
    color: #0b462a !important;
    background-color: #fff !important;
}

.big[data-v-cd38c622] {
    color: #fff !important;
    background-color: #0b462a !important;
}

.sum[data-v-cd38c622] {
    color: #0b462a !important;
    background-color: #f9bc36 !important;
}

.binguo_bet_count[data-v-cd38c622] {
    padding-bottom: 0.42667rem;
}

.binguo_bet_count .lately[data-v-cd38c622] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.4rem;
}

.binguo_bet_count .sum_column[data-v-cd38c622] {
    width: 0.64rem;
    height: 0.64rem;
    border-radius: 0.10667rem;
    text-align: center;
    line-height: 0.64rem;
    margin: 0.10667rem 0;
}

.binguo_bet_count .alike_column[data-v-cd38c622] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-justify-content: space-around;
    justify-content: space-around;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0.13333rem;
}

.binguo_bet_count .alike_column div[data-v-cd38c622] {
    width: 0.64rem;
    height: 0.64rem;
    border-radius: 50%;
    line-height: 0.64rem;
}

.binguo_bet_count .progress_box[data-v-cd38c622] {
    margin-bottom: 0.85333rem;
}

.binguo_bet_count .progress[data-v-cd38c622] {
    margin-bottom: 0.4rem;
}

.binguo_bet_count .progress .tit[data-v-cd38c622] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    color: #fff;
    margin-bottom: 0.13333rem;
}

.binguo_bet_count .progress .tit span[data-v-cd38c622] {
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 700;
    line-height: 0.4rem;
}

.binguo_bet_count .progress .tit div[data-v-cd38c622] {
    font-weight: 400;
}

.binguo_bet_count .progress .tit div span[data-v-cd38c622] {
    font-weight: 700;
}

.binguo_bet_count .two_title[data-v-cd38c622] {
    padding-top: 0.8rem;
}

.binguo_bet_count .average_column[data-v-cd38c622],
.binguo_bet_count .noaverage_column[data-v-cd38c622] {
    color: #fff;
}

.binguo_bet_count[data-v-cd38c622] .tab_body {
    border-bottom: 0.01333rem solid #0b462a;
}

.binguo_bet_count[data-v-cd38c622] .van-progress__pivot {
    display: none;
}

.binguoCountTable[data-v-cd38c622] .default_cell {
    color: #fff;
}

.van-toast[data-v-f03aed68] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-f03aed68] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-f03aed68] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-f03aed68] {
    height: 80%;
}

.bingtip_count_title[data-v-f03aed68] {
    text-align: center;
    color: #5dba47;
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.4rem;
    margin-bottom: 0.34667rem;
}

.small[data-v-f03aed68] {
    color: #0b462a !important;
    background-color: #fff !important;
}

.big[data-v-f03aed68] {
    color: #fff !important;
    background-color: #0b462a !important;
}

.sum[data-v-f03aed68] {
    color: #0b462a !important;
    background-color: #f9bc36 !important;
}

.binguo_detail[data-v-f03aed68] {
    padding-bottom: 0.77333rem;
}

.binguo_detail .result1[data-v-f03aed68] {
    height: 4.8rem;
    background: #0a603e;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    padding: 0.26667rem 0.32rem;
    border-radius: 0.16rem;
    margin-bottom: 0.53333rem;
}

.binguo_detail .result1 .column_list[data-v-f03aed68] {
    width: 0.69333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    margin-right: 0.2rem;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.binguo_detail .result1 .column_list .item[data-v-f03aed68] {
    position: relative;
    width: 0.69333rem;
    height: 0.69333rem;
    border-radius: 0.10667rem;
    text-align: center;
    line-height: 0.69333rem;
}

.binguo_detail .result1 .column_list .item[data-v-f03aed68]:after {
    content: "";
    position: absolute;
    bottom: -0.2rem;
    left: 50%;
    width: 0.01333rem;
    height: 0.2rem;
    border-radius: 0.10667rem;
    background: #5dba47;
    z-index: 1;
}

.binguo_detail .result1 .column_list .item[data-v-f03aed68]:last-child:after {
    content: "";
    position: absolute;
    width: 0;
    height: 0;
}

.binguo_detail .result1 .column_list:nth-child(odd) .item[data-v-f03aed68]:first-child {
    z-index: 2;
}

.binguo_detail .result1 .column_list:nth-child(odd) .item[data-v-f03aed68]:first-child:before {
    content: "";
    position: absolute;
    top: 50%;
    left: -0.2rem;
    width: 0.2rem;
    height: 0.01333rem;
    border-radius: 0.10667rem;
    background: #5dba47;
    z-index: 1;
}

.binguo_detail .result1 .column_list:nth-child(odd) .item[data-v-f03aed68]:last-child:before {
    content: "";
    position: absolute;
    top: 50%;
    right: -0.2rem;
    width: 0.2rem;
    height: 0.01333rem;
    border-radius: 0.10667rem;
    background: #5dba47;
    z-index: 1;
}

.binguo_detail .result1 .column_list:last-child .item[data-v-f03aed68]:first-child:before {
    content: "";
    position: absolute;
    top: 50%;
    right: -0.2rem;
    width: 0.2rem;
    height: 0.01333rem;
    border-radius: 0.10667rem;
    background: #5dba47;
    z-index: 1;
}

.binguo_detail .record_list[data-v-f03aed68] {
    display: grid;
    background: #0a603e;
    grid-template-columns: repeat(10, 1fr);
    border-radius: 0.13333rem;
    margin-bottom: 0.53333rem;
}

.binguo_detail .record_list .record_item[data-v-f03aed68] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    border-right: 0.01333rem solid #0b462a;
}

.binguo_detail .record_list .record_item .item[data-v-f03aed68] {
    width: 100%;
    position: relative;
    height: 0.93333rem;
    border-bottom: 0.01333rem solid #0b462a;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.binguo_detail .record_list .record_item .item div[data-v-f03aed68] {
    width: 0.72rem;
    height: 0.72rem;
    border-radius: 0.13333rem;
    text-align: center;
    line-height: 0.72rem;
}

.binguo_detail .record_list .record_item .item[data-v-f03aed68]:last-child {
    border-bottom: none;
}

.binguo_detail .issueNo_column[data-v-f03aed68] {
    color: #fff;
    font-size: 0.29333rem;
}

.binguo_detail .sum_column[data-v-f03aed68] {
    width: 0.64rem;
    height: 0.64rem;
    border-radius: 0.13333rem;
    line-height: 0.64rem;
}

.binguo_detail .num_column[data-v-f03aed68] {
    width: 0.85333rem;
    height: 0.53333rem;
    border-radius: 0.10667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.binguo_detail .num_column div[data-v-f03aed68] {
    width: 0.21333rem;
    height: 0.21333rem;
    border-radius: 50%;
    margin: 0 0.02667rem;
    background: #0b462a;
}

.binguo_detail .num_column1[data-v-f03aed68] {
    background-color: #87c7af;
}

.binguo_detail .num_column2[data-v-f03aed68] {
    background-color: #5dba47;
}

.binguo_detail .num_column3[data-v-f03aed68] {
    background-color: #0b462a;
}

.binguo_detail .issueNo_head[data-v-f03aed68] {
    width: 2.4rem;
    height: 1.33333rem;
    position: relative;
    color: #f9bc36;
    font-size: 0.34667rem;
}

.binguo_detail .issueNo_head .issue_text[data-v-f03aed68] {
    position: absolute;
    left: 55%;
    top: 0.13333rem;
}

.binguo_detail .issueNo_head .issue_number[data-v-f03aed68] {
    position: absolute;
    left: 10%;
    top: 0.66667rem;
}

.binguo_detail .issueNo_head[data-v-f03aed68]:before {
    content: "";
    position: absolute;
    top: 0.66667rem;
    left: -0.13333rem;
    width: 2.85333rem;
    height: 0.01333rem;
    background-color: #0b462a;
    -webkit-transform: rotate(28deg);
    transform: rotate(28deg);
    -webkit-transform-origin: top;
    transform-origin: top;
}

.ball[data-v-f03aed68] {
    width: 0.66667rem;
    height: 0.66667rem;
    border-radius: 50%;
    background: -webkit-linear-gradient(286deg, #febc59 14.91%, #ff820b 89.16%);
    background: linear-gradient(164deg, #febc59 14.91%, #ff820b 89.16%);
    box-shadow: 0 0.02667rem 0.05333rem #fff880 inset;
    text-align: center;
    line-height: 0.66667rem;
    color: #0f6946;
    font-size: 0.42667rem;
    font-style: normal;
    font-weight: 700;
    position: relative;
    z-index: 2;
    margin: auto;
}

.ball[data-v-f03aed68]:after {
    content: "";
    position: absolute;
    top: 24%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    width: 0.4rem;
    height: 0.4rem;
    background: -webkit-radial-gradient( rgba(255, 255, 255, 0.673) 20%, rgba(10, 96, 62, 0.313) 90%);
    background: radial-gradient( rgba(255, 255, 255, 0.673) 20%, rgba(10, 96, 62, 0.313) 90%);
    -webkit-filter: blur(0.05333rem);
    filter: blur(0.05333rem);
    border-radius: 50%;
    z-index: 1;
}

.van-toast[data-v-ec5b8d89] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-ec5b8d89] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-ec5b8d89] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-ec5b8d89] {
    height: 80%;
}

.trend_container[data-v-ec5b8d89] {
    padding-top: 0.6rem;
}

.trend_container .trend_header[data-v-ec5b8d89] {
    width: 100%;
    height: 3.28rem;
    position: relative;
}

.trend_container .trend_header .trend_header_title[data-v-ec5b8d89] {
    padding-left: 0.32rem;
    color: #5dba47;
    font-size: 0.48rem;
    font-style: normal;
    font-weight: 700;
    line-height: 0.48rem;
}

.trend_container .trend_header .trend_header_title span[data-v-ec5b8d89] {
    color: #fffbbb;
    font-size: 0.48rem;
    font-style: normal;
    font-weight: 700;
    line-height: 0.66667rem;
}

.trend_container .trend_header .trend_header_title[data-v-ec5b8d89]:before {
    content: "";
    position: absolute;
    top: 2%;
    left: 0;
    width: 0.08rem;
    height: 0.48rem;
    border-radius: 0.4rem;
    background: #feb320;
}

.trend_container .trend_header .trend1[data-v-ec5b8d89] {
    width: 3.21333rem;
    height: 2.86667rem;
    position: absolute;
    right: 1.04rem;
    top: -0.46667rem;
    z-index: 2;
}

.trend_container .trend_header .trend2[data-v-ec5b8d89] {
    width: auto;
    height: 3.33333rem;
    position: absolute;
    right: -0.32rem;
    top: 1.86667rem;
    z-index: 1;
}

.trend_container .trend_table[data-v-ec5b8d89] {
    position: relative;
}

.trend_container .trend_table .trend_tip[data-v-ec5b8d89] {
    position: relative;
    z-index: 3;
    width: 100%;
    height: 2.93333rem;
    background: url(/assets/png/trend3-2a1b1d6f.png) no-repeat center;
    background-size: auto 2.90667rem;
    font-size: 0.42667rem;
    color: #fff;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    white-space: wrap;
}

.trend_container .trend_table .trend_tip .tip_text[data-v-ec5b8d89] {
    width: 5.33333rem;
    text-align: center;
}

.trend_container .trend_table .trend_tip .trend_go[data-v-ec5b8d89] {
    position: absolute;
    right: 0.16rem;
    top: 50%;
    width: 1.92rem;
    height: 2rem;
    margin-top: -1rem;
    background: url(/assets/png/trend_go-7405456e.png) no-repeat center;
    background-size: 1.92rem 2rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    font-size: 0.85333rem;
    color: #d10000;
    vertical-align: baseline;
}

.trend_container .trend_table .trend_tip .trend_go span[data-v-ec5b8d89] {
    margin-top: 0.29333rem;
    font-size: 0.32rem;
}

.rankID_column[data-v-ec5b8d89] {
    width: 1.33333rem;
    height: 1.06667rem;
    background-size: 1.06667rem 1.06667rem;
    background-repeat: no-repeat;
    background-position: center;
}

.rankID_column.top_1[data-v-ec5b8d89] {
    background-image: url(/assets/png/top_1-4e868024.png);
}

.rankID_column.top_2[data-v-ec5b8d89] {
    background-image: url(/assets/png/top_2-7d8a7364.png);
}

.rankID_column.top_3[data-v-ec5b8d89] {
    background-image: url(/assets/png/top_3-d324faac.png);
}

.rankID_column.rank_text[data-v-ec5b8d89] {
    background: -webkit-linear-gradient(top, #fff 0%, #ffa854 100%);
    background: linear-gradient(180deg, #fff 0%, #ffa854 100%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    text-shadow: 0 0.02667rem 0.01333rem rgba(0, 0, 0, 0.01);
    font-size: 0.48rem;
    font-style: normal;
    font-weight: 900;
    line-height: 1.06667rem;
}

.custom_column[data-v-ec5b8d89] {
    color: #fff;
    font-size: 0.37333rem;
}

.winmount_column[data-v-ec5b8d89] {
    background: -webkit-linear-gradient(right, #5ece49 0%, #34c089 100%);
    background: linear-gradient(270deg, #5ece49 0%, #34c089 100%);
    height: 0.66667rem;
    padding: 0 0.50667rem;
    line-height: 0.66667rem;
    text-align: center;
    border-radius: 0.77333rem;
    min-width: 3.33333rem;
}

[data-v-ec5b8d89] .tab_body:nth-child(odd) {
    background-color: #038d5a !important;
}

[data-v-ec5b8d89] .tab_body:nth-child(2n) {
    background-color: #007e50 !important;
}

[data-v-ec5b8d89] .default_cell {
    background: none;
}

[data-v-ec5b8d89] .cuTable {
    margin-top: -0.10667rem;
    width: calc(100% + 0.64rem);
    margin-left: -0.32rem;
}

.van-toast[data-v-177bff59] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-177bff59] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-177bff59] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-177bff59] {
    height: 80%;
}

.bingtip_count_title[data-v-177bff59] {
    text-align: center;
    color: #5dba47;
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.4rem;
    margin-bottom: 0.34667rem;
}

.small[data-v-177bff59] {
    color: #0b462a !important;
    background-color: #fff !important;
}

.big[data-v-177bff59] {
    color: #fff !important;
    background-color: #0b462a !important;
}

.sum[data-v-177bff59] {
    color: #0b462a !important;
    background-color: #f9bc36 !important;
}

.last7Day_container[data-v-177bff59] {
    padding-bottom: 0.4rem;
}

.result[data-v-177bff59] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.result .quan[data-v-177bff59] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-justify-content: space-around;
    justify-content: space-around;
    margin-bottom: 0.05333rem;
}

.result .quan div[data-v-177bff59] {
    width: 0.34667rem;
    height: 0.34667rem;
    border-radius: 50%;
    border: 0.01333rem solid #87c7af;
    color: #fff;
    text-align: center;
    font-size: 0.29333rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.29333rem;
}

.result .result_sum[data-v-177bff59] {
    width: 0.42667rem;
    height: 0.42667rem;
    border-radius: 0.08rem;
}

.binguo_count {
    padding: 0.32rem 0.32rem 0;
    background: #0a4529;
    min-height: 100vh;
}

.column_time {
    width: 1.33333rem;
    height: 100%;
    background: #0e6d48 !important;
    color: #fff;
    font-size: 0.29333rem;
}

.van-toast[data-v-8073d5d0] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-8073d5d0] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-8073d5d0] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-8073d5d0] {
    height: 80%;
}

.bingtip_count_title[data-v-8073d5d0] {
    text-align: center;
    color: #5dba47;
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.4rem;
    margin-bottom: 0.34667rem;
}

.small[data-v-8073d5d0] {
    color: #0b462a !important;
    background-color: #fff !important;
}

.big[data-v-8073d5d0] {
    color: #fff !important;
    background-color: #0b462a !important;
}

.sum[data-v-8073d5d0] {
    color: #0b462a !important;
    background-color: #f9bc36 !important;
}

.body-container[data-v-8073d5d0] {
    width: 100%;
    padding: 0.26667rem 0.32rem 0;
}

.MyGameRecordList__C-item-l-big[data-v-8073d5d0] {
    color: var(--colorText-2);
}

.MyGameRecordList__C-item-l-small[data-v-8073d5d0] {
    color: #fff;
}

.MyGameRecordList__C[data-v-8073d5d0] {
    padding-bottom: 0.26667rem;
}

.MyGameRecordList__C .MyGameRecordList__C-item[data-v-8073d5d0] {
    height: 1.44rem;
    -webkit-flex-shrink: 0;
    flex-shrink: 0;
    border-radius: 0.13333rem;
    background-color: #0a603e;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    cursor: pointer;
    margin-bottom: 0.26667rem;
    padding-left: 0.32rem;
}

.MyGameRecordList__C .MyGameRecordList__C-item .MyGameRecordList__C_left[data-v-8073d5d0] {
    width: calc(100% - 1.04rem);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecordList__C .MyGameRecordList__C-item .MyGameRecordList__C-item-l[data-v-8073d5d0] {
    height: 0.96rem;
    width: 0.96rem;
    -webkit-flex-shrink: 0;
    flex-shrink: 0;
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    font-family: Inter;
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.4rem;
    text-align: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    padding: 0.26667rem;
}

.MyGameRecordList__C .MyGameRecordList__C-item .MyGameRecordList__C-item-m .MyGameRecordList__C-item-m-top[data-v-8073d5d0] {
    width: 3.57333rem;
    text-align: left;
    font-size: 0.37333rem;
    font-style: normal;
    font-weight: 6.66667rem;
    line-height: 0.37333rem;
    color: #fff;
    display: block;
    padding-left: 0.37333rem;
}

.MyGameRecordList__C .MyGameRecordList__C-item .MyGameRecordList__C-item-m .MyGameRecordList__C-item-m-bottom[data-v-8073d5d0] {
    width: 3.45333rem;
    color: var(--norm_red-color);
    font-family: Inter;
    font-size: 0.29333rem;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    margin-left: 0.37333rem;
}

.MyGameRecordList__C .MyGameRecordList__C-item .MyGameRecordList__C-item-r[data-v-8073d5d0] {
    color: var(--colorText-25);
    text-align: right;
    font-size: 0.37333rem;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    padding-right: 0.13333rem;
}

.MyGameRecordList__C .MyGameRecordList__C-item[data-v-8073d5d0]:last-child {
    margin-bottom: 0;
}

.MyGameRecordList__C .MyGameRecordList__C-detail[data-v-8073d5d0] {
    color: #fff;
    background-color: #0a603e;
    border-radius: 0.13333rem;
    padding: 0.32rem;
    margin-bottom: 0.13333rem;
    margin-top: -0.24rem;
}

.MyGameRecordList__C .MyGameRecordList__C-detail .detail_title[data-v-8073d5d0] {
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 700;
    line-height: 0.6rem;
    border-bottom: 0.01333rem solid var(--LotteryBingoTextColor);
    padding-bottom: 0.13333rem;
    margin-bottom: 0.32rem;
}

.MyGameRecordList__C .MyGameRecordList__C-detail .detail_item[data-v-8073d5d0] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.26667rem;
}

.MyGameRecordList__C .MyGameRecordList__C-detail .detail_item .item_title[data-v-8073d5d0] {
    color: var(--LotteryBingoBg-3);
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.37333rem;
    background: url(/assets/png/record_icon-fca8b0d0.png) no-repeat left center;
    background-size: 0.26667rem 0.26667rem;
    padding-left: 0.61333rem;
    position: relative;
}

.MyGameRecordList__C .MyGameRecordList__C-detail .detail_item .item_title[data-v-8073d5d0]:after {
    content: "";
    display: block;
    position: absolute;
    bottom: -0.26667rem;
    left: 0.13333rem;
    width: 0;
    height: 0.26667rem;
    border-left: 0.01333rem dashed var(--norm_red-color);
}

html:lang(ar) .MyGameRecordList__C .MyGameRecordList__C-detail .detail_item .item_title[data-v-8073d5d0]:after {
    right: 0.13333rem;
    left: unset;
}

.MyGameRecordList__C .MyGameRecordList__C-detail .detail_item .item_result[data-v-8073d5d0] {
    color: #fff;
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.37333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecordList__C .MyGameRecordList__C-detail .detail_item .item_result svg[data-v-8073d5d0] {
    width: 0.32rem;
    height: 0.32rem;
    margin-left: 0.21333rem;
}

.MyGameRecordList__C .MyGameRecordList__C-detail .detail_item .item_result .draw_num[data-v-8073d5d0] {
    width: 0.42667rem;
    height: 0.42667rem;
    border-radius: 0.13333rem;
    text-align: center;
    line-height: 0.42667rem;
    font-size: 0.29333rem;
    margin-right: 0.13333rem;
}

.MyGameRecordList__C .MyGameRecordList__C-detail .detail_item .item_result .draw_result[data-v-8073d5d0] {
    width: 0.42667rem;
    height: 0.42667rem;
    border-radius: 50%;
    text-align: center;
    line-height: 0.42667rem;
    font-size: 0.29333rem;
    background-color: var(--norm_red-color);
    color: var(--LotteryBingoTextColor);
    margin: 0 0.02667rem;
}

.MyGameRecordList__C .MyGameRecordList__C-detail .detail_item:last-child .item_title[data-v-8073d5d0]:after {
    height: 0;
}

.MyGameRecordList__C .MyGameRecordList__C-detail .detail_item:last-child .item_result[data-v-8073d5d0] {
    color: var(--norm_red-color);
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.37333rem;
}

.MyGameRecordList__C .item_bet[data-v-8073d5d0] {
    min-width: 0.48rem;
    height: 0.48rem;
    padding: 0 0.05333rem;
    border-radius: 0.13333rem;
    background: var(--LotteryBingoTextColor);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
    font-size: 0.29333rem;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
}

.MyGameRecordList__C .item_alike[data-v-8073d5d0] {
    border-radius: 50%;
    margin-left: 0.05333rem;
}

.success[data-v-8073d5d0] {
    color: #39eb8b !important;
}

.fail[data-v-8073d5d0] {
    color: var(--main-color) !important;
}

.wait[data-v-8073d5d0] {
    color: var(--colorText-25) !important;
}

.ing[data-v-8073d5d0] {
    color: var(--bgcolor-27) !important;
}

.van-toast[data-v-5e0daa42] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-5e0daa42] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-5e0daa42] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-5e0daa42] {
    height: 80%;
}

.record-container[data-v-5e0daa42] {
    min-height: 100vh;
    width: 100%;
    background-color: #0a4529;
}

.van-toast[data-v-6c7a1db6] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-6c7a1db6] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-6c7a1db6] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-6c7a1db6] {
    height: 80%;
}

.Betting__Popup .bgcolor[data-v-6c7a1db6] {
    background-color: var(--main-color);
}

.Betting__Popup-head[data-v-6c7a1db6] {
    height: 2.53333rem;
    position: relative;
    padding-top: 0.4rem;
    background: var(--main-color);
}

.Betting__Popup-head[data-v-6c7a1db6]:after {
    content: "";
    position: absolute;
    width: 50%;
    left: 0;
    bottom: 0;
    height: 0.78667rem;
    background-image: -webkit-linear-gradient( 81deg, var(--bg_color_L2) 50%, transparent 50%);
    background-image: linear-gradient( 9deg, var(--bg_color_L2) 50%, transparent 50%);
}

html:lang(ar) .Betting__Popup-head[data-v-6c7a1db6]:after {
    right: 0;
    left: unset;
}

.Betting__Popup-head[data-v-6c7a1db6]:before {
    content: "";
    position: absolute;
    right: 0;
    bottom: 0;
    width: 50%;
    height: 0.78667rem;
    background-image: -webkit-linear-gradient( 99deg, var(--bg_color_L2) 50%, transparent 50%);
    background-image: linear-gradient( -9deg, var(--bg_color_L2) 50%, transparent 50%);
}

html:lang(ar) .Betting__Popup-head[data-v-6c7a1db6]:before {
    right: unset;
    left: 0;
}

.Betting__Popup-head-title[data-v-6c7a1db6] {
    height: 0.58667rem;
    font-weight: 700;
    font-size: 0.48rem;
    text-align: center;
    color: var(--text_color_L1);
}

.Betting__Popup-head-selectName[data-v-6c7a1db6] {
    width: 7.46667rem;
    height: 0.66667rem;
    margin: 0.21333rem auto 0;
    background: var(--light-main_gradient-color, var(--text_color_L1));
    border-radius: 0.13333rem;
    text-align: center;
    font-weight: 500;
    font-size: 0.34667rem;
    color: var(--text_color_L4);
}

.Betting__Popup-head-selectName>span[data-v-6c7a1db6] {
    line-height: 0.66667rem;
}

.Betting__Popup-head-selectName>span+span[data-v-6c7a1db6] {
    margin-left: 0.37333rem;
}

.Betting__Popup-body[data-v-6c7a1db6] {
    height: 5.2rem;
    padding: 0.76rem 0.34667rem 0.53333rem;
}

.Betting__Popup-body-line[data-v-6c7a1db6] {
    font-size: 0.42667rem;
    color: var(--darkTextW, var(--text_color_L1));
    height: 0.74667rem;
    line-height: 0.74667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Betting__Popup-body-line-list[data-v-6c7a1db6] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Betting__Popup-body-line-item[data-v-6c7a1db6] {
    padding: 0 0.21333rem;
    background: var(--bg_color_L3);
    border-radius: 0.08rem;
    color: var(--text_color_L2);
}

.Betting__Popup-body-line-item+div[data-v-6c7a1db6] {
    margin-left: 0.16rem;
}

.Betting__Popup-body-line+div[data-v-6c7a1db6] {
    margin-top: 0.4rem;
}

.Betting__Popup-body-line-btnL[data-v-6c7a1db6] {
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.Betting__Popup-body-line[data-v-6c7a1db6]:last-child {
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    justify-content: flex-start;
}

.Betting__Popup-foot[data-v-6c7a1db6] {
    height: 0.96rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    text-align: center;
    line-height: 0.96rem;
    font-size: 0.37333rem;
    color: var(--text_color_L4);
}

.Betting__Popup-foot-c[data-v-6c7a1db6] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    background: var(--bg_color_L3);
    color: var(--text_color_L2);
}

.Betting__Popup-foot-s[data-v-6c7a1db6] {
    -webkit-box-flex: 2;
    -webkit-flex: 2;
    flex: 2;
}

.Betting__Popup-btn[data-v-6c7a1db6] {
    width: 0.74667rem;
    height: 0.74667rem;
    pointer-events: none;
    text-align: center;
    font-size: 0.66667rem;
    padding: 0;
    background: var(--gray-color-1);
    color: var(--button_dis_color);
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    border-radius: 0.08rem;
}

.Betting__Popup-input[data-v-6c7a1db6] {
    border: 0.01333rem solid var(--gray-color-1);
    padding: 0.02667rem 0.26667rem;
    width: 2.10667rem;
    margin: 0 0.16rem;
    background: unset;
    background-color: var(--bg_color_L1);
    border-radius: 0.08rem;
}

.Betting__Popup-input[data-v-6c7a1db6]:after {
    content: none;
}

.Betting__Popup-input[data-v-6c7a1db6] .van-field__control {
    text-align: center;
    font-size: 0.37333rem;
    line-height: 0.72rem;
}

.Betting__Popup-agree[data-v-6c7a1db6] {
    padding-left: 0.8rem;
    background-image: url(/assets/png/agree-b-47b8f86d.png);
    background-repeat: no-repeat;
    background-position: left center;
    background-size: 0.64rem;
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

html:lang(ar) .Betting__Popup-agree[data-v-6c7a1db6] {
    background-position: right center;
}

.Betting__Popup-agree.active[data-v-6c7a1db6] {
    background-image: url(/assets/png/agree-a-32b06ce9.png);
}

.Betting__Popup-preSaleShow[data-v-6c7a1db6] {
    margin-left: 0.34667rem;
    font-size: 0.32rem;
    color: var(--norm_red-color);
}

.Betting__Popup-PreSale[data-v-6c7a1db6] {
    width: 7.04rem;
}

.Betting__Popup-PreSale-head[data-v-6c7a1db6] {
    height: 1.2rem;
    line-height: 1.2rem;
    color: var(--text_color_L4);
    font-size: 0.4rem;
    text-align: center;
    background: var(--main_gradient-color);
}

.Betting__Popup-PreSale-body[data-v-6c7a1db6] {
    max-height: 8rem;
    overflow-y: auto;
    color: var(--text_color_L1);
    padding: 0.4rem;
    font-size: 0.32rem;
    line-height: 0.8rem;
}

.Betting__Popup-PreSale-body[data-v-6c7a1db6] p {
    margin-bottom: 0.2rem;
    line-height: 0.53333rem;
}

.Betting__Popup-PreSale-foot[data-v-6c7a1db6] {
    height: 1.86667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.Betting__Popup-PreSale-foot-btn[data-v-6c7a1db6] {
    width: 60%;
    background: var(--main_gradient-color);
    border-radius: 0.53333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    font-size: 0.37333rem;
    color: var(--text_color_L4);
}

.bgcolor[data-v-6c7a1db6] {
    pointer-events: all;
    color: var(--bg_color_L1);
}

.van-toast[data-v-91d808d9] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-91d808d9] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-91d808d9] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-91d808d9] {
    height: 80%;
}

.changLong__C[data-v-91d808d9] {
    padding: 0.32rem 0.34667rem;
}

.changLong__C[data-v-91d808d9] .navbar__content .van-icon,
.changLong__C[data-v-91d808d9] .navbar__content .navbar__content-center {
    color: var(--text_color_L4);
}

.changLong__C[data-v-91d808d9] .van-tabs__line {
    width: calc(50% - 0.69333rem);
    background: var(--colorText-2);
}

.changLong__C[data-v-91d808d9] .van-tabs__content {
    padding: 0.32rem 0.34667rem;
}

.changLong__C-bet[data-v-91d808d9] {
    height: 2.4rem;
    width: 100%;
    background: var(--bg_color_L2);
    border-radius: 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    padding: 0.24rem 0.18667rem;
}

.changLong__C-bet-l[data-v-91d808d9] {
    width: auto;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
}

.changLong__C-bet-l .titel[data-v-91d808d9] {
    height: 0.53333rem;
    line-height: 0.53333rem;
    margin-bottom: 0.24rem;
    color: var(--text_color_L1);
    font-size: 0.34667rem;
    padding-left: 1.09333rem;
    background-position: left;
    background-repeat: no-repeat;
    background-size: 0.8rem 0.53333rem;
}

html:lang(ar) .changLong__C-bet-l .titel[data-v-91d808d9] {
    background-position: right;
}

.changLong__C-bet-l .titel.k3[data-v-91d808d9] {
    background-image: url(/assets/png/icon-k3-dabf0a83.png);
}

.changLong__C-bet-l .titel.Fd[data-v-91d808d9] {
    background-image: url(/assets/png/icon-5d-dadd282e.png);
}

.changLong__C-bet-l .titel.winGo[data-v-91d808d9] {
    background-image: url(/assets/png/icon-wg-b65da4c5.png);
}

.changLong__C-bet-l .num[data-v-91d808d9] {
    height: 0.4rem;
    margin-bottom: 0.13333rem;
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.changLong__C-bet-l .num .time[data-v-91d808d9] {
    color: var(--norm_red-color);
}

.changLong__C-bet-l .other[data-v-91d808d9] {
    height: 0.64rem;
    line-height: 0.64rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.changLong__C-bet-l .other>div[data-v-91d808d9] {
    color: var(--text_color_L4);
    font-size: 0.32rem;
}

.changLong__C-bet-l .other>div+div[data-v-91d808d9] {
    margin-left: 0.08rem;
}

.changLong__C-bet-l .other .remark[data-v-91d808d9] {
    color: var(--text_color_L1);
    background: var(--button_dis_color);
    padding: 0 0.18667rem;
}

.changLong__C-bet-l .other .issue[data-v-91d808d9] {
    background: var(--main-color);
    color: var(--text_color_L4);
    padding: 0 0.18667rem;
}

.changLong__C-bet-l .other .gameResult[data-v-91d808d9] {
    padding: 0 0.13333rem;
}

.changLong__C-bet-l .other .gameResult.bg-L[data-v-91d808d9],
.changLong__C-bet-l .other .gameResult.bg-O[data-v-91d808d9] {
    background-color: var(--norm_secondary-color);
    color: var(--text_color_L4);
}

.changLong__C-bet-l .other .gameResult.bg-red[data-v-91d808d9],
.changLong__C-bet-l .other .gameResult.bg-E[data-v-91d808d9] {
    background-color: var(--norm_red-color);
    color: var(--text_color_L4);
}

.changLong__C-bet-l .other .gameResult.bg-violet[data-v-91d808d9] {
    background-color: var(--norm_Purple-color);
    color: var(--text_color_L4);
}

.changLong__C-bet-l .other .gameResult.bg-green[data-v-91d808d9],
.changLong__C-bet-l .other .gameResult.bg-small[data-v-91d808d9],
.changLong__C-bet-l .other .gameResult.bg-H[data-v-91d808d9] {
    background-color: var(--norm_bule-color);
    color: var(--text_color_L4);
}

.changLong__C-bet-r[data-v-91d808d9] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.changLong__C-bet-r>div[data-v-91d808d9] {
    width: 1.33333rem;
    height: 0.8rem;
    line-height: 0.8rem;
    text-align: center;
    border: 0.00667rem solid var(--main-color);
    border-radius: 0.10667rem;
    font-size: 0.32rem;
    color: var(--main-color);
}

.changLong__C-bet-r>div.active[data-v-91d808d9] {
    background: var(--main-color);
    color: var(--text_color_L4);
}

.changLong__C-bet-r>div+div[data-v-91d808d9] {
    margin-left: 0.21333rem;
}

.changLong__C-bet-r.disable>div[data-v-91d808d9] {
    pointer-events: none;
    background-color: var(--button_dis_color);
    color: var(--text_color_L4);
    border: 0.00667rem solid var(--button_dis_color);
}

.changLong__C-bet-r.disable>div.active[data-v-91d808d9] {
    background-color: var(--button_dis_color);
    color: var(--text_color_L4);
}

.changLong__C-bet+div[data-v-91d808d9] {
    margin-top: 0.21333rem;
}

.van-toast[data-v-4b21e13b] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-4b21e13b] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-4b21e13b] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-4b21e13b] {
    height: 80%;
}

.MyGameRecord__C[data-v-4b21e13b] {
    width: calc(100% - 0.69333rem);
    margin: 0.32rem auto 0;
}

.MyGameRecord__C-head[data-v-4b21e13b] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
    background-color: var(--darkBg, var(--bg_color_L2));
    padding: 0.32rem 0.32rem 0;
}

.MyGameRecord__C-head-moreB[data-v-4b21e13b] {
    border: 0.01333rem solid var(--main-color);
    height: 0.8rem;
    line-height: 0.8rem;
    border-radius: 0.26667rem;
    padding: 0 0.24rem;
    color: var(--main-color);
    font-size: 0.32rem;
    position: relative;
}

.MyGameRecord__C-head-moreB svg[data-v-4b21e13b] {
    height: 0.42667rem;
    width: 0.42667rem;
}

.MyGameRecord__C-body[data-v-4b21e13b] {
    background-color: var(--darkBg, var(--bg_color_L2));
    padding: 0 0.32rem;
}

.MyGameRecord__C-body-empty[data-v-4b21e13b] {
    height: 5.33333rem;
}

.MyGameRecord__C-foot[data-v-4b21e13b] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecord__C-foot-page[data-v-4b21e13b] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.MyGameRecord__C-foot-previous[data-v-4b21e13b],
.MyGameRecord__C-foot-next[data-v-4b21e13b] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    color: var(--text_color_L4);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.MyGameRecord__C-foot-previous.disabled[data-v-4b21e13b],
.MyGameRecord__C-foot-next.disabled[data-v-4b21e13b] {
    background: var(--bg_color_L3);
    pointer-events: none;
    color: var(--text_color_L2);
}

.MyGameRecord__C-foot-previous.disabled .MyGameRecord__C-icon[data-v-4b21e13b],
.MyGameRecord__C-foot-next.disabled .MyGameRecord__C-icon[data-v-4b21e13b] {
    color: var(--saveTextColor-7);
}

.MyGameRecord__C-foot-previous .MyGameRecord__C-icon[data-v-4b21e13b],
.MyGameRecord__C-foot-next .MyGameRecord__C-icon[data-v-4b21e13b] {
    color: #fff;
}

.van-toast[data-v-cffd8c9f] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-cffd8c9f] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-cffd8c9f] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-cffd8c9f] {
    height: 80%;
}

.MyGameRecord__C[data-v-cffd8c9f] {
    width: calc(100% - 0.69333rem);
    margin: 0.32rem auto 0;
    background-color: var(--bg_color_L2);
    border-radius: 0.21333rem;
}

.MyGameRecord__C-head[data-v-cffd8c9f] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
    padding: 0.32rem 0.32rem 0;
}

.MyGameRecord__C-head-moreB[data-v-cffd8c9f] {
    border: 0.01333rem solid var(--main-color);
    height: 0.8rem;
    line-height: 0.8rem;
    border-radius: 0.26667rem;
    padding: 0 0.24rem;
    color: var(--main-color);
    font-size: 0.32rem;
    position: relative;
}

.MyGameRecord__C-head-moreB svg[data-v-cffd8c9f] {
    width: 0.4rem;
    height: 0.4rem;
}

.MyGameRecord__C-body[data-v-cffd8c9f] {
    padding: 0 0.32rem;
}

.MyGameRecord__C-body-empty[data-v-cffd8c9f] {
    height: 5.33333rem;
}

.MyGameRecord__C-foot[data-v-cffd8c9f] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    color: var(--text_color_L2);
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecord__C-foot-page[data-v-cffd8c9f] {
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.MyGameRecord__C-foot-previous[data-v-cffd8c9f],
.MyGameRecord__C-foot-next[data-v-cffd8c9f] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.MyGameRecord__C-foot-previous.disabled[data-v-cffd8c9f],
.MyGameRecord__C-foot-next.disabled[data-v-cffd8c9f] {
    background: var(--button_dis_color);
    pointer-events: none;
}

.MyGameRecord__C-foot-previous.disabled .MyGameRecord__C-icon[data-v-cffd8c9f],
.MyGameRecord__C-foot-next.disabled .MyGameRecord__C-icon[data-v-cffd8c9f] {
    color: var(--text_color_L2);
}

.MyGameRecord__C-foot-previous .MyGameRecord__C-icon[data-v-cffd8c9f],
.MyGameRecord__C-foot-next .MyGameRecord__C-icon[data-v-cffd8c9f] {
    color: var(--text_color_L4);
}

.van-toast[data-v-7c263a55] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-7c263a55] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-7c263a55] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-7c263a55] {
    height: 80%;
}

.BetRecord__C-gameTab[data-v-7c263a55] {
    border-top: 0.01333rem solid var(--gray-color-1);
}

.BetRecord__C-gameTab[data-v-7c263a55] .van-tabs__line {
    width: calc(33% - 0.69333rem);
    background: var(--norm_green-color);
}

.BetRecord__C-gameTab[data-v-7c263a55] .van-tabs__nav {
    background-color: var(--bg_color_L2);
}

.BetRecord__C-gameTab[data-v-7c263a55] .van-tab--line {
    color: var(--text_color_L3);
}

.BetRecord__C-gameTab[data-v-7c263a55] .van-tab--active {
    color: var(--text_color_L1);
    font-weight: 500;
}

.BetRecord__C-timeTab[data-v-7c263a55] {
    border-top: 0.01333rem solid var(--gray-color-1);
}

.BetRecord__C-timeTab[data-v-7c263a55] .van-tabs__line {
    width: calc(25% - 0.69333rem);
    background: var(--norm_red-color);
}

.BetRecord__C-timeTab[data-v-7c263a55] .van-tab--line {
    color: var(--text_color_L3);
}

.BetRecord__C-timeTab[data-v-7c263a55] .van-tabs__nav {
    background-color: var(--bg_color_L2);
}

.BetRecord__C-timeTab[data-v-7c263a55] .van-tab--active {
    color: var(--text_color_L1);
    font-weight: 500;
}

.van-toast[data-v-6aad721b] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-6aad721b] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-6aad721b] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-6aad721b] {
    height: 80%;
}

.changLong__C-tab[data-v-6aad721b] .van-tabs__line {
    width: calc(50% - 0.69333rem);
    background-color: var(--main-color);
}

.changLong__C-tab[data-v-6aad721b] .van-tabs__nav {
    background-color: var(--bg_color_L2);
}

.changLong__C-tab[data-v-6aad721b] .van-tab--active {
    color: var(--text_color_L1);
    font-weight: 500;
}

.changLong__C[data-v-6aad721b] .navbar__content .van-icon,
.changLong__C[data-v-6aad721b] .navbar__content .navbar__content-center {
    color: var(--textW);
}

.van-toast[data-v-75b35bf5] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-75b35bf5] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-75b35bf5] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-75b35bf5] {
    height: 80%;
}

.K3TL__C[data-v-75b35bf5] {
    width: calc(100% - 0.69333rem);
    margin: 0.34667rem auto 0;
    background-color: var(--bg_color_L2);
    padding: 0.42667rem 0.29333rem 0.45333rem;
    border-radius: 0.26667rem 0.26667rem 0 0;
}

.K3TL__C-rule[data-v-75b35bf5] {
    height: 0.61333rem;
    width: 2.93333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    font-size: 0.29333rem;
    text-align: center;
    border: 0.01333rem solid var(--main-color);
    border-radius: 0.8rem;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    color: var(--main-color);
    margin-left: 0.4rem;
    gap: 0.04rem;
}

.K3TL__C-rule svg[data-v-75b35bf5] {
    color: var(--main-color);
    width: 0.42667rem;
    height: 0.42667rem;
}

.K3TL__C-l1[data-v-75b35bf5] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 0.61333rem;
    color: var(--text_color_L2);
    font-size: 0.32rem;
}

.K3TL__C-l1 .left[data-v-75b35bf5] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 0.61333rem;
}

.K3TL__C-l1>div[data-v-75b35bf5]:not(.left) {
    -webkit-align-self: flex-start;
    align-self: flex-start;
}

.K3TL__C-l2[data-v-75b35bf5] {
    height: 0.8rem;
    line-height: 0.8rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    font-weight: 700;
    font-size: 0.53333rem;
    color: var(--text_color_L1);
}

.K3TL__C-l3[data-v-75b35bf5] {
    height: 3.09333rem;
    margin-top: 0.48rem;
    background: #00b977;
    border-radius: 0.18667rem;
    position: relative;
    padding: 0.26667rem;
}

.K3TL__C-l3[data-v-75b35bf5]:after,
.K3TL__C-l3[data-v-75b35bf5]:before {
    content: "";
    display: block;
    width: 0.13333rem;
    height: 0.69333rem;
    position: absolute;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    z-index: 0;
    background-color: #008b59;
}

.K3TL__C-l3[data-v-75b35bf5]:before {
    border-radius: 0.13333rem 0 0 0.13333rem;
    left: -0.13333rem;
}

.K3TL__C-l3[data-v-75b35bf5]:after {
    border-radius: 0 0.13333rem 0.13333rem 0;
    right: -0.13333rem;
}

.K3TL__C-l3 .box[data-v-75b35bf5] {
    background: #003c26;
    border-radius: 0.13333rem;
    height: 100%;
    width: 100%;
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0.13333rem;
}

.K3TL__C-l3 .box[data-v-75b35bf5]:after,
.K3TL__C-l3 .box[data-v-75b35bf5]:before {
    position: absolute;
    width: 0;
    height: 0;
    border-top: 0.18667rem solid transparent;
    border-bottom: 0.18667rem solid transparent;
    content: "";
    z-index: 3;
}

.K3TL__C-l3 .box[data-v-75b35bf5]:before {
    left: 0;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    border-right: 0.53333rem solid transparent;
    border-left: 0.53333rem solid #00b575;
}

.K3TL__C-l3 .box[data-v-75b35bf5]:after {
    right: 0;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    border-left: 0.53333rem solid transparent;
    border-right: 0.53333rem solid #00b575;
}

.K3TL__C-l3 .box>div[data-v-75b35bf5] {
    width: calc((100% - 0.4rem) / 3);
    height: 2.29333rem;
    background-color: #727272;
    border-radius: 0.13333rem;
    position: relative;
    background-position: center;
    background-size: 70%;
    background-repeat: no-repeat;
}

.K3TL__C-l3 .box>div[data-v-75b35bf5]:before {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 100%;
    content: "";
    z-index: 2;
    box-shadow: inset 0 -0.13333rem 0.13333rem #0000004d, inset 0 0.13333rem 0.13333rem #0000004d;
}

.K3TL__C-l3 .num1[data-v-75b35bf5] {
    background-image: url(/assets/png/num1-9f16525b.png);
}

.K3TL__C-l3 .num2[data-v-75b35bf5] {
    background-image: url(/assets/png/num2-96e175aa.png);
}

.K3TL__C-l3 .num3[data-v-75b35bf5] {
    background-image: url(/assets/png/num3-52bb404d.png);
}

.K3TL__C-l3 .num4[data-v-75b35bf5] {
    background-image: url(/assets/png/num4-6bed6212.png);
}

.K3TL__C-l3 .num5[data-v-75b35bf5] {
    background-image: url(/assets/png/num5-7962f058.png);
}

.K3TL__C-l3 .num6[data-v-75b35bf5] {
    background-image: url(/assets/png/num6-1cc40321.png);
}

.K3TL__C-l3>div[data-v-75b35bf5],
.K3TL__C-l3>p[data-v-75b35bf5] {
    width: 1.46667rem;
    height: 1.46667rem;
    line-height: 1.46667rem;
    text-align: center;
    font-weight: 700;
    font-size: 0.64rem;
    background-position: center;
    background-size: 100% 100%;
    background-repeat: no-repeat;
}

.K3TL__C-time[data-v-75b35bf5] {
    height: 0.8rem;
    line-height: 0.8rem;
    bottom: 0.29333rem;
    right: 0.32rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

html:lang(ar) .K3TL__C-time[data-v-75b35bf5] {
    direction: ltr;
}

.K3TL__C-time>div[data-v-75b35bf5] {
    background: var(--bg_color_L3);
    border-radius: 0.05333rem;
    color: var(--main-color);
    font-weight: 700;
    font-size: 0.48rem;
    text-align: center;
    padding: 0 0.13333rem;
    background-position: center;
    background-size: 100% 100%;
    background-repeat: no-repeat;
}

.K3TL__C-time>div[notime][data-v-75b35bf5] {
    background-color: transparent;
}

.K3TL__C-time>div+div[data-v-75b35bf5] {
    margin-left: 0.12rem;
}

.van-toast[data-v-ed0c8e79] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-ed0c8e79] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-ed0c8e79] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-ed0c8e79] {
    height: 80%;
}

.K3B__C-bettingList[data-v-ed0c8e79] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.K3B__C-bettingList>div[data-v-ed0c8e79] {
    width: calc((100% - 0.6rem) / 4);
    height: 1.6rem;
    border-radius: 0.13333rem;
    text-align: center;
    margin-top: 0.21333rem;
    color: var(--text_color_L2);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.K3B__C-bettingList>div .ball[data-v-ed0c8e79] {
    width: 1.17333rem;
    height: 1.17333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin: 0 auto;
}

.K3B__C-bettingList>div .ball.rball[data-v-ed0c8e79] {
    background: url(/assets/png/redBall-fd34b99e.png) no-repeat center center;
    background-size: cover;
}

.K3B__C-bettingList>div .ball.rball .K3B__C-odds-bet[data-v-ed0c8e79] {
    background: -webkit-linear-gradient(top, #ff827a 0%, #e93333 68.18%);
    background: linear-gradient(180deg, #ff827a 0%, #e93333 68.18%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.K3B__C-bettingList>div .ball.gball[data-v-ed0c8e79] {
    background: url(/assets/png/greenBall-b7685130.png) no-repeat center center;
    background-size: cover;
}

.K3B__C-bettingList>div .ball.gball .K3B__C-odds-bet[data-v-ed0c8e79] {
    background: var(--norm_green-color);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.K3B__C-bettingList>div .ball .K3B__C-odds-bet[data-v-ed0c8e79] {
    font-size: 0.64rem;
    font-weight: 700;
}

.K3B__C-bettingList>div.numA[data-v-ed0c8e79],
.K3B__C-bettingList>div.numB[data-v-ed0c8e79],
.K3B__C-bettingList>div.numC[data-v-ed0c8e79],
.K3B__C-bettingList>div.numD[data-v-ed0c8e79] {
    height: 1.17333rem;
    background-color: var(--norm_secondary-color);
    color: #fff;
}

.K3B__C-bettingList>div.numB[data-v-ed0c8e79] {
    background-color: var(--norm_bule-color);
}

.K3B__C-bettingList>div.numC[data-v-ed0c8e79] {
    background-color: var(--norm_red-color);
}

.K3B__C-bettingList>div.numD[data-v-ed0c8e79] {
    background-color: var(--norm_green-color);
}

.K3B__C-bettingList>div .K3B__C-odds-bet[data-v-ed0c8e79] {
    font-size: 0.37333rem;
}

.K3B__C-bettingList>div .K3B__C-odds-rate[data-v-ed0c8e79] {
    font-size: 0.29333rem;
}

.van-toast[data-v-5c28a69e] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-5c28a69e] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-5c28a69e] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-5c28a69e] {
    height: 80%;
}

.K3B__C-betting2[data-v-5c28a69e] {
    margin-top: 0.26667rem;
}

.K3B__C-betting2-tip1[data-v-5c28a69e] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 0.4rem;
    font-size: 0.34667rem;
    line-height: 0.4rem;
    color: var(--text_color_L1);
}

.K3B__C-betting2-tip1 .icon[data-v-5c28a69e] {
    margin-left: 0.13333rem;
}

.K3B__C-betting2-line1[data-v-5c28a69e],
.K3B__C-betting2-line2[data-v-5c28a69e],
.K3B__C-betting2-line3[data-v-5c28a69e] {
    height: 0.93333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    margin: 0.21333rem 0;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.K3B__C-betting2-line1.mb30[data-v-5c28a69e],
.K3B__C-betting2-line2.mb30[data-v-5c28a69e],
.K3B__C-betting2-line3.mb30[data-v-5c28a69e] {
    margin-bottom: 0.4rem;
}

.K3B__C-betting2-line1>div[data-v-5c28a69e],
.K3B__C-betting2-line2>div[data-v-5c28a69e],
.K3B__C-betting2-line3>div[data-v-5c28a69e] {
    width: calc((100% - 1.33333rem) / 6);
    height: 0.93333rem;
    line-height: 0.93333rem;
    color: #fff;
    text-align: center;
    border-radius: 0.13333rem;
    opacity: 0.5;
}

.K3B__C-betting2-line1>div.active[data-v-5c28a69e],
.K3B__C-betting2-line2>div.active[data-v-5c28a69e],
.K3B__C-betting2-line3>div.active[data-v-5c28a69e] {
    opacity: 1;
}

.K3B__C-betting2-line1>div[data-v-5c28a69e] {
    background: var(--norm_Purple-color);
    font-size: 0.37333rem;
}

.K3B__C-betting2-line1>div.active[data-v-5c28a69e] {
    position: relative;
}

.K3B__C-betting2-line1>div.active[data-v-5c28a69e]:after {
    content: "";
    display: block;
    width: 0.42667rem;
    height: 0.42667rem;
    background-image: url(/assets/svg/subtract-ca63ef68.svg);
    background-size: 0.42667rem;
    background-position: center;
    position: absolute;
    bottom: 0;
    right: 0;
}

.K3B__C-betting2-line2>div[data-v-5c28a69e] {
    background: var(--norm_red-color);
    font-size: 0.37333rem;
}

.K3B__C-betting2-line2>div.active[data-v-5c28a69e] {
    position: relative;
}

.K3B__C-betting2-line2>div.active[data-v-5c28a69e]:after {
    content: "";
    display: block;
    width: 0.42667rem;
    height: 0.42667rem;
    background-image: url(/assets/svg/subtract-ca63ef68.svg);
    background-size: 0.42667rem;
    background-position: center;
    position: absolute;
    bottom: 0;
    right: 0;
}

.K3B__C-betting2-line3>div[data-v-5c28a69e] {
    font-size: 0.37333rem;
    background: var(--norm_green-color);
}

.K3B__C-betting2-line3>div.active[data-v-5c28a69e] {
    position: relative;
}

.K3B__C-betting2-line3>div.active[data-v-5c28a69e]:after {
    content: "";
    display: block;
    width: 0.42667rem;
    height: 0.42667rem;
    background-image: url(/assets/svg/subtract-ca63ef68.svg);
    background-size: 0.42667rem;
    background-position: center;
    position: absolute;
    bottom: 0;
    right: 0;
}

.van-toast[data-v-3deb049d] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-3deb049d] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-3deb049d] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-3deb049d] {
    height: 80%;
}

.K3B__C-betting3[data-v-3deb049d] {
    margin-top: 0.26667rem;
}

.K3B__C-betting3-tip1[data-v-3deb049d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 0.4rem;
    font-size: 0.34667rem;
    line-height: 0.4rem;
    color: var(--text_color_L1);
    margin-bottom: 0.21333rem;
}

.K3B__C-betting3-tip1 .icon[data-v-3deb049d] {
    margin-left: 0.13333rem;
}

.K3B__C-betting3-line1[data-v-3deb049d] {
    height: 0.93333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    margin: 0.21333rem 0;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.K3B__C-betting3-line1.mb30[data-v-3deb049d] {
    margin-bottom: 0.4rem;
}

.K3B__C-betting3-line1>div[data-v-3deb049d] {
    width: calc((100% - 1.33333rem) / 6);
    height: 0.93333rem;
    line-height: 0.93333rem;
    color: #fff;
    text-align: center;
    border-radius: 0.13333rem;
    background: var(--norm_Purple-color);
    font-size: 0.37333rem;
    opacity: 0.5;
}

.K3B__C-betting3-line1>div.active[data-v-3deb049d] {
    position: relative;
    opacity: 1;
}

.K3B__C-betting3-line1>div.active[data-v-3deb049d]:after {
    content: "";
    display: block;
    width: 0.42667rem;
    height: 0.42667rem;
    background-image: url(/assets/svg/subtract-ca63ef68.svg);
    background-size: 0.42667rem;
    background-position: center;
    position: absolute;
    bottom: 0;
    right: 0;
}

.K3B__C-betting3-btn[data-v-3deb049d] {
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    background: var(--norm_red-color);
    border-radius: 0.13333rem;
    color: #fff;
    font-size: 0.37333rem;
    margin-bottom: 0.21333rem;
    opacity: 0.5;
}

.K3B__C-betting3-btn.active[data-v-3deb049d] {
    opacity: 1;
    position: relative;
}

.K3B__C-betting3-btn.active[data-v-3deb049d]:after {
    content: "";
    display: block;
    width: 0.42667rem;
    height: 0.42667rem;
    background-image: url(/assets/svg/subtract-ca63ef68.svg);
    background-size: 0.42667rem;
    background-position: center;
    position: absolute;
    bottom: 0;
    right: 0;
}

.van-toast[data-v-bcf2c3f9] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-bcf2c3f9] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-bcf2c3f9] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-bcf2c3f9] {
    height: 80%;
}

.K3B__C-betting4[data-v-bcf2c3f9] {
    margin-top: 0.26667rem;
}

.K3B__C-betting4-tip1[data-v-bcf2c3f9] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 0.4rem;
    font-size: 0.34667rem;
    line-height: 0.4rem;
    color: var(--text_color_L1);
    margin-bottom: 0.21333rem;
}

.K3B__C-betting4-tip1 .icon[data-v-bcf2c3f9] {
    margin-left: 0.13333rem;
}

.K3B__C-betting4-line1[data-v-bcf2c3f9] {
    height: 0.93333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    margin: 0.21333rem 0;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.K3B__C-betting4-line1.mb30[data-v-bcf2c3f9] {
    margin-bottom: 0.4rem;
}

.K3B__C-betting4-line1>div[data-v-bcf2c3f9] {
    width: calc((100% - 1.33333rem) / 6);
    height: 0.93333rem;
    line-height: 0.93333rem;
    color: #fff;
    text-align: center;
    border-radius: 0.13333rem;
    background: var(--norm_Purple-color);
    font-size: 0.37333rem;
    opacity: 0.5;
}

.K3B__C-betting4-line1>div.active[data-v-bcf2c3f9] {
    position: relative;
    opacity: 1;
}

.K3B__C-betting4-line1>div.active[data-v-bcf2c3f9]:after {
    content: "";
    display: block;
    width: 0.42667rem;
    height: 0.42667rem;
    background-image: url(/assets/svg/subtract-ca63ef68.svg);
    background-size: 0.42667rem;
    background-position: center;
    position: absolute;
    bottom: 0;
    right: 0;
}

.K3B__C-betting4-btn[data-v-bcf2c3f9] {
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    background: var(--norm_red-color);
    border-radius: 0.13333rem;
    color: #fff;
    font-size: 0.37333rem;
    margin-bottom: 0.4rem;
    opacity: 0.5;
}

.K3B__C-betting4-btn.active[data-v-bcf2c3f9] {
    opacity: 1;
    position: relative;
}

.K3B__C-betting4-btn.active[data-v-bcf2c3f9]:after {
    content: "";
    display: block;
    width: 0.42667rem;
    height: 0.42667rem;
    background-image: url(/assets/svg/subtract-ca63ef68.svg);
    background-size: 0.42667rem;
    background-position: center;
    position: absolute;
    bottom: 0;
    right: 0;
}

.van-toast[data-v-5f002ad4] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-5f002ad4] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-5f002ad4] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-5f002ad4] {
    height: 80%;
}

.Betting__Popup-body .title[data-v-5f002ad4] {
    margin-bottom: 0.13333rem;
    font-size: 0.42667rem;
    color: var(--text_color_L1);
}

.Betting__Popup-body .list[data-v-5f002ad4] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.Betting__Popup-type1[data-v-5f002ad4] {
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.26667rem;
}

.Betting__Popup-type1 .list>div[data-v-5f002ad4] {
    width: 0.64rem;
    height: 0.64rem;
    line-height: 0.64rem;
    text-align: center;
    background: #b5b5b5;
    border-radius: 0.64rem;
    font-size: 0.32rem;
    color: #fff;
    margin: 0.05333rem;
}

.Betting__Popup-type1 .list>div.red[data-v-5f002ad4] {
    background-color: var(--norm_red-color);
}

.Betting__Popup-type1 .list>div.green[data-v-5f002ad4] {
    background-color: var(--norm_green-color);
}

.Betting__Popup-type1 .list>div.numA[data-v-5f002ad4],
.Betting__Popup-type1 .list>div.numB[data-v-5f002ad4],
.Betting__Popup-type1 .list>div.numC[data-v-5f002ad4],
.Betting__Popup-type1 .list>div.numD[data-v-5f002ad4] {
    background-color: var(--norm_secondary-color);
    border-radius: 0.10667rem;
    width: 1.06667rem;
}

.Betting__Popup-type1 .list>div.numB[data-v-5f002ad4] {
    background-color: var(--norm_bule-color);
}

.Betting__Popup-type1 .list>div.numC[data-v-5f002ad4] {
    background-color: var(--norm_red-color);
}

.Betting__Popup-type1 .list>div.numD[data-v-5f002ad4] {
    background-color: var(--norm_red-color);
}

.Betting__Popup-type2[data-v-5f002ad4] {
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.26667rem;
    font-size: 0.42667rem;
    color: var(--colorText-3);
}

.Betting__Popup-type2[data-v-5f002ad4]::last-child {
    margin-bottom: 0.48rem;
}

.Betting__Popup-type2-d[data-v-5f002ad4] {
    height: 0.58667rem;
    background: var(--norm_Purple-color);
    border-radius: 0.10667rem;
    color: var(--text_color_L1);
    line-height: 0.58667rem;
    text-align: center;
    margin: 0.02667rem 0.05333rem;
    font-size: 0.32rem;
    padding: 0 0.24rem;
}

.Betting__Popup-type2-o[data-v-5f002ad4] {
    height: 0.58667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background: var(--norm_red-color);
    border-radius: 0.10667rem;
    text-align: center;
    overflow: hidden;
    font-size: 0.32rem;
}

.Betting__Popup-type2-o+div[data-v-5f002ad4] {
    margin-left: 0.13333rem;
}

.Betting__Popup-type2-o[data-v-5f002ad4] div {
    height: 100%;
    line-height: 0.58667rem;
    padding: 0 0.13333rem;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    color: var(--text_color_L1);
}

.Betting__Popup-type2-o[data-v-5f002ad4] div:last-child {
    background-color: var(--norm_green-color);
}

.Betting__Popup-type2-r[data-v-5f002ad4] {
    width: -webkit-max-content;
    width: max-content;
    height: 0.58667rem;
    line-height: 0.58667rem;
    padding: 0 0.56rem;
    background: var(--norm_red-color);
    border-radius: 0.10667rem;
    font-size: 0.32rem;
    color: var(--text_color_L1);
    margin-bottom: 0.21333rem;
}

.Betting__Popup-body[data-v-5f002ad4] {
    padding: 0.50667rem 0.34667rem 0.53333rem;
}

.Betting__Popup-body-line[data-v-5f002ad4] {
    font-size: 0.42667rem;
    color: var(--text_color_L1);
    height: 0.74667rem;
    line-height: 0.74667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Betting__Popup-body-line-list[data-v-5f002ad4] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Betting__Popup-body-line-item[data-v-5f002ad4] {
    padding: 0 0.21333rem;
    background: var(--bg_color_L3);
    color: var(--text_color_L2);
    border-radius: 0.08rem;
}

.Betting__Popup-body-line-item+div[data-v-5f002ad4] {
    margin-left: 0.16rem;
}

.Betting__Popup-body-line+div[data-v-5f002ad4] {
    margin-top: 0.4rem;
}

.Betting__Popup-body-line-btnL[data-v-5f002ad4] {
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.Betting__Popup-body-line[data-v-5f002ad4]:last-child {
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    justify-content: flex-start;
}

.Betting__Popup-foot[data-v-5f002ad4] {
    height: 0.96rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    text-align: center;
    line-height: 0.96rem;
    font-size: 0.37333rem;
    color: var(--text_color_L1);
}

.Betting__Popup-foot-c[data-v-5f002ad4] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    background: var(--bg_color_L3);
    color: var(--text_color_L2);
}

.Betting__Popup-foot-s[data-v-5f002ad4] {
    -webkit-box-flex: 2;
    -webkit-flex: 2;
    flex: 2;
    background: var(--main-color);
    color: var(--text_color_L1);
}

.Betting__Popup-btn[data-v-5f002ad4] {
    width: 0.74667rem;
    height: 0.74667rem;
    pointer-events: none;
    text-align: center;
    font-size: 0.66667rem;
    padding: 0;
    background: var(--bg_color_L3);
    color: var(--button_dis_color);
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    border-radius: 0.08rem;
}

.Betting__Popup-input[data-v-5f002ad4] {
    padding: 0.02667rem 0.26667rem;
    width: 2.10667rem;
    margin: 0 0.16rem;
    background-color: var(--bg_color_L1);
    color: var(--text_color_L1);
}

.Betting__Popup-input[data-v-5f002ad4] .van-field__control {
    text-align: center;
    font-size: 0.37333rem;
    line-height: 0.72rem;
}

.Betting__Popup-input[data-v-5f002ad4]:after {
    content: none;
}

.Betting__Popup-agree[data-v-5f002ad4] {
    padding-left: 0.8rem;
    background-image: url(/assets/png/agree-b-47b8f86d.png);
    background-repeat: no-repeat;
    background-position: left center;
    background-size: 0.64rem;
    font-size: 0.32rem;
    color: var(--colorText-3);
}

html:lang(ar) .Betting__Popup-agree[data-v-5f002ad4] {
    background-position: right center;
}

.Betting__Popup-agree.active[data-v-5f002ad4] {
    background-image: url(/assets/png/agree-a-32b06ce9.png);
}

.Betting__Popup-preSaleShow[data-v-5f002ad4] {
    margin-left: 0.34667rem;
    font-size: 0.32rem;
    color: var(--norm_red-color);
}

.Betting__Popup-PreSale[data-v-5f002ad4] {
    width: 7.04rem;
}

.Betting__Popup-PreSale-head[data-v-5f002ad4] {
    height: 1.2rem;
    line-height: 1.2rem;
    color: var(--text_color_L4);
    font-size: 0.4rem;
    text-align: center;
    background: var(--main_gradient-color);
}

.Betting__Popup-PreSale-body[data-v-5f002ad4] {
    max-height: 8rem;
    overflow-y: auto;
    padding: 0.4rem;
    font-size: 0.32rem;
    line-height: 0.8rem;
    color: var(--text_color_L1);
}

.Betting__Popup-PreSale-body[data-v-5f002ad4] p {
    margin-bottom: 0.2rem;
    line-height: 0.53333rem;
}

.Betting__Popup-PreSale-foot[data-v-5f002ad4] {
    height: 1.86667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.Betting__Popup-PreSale-foot-btn[data-v-5f002ad4] {
    width: 60%;
    background: var(--main_gradient-color);
    border-radius: 0.53333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    font-size: 0.37333rem;
    color: var(--text_color_L4);
}

.bgcolor[data-v-5f002ad4] {
    pointer-events: all;
    color: var(--text_color_L4);
    background: var(--main-color);
}

.van-toast[data-v-8a4509d7] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-8a4509d7] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-8a4509d7] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-8a4509d7] {
    height: 80%;
}

.K3B__C[data-v-8a4509d7] {
    width: calc(100% - 0.69333rem);
    margin: auto;
    background: var(--bg_color_L2);
    border-radius: 0 0 0.26667rem 0.26667rem;
    padding: 0 0.26667rem 0.25333rem;
    position: relative;
}

.K3B__C-mark[data-v-8a4509d7] {
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    position: absolute;
    z-index: 99;
    top: 0;
    left: 0;
    color: var(--main-color);
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

html:lang(ar) .K3B__C-mark[data-v-8a4509d7] {
    right: o;
    left: unset;
    direction: ltr;
}

.K3B__C-mark>div[data-v-8a4509d7] {
    display: inline-block;
    border-radius: 0.4rem;
    padding: 0 0.4rem;
    background-color: var(--bg_color_L3);
    font-weight: 700;
    font-size: 3.73333rem;
}

.K3B__C-mark>div+div[data-v-8a4509d7] {
    margin-left: 1.04rem;
}

.K3B__C-nav[data-v-8a4509d7] {
    height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    font-size: 0.29333rem;
    color: var(--text_color_L2);
    overflow: hidden;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.K3B__C-nav>div[data-v-8a4509d7] {
    line-height: 1.06667rem;
    text-align: center;
    width: calc(25% - 0.04rem);
    background: var(--bg_color_L3);
    border-radius: 0.13333rem 0.13333rem 0 0;
}

.K3B__C-nav>div.active[data-v-8a4509d7] {
    background: var(--main-color);
    color: var(--text_color_L4);
}

[data-v-8a4509d7] .van-popup {
    overflow-y: visible;
}

[data-v-8a4509d7] .van-popup .van-icon-close {
    font-size: 0.8rem;
    bottom: -1rem;
    left: 50%;
    -webkit-transform: translate(-50%, 0);
    transform: translate(-50%);
}

.qpopup-box[data-v-8a4509d7] {
    max-width: 8rem;
    padding: 0.8rem 0.77333rem 1.04rem;
}

.qpopup-box-list[data-v-8a4509d7] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.26667rem;
}

.qpopup-box-list .num[data-v-8a4509d7] {
    height: 1.2rem;
    width: 1.2rem;
    background-color: var(--colorText-2);
    margin: 0 0.26667rem;
}

.qpopup-box-list .num.num1[data-v-8a4509d7] {
    background: url(/assets/png/n1-584b8878.png) no-repeat center center;
    background-size: cover;
}

.qpopup-box-list .num.num2[data-v-8a4509d7] {
    background: url(/assets/png/n2-447499dc.png) no-repeat center center;
    background-size: cover;
}

.qpopup-box-list .num.num3[data-v-8a4509d7] {
    background: url(/assets/png/n3-1432a6bd.png) no-repeat center center;
    background-size: cover;
}

.qpopup-box-list .num.num4[data-v-8a4509d7] {
    background: url(/assets/png/n4-9d453819.png) no-repeat center center;
    background-size: cover;
}

.qpopup-box-list .num.num5[data-v-8a4509d7] {
    background: url(/assets/png/n5-09b70e91.png) no-repeat center center;
    background-size: cover;
}

.qpopup-box-list .num.num6[data-v-8a4509d7] {
    background: url(/assets/png/n6-b68c6bb6.png) no-repeat center center;
    background-size: cover;
}

.qpopup-box-list .num.num7[data-v-8a4509d7] {
    background: url(/assets/png/n7-039e2d7d.png) no-repeat center center;
    background-size: cover;
}

.qpopup-box-txt[data-v-8a4509d7] {
    text-align: center;
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.van-toast[data-v-4e09079f] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-4e09079f] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-4e09079f] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-4e09079f] {
    height: 80%;
}

.GameRecord__C[data-v-4e09079f] {
    width: calc(100% - 0.69333rem);
    margin: 0.48rem auto 0;
    text-align: center;
    font-size: 0.32rem;
}

.GameRecord__C-head[data-v-4e09079f] {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--sheet_nva_color);
    border-radius: 0.13333rem 0.13333rem 0 0;
    font-weight: 700;
    font-size: 0.34667rem;
    color: #fff;
}

.GameRecord__C-body[data-v-4e09079f] {
    line-height: 1.06667rem;
}

.GameRecord__C-body-empty[data-v-4e09079f] {
    height: 5.33333rem;
}

.GameRecord__C-body>div[data-v-4e09079f] {
    background: var(--bg_color_L2);
    color: var(--text_color_L1);
}

.GameRecord__C-body>div+div[data-v-4e09079f] {
    border-top: 0.01333rem solid var(--gray-color-1);
}

.GameRecord__C-body-premium[data-v-4e09079f] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 100%;
    max-width: 2.13333rem;
    margin: auto;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.GameRecord__C-body-premium>div[data-v-4e09079f] {
    width: 0.53333rem;
    height: 0.53333rem;
    background-repeat: no-repeat;
    background-size: 0.53333rem;
    background-position: center;
}

.GameRecord__C-body-premium .n1[data-v-4e09079f] {
    background-image: url(/assets/png/n1-584b8878.png);
}

.GameRecord__C-body-premium .n2[data-v-4e09079f] {
    background-image: url(/assets/png/n2-447499dc.png);
}

.GameRecord__C-body-premium .n3[data-v-4e09079f] {
    background-image: url(/assets/png/n3-1432a6bd.png);
}

.GameRecord__C-body-premium .n4[data-v-4e09079f] {
    background-image: url(/assets/png/n4-9d453819.png);
}

.GameRecord__C-body-premium .n5[data-v-4e09079f] {
    background-image: url(/assets/png/n5-09b70e91.png);
}

.GameRecord__C-body-premium .n6[data-v-4e09079f] {
    background-image: url(/assets/png/n6-b68c6bb6.png);
}

.GameRecord__C-foot[data-v-4e09079f] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    color: var(--text_color_L2);
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.GameRecord__C-foot-previous[data-v-4e09079f],
.GameRecord__C-foot-next[data-v-4e09079f] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot-previous.disabled[data-v-4e09079f],
.GameRecord__C-foot-next.disabled[data-v-4e09079f] {
    background: var(--button_dis_color);
    pointer-events: none;
}

.GameRecord__C-foot-previous.disabled .GameRecord__C-icon[data-v-4e09079f],
.GameRecord__C-foot-next.disabled .GameRecord__C-icon[data-v-4e09079f] {
    color: var(--text_color_L2);
}

.GameRecord__C-foot-previous .GameRecord__C-icon[data-v-4e09079f],
.GameRecord__C-foot-next .GameRecord__C-icon[data-v-4e09079f] {
    color: var(--text_color_L4);
}

.van-toast[data-v-4159c83a] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-4159c83a] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-4159c83a] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-4159c83a] {
    height: 80%;
}

.Trend__C[data-v-4159c83a] {
    width: calc(100% - 0.69333rem);
    margin: 0.48rem auto 0;
    text-align: center;
    font-size: 0.32rem;
}

.Trend__C-head[data-v-4159c83a] {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--sheet_nva_color);
    border-radius: 0.13333rem 0.13333rem 0 0;
    font-weight: 700;
    font-size: 0.34667rem;
    color: #fff;
}

.Trend__C-body[data-v-4159c83a] {
    line-height: 1.06667rem;
}

.Trend__C-body-empty[data-v-4159c83a] {
    height: 5.33333rem;
}

.Trend__C-body>div[data-v-4159c83a] {
    background: var(--darkBg, var(--bg_color_L2));
    color: var(--text_color_L1);
}

.Trend__C-body>div+div[data-v-4159c83a] {
    border-top: 0.01333rem solid var(--gray-color-1);
}

.Trend__C-body-premium[data-v-4159c83a] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 100%;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    padding: 0 0.10667rem;
}

.Trend__C-body-premium>div[data-v-4159c83a] {
    width: 0.48rem;
    height: 0.48rem;
    background-repeat: no-repeat;
    background-size: 0.48rem;
    background-position: center;
}

.Trend__C-body-premium .n1[data-v-4159c83a] {
    background-image: url(/assets/png/n1-584b8878.png);
}

.Trend__C-body-premium .n2[data-v-4159c83a] {
    background-image: url(/assets/png/n2-447499dc.png);
}

.Trend__C-body-premium .n3[data-v-4159c83a] {
    background-image: url(/assets/png/n3-1432a6bd.png);
}

.Trend__C-body-premium .n4[data-v-4159c83a] {
    background-image: url(/assets/png/n4-9d453819.png);
}

.Trend__C-body-premium .n5[data-v-4159c83a] {
    background-image: url(/assets/png/n5-09b70e91.png);
}

.Trend__C-body-premium .n6[data-v-4159c83a] {
    background-image: url(/assets/png/n6-b68c6bb6.png);
}

.Trend__C-body-gameText[data-v-4159c83a] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    height: 100%;
    line-height: 1;
    width: 100%;
    word-break: break-all;
}

.Trend__C-foot[data-v-4159c83a] {
    height: 1.86667rem;
    background: var(--bg_color_L2);
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    color: var(--text_color_L1);
}

.Trend__C-foot-previous[data-v-4159c83a],
.Trend__C-foot-next[data-v-4159c83a] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.Trend__C-foot-previous.disabled[data-v-4159c83a],
.Trend__C-foot-next.disabled[data-v-4159c83a] {
    background: var(--button_dis_color);
    pointer-events: none;
}

.Trend__C-foot-previous.disabled .Trend__C-icon[data-v-4159c83a],
.Trend__C-foot-next.disabled .Trend__C-icon[data-v-4159c83a] {
    color: var(--saveTextColor-7);
}

.Trend__C-foot-previous .Trend__C-icon[data-v-4159c83a],
.Trend__C-foot-next .Trend__C-icon[data-v-4159c83a] {
    color: var(--text_color_L4);
}

.van-toast[data-v-2d418cc5] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-2d418cc5] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-2d418cc5] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-2d418cc5] {
    height: 80%;
}

.WinningTip__C[data-v-2d418cc5] {
    position: fixed;
    width: 100%;
    height: 100%;
    z-index: 99;
    background-color: #00000080;
    top: 0;
    left: 0;
}

html:lang(ar) .WinningTip__C[data-v-2d418cc5] {
    right: 0;
    left: unset;
}

.WinningTip__C-body[data-v-2d418cc5] {
    position: absolute;
    width: 7.73333rem;
    height: 10.93333rem;
    background-image: url(/assets/png/missningBg-c1f02bcd.png);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
    padding-top: 3.33333rem;
}

.WinningTip__C-body.isL[data-v-2d418cc5] {
    background-image: url(/assets/png/missningLBg-ca049a47.png);
}

.WinningTip__C-body.isL .WinningTip__C-body-l1[data-v-2d418cc5],
.WinningTip__C-body.isL .WinningTip__C-body-l2[data-v-2d418cc5],
.WinningTip__C-body.isL .WinningTip__C-body-l3[data-v-2d418cc5],
.WinningTip__C-body.isL .WinningTip__C-body-l4[data-v-2d418cc5] {
    color: #587ba4;
}

.WinningTip__C-body.isL .WinningTip__C-body-l2 .line2>div[data-v-2d418cc5] {
    background: #6889b1;
}

.WinningTip__C-body-l1[data-v-2d418cc5] {
    font-weight: 700;
    font-size: 0.64rem;
    text-align: center;
    color: #fff;
    height: 0.77333rem;
    line-height: 0.77333rem;
    margin-bottom: 0.45333rem;
}

.WinningTip__C-body-l2[data-v-2d418cc5] {
    height: 1.33333rem;
    color: #fff;
    font-size: 0.29333rem;
    margin-bottom: 0.64rem;
}

.WinningTip__C-body-l2 .line1[data-v-2d418cc5] {
    height: 0.53333rem;
    width: 2.50667rem;
    margin: auto;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.WinningTip__C-body-l2 .line1>div[data-v-2d418cc5] {
    width: 0.53333rem;
    height: 0.53333rem;
    background-repeat: no-repeat;
    background-size: 0.53333rem;
    background-position: center;
}

.WinningTip__C-body-l2 .line1 .n1[data-v-2d418cc5] {
    background-image: url(/assets/png/n1-584b8878.png);
}

.WinningTip__C-body-l2 .line1 .n2[data-v-2d418cc5] {
    background-image: url(/assets/png/n2-447499dc.png);
}

.WinningTip__C-body-l2 .line1 .n3[data-v-2d418cc5] {
    background-image: url(/assets/png/n3-1432a6bd.png);
}

.WinningTip__C-body-l2 .line1 .n4[data-v-2d418cc5] {
    background-image: url(/assets/png/n4-9d453819.png);
}

.WinningTip__C-body-l2 .line1 .n5[data-v-2d418cc5] {
    background-image: url(/assets/png/n5-09b70e91.png);
}

.WinningTip__C-body-l2 .line1 .n6[data-v-2d418cc5] {
    background-image: url(/assets/png/n6-b68c6bb6.png);
}

.WinningTip__C-body-l2 .line2[data-v-2d418cc5] {
    height: 0.58667rem;
    width: 3.57333rem;
    margin: 0.16rem auto 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.WinningTip__C-body-l2 .line2>div[data-v-2d418cc5] {
    height: 0.58667rem;
    line-height: 0.58667rem;
    background: #fdac32;
    border-radius: 0.13333rem;
    width: 1.33333rem;
    text-align: center;
    color: #fff;
}

.WinningTip__C-body-l2 .line2>div.yuan[data-v-2d418cc5] {
    width: 0.53333rem;
    height: 0.53333rem;
    line-height: 0.53333rem;
    margin: 0 0.18667rem;
    border-radius: 50%;
}

.WinningTip__C-body-l3[data-v-2d418cc5] {
    height: 1.73333rem;
}

.WinningTip__C-body-l3 .isLose[data-v-2d418cc5] {
    font-weight: 700;
    font-size: 0.64rem;
    line-height: 0.77333rem;
    color: var(--colorText-38);
    text-align: center;
    margin-bottom: 0.34667rem;
    padding-top: 0.26667rem;
}

.WinningTip__C-body-l3 .head[data-v-2d418cc5] {
    height: 0.4rem;
    line-height: 0.4rem;
    font-weight: 700;
    font-size: 0.34667rem;
    color: #fb5b5b;
    text-align: center;
    margin-bottom: 0.10667rem;
}

.WinningTip__C-body-l3 .bonus[data-v-2d418cc5] {
    height: 0.64rem;
    line-height: 0.64rem;
    font-weight: 700;
    font-size: 0.53333rem;
    color: #fb5b5b;
    text-align: center;
    margin-bottom: 0.26667rem;
}

.WinningTip__C-body-l3 .gameDetail[data-v-2d418cc5] {
    height: 0.37333rem;
    line-height: 0.37333rem;
    font-size: 0.29333rem;
    text-align: center;
    color: var(--text_color_L2);
}

.WinningTip__C-body-l4[data-v-2d418cc5] {
    height: 0.64rem;
    line-height: 0.64rem;
    font-size: 0.32rem;
    color: #fff;
    position: absolute;
    left: 0.74667rem;
    bottom: 0.74667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

html:lang(ar) .WinningTip__C-body-l4[data-v-2d418cc5] {
    right: 0.74667rem;
    left: unset;
}

.WinningTip__C-body-l4 .acitveBtn[data-v-2d418cc5] {
    height: 0.56rem;
    width: 0.56rem;
    border-radius: 50%;
    background: var(--winTips);
    border: 0.01333rem solid #fff;
    margin-right: 0.18667rem;
    position: relative;
}

.WinningTip__C-body-l4 .acitveBtn.active[data-v-2d418cc5]:before {
    content: "";
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
    height: 0.24rem;
    width: 0.32rem;
    display: block;
    background-image: url(/assets/png/vector-dc489162.png);
    background-repeat: no-repeat;
    background-size: 0.32rem 0.24rem;
    background-position: center;
}

.WinningTip__C .closeBtn[data-v-2d418cc5] {
    width: 0.8rem;
    height: 0.8rem;
    background-image: url(/assets/png/close-84ce5e6a.png);
    background-repeat: no-repeat;
    background-size: 0.8rem;
    background-position: center;
    position: absolute;
    left: 50%;
    -webkit-transform: translateX(-50%) translateY(100%);
    transform: translate(-50%) translateY(100%);
    bottom: -0.26667rem;
}

.van-toast[data-v-d024c659] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-d024c659] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-d024c659] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-d024c659] {
    height: 80%;
}

.K3__C[data-v-d024c659] {
    padding-bottom: 0.34667rem;
}

.K3__C-head[data-v-d024c659] {
    height: 1.25333rem;
    background: -webkit-linear-gradient(left, #de2325 0%, #ff504a 100%);
    background: linear-gradient(90deg, #de2325 0%, #ff504a 100%);
    padding: 0 0.34667rem;
    position: relative;
}

.K3__C-head div[data-v-d024c659] {
    background-repeat: no-repeat;
    background-position: center;
}

.K3__C-head-bcak[data-v-d024c659] {
    position: absolute;
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/bcakIcon-b7c1d288.png);
    background-size: 0.64rem;
    left: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
}

.K3__C-head-logo[data-v-d024c659] {
    background: url(/assets/png/headlogo-56515a97.png);
    background-size: 2.98667rem 1.12rem;
    height: 1.12rem;
    width: 2.98667rem;
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
}

.K3__C-head-more[data-v-d024c659] {
    position: absolute;
    width: 1.54667rem;
    height: 0.64rem;
    right: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.K3__C-head-more>div[data-v-d024c659] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/kefu-b361c42f.png);
    background-size: 0.64rem;
}

.K3__C-head-more>div[data-v-d024c659]:last-child {
    background-image: url(/assets/png/voice-62dbf38c.png);
}

.K3__C-head-more>div:last-child.disableVoice[data-v-d024c659] {
    background-image: url(/assets/png/voice-off-633f5ccc.png);
}

.K3__C[data-v-d024c659] .noticeBar__container {
    width: calc(100% - 0.69333rem) !important;
    margin: 0.45333rem auto;
    position: relative;
    z-index: 1;
    top: 0;
}

.van-toast[data-v-35613996] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-35613996] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-35613996] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-35613996] {
    height: 80%;
}

.TimeLeft__C[data-v-35613996] {
    padding: 0.26667rem 0.32rem;
}

.TimeLeft__C .box[data-v-35613996] {
    width: 100%;
    height: 3.6rem;
    background: var(--darkBg, var(--bg_color_L2));
    border-radius: 0.16rem;
    padding: 0.26667rem 0.18667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.TimeLeft__C .box .tit[data-v-35613996] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.TimeLeft__C .box .tit .citycon[data-v-35613996] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
}

.TimeLeft__C .box .tit .citycon .citybg[data-v-35613996] {
    width: 0.08rem;
    height: 0.4rem;
    border-radius: 0.26667rem;
    background: var(--main-color);
    margin-top: 0.05333rem;
    margin-right: 0.18667rem;
}

.TimeLeft__C .box .tit .citycon .font30[data-v-35613996] {
    font-size: 0.4rem;
    color: var(--darkTextW, var(--main-color));
    font-weight: 700;
}

.TimeLeft__C .box .tit .playmethod[data-v-35613996] {
    width: 4.13333rem;
    height: 0.53333rem;
    border-radius: 0.13333rem;
    background: var(--bgDark-2, var(--bg_color_L3));
    font-size: 0.34667rem;
    color: var(--text_color_L2);
    margin-top: 0.10667rem;
    padding-left: 0.21333rem;
    overflow: hidden;
}

.TimeLeft__C .box .tit .odds[data-v-35613996] {
    width: 4.13333rem;
    height: 0.53333rem;
    line-height: 0.53333rem;
    background: var(--bgDark-2, var(--bg_color_L3));
    border-radius: 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    margin-top: 0.16rem;
    margin-bottom: 0.13333rem;
    padding: 0 0.21333rem;
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.TimeLeft__C .box .tit .color8[data-v-35613996] {
    width: 4.13333rem;
    height: 0.53333rem;
    border-radius: 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    margin-top: 0.16rem;
    margin-bottom: 0.13333rem;
    padding-left: 0.21333rem;
    font-size: 0.32rem;
}

.TimeLeft__C .box .tit .bettingcut[data-v-35613996] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    width: 4.13333rem;
    height: 1.17333rem;
    background: var(--bgDark-2, var(--bg_color_L3));
    border-radius: 0.13333rem;
    padding-left: 0.26667rem;
    margin-top: 0.13333rem;
}

.TimeLeft__C .box .tit .bettingcut .font22[data-v-35613996] {
    font-size: 0.29333rem;
    color: var(--text_color_L2);
    font-weight: 400;
    padding-top: 0.2rem;
}

.TimeLeft__C .box .tit .bettingcut .font28[data-v-35613996] {
    font-size: 0.37333rem;
    color: var(--text_color_L2);
}

.TimeLeft__C .box .info[data-v-35613996] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.TimeLeft__C .box .info .playillustrate[data-v-35613996] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    width: 3.2rem;
    height: 0.66667rem;
    border-radius: 0.53333rem;
    border: 0.01333rem solid var(--main-color);
    margin-left: 1.33333rem;
}

.TimeLeft__C .box .info .playillustrate .illustratebg[data-v-35613996] {
    width: 0.56rem;
    height: 0.56rem;
    background: url(/assets/png/warning2-48309257.png);
    background-position: center;
    background-repeat: no-repeat;
    background-size: contain;
    margin-left: 0.64rem;
    margin-top: 0.02667rem;
}

.TimeLeft__C .box .info .playillustrate .font24[data-v-35613996] {
    line-height: 0.66667rem;
    font-size: 0.32rem;
    color: var(--main-color);
}

.TimeLeft__C .box .info .issue[data-v-35613996] {
    margin-top: 0.21333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
}

.TimeLeft__C .box .info .issue .issuebg[data-v-35613996] {
    width: 0.56rem;
    height: 0.56rem;
    background-image: url(/assets/png/ticketstar-80b8605a.png);
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center;
}

.TimeLeft__C .box .info .issue .font26[data-v-35613996] {
    font-size: 0.34667rem;
    color: var(--text_color_L2);
    font-weight: 400;
    margin-top: 0.08rem;
    margin-left: 0.05333rem;
}

.TimeLeft__C .box .info .closure[data-v-35613996] {
    margin-top: 0.17333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.TimeLeft__C .box .info .closure .closuretime[data-v-35613996] {
    font-size: 0.37333rem;
    color: var(--text_color_L2);
    text-align: right;
    margin-bottom: 0.16rem;
}

.TimeLeft__C .box .info .closure .closurtimes[data-v-35613996] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
}

.TimeLeft__C .box .info .closure .closurtimes .red[data-v-35613996] {
    color: var(--main-color);
    font-size: 0.53333rem;
    margin-right: 0.05333rem;
}

.TimeLeft__C .box .info .closure .closurtimes .redsqure[data-v-35613996] {
    width: 0.53333rem;
    height: 0.66667rem;
    line-height: 0.66667rem;
    text-align: center;
    background: var(--main-color);
    color: #fff;
    font-size: 0.48rem;
    font-weight: 700;
    margin-right: 0.05333rem;
    position: relative;
}

.TimeLeft__C .box .info .closure .closurtimes .redsqure[data-v-35613996]:last-of-type:before {
    content: "";
    width: 0;
    height: 0;
    position: absolute;
    right: 0;
    bottom: 0;
    border: 0.06667rem solid var(--darkBg, var(--bg_color_L2));
    border-top-color: transparent;
    border-left-color: transparent;
}

.TimeLeft__C .box .info .closure .closurtimes .redsqure[data-v-35613996]:first-of-type:before {
    content: "";
    width: 0;
    height: 0;
    position: absolute;
    left: 0;
    top: 0;
    border: 0.06667rem solid var(--darkBg, var(--bg_color_L2));
    border-bottom-color: transparent;
    border-right-color: transparent;
}

html:lang(ar) .TimeLeft__C .box .info .closure .closurtimes .redsqure[data-v-35613996]:first-of-type:before {
    left: unset;
    right: 0;
}

.van-toast[data-v-9adf5430] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-9adf5430] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-9adf5430] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-9adf5430] {
    height: 80%;
}

.TimeLeft__C[data-v-9adf5430] {
    padding: 0.26667rem 0.32rem;
}

.TimeLeft__C .box[data-v-9adf5430] {
    width: 100%;
    min-height: 3.6rem;
    background: var(--darkBg, var(--bg_color_L2));
    border-radius: 0.16rem;
    padding: 0.26667rem 0.18667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.TimeLeft__C .box .tit[data-v-9adf5430] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.TimeLeft__C .box .tit .citycon[data-v-9adf5430] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
}

.TimeLeft__C .box .tit .citycon .citybg[data-v-9adf5430] {
    width: 0.08rem;
    height: 0.4rem;
    border-radius: 0.26667rem;
    background: var(--main-color);
    margin-top: 0.05333rem;
    margin-right: 0.18667rem;
}

.TimeLeft__C .box .tit .citycon .font30[data-v-9adf5430] {
    font-size: 0.4rem;
    color: var(--darkTextW, var(--main-color));
    font-weight: 700;
}

.TimeLeft__C .box .tit .playmethod[data-v-9adf5430] {
    width: 4.13333rem;
    min-height: 0.53333rem;
    border-radius: 0.13333rem;
    background: var(--bgDark-2, var(--bg_color_L3));
    font-size: 0.34667rem;
    color: var(--text_color_L2);
    margin-top: 0.10667rem;
    padding: 0 0.21333rem;
    overflow: hidden;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.TimeLeft__C .box .tit .odds[data-v-9adf5430] {
    width: 4.13333rem;
    line-height: 0.53333rem;
    background: var(--bgDark-2, var(--bg_color_L3));
    border-radius: 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    margin-top: 0.16rem;
    padding: 0.13333rem 0.21333rem;
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.TimeLeft__C .box .tit .odds .result[data-v-9adf5430] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    gap: 0.06667rem;
}

.TimeLeft__C .box .tit .odds .result span[data-v-9adf5430] {
    width: 0.53333rem;
    height: 0.53333rem;
    background: var(--main-color);
    border-radius: 50%;
    color: #fff;
    text-align: center;
}

.TimeLeft__C .box .tit .color8[data-v-9adf5430] {
    width: 4.13333rem;
    height: 0.53333rem;
    border-radius: 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    margin-top: 0.16rem;
    margin-bottom: 0.13333rem;
    padding-left: 0.21333rem;
    font-size: 0.32rem;
}

.TimeLeft__C .box .tit .bettingcut[data-v-9adf5430] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    width: 4.13333rem;
    height: 1.17333rem;
    background: var(--bg_color_L3);
    border-radius: 0.13333rem;
    padding-left: 0.26667rem;
    margin-top: 0.13333rem;
}

.TimeLeft__C .box .tit .bettingcut .font22[data-v-9adf5430] {
    font-size: 0.29333rem;
    color: var(--text_color_L2);
    font-weight: 400;
    padding-top: 0.2rem;
}

.TimeLeft__C .box .tit .bettingcut .font28[data-v-9adf5430] {
    font-size: 0.37333rem;
    color: var(--text_color_L2);
}

.TimeLeft__C .box .info[data-v-9adf5430] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.TimeLeft__C .box .info .playillustrate[data-v-9adf5430] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    width: 3.2rem;
    height: 0.66667rem;
    border-radius: 0.53333rem;
    border: 0.01333rem solid var(--main-color);
    margin-left: 1.33333rem;
}

.TimeLeft__C .box .info .playillustrate .illustratebg[data-v-9adf5430] {
    width: 0.56rem;
    height: 0.56rem;
    background: url(/assets/png/warning2-48309257.png);
    background-position: center;
    background-repeat: no-repeat;
    background-size: contain;
    margin-left: 0.64rem;
    margin-top: 0.02667rem;
}

.TimeLeft__C .box .info .playillustrate .font24[data-v-9adf5430] {
    line-height: 0.66667rem;
    font-size: 0.32rem;
    color: var(--main-color);
}

.TimeLeft__C .box .info .issue[data-v-9adf5430] {
    margin-top: 0.21333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
}

.TimeLeft__C .box .info .issue .issuebg[data-v-9adf5430] {
    width: 0.56rem;
    height: 0.56rem;
    background-image: url(/assets/png/ticketstar-80b8605a.png);
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center;
}

.TimeLeft__C .box .info .issue .font26[data-v-9adf5430] {
    font-size: 0.34667rem;
    color: var(--text_color_L2);
    font-weight: 400;
    margin-top: 0.08rem;
    margin-left: 0.05333rem;
}

.TimeLeft__C .box .info .closure[data-v-9adf5430] {
    margin-top: 0.17333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.TimeLeft__C .box .info .closure .closuretime[data-v-9adf5430] {
    font-size: 0.37333rem;
    color: var(--text_color_L2);
    text-align: right;
    margin-bottom: 0.16rem;
}

.TimeLeft__C .box .info .closure .closurtimes[data-v-9adf5430] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
}

.TimeLeft__C .box .info .closure .closurtimes .red[data-v-9adf5430] {
    color: var(--main-color);
    font-size: 0.53333rem;
    margin-right: 0.05333rem;
}

.TimeLeft__C .box .info .closure .closurtimes .redsqure[data-v-9adf5430] {
    width: 0.53333rem;
    height: 0.66667rem;
    line-height: 0.66667rem;
    text-align: center;
    background: var(--main-color);
    color: #fff;
    font-size: 0.48rem;
    font-weight: 700;
    margin-right: 0.05333rem;
    position: relative;
}

.TimeLeft__C .box .info .closure .closurtimes .redsqure[data-v-9adf5430]:last-of-type:before {
    content: "";
    width: 0;
    height: 0;
    position: absolute;
    right: 0;
    bottom: 0;
    border: 0.06667rem solid var(--darkBg, var(--bg_color_L2));
    border-top-color: transparent;
    border-left-color: transparent;
}

.TimeLeft__C .box .info .closure .closurtimes .redsqure[data-v-9adf5430]:first-of-type:before {
    content: "";
    width: 0;
    height: 0;
    position: absolute;
    left: 0;
    top: 0;
    border: 0.06667rem solid var(--darkBg, var(--bg_color_L2));
    border-bottom-color: transparent;
    border-right-color: transparent;
}

html:lang(ar) .TimeLeft__C .box .info .closure .closurtimes .redsqure[data-v-9adf5430]:first-of-type:before {
    left: unset;
    right: 0;
}

.TimeLeft__C .box .info .closure.isShowPreparing[data-v-9adf5430] {
    background: var(--bgDark-2, var(--bg_color_L3));
    border-radius: 0.13333rem;
    min-height: 1.45333rem;
    color: var(--darkTextW, var(--main-color));
    font-size: 0.37333rem;
    font-weight: 700;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.ColorsContainer {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    padding: 0.26667rem 0.32rem;
}

.ColorsContainer .ColorsMethod {
    height: 0.93333rem;
    margin-bottom: 0.06667rem;
    background-color: transparent;
}

.ColorsContainer .ColorsMethod .coloritem {
    width: 3.2rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    background-image: url(/assets/svg/play-84aec881.svg);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    font-weight: 400;
    color: var(--text_color_L2);
    font-size: 0.34667rem;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
}

.ColorsContainer .ColorsMethod .active {
    background-image: url(/assets/svg/playactive-b5560d7e.svg);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    color: #fff;
    font-weight: 700;
}

.ColorsContainer .PlayMethod {
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background-color: #fff;
}

.ColorsContainer .PlayMethod .playitem {
    width: 4.26667rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    font-size: 0.34667rem;
    font-weight: 400;
    color: var(--text_color_L2);
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
}

.ColorsContainer .PlayMethod .active {
    background: var( --linerGradien-94, linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%));
    border-radius: 0.13333rem;
    color: #fff;
    font-weight: 700;
}

.ColorsContainer .fun-tab-item {
    padding: 0;
}

.van-toast[data-v-cca50955] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-cca50955] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-cca50955] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-cca50955] {
    height: 80%;
}

.NumberSelectContainer[data-v-cca50955] {
    padding: 0.26667rem 0.32rem;
    position: relative;
}

.NumberSelectContainer-mark[data-v-cca50955] {
    width: 100%;
    height: 100%;
    background: var(--bgcolor-32);
    position: absolute;
    z-index: 99;
    top: 0;
    left: 0;
    color: #fff;
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

html:lang(ar) .NumberSelectContainer-mark[data-v-cca50955] {
    right: 0.01333rem;
    left: unset;
    direction: ltr;
}

.NumberSelectContainer-mark>div[data-v-cca50955] {
    min-width: 5.86667rem;
    height: 1.33333rem;
    line-height: 1.33333rem;
    display: inline-block;
    text-align: center;
    border-radius: 0.26667rem;
    padding: 0 0.26667rem;
    border: 0.01333rem solid var(--textBlueLight, var(--bg_color_L2));
    font-size: 0.42667rem;
    color: var(--textBlueLight, var(--bg_color_L2));
    font-weight: 700;
}

.NumberSelectContainer .NumberTab[data-v-cca50955] {
    margin-bottom: 0.26667rem;
    border-radius: 0.13333rem;
}

.NumberSelectContainer .NumberTab .tabitem[data-v-cca50955] {
    width: 3.73333rem;
    height: 1.17333rem;
    line-height: 1.17333rem;
    text-align: center;
    background: var(--darkBg, var(--bg_color_L2));
    font-size: 0.4rem;
    color: var(--text_color_L2);
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
}

.NumberSelectContainer .NumberTab[data-v-cca50955] .fun-tab-item {
    padding: 0;
}

.NumberSelectContainer .NumberTab .active[data-v-cca50955] {
    background: var(--linerGradien-94, var(--main_gradient-color2));
    color: #fff;
    border-radius: 0.13333rem;
}

.NumberSelectContainer .NumberTabContent[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.NumberSelectContainer .NumberTabContent .intervalcontainer[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-bottom: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .intervalcontainer .intervalitem[data-v-cca50955] {
    width: 1.73333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    background: var(--bg_color_L2);
    border-radius: 0.26667rem;
    font-size: 0.34667rem;
    color: var(--text_color_L2);
    text-align: center;
    margin-right: 0.13333rem;
    margin-bottom: 0.13333rem;
}

.NumberSelectContainer .NumberTabContent .intervalcontainer .active[data-v-cca50955] {
    font-weight: 700;
    color: #fff;
    background: var(--main_gradient-color2);
}

.NumberSelectContainer .NumberTabContent .selectcontainer[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    width: 9.36rem;
    height: 5.18667rem;
    background: var(--darkBg, var(--bg_color_L2));
    margin-bottom: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .selectcontainer[data-v-cca50955]:last-child {
    margin-bottom: 0;
}

.NumberSelectContainer .NumberTabContent .selectbutton[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    padding: 0.26667rem 0.21333rem;
}

.NumberSelectContainer .NumberTabContent .selectbutton .basicbutton[data-v-cca50955],
.NumberSelectContainer .NumberTabContent .selectbutton .selecteven[data-v-cca50955],
.NumberSelectContainer .NumberTabContent .selectbutton .selectodd[data-v-cca50955],
.NumberSelectContainer .NumberTabContent .selectbutton .selectsmall[data-v-cca50955],
.NumberSelectContainer .NumberTabContent .selectbutton .selectbig[data-v-cca50955],
.NumberSelectContainer .NumberTabContent .selectbutton .selectall[data-v-cca50955] {
    width: 1.68rem;
    height: 0.93333rem;
    font-size: 0.32rem;
    color: #fff;
    line-height: 0.93333rem;
    text-align: center;
}

.NumberSelectContainer .NumberTabContent .selectbutton .selectall[data-v-cca50955] {
    background: var(--norm_red-color);
    border-top-right-radius: 0.26667rem;
    border-bottom-left-radius: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .selectbutton .selectbig[data-v-cca50955] {
    background: var(--norm_secondary-color);
    border-radius: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .selectbutton .selectsmall[data-v-cca50955] {
    background: var(--norm_bule-color);
    border-radius: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .selectbutton .selectodd[data-v-cca50955] {
    background: var(--norm_Purple-color);
    border-radius: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .selectbutton .selecteven[data-v-cca50955] {
    background: var(--norm_red-color);
    border-top-right-radius: 0.26667rem;
    border-bottom-left-radius: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .selectcontent[data-v-cca50955] {
    width: 8.93333rem;
    height: 3.46667rem;
    background: var(--bgDark-3, var(--bg_color_L3));
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    margin: 0 0.21333rem;
}

.NumberSelectContainer .NumberTabContent .selectheader[data-v-cca50955] {
    font-size: 0.42667rem;
    color: var(--text_color_L2);
    padding: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .selectball[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.NumberSelectContainer .NumberTabContent .ball[data-v-cca50955] {
    width: 0.93333rem;
    height: 0.93333rem;
    font-size: 0.42667rem;
    line-height: 0.93333rem;
    text-align: center;
    font-weight: 700;
    color: var(--text_color_L2);
    background: url(/assets/svg/nbg-dba06970.svg) no-repeat center center;
    background-size: cover;
    margin-bottom: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .ball.action[data-v-cca50955] {
    color: var(--main-color);
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
}

.NumberSelectContainer .NumberTabContent .ball[data-v-cca50955]:nth-child(1),
.NumberSelectContainer .NumberTabContent .ball[data-v-cca50955]:nth-child(6) {
    margin-left: 0.66667rem;
}

.NumberSelectContainer .NumberTabContent .quickcontainer[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .redline[data-v-cca50955] {
    width: 0.08rem;
    height: 0.4rem;
    background: var(--main-color);
    margin-top: 0.05333rem;
    margin-right: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .randomcontainer[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .randomcontainer .randomheader[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    margin-bottom: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .randomcontainer .randomheader .font30[data-v-cca50955] {
    font-size: 0.4rem;
    font-weight: 700;
    color: var(--darkTextW, var(--text_color_L1));
}

.NumberSelectContainer .NumberTabContent .quickcontainer .randomcontainer .randombutton[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    margin-bottom: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .randomcontainer .randombutton>div[data-v-cca50955] {
    width: 1.73333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    background: var(--darkBg, var(--bg_color_L2));
    font-size: 0.34667rem;
    color: var(--text_color_L2);
    text-align: center;
    border-radius: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .randomcontainer .randombutton .active[data-v-cca50955] {
    background: var(--main_gradient-color2);
    color: #fff;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialheader[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    margin-bottom: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialheader .font30[data-v-cca50955] {
    font-size: 0.4rem;
    color: var(--darkTextW, var(--text_color_L1));
    font-weight: 700;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialbutton[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialbutton .basic[data-v-cca50955],
.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialbutton .specialeven[data-v-cca50955],
.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialbutton .specialodd[data-v-cca50955],
.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialbutton .specialsmall[data-v-cca50955],
.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialbutton .specialbig[data-v-cca50955],
.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialbutton .specialsame[data-v-cca50955] {
    width: 1.73333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    font-size: 0.32rem;
    color: #fff;
    text-align: center;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialbutton .specialsame[data-v-cca50955] {
    background: var(--main_gradient-color2);
    border-radius: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialbutton .specialbig[data-v-cca50955] {
    background: var(--norm_secondary-color);
    border-radius: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialbutton .specialsmall[data-v-cca50955] {
    background: var(--norm_bule-color);
    border-radius: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialbutton .specialodd[data-v-cca50955] {
    background: var(--norm_Purple-color);
    border-radius: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .quickcontainer .specialcontainer .specialbutton .specialeven[data-v-cca50955] {
    background: var(--norm_red-color);
    border-top-right-radius: 0.26667rem;
    border-bottom-left-radius: 0.26667rem;
}

.NumberSelectContainer .NumberTabContent .numbercontainer[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    background: var(--darkBg, var(--bg_color_L2));
    border-radius: 0.32rem;
    padding: 0.26667rem;
    margin-top: 0.4rem;
}

.NumberSelectContainer .NumberTabContent .numbercontainer .Ntit[data-v-cca50955] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    line-height: 0.74667rem;
    font-size: 0.42667rem;
    color: var(--text_color_L3);
    font-weight: 400;
}

.NumberSelectContainer .NumberTabContent .numbercontainer .list[data-v-cca50955] {
    width: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.NumberSelectContainer .NumberTabContent .numbercontainer .list .item[data-v-cca50955] {
    width: 20%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.NumberSelectContainer .NumberTabContent .numbercontainer .list .item .number[data-v-cca50955] {
    width: 1.06667rem;
    height: 1.06667rem;
    line-height: 1.06667rem;
    text-align: center;
    font-size: 0.42667rem;
    font-weight: 700;
    color: var(--text_color_L2);
    background: url(/assets/svg/nbg-dba06970.svg) no-repeat center center;
    background-size: cover;
}

.NumberSelectContainer .NumberTabContent .numbercontainer .list .item .number.action[data-v-cca50955] {
    color: var(--main-color);
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
}

[data-v-cca50955]::-webkit-scrollbar {
    height: 0.06667rem;
}

[data-v-cca50955]::-webkit-scrollbar-thumb {
    border-radius: 0.06667rem;
    background: var(--borderColor-5);
}

[data-v-cca50955]::-webkit-scrollbar-track {
    border-radius: 0.06667rem;
}

[data-v-cca50955]::-webkit-scrollbar {
    position: absolute;
    bottom: 0.13333rem;
}

.van-toast[data-v-a08d1fa6] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-a08d1fa6] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-a08d1fa6] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-a08d1fa6] {
    height: 80%;
}

.TasteContainer[data-v-a08d1fa6] {
    margin: 0.26667rem 0.32rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    width: 9.36rem;
    height: 11.08rem;
    background: var(--bg_color_L2);
    border-radius: 0.26667rem;
}

.TasteContainer .TasteHeader[data-v-a08d1fa6] {
    height: 0.8rem;
    background: var(--boxShadowColor-46);
    font-size: 0.37333rem;
    color: #fff;
    border-top-left-radius: 0.26667rem;
    border-top-right-radius: 0.26667rem;
    line-height: 0.8rem;
    text-align: center;
}

.TasteContainer .NumberSelect[data-v-a08d1fa6] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.TasteContainer .NumberSelect .NumberSelectCon[data-v-a08d1fa6] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    padding: 0.26667rem 0.26667rem 0;
}

.TasteContainer .NumberSelect .NumberSelectCon .NumberCon[data-v-a08d1fa6] {
    width: calc((100% - 0.4rem) / 4);
    height: 1.46667rem;
    background: var(--bg_color_L3);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    border-radius: 0.26667rem;
    margin-bottom: 0.16rem;
    text-align: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-right: 0.06667rem;
}

.TasteContainer .NumberSelect .NumberSelectCon .NumberCon.more[data-v-a08d1fa6] {
    width: calc((100% - 0.26667rem) / 2);
}

.TasteContainer .NumberSelect .NumberSelectCon .action[data-v-a08d1fa6] {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    box-shadow: var(--boxShadowColor-46);
}

.TasteContainer .NumberSelect .NumberSelectCon .active[data-v-a08d1fa6] {
    color: #fff !important;
}

.TasteContainer .NumberSelect .NumberSelectCon .number[data-v-a08d1fa6] {
    font-size: 0.48rem;
    color: var(--text_color_L2);
    font-weight: 700;
}

.TasteContainer .NumberSelect .NumberSelectCon .odds[data-v-a08d1fa6] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.TasteContainer .NumberSelect .MethodSelect[data-v-a08d1fa6] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    padding: 0 0.26667rem;
}

.TasteContainer .NumberSelect .MethodSelect .methodnumber[data-v-a08d1fa6] {
    font-size: 0.37333rem;
    color: #fff;
    font-weight: 700;
}

.TasteContainer .NumberSelect .MethodSelect .methododds[data-v-a08d1fa6] {
    font-size: 0.32rem;
    color: #fff;
}

.TasteContainer .NumberSelect .MethodSelect .methodbig[data-v-a08d1fa6] {
    width: 2.13333rem;
    height: 1.46667rem;
    background: var(--norm_secondary-color);
    box-shadow: var(--BoxShadowColor-5);
    border-top-right-radius: 0.26667rem;
    border-bottom-left-radius: 0.26667rem;
    text-align: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.TasteContainer .NumberSelect .MethodSelect .methodsmall[data-v-a08d1fa6] {
    width: 2.13333rem;
    height: 1.46667rem;
    background: var(--norm_bule-color);
    box-shadow: var(--BoxShadowColor-5);
    border-radius: 0.26667rem;
    text-align: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.TasteContainer .NumberSelect .MethodSelect .methododd[data-v-a08d1fa6] {
    width: 2.13333rem;
    height: 1.46667rem;
    background: var(--norm_Purple-color);
    border-radius: 0.26667rem;
    text-align: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.TasteContainer .NumberSelect .MethodSelect .methodeven[data-v-a08d1fa6] {
    width: 2.13333rem;
    height: 1.46667rem;
    background: var(--norm_red-color);
    box-shadow: var(--BoxShadowColor-5);
    border-top-right-radius: 0.26667rem;
    border-bottom-left-radius: 0.26667rem;
    text-align: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.van-toast[data-v-b37345b8] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-b37345b8] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-b37345b8] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-b37345b8] {
    height: 80%;
}

.NewVietnam__C[data-v-b37345b8] {
    padding-bottom: 0.34667rem;
    overflow-y: auto;
    background-color: var(--bgDark-4, var(--bg_color_L1));
}

.NewVietnam__C-head[data-v-b37345b8] {
    height: 1.25333rem;
    background: var(--main_gradient-color);
    padding: 0 0.34667rem;
    position: relative;
}

.NewVietnam__C-head div[data-v-b37345b8] {
    background-repeat: no-repeat;
    background-position: center;
}

.NewVietnam__C-head-bcak[data-v-b37345b8] {
    position: absolute;
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/bcakIcon-b7c1d288.png);
    background-size: 0.64rem;
    left: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
}

html:lang(ar) .NewVietnam__C-head-bcak[data-v-b37345b8] {
    left: unset;
    right: 0.34667rem;
}

.NewVietnam__C-head-logo[data-v-b37345b8] {
    background-size: 2.98667rem 1.12rem;
    height: 1.12rem;
    width: 2.98667rem;
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
}

.NewVietnam__C-head-more[data-v-b37345b8] {
    position: absolute;
    width: 1.54667rem;
    height: 0.64rem;
    right: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

html:lang(ar) .NewVietnam__C-head-more[data-v-b37345b8] {
    right: unset;
    left: 0.34667rem;
}

.NewVietnam__C-head-more>div[data-v-b37345b8] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/kefu-b361c42f.png);
    background-size: 0.64rem;
}

.NewVietnam__C-head-more>div[data-v-b37345b8]:last-child {
    background-image: url(/assets/png/voice-62dbf38c.png);
}

.NewVietnam__C-head-more>div:last-child.disableVoice[data-v-b37345b8] {
    background-image: url(/assets/png/voice-off-633f5ccc.png);
}

.NewVietnam__C[data-v-b37345b8] .driver-close-btn,
.NewVietnam__C[data-v-b37345b8] .driver-prev-btn {
    display: none;
}

.popup[data-v-b37345b8] {
    overflow-y: visible !important;
    border-radius: 0.13333rem 0.13333rem 0 0;
    width: 100%;
}

.popup[data-v-b37345b8] .van-popup {
    overflow-y: visible !important;
    border-radius: 0.26667rem 0.26667rem 0 0;
}

.popup .box[data-v-b37345b8] {
    position: relative;
}

.popup .box .close[data-v-b37345b8] {
    position: absolute;
    top: -1.06667rem;
    left: 50%;
    -webkit-transform: translate(-50%, 0);
    transform: translate(-50%);
}

.popup .box .close .img[data-v-b37345b8] {
    width: 0.8rem;
    height: 0.8rem;
}

.popup .box .title[data-v-b37345b8] {
    font-size: 0.42667rem;
    color: var(--text_color_L1);
}

.popup .box .numList[data-v-b37345b8] {
    max-height: 5.33333rem;
    overflow-x: auto;
}

.popup .box .numList .item[data-v-b37345b8] {
    width: 1.06667rem;
    height: 1.06667rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
    margin: 0 0.13333rem;
}

.popup-info-item[data-v-b37345b8] {
    height: 0.8rem;
    line-height: 0.8rem;
    margin-top: 0.26667rem;
}

.popup-info-item .tit[data-v-b37345b8] {
    font-size: 0.37333rem;
    color: var(--text_color_L2);
}

.popup-info-item .amount-box .li[data-v-b37345b8],
.popup-info-item .multiple-box .li[data-v-b37345b8] {
    text-align: center;
    font-size: 0.32rem;
    padding: 0 0.13333rem;
    height: 0.8rem;
    line-height: 0.8rem;
    min-width: 1.33333rem;
    margin-left: 0.13333rem;
    border: 0.01333rem solid var(--gray-color-1);
    border-radius: 0.13333rem;
    color: #00AF54;
}

.popup-info-item .amount-box .li.action[data-v-b37345b8],
.popup-info-item .multiple-box .li.action[data-v-b37345b8] {
    border: none;
    color: #fff;
    background: var(--main_gradient-color);
}

.popup-info-item .multiple-box .li[data-v-b37345b8] {
    padding: 0 0.26667rem;
    min-width: auto;
}

.popup-info-item .stepper-box .digit-box[data-v-b37345b8] {
    width: 2.66667rem;
    height: 0.8rem;
    border-radius: 0.8rem;
    padding: 0;
    margin: 0 0.13333rem;
    background-color: var(--walletBgColor-1);
}

.popup-info-item .stepper-box .digit-box[data-v-b37345b8] .van-field__control {
    height: 0.74667rem;
    text-align: center;
}

.popup-info-item .stepper-box .li[data-v-b37345b8] {
    height: 0.8rem;
    width: 0.8rem;
    font-size: 0.8rem;
    border-radius: 50%;
    background-color: var(--main-color);
    color: #fff;
}

.popup-info-item .stepper-box .li.minus[data-v-b37345b8] {
    text-align: center;
    line-height: 0.66667rem;
}

.popup-info-item .txt[data-v-b37345b8] {
    color: #00AF54;
}

.popup-info .quantity[data-v-b37345b8] {
    margin-top: 0.26667rem;
    padding: 0 0.21333rem;
    height: 1.17333rem;
    background-color: var(--bgDark-2, var(--homeActiveBgColor));
    border-radius: 0.13333rem;
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.popup-info .quantity .line[data-v-b37345b8] {
    padding: 0 0.13333rem;
    color: var(--text_color_L2);
}

.popup-info .quantity .num[data-v-b37345b8] {
    color: #00AF54;
    font-size: 0.4rem;
}

.popup-info .wallet[data-v-b37345b8],
.popup-info .balance[data-v-b37345b8] {
    padding: 0 0.21333rem;
    margin-top: 0.26667rem;
    height: 0.8rem;
    background-color: var(--bgDark-2, var(--homeActiveBgColor));
}

.popup-info .wallet .txt[data-v-b37345b8],
.popup-info .balance .txt[data-v-b37345b8] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.popup-info .wallet .txt img[data-v-b37345b8],
.popup-info .balance .txt img[data-v-b37345b8] {
    width: 0.4rem;
    height: 0.4rem;
    margin-right: 0.13333rem;
}

.popup-info .wallet .txt .num[data-v-b37345b8],
.popup-info .balance .txt .num[data-v-b37345b8] {
    font-size: 0.37333rem;
    color: var(--text_color_L1);
    padding-left: 0.26667rem;
}

.popup-info .wallet .txt .num.yellow[data-v-b37345b8],
.popup-info .balance .txt .num.yellow[data-v-b37345b8] {
    color: var(--norm_secondary-color);
}

.popup-info .wallet .bg333[data-v-b37345b8],
.popup-info .balance .bg333[data-v-b37345b8] {
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.popup-info .wallet .bg7172[data-v-b37345b8],
.popup-info .balance .bg7172[data-v-b37345b8] {
    font-size: 0.32rem;
    color: var(--main-color);
}

.popup-info .wallet .bet[data-v-b37345b8],
.popup-info .balance .bet[data-v-b37345b8] {
    border: 0.01333rem solid #00AF54;
    border-radius: 0.13333rem;
    height: 0.64rem;
    line-height: 0.64rem;
    color: #00AF54;
    padding: 0 0.26667rem;
}

.popup-btn[data-v-b37345b8] {
    height: 1.6rem;
}

.popup-btn .left[data-v-b37345b8] {
    width: 45%;
}

.popup-btn .left .btn[data-v-b37345b8] {
    height: 1.6rem;
    font-size: 0.42667rem;
    border-radius: 0;
    color: var(--text_color_L2);
    background-color: #00AF54;
}

.popup-btn .right[data-v-b37345b8] {
    width: 55%;
}

.popup-btn .right .btn[data-v-b37345b8] {
    height: 1.6rem;
    font-size: 0.42667rem;
    border-radius: 0;
    color: #fff;
    background-color: #00AF54;
}

.popup-btn .right .noActive[data-v-b37345b8] {
    background-color: #00AF54;
    color: var(--text_color_L2);
}

.PreSaleRule[data-v-b37345b8] {
    width: 7.04rem;
}

.PreSaleRule .head[data-v-b37345b8] {
    height: 1.2rem;
    line-height: 1.2rem;
    color: #fff;
    font-size: 0.4rem;
    text-align: center;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: left center;
    background-image: url(/assets/png/wingoPreSaleBg-6566ea95.png);
}

.PreSaleRule .body[data-v-b37345b8] {
    max-height: 8rem;
    overflow-y: auto;
    padding: 0.4rem;
    font-size: 0.32rem;
    line-height: 0.8rem;
}

.PreSaleRule .body[data-v-b37345b8] p {
    margin-bottom: 0.2rem;
    line-height: 0.53333rem;
}

.PreSaleRule .foot[data-v-b37345b8] {
    height: 1.86667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.PreSaleRule .foot .btn[data-v-b37345b8] {
    width: 60%;
    background: var(--main_gradient-color);
    border-radius: 0.53333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    font-size: 0.37333rem;
    color: #fff;
}

.Tips[data-v-b37345b8] {
    width: 8rem;
    height: 2.13333rem;
    line-height: 2.13333rem;
    background: var(--bg_color_L2);
    border: 0.01333rem solid var(--borderColor-5);
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.Tips>div[data-v-b37345b8] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    overflow-y: hidden;
}

.Tips>div img[data-v-b37345b8] {
    width: 1.17333rem;
    height: 1.17333rem;
    margin-top: 0.45333rem;
}

.Tips>div .font36[data-v-b37345b8] {
    color: var(--text_color_L1);
    font-weight: 700;
    font-size: 0.48rem;
    margin-left: 0.32rem;
}

.GameList__C-region[data-v-b37345b8] {
    height: 1.2rem;
    line-height: 1.2rem;
    overflow: hidden;
    padding: 0 0.26667rem;
    margin: 0.26667rem 0;
}

.GameList__C-region .item[data-v-b37345b8] {
    width: calc(33.3% - 0.53333rem);
    position: relative;
    text-align: center;
    font-size: 0.48rem;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

.GameList__C-region .item[data-v-b37345b8]:nth-child(1) {
    background: var(--bg_color_L2);
    border-radius: 0.13333rem 0 0 0.13333rem;
}

.GameList__C-region .item[data-v-b37345b8]:nth-child(1):after {
    position: absolute;
    top: 0;
    right: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-bottom: 1.2rem solid #fff;
    border-right: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

.GameList__C-region .item[data-v-b37345b8]:nth-child(2) {
    background: var(--bg_color_L2);
}

.GameList__C-region .item[data-v-b37345b8]:nth-child(2):after {
    position: absolute;
    top: 0;
    right: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-top: 1.2rem solid #fff;
    border-right: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-b37345b8]:nth-child(2):after {
    left: -0.66667rem;
    right: unset;
}

.GameList__C-region .item[data-v-b37345b8]:nth-child(2):before {
    position: absolute;
    top: 0;
    left: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-top: 1.2rem solid #fff;
    border-left: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-b37345b8]:nth-child(2):before {
    right: -0.66667rem;
    left: unset;
}

.GameList__C-region .item[data-v-b37345b8]:nth-child(3) {
    background: var(--bg_color_L2);
    border-radius: 0 0.13333rem 0.13333rem 0;
}

.GameList__C-region .item[data-v-b37345b8]:nth-child(3):before {
    position: absolute;
    top: 0;
    left: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-bottom: 1.2rem solid #fff;
    border-left: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-b37345b8]:nth-child(3):before {
    right: -0.66667rem;
    left: unset;
}

.GameList__C-region .item.action[data-v-b37345b8] {
    color: #fff;
}

.GameList__C-region .item.action[data-v-b37345b8]:nth-child(1) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-b37345b8]:nth-child(1):after {
    border-bottom: 1.2rem solid var(--borderColor-5);
}

.GameList__C-region .item.action[data-v-b37345b8]:nth-child(2) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-b37345b8]:nth-child(2):after {
    border-top: 1.2rem solid var(--borderColor-5);
}

.GameList__C-region .item.action[data-v-b37345b8]:nth-child(2):before {
    border-top: 1.2rem solid #00AF54;
}

.GameList__C-region .item.action[data-v-b37345b8]:nth-child(3) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-b37345b8]:nth-child(3):before {
    border-bottom: 1.2rem solid #00AF54;
}

.GameList__C-time[data-v-b37345b8] {
    padding-left: 0.2rem;
    overflow-y: auto;
    height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameList__C-time .item[data-v-b37345b8] {
    position: relative;
    white-space: nowrap;
    background-color: #fff;
    margin: 0 0.10667rem;
    padding: 0.04rem 0.16rem 0;
    text-align: center;
    border-radius: 0.13333rem 0.13333rem 0 0;
}

.GameList__C-time .item .week[data-v-b37345b8] {
    font-size: 0.16rem;
    color: var(--text_color_L1);
}

.GameList__C-time .item .time[data-v-b37345b8] {
    font-size: 0.16rem;
    color: var(--text_color_L2);
}

.GameList__C-time .item[data-v-b37345b8]:after,
.GameList__C-time .item[data-v-b37345b8]:before {
    content: "";
    width: 0.4rem;
    height: 0.4rem;
    position: absolute;
    bottom: 0;
    z-index: 9;
}

.GameList__C-time .item[data-v-b37345b8]:after {
    background: -webkit-radial-gradient( 100% 0, circle, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    background: radial-gradient( circle at 100% 0, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    right: -0.4rem;
}

html:lang(ar) .GameList__C-time .item[data-v-b37345b8]:after {
    left: -0.4rem;
    right: unset;
}

.GameList__C-time .item[data-v-b37345b8]:before {
    background: -webkit-radial-gradient( 0 0, circle, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    background: radial-gradient( circle at 0 0, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    left: -0.4rem;
}

html:lang(ar) .GameList__C-time .item[data-v-b37345b8]:before {
    right: -0.4rem;
    left: unset;
}

.GameList__C-time .item.active[data-v-b37345b8] {
    background-color: var(--main-color);
    color: #fff;
    z-index: 10;
}

.GameList__C-time .item.active .week[data-v-b37345b8],
.GameList__C-time .item.active .time[data-v-b37345b8] {
    color: #fff;
}

.GameList__C-time .item.active[data-v-b37345b8]:before {
    background: -webkit-radial-gradient( 0 0, circle, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    background: radial-gradient( circle at 0 0, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    left: -0.4rem;
    z-index: 10;
}

html:lang(ar) .GameList__C-time .item.active[data-v-b37345b8]:before {
    right: -0.4rem;
    left: unset;
}

.GameList__C-time .item.active[data-v-b37345b8]:after {
    background: -webkit-radial-gradient( 100% 0, circle, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    background: radial-gradient( circle at 100% 0, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    right: -0.4rem;
    z-index: 10;
}

html:lang(ar) .GameList__C-time .item.active[data-v-b37345b8]:after {
    left: -0.4rem;
    right: unset;
}

.GameList__C-city[data-v-b37345b8] {
    border-top: 0.02667rem solid #fff;
    overflow-y: auto;
    height: 0.6rem;
    height: 1.17333rem;
    background-color: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameList__C-city .item[data-v-b37345b8] {
    height: 0.93333rem;
    line-height: 0.93333rem;
    white-space: nowrap;
    margin: 0.08rem 0.10667rem;
    padding: 0 0.10667rem;
    text-align: center;
    color: #fff;
}

.GameList__C-city .item.action[data-v-b37345b8] {
    background-color: #fff;
    color: var(--main-color);
    border-radius: 0.06667rem;
}

.GameList__C-bet[data-v-b37345b8] {
    width: 100%;
    margin-top: 0.2rem;
    padding: 0 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 1.06667rem;
    overflow-x: scroll;
}

.GameList__C-bet ul[data-v-b37345b8] {
    margin: 0;
    padding: 0;
    list-style: none;
    -webkit-flex-wrap: nowrap;
    flex-wrap: nowrap;
    white-space: nowrap;
}

.GameList__C-bet .item[data-v-b37345b8] {
    -webkit-box-flex: 0;
    -webkit-flex: 0 0 auto;
    flex: 0 0 auto;
    height: 0.93333rem;
    padding: 0.25333rem 0.88rem;
    background: var(--bg_color_L2);
    border-radius: 0.16rem;
    margin-right: 0.32rem;
    color: var(--text_color_L2);
}

.GameList__C-bet .item.action[data-v-b37345b8] {
    color: #fff;
    background: var(--main_gradient-color2);
}

.Betting__C-mark[data-v-b37345b8] {
    width: 100%;
    height: 100%;
    background: var(--bgcolor-32);
    position: fixed;
    z-index: 99;
    top: 0;
    left: 0;
    color: #fff;
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

html:lang(ar) .Betting__C-mark[data-v-b37345b8] {
    right: 0;
    left: unset;
    direction: ltr;
}

.Betting__C-mark>div[data-v-b37345b8] {
    width: 5.86667rem;
    height: 1.33333rem;
    line-height: 1.33333rem;
    display: inline-block;
    border-radius: 0.26667rem;
    border: 0.01333rem solid #fff;
    font-size: 0.42667rem;
    color: #fff;
    font-weight: 700;
    padding: 0 0.4rem 0 2.08rem;
}

.Betting__C-bet[data-v-b37345b8] {
    margin-top: 0.4rem;
    padding: 0 0.26667rem;
}

.Betting__C-bet .tit[data-v-b37345b8] {
    height: 0.53333rem;
    line-height: 0.53333rem;
}

.Betting__C-bet .tit-select[data-v-b37345b8] {
    padding-left: 0.26667rem;
    font-size: 0.42667rem;
    font-weight: 700;
    border-left: 0.08rem solid var(--main-color);
}

.Betting__C-bet .tit-list .check[data-v-b37345b8] {
    padding-left: 0.26667rem;
    color: var(--text_color_L2);
}

.Betting__C-bet .tit-list .check-item[data-v-b37345b8] {
    height: 0.42667rem;
    width: 0.42667rem;
    border-radius: 0.42667rem;
    border: 0.02667rem solid #c9c9c9;
    margin-right: 0.10667rem;
}

.Betting__C-bet .tit-list .check.action[data-v-b37345b8] {
    color: #00AF54;
}

.Betting__C-bet .tit-list .check.action .check-item[data-v-b37345b8] {
    border: 0.01333rem solid #00AF54;
    position: relative;
}

.Betting__C-bet .tit-list .check.action .check-item[data-v-b37345b8]:after {
    content: "";
    display: block;
    border-radius: 0.26667rem;
    background-color: #00AF54;
    width: 0.26667rem;
    height: 0.26667rem;
    position: absolute;
    left: 0.05333rem;
    top: 0.05333rem;
}

html:lang(ar) .Betting__C-bet .tit-list .check.action .check-item[data-v-b37345b8]:after {
    right: 0.05333rem;
    left: unset;
}

.Betting__C-bet .nList[data-v-b37345b8] {
    background: var(--bg_color_L2);
    border-radius: 0.32rem;
    padding: 0.26667rem;
    margin-top: 0.4rem;
}

.Betting__C-bet .nList .Ntit[data-v-b37345b8] {
    line-height: 0.74667rem;
    font-size: 0.42667rem;
    color: var(--text_color_L3);
    font-weight: 400;
}

.Betting__C-bet .nList .list[data-v-b37345b8] {
    width: 100%;
}

.Betting__C-bet .nList .list .item[data-v-b37345b8] {
    width: 20%;
}

.Betting__C-bet .nList .list .item .number[data-v-b37345b8] {
    width: 1.06667rem;
    height: 1.06667rem;
    font-size: 0.42667rem;
    font-weight: 700;
    color: var(--text_color_L2);
    background: url(/assets/svg/nbg-dba06970.svg) no-repeat center center;
    background-size: cover;
}

.Betting__C-bet .nList .list .item .number.action[data-v-b37345b8] {
    color: #00AF54;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
}

.Footer__C[data-v-b37345b8] {
    width: 100%;
    position: fixed;
    left: auto;
    bottom: 0;
    height: 1.6rem;
    z-index: 98;
}

.Footer__C .nav[data-v-b37345b8] {
    height: 1.6rem;
    background-color: #fee;
    max-width: 10rem;
}

.Footer__C .nav .left[data-v-b37345b8] {
    width: 55%;
}

.Footer__C .nav .left .item[data-v-b37345b8] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    padding-left: 0.26667rem;
    color: var(--main-color);
}

.Footer__C .nav .left .item .txt[data-v-b37345b8] {
    margin-bottom: 0.08rem;
}

.Footer__C .nav .left .item .num[data-v-b37345b8] {
    color: #00AF54;
    font-weight: 600;
}

.Footer__C .bet-btn[data-v-b37345b8] {
    width: 40%;
    background-color: #00AF54;
    color: #fff;
    font-size: 0.48rem;
    font-weight: 600;
}

.Footer__C .disabled-btn[data-v-b37345b8] {
    width: 40%;
    background-color: var(--button_dis_color);
    color: var(--text_color_L2);
    font-size: 0.48rem;
    font-weight: 400;
    pointer-events: none;
}

.RecordNav__C[data-v-b37345b8] {
    width: calc(100% - 0.64rem);
    height: 1.17333rem;
    line-height: 1.17333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    margin: 0.32rem auto 0;
    border-radius: 0.16rem;
    overflow: hidden;
}

.RecordNav__C>div[data-v-b37345b8] {
    width: 50%;
    height: 100%;
    background: var(--bgDark-3, var(--bg_color_L2));
    font-size: 0.42667rem;
    color: var(--text_color_L2);
    text-align: center;
    overflow: hidden;
}

.RecordNav__C>div.active[data-v-b37345b8] {
    background: var(--dark-linerGradien-91, var(--main_gradient-color2));
    font-weight: 600;
    color: #fff;
}

.GameRecord__C[data-v-b37345b8] {
    width: calc(100% - 0.69333rem);
    margin: 0.26667rem auto 1.6rem;
    text-align: center;
    font-size: 0.32rem;
}

.GameRecord__C-head[data-v-b37345b8] {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--bgDark-2, var(--main-color));
    border-radius: 0.13333rem 0.13333rem 0 0;
    font-weight: 600;
    font-size: 0.37333rem;
    color: #fff;
}

.GameRecord__C-body[data-v-b37345b8] {
    color: var(--text_color_L1);
    font-size: 0.32rem;
    background: var(--darkBg, var(--bg_color_L1));
    border-radius: 0 0 0.13333rem 0.13333rem;
}

.GameRecord__C-body[data-v-b37345b8] .van-row {
    min-height: 1.30667rem;
    border-bottom: 0.01333rem solid var(--bgDark-2, var(--saveTextColor-3));
}

.GameRecord__C-body .details[data-v-b37345b8] {
    width: 100%;
    border: 0.01333rem solid var(--borderColor-5);
    border-radius: 0.26667rem;
    padding: 0.33333rem;
}

.GameRecord__C-body .details .tit[data-v-b37345b8] {
    font-size: 0.4rem;
    color: var(--text_color_L1);
    margin-bottom: 0.26667rem;
    font-weight: 700;
}

.GameRecord__C-body .details .tit img[data-v-b37345b8] {
    width: 0.64rem;
    height: 0.64rem;
    position: relative;
    top: 0.13333rem;
}

.GameRecord__C-body .details .tag-read img[data-v-b37345b8] {
    width: 0.32rem;
    height: 0.32rem;
}

.GameRecord__C-body .details .detailLi[data-v-b37345b8] {
    min-height: 0.66667rem;
    line-height: 0.66667rem;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
}

.GameRecord__C-body .details .detailLi .red[data-v-b37345b8] {
    color: var(--main_gradient-color);
}

.GameRecord__C-body .details .detailLi .prize[data-v-b37345b8] {
    background: var(--bgDark-4, --walletBgColor-1);
    margin-bottom: 0.16rem;
    padding: 0.26667rem;
    border-radius: 0.26667rem;
}

.GameRecord__C-body .details .detailLi .prize[data-v-b37345b8]:last-child {
    margin-bottom: 0;
}

.GameRecord__C-body .details .detailLi .selectItem0[data-v-b37345b8],
.GameRecord__C-body .details .detailLi .selectItem1[data-v-b37345b8],
.GameRecord__C-body .details .detailLi .selectItem2[data-v-b37345b8] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameRecord__C-body .details .detailLi .selectItem0>div[data-v-b37345b8]:nth-of-type(1),
.GameRecord__C-body .details .detailLi .selectItem1>div[data-v-b37345b8]:nth-of-type(1),
.GameRecord__C-body .details .detailLi .selectItem2>div[data-v-b37345b8]:nth-of-type(1) {
    width: 45%;
}

.GameRecord__C-body .details .detailLi .selectItem0>div[data-v-b37345b8]:nth-of-type(2),
.GameRecord__C-body .details .detailLi .selectItem1>div[data-v-b37345b8]:nth-of-type(2),
.GameRecord__C-body .details .detailLi .selectItem2>div[data-v-b37345b8]:nth-of-type(2) {
    width: 0.13333rem;
}

.GameRecord__C-body .details .detailLi .selectItem0 span[data-v-b37345b8],
.GameRecord__C-body .details .detailLi .selectItem1 span[data-v-b37345b8],
.GameRecord__C-body .details .detailLi .selectItem2 span[data-v-b37345b8] {
    font-weight: 700;
    font-size: 0.42667rem;
    color: var(--darkTextW, --text_color_L1);
    padding-left: 0;
    text-align: center;
}

.GameRecord__C-body .details .detailLi .selectItem0 span[data-v-b37345b8] {
    color: #00AF54;
}

.GameRecord__C-body .details .detailLi .prize-tit[data-v-b37345b8] {
    text-align: left;
    font-size: 0.37333rem;
    color: var(--darkTextW, --text_color_L1);
    padding-left: 0.26667rem;
}

.GameRecord__C-body .details .detailLi .action0[data-v-b37345b8] {
    color: #00AF54 !important;
    font-weight: 700;
    font-size: 0.42667rem;
}

.GameRecord__C-body .details .detailLi .action1[data-v-b37345b8],
.GameRecord__C-body .details .detailLi .action2[data-v-b37345b8] {
    font-weight: 700;
    font-size: 0.42667rem;
}

.GameRecord__C-body .details .detailLi .prize-box[data-v-b37345b8] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
}

.GameRecord__C-body .details .detailLi .prize-box-item[data-v-b37345b8] {
    text-align: left;
    padding-left: 0.26667rem;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: var(--text_color_L1);
    font-size: 0.37333rem;
    font-weight: 500;
}

.GameRecord__C-body .details .detailLi .c-flex-warp[data-v-b37345b8] {
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.GameRecord__C-body .details .detailLi .select[data-v-b37345b8] {
    margin-left: 0.53333rem;
}

.GameRecord__C-body .details .detailLi .select .ball[data-v-b37345b8] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 0.64rem;
    height: 0.42667rem;
    line-height: 0.42667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-left: 0.13333rem;
    margin-bottom: 0.13333rem;
    background: var(--main-color);
    border-radius: 0.08rem;
    color: #fff;
}

.GameRecord__C-body .details .detailLi .Bet-box.pb[data-v-b37345b8] {
    padding-bottom: 0.06667rem;
}

.GameRecord__C-body .details .detailLi .Bet-box ul li[data-v-b37345b8] {
    height: 0.26667rem;
    line-height: 0.26667rem;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    margin: 0.02667rem 0.05333rem;
    background-color: var(--gray-color-1);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionViolet[data-v-b37345b8] {
    color: #fff;
    background-color: var(--bgcolor-21);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionRed[data-v-b37345b8] {
    color: #fff;
    background-color: var(--norm_red-color);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionGreen[data-v-b37345b8] {
    color: #fff;
    background-color: var(--bgColor-13);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionRedGreen[data-v-b37345b8] {
    color: #fff;
    background-color: var(--norm_red-color);
    background-image: var(--linearGradien-21);
}

.GameRecord__C-body .details .detailLi .Bet-box .actionBtn[data-v-b37345b8] {
    height: 0.34667rem;
    line-height: 0.34667rem;
    display: inline-block;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    background-color: var(--norm_red-color);
    color: #fff;
}

.GameRecord__C-body .goItem[data-v-b37345b8] {
    height: 1.30667rem;
    line-height: 1.30667rem;
    text-align: center;
    color: var(--darkTextW, --main-color);
    font-size: 0.32rem;
}

.GameRecord__C-body .li[data-v-b37345b8] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
    width: 0.4rem;
    height: 0.4rem;
    border-radius: 50%;
    background: var(--walletBgColor-1);
    margin: 0 0.02667rem;
}

.GameRecord__C-body .li .circle-black[data-v-b37345b8] {
    background-color: var(--walletBgColor-1);
    color: var(--text_color_L1);
    font-size: 0.32rem;
}

.GameRecord__C-body .time[data-v-b37345b8] {
    color: var(--textM3, var(--text_color_L2));
    font-size: 0.32rem;
    height: 100%;
}

.GameRecord__C-body .numList[data-v-b37345b8] {
    width: 3rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    position: relative;
    top: 0.4rem;
}

.GameRecord__C-body .numList .numItem[data-v-b37345b8] {
    width: 0.4rem;
    height: 0.4rem;
    background: var(--walletBgColor-1);
    color: var(--text_color_L1);
    font-size: 0.32rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    border-radius: 50%;
}

.GameRecord__C-body .redNumItem[data-v-b37345b8] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot[data-v-b37345b8] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.GameRecord__C-foot-previous[data-v-b37345b8],
.GameRecord__C-foot-next[data-v-b37345b8] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot-previous.disabled[data-v-b37345b8],
.GameRecord__C-foot-next.disabled[data-v-b37345b8] {
    background: var(--gray-color-1);
    pointer-events: none;
}

.GameRecord__C-foot-previous.disabled .GameRecord__C-icon[data-v-b37345b8],
.GameRecord__C-foot-next.disabled .GameRecord__C-icon[data-v-b37345b8] {
    color: var(--saveTextColor-7);
}

.GameRecord__C-foot-previous .GameRecord__C-icon[data-v-b37345b8],
.GameRecord__C-foot-next .GameRecord__C-icon[data-v-b37345b8] {
    color: #fff;
}

.MyGameRecord__C[data-v-b37345b8] {
    width: 100%;
    margin: 0.32rem auto 1.6rem;
}

.MyGameRecord__C-head[data-v-b37345b8] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
    background-color: var(--darkBg, var(--bg_color_L2));
    padding: 0.32rem 0.32rem 0;
}

.MyGameRecord__C-head-moreB[data-v-b37345b8] {
    border: 0.01333rem solid var(--main-color);
    height: 0.8rem;
    line-height: 0.8rem;
    border-radius: 0.26667rem;
    padding: 0 0.72rem 0 0.24rem;
    color: var(--main-color);
    font-size: 0.32rem;
    position: relative;
    margin-bottom: 0.4rem;
}

.MyGameRecord__C-head-moreB[data-v-b37345b8]:after {
    content: "";
    display: block;
    width: 0.4rem;
    height: 0.4rem;
    position: absolute;
    top: 50%;
    right: 0.2rem;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    background-image: url(/assets/jpg/moreBtn-ffccf44d.jpg);
    background-repeat: no-repeat;
    background-size: 0.4rem;
    background-position: center;
}

html:lang(ar) .MyGameRecord__C-head-moreB[data-v-b37345b8]:after {
    left: 0.2rem;
    right: unset;
    -webkit-transform: scaleX(-1);
    transform: scaleX(-1);
    top: 25%;
}

.MyGameRecord__C-body[data-v-b37345b8] {
    padding: 0 0.32rem;
}

.MyGameRecord__C-body-empty[data-v-b37345b8] {
    height: 5.33333rem;
}

.MyGameRecord__C-foot[data-v-b37345b8] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecord__C-foot-page[data-v-b37345b8] {
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.MyGameRecord__C-foot-previous[data-v-b37345b8],
.MyGameRecord__C-foot-next[data-v-b37345b8] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.MyGameRecord__C-foot-previous.disabled[data-v-b37345b8],
.MyGameRecord__C-foot-next.disabled[data-v-b37345b8] {
    background: var(--gray-color-1);
    pointer-events: none;
}

.MyGameRecord__C-foot-previous.disabled .MyGameRecord__C-icon[data-v-b37345b8],
.MyGameRecord__C-foot-next.disabled .MyGameRecord__C-icon[data-v-b37345b8] {
    color: var(--saveTextColor-7);
}

.MyGameRecord__C-foot-previous .MyGameRecord__C-icon[data-v-b37345b8],
.MyGameRecord__C-foot-next .MyGameRecord__C-icon[data-v-b37345b8] {
    color: #fff;
}

.list[data-v-b37345b8] {
    padding: 0 0.26667rem;
}

.list .hb[data-v-b37345b8] {
    background-color: #fff;
    color: var(--colorText-3);
    font-size: 0.37333rem;
}

.list .hb .item[data-v-b37345b8] {
    padding: 0.21333rem;
    border-bottom: 0.02667rem solid var(--gray-color-1);
    color: var(--colorText-3);
    font-size: 0.37333rem;
}

.list .hb .item.action[data-v-b37345b8] {
    padding: 0.32rem 0.26667rem;
}

.list .hb .item .goItem[data-v-b37345b8] {
    height: 0.42667rem;
}

.list .hb .li[data-v-b37345b8] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
    width: 0.42667rem !important;
    height: 0.42667rem;
    border: 0.02667rem solid var(--gray-color-1);
    border-radius: 0.42667rem;
    margin-right: 0.10667rem;
    color: var(--gray-color-1);
}

.list .hb .li.action[data-v-b37345b8] {
    font-size: 0.32rem;
    border: none;
    color: #fff;
    background-color: var(--norm_red-color);
}

.list .hb .li.circle-black[data-v-b37345b8] {
    border: 0.02667rem solid var(--text_color_L1);
    color: var(--text_color_L1);
    background: var(--bgColor-6);
}

.list .hb .li.actionH[data-v-b37345b8] {
    border: none;
    color: #fff;
    background-color: var(--borderColor-4);
}

.list .hb .li.actionL[data-v-b37345b8] {
    border: 0.01333rem solid var(--borderColor-4);
    color: var(--borderColor-4);
    background-color: #fff;
}

.list .hb .li.actionO[data-v-b37345b8] {
    border: none;
    color: #fff;
    background-color: var(--norm_secondary-color);
}

.list .hb .li.actionE[data-v-b37345b8] {
    border: 0.01333rem solid var(--norm_secondary-color);
    color: var(--norm_secondary-color);
    background-color: #fff;
}

.list .hb .qiu[data-v-b37345b8] {
    width: 3rem;
    position: relative;
}

.list .hb .qiu .line-canvas[data-v-b37345b8] {
    position: absolute !important;
    top: 0.12rem;
    left: 0;
    height: 0.73333rem;
    width: 2.61333rem;
    z-index: 99;
}

html:lang(ar) .list .hb .qiu .line-canvas[data-v-b37345b8] {
    right: 0.12rem;
    left: unset;
}

.list .hb .red[data-v-b37345b8] {
    color: var(--colorText-2);
}

.list .hb .green[data-v-b37345b8] {
    color: var(--norm_green-color);
}

.list .hb .blue[data-v-b37345b8] {
    color: var(--colorText-7);
}

.list .hb .box .li[data-v-b37345b8] {
    display: block;
    height: 0.13333rem;
    width: 0.13333rem;
    border-radius: 0.13333rem;
    margin: 0 0.06667rem;
}

.list .hb .item[data-v-b37345b8] {
    padding: 0.53333rem 0.4rem;
}

.list .hb .item .info[data-v-b37345b8] {
    width: 100%;
}

.list .hb .item .info .issueName .state[data-v-b37345b8] {
    color: #fff;
    padding: 0.10667rem 0.26667rem;
    margin-left: 0.26667rem;
    border-radius: 0.53333rem;
    font-size: 0.32rem;
    display: inline-block;
    text-align: center;
}

.list .hb .item .info .issueName .state.red[data-v-b37345b8] {
    background-color: var(--norm_red-color);
}

.list .hb .item .info .issueName .state.green[data-v-b37345b8] {
    background-color: var(--norm_green-color);
}

.list .hb .item .info .tiem[data-v-b37345b8] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
    margin-top: 0.13333rem;
}

.list .hb .item .info .money[data-v-b37345b8] {
    font-weight: 600;
    font-size: 0.42667rem;
}

.list .hb .item .info .money .fail[data-v-b37345b8] {
    color: var(--norm_red-color);
}

.list .hb .item .info .money .success[data-v-b37345b8] {
    color: var(--bgColor-13);
}

.list .hb .details[data-v-b37345b8] {
    padding: 0.4rem;
    border-bottom: 0.01333rem solid var(--gray-color-1);
}

.list .hb .details .tit[data-v-b37345b8] {
    font-size: 0.4rem;
    color: var(--text_color_L1);
    margin-bottom: 0.26667rem;
    font-weight: 700;
}

.list .hb .details .tit img[data-v-b37345b8] {
    width: 0.64rem;
    height: 0.64rem;
    position: relative;
    top: 0.13333rem;
}

.list .hb .details .tag-read img[data-v-b37345b8] {
    width: 0.32rem;
    height: 0.32rem;
}

.list .hb .details .detailLi[data-v-b37345b8] {
    min-height: 0.66667rem;
    line-height: 0.66667rem;
    background: var(--bgColor-6);
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
    margin-bottom: 0.21333rem;
}

.list .hb .details .detailLi .red[data-v-b37345b8] {
    color: var(--main_gradient-color);
}

.list .hb .details .detailLi .result[data-v-b37345b8] {
    height: 0.93333rem;
    line-height: 0.93333rem;
    background: var(--main-color);
    border-radius: 0.13333rem 0.13333rem 0 0;
    color: #fff;
    text-align: left;
    padding: 0 --0.26667rem;
}

.list .hb .details .detailLi .prize-tit[data-v-b37345b8] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.list .hb .details .detailLi .prize-box[data-v-b37345b8] {
    border-bottom: 0.01333rem solid #fff;
}

.list .hb .details .detailLi .prize-box-item[data-v-b37345b8] {
    text-align: center;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.list .hb .details .detailLi .c-flex-warp[data-v-b37345b8] {
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.list .hb .details .detailLi .select[data-v-b37345b8] {
    margin-left: 0.53333rem;
}

.list .hb .details .detailLi .select .ball[data-v-b37345b8] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 0.64rem;
    height: 0.42667rem;
    line-height: 0.42667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-left: 0.13333rem;
    margin-bottom: 0.13333rem;
    background: var(--main-color);
    border-radius: 0.08rem;
    color: #fff;
}

.list .hb .details .detailLi .Bet-box.pb[data-v-b37345b8] {
    padding-bottom: 0.06667rem;
}

.list .hb .details .detailLi .Bet-box ul li[data-v-b37345b8] {
    height: 0.26667rem;
    line-height: 0.26667rem;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    margin: 0.02667rem 0.05333rem;
    background-color: var(--gray-color-1);
}

.list .hb .details .detailLi .Bet-box ul li.actionViolet[data-v-b37345b8] {
    color: #fff;
    background-color: var(--bgcolor-21);
}

.list .hb .details .detailLi .Bet-box ul li.actionRed[data-v-b37345b8] {
    color: #fff;
    background-color: var(--norm_red-color);
}

.list .hb .details .detailLi .Bet-box ul li.actionGreen[data-v-b37345b8] {
    color: #fff;
    background-color: var(--bgColor-13);
}

.list .hb .details .detailLi .Bet-box ul li.actionRedGreen[data-v-b37345b8] {
    color: #fff;
    background-color: var(--norm_red-color);
    background-image: var(--linearGradien-21);
}

.list .hb .details .detailLi .Bet-box .actionBtn[data-v-b37345b8] {
    height: 0.34667rem;
    line-height: 0.34667rem;
    display: inline-block;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    background-color: var(--norm_red-color);
    color: #fff;
}

.areList[data-v-b37345b8] {
    margin: 0.53333rem;
    position: relative;
}

.areList .close[data-v-b37345b8] {
    position: absolute;
    top: -1.6rem;
    left: 50%;
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
    width: 0.8rem;
    height: 0.8rem;
}

.areList .items h1[data-v-b37345b8] {
    color: var(--darkTextW, var(--borderColor-26));
    font-size: 0.42667rem;
}

.areList .items .itemsC[data-v-b37345b8] {
    margin: 0.26667rem 0 0.4rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    gap: 0.2rem;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.areList .items .itemsC>div[data-v-b37345b8] {
    width: calc((100% - 0.53333rem) / 2);
    background: var(--bgDark-3, var(--homeActiveBgColor));
    border-radius: 0.13333rem;
    min-height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
}

.areList .items .itemsC .isActive[data-v-b37345b8] {
    background: var(--norm_red-color);
    color: #fff;
}

.titlebets[data-v-b37345b8] {
    font-size: 0.29333rem;
    color: var(--main-color);
}

.border60[data-v-b37345b8] {
    width: 4.53333rem;
    height: 0.66667rem;
    line-height: 0.66667rem;
    border-radius: 0.8rem;
    border: 0.01333rem solid var(--main-color);
    margin: 0 auto;
    margin-top: 0.30667rem;
}

.bottombg[data-v-b37345b8] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/arrowbottom-4eb91cbc.png);
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center;
}

.compound2[data-v-b37345b8],
.compound3[data-v-b37345b8] {
    padding-top: 0.26667rem;
    max-height: 5.33333rem;
    overflow-y: auto;
}

.compound2 .item[data-v-b37345b8],
.compound3 .item[data-v-b37345b8] {
    width: 100%;
    margin-bottom: 0.26667rem;
}

.compound2 .item.item0-3 .box .c-row[data-v-b37345b8],
.compound3 .item.item0-3 .box .c-row[data-v-b37345b8] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.21333rem;
}

.compound2 .item.item0-3 .box .num[data-v-b37345b8],
.compound3 .item.item0-3 .box .num[data-v-b37345b8] {
    width: calc((100% - 1.28rem) / 7);
    height: 1.13333rem;
    background-size: 1.13333rem 1.13333rem;
}

.compound2 .item.item0-2 .box .c-row[data-v-b37345b8],
.compound2 .item.item5-2 .box .c-row[data-v-b37345b8],
.compound3 .item.item0-2 .box .c-row[data-v-b37345b8],
.compound3 .item.item5-2 .box .c-row[data-v-b37345b8] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.21333rem;
}

.compound2 .item.item0-2 .box .num[data-v-b37345b8],
.compound2 .item.item5-2 .box .num[data-v-b37345b8],
.compound3 .item.item0-2 .box .num[data-v-b37345b8],
.compound3 .item.item5-2 .box .num[data-v-b37345b8] {
    width: calc((100% - 1.28rem) / 7);
    height: 0.8rem;
    background-size: 0.8rem 0.8rem;
}

.compound2 .item.item4-2 .box .c-row[data-v-b37345b8],
.compound3 .item.item4-2 .box .c-row[data-v-b37345b8] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item4-2 .box .num[data-v-b37345b8],
.compound3 .item.item4-2 .box .num[data-v-b37345b8] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-8),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-7),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-6),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-5),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-4),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-2),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-1),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-8),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-7),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-5),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-4),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-2),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-1),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
}

.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-7),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-6),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-4),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-1),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-7),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-4),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-1),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n) {
    margin-left: -0.10667rem;
}

.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-b37345b8]:nth-child(9n-6) {
    margin-right: 0.42667rem;
}

.compound2 .item.item3-2 .box .c-row[data-v-b37345b8],
.compound3 .item.item3-2 .box .c-row[data-v-b37345b8] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item3-2 .box .num[data-v-b37345b8],
.compound3 .item.item3-2 .box .num[data-v-b37345b8] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-1),
.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-2),
.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-3),
.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-4),
.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-5),
.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-6),
.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-7),
.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-1),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-2),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-3),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-5),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-6),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-7),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
}

.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-6),
.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-5),
.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-4),
.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-2),
.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-1),
.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-6),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-5),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-2),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-1),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n) {
    margin-left: -0.06667rem;
}

.compound2 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-b37345b8]:nth-child(8n-4) {
    margin-right: 1.73333rem;
}

.compound2 .item.item2-2 .box .c-row[data-v-b37345b8],
.compound3 .item.item2-2 .box .c-row[data-v-b37345b8] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item2-2 .box .num[data-v-b37345b8],
.compound3 .item.item2-2 .box .num[data-v-b37345b8] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-1),
.compound2 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-2),
.compound2 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-3),
.compound2 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-4),
.compound2 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-5),
.compound2 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-6),
.compound2 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-7),
.compound2 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n),
.compound3 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-1),
.compound3 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-2),
.compound3 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-3),
.compound3 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-4),
.compound3 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-5),
.compound3 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-6),
.compound3 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n-7),
.compound3 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
    margin-left: -0.01333rem;
}

.compound2 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n),
.compound3 .item.item2-2 .box .num[data-v-b37345b8]:nth-child(8n) {
    margin-right: 1.33333rem;
}

.compound2 .item.item1-2 .box .c-row[data-v-b37345b8],
.compound3 .item.item1-2 .box .c-row[data-v-b37345b8] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item1-2 .box .num[data-v-b37345b8],
.compound3 .item.item1-2 .box .num[data-v-b37345b8] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-1),
.compound2 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-2),
.compound2 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-3),
.compound2 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-4),
.compound2 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-5),
.compound2 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-6),
.compound2 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-7),
.compound2 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-8),
.compound2 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-9),
.compound2 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n),
.compound3 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-1),
.compound3 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-2),
.compound3 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-3),
.compound3 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-4),
.compound3 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-5),
.compound3 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-6),
.compound3 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-7),
.compound3 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-8),
.compound3 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n-9),
.compound3 .item.item1-2 .box .num[data-v-b37345b8]:nth-child(10n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
    margin-left: -0.09333rem;
}

.compound2 .item .box[data-v-b37345b8],
.compound3 .item .box[data-v-b37345b8] {
    border-radius: 0.26667rem;
    position: relative;
    width: 100%;
}

.compound2 .item .box .num[data-v-b37345b8],
.compound3 .item .box .num[data-v-b37345b8] {
    min-width: 0.8rem;
    min-height: 0.8rem;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: 0.8rem 0.8rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
}

.compound2 .item .box .money[data-v-b37345b8],
.compound3 .item .box .money[data-v-b37345b8] {
    text-align: center;
    background-color: var(--gray-color-1);
    position: relative;
    height: 0.53333rem;
    border-radius: 0 0 0.26667rem 0.26667rem;
}

.compound2 .item .box .money .all[data-v-b37345b8],
.compound3 .item .box .money .all[data-v-b37345b8] {
    position: relative;
    z-index: 9;
    line-height: 0.8rem;
    font-size: 0.32rem;
    color: #00AF54;
}

.compound2 .item .box .money[data-v-b37345b8]:after,
.compound3 .item .box .money[data-v-b37345b8]:after {
    position: absolute;
    top: 0;
    left: 0;
    content: "";
    display: block;
    width: 100%;
    height: 0.21333rem;
    background-color: var(--gray-color-1);
    border-radius: 0 0 50% 50%;
}

.compound2 .item .box .dele[data-v-b37345b8],
.compound3 .item .box .dele[data-v-b37345b8] {
    position: absolute;
    right: -0.18667rem;
    top: -0.18667rem;
    height: 0.37333rem;
    width: 0.37333rem;
    border-radius: 0.53333rem;
    background-color: #00AF54;
}

.compound2 .item .box .dele .icon[data-v-b37345b8],
.compound3 .item .box .dele .icon[data-v-b37345b8] {
    font-size: 0.26667rem;
}

.compound2 .item.item0-4 .box .c-row[data-v-b37345b8] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.53333rem;
}

.compound2 .item.item0-4 .box .num[data-v-b37345b8] {
    width: calc((100% - 2.13333rem) / 5);
    background: var(--main_gradient-color);
    color: #fff;
    border-radius: 0.13333rem;
    min-height: 1.06667rem;
    min-width: 1.33333rem;
}

.compound[data-v-b37345b8] {
    padding-top: 0.26667rem;
    max-height: 6rem;
    overflow: auto;
}

.compound .item[data-v-b37345b8] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 100%;
    margin-bottom: 0.4rem;
}

.compound .item .title[data-v-b37345b8] {
    width: 1.38667rem;
    overflow: hidden;
    position: relative;
    text-align: center;
    font-size: 0.42667rem;
    color: var(--text_color_L2);
}

.compound .item .numcontainer[data-v-b37345b8] {
    width: 7.94667rem;
    margin-left: 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    justify-content: flex-start;
    gap: 0.13333rem;
}

.compound .item .numcontainer .num[data-v-b37345b8] {
    width: calc((100% - 0.85333rem) / 5);
    height: 0.8rem;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: 0.8rem 0.8rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
    position: relative;
    text-align: center;
    line-height: 0.8rem;
}

.compound .item .numcontainer .num .dele[data-v-b37345b8] {
    position: absolute;
    right: -0.18667rem;
    top: -0.18667rem;
    height: 0.37333rem;
    width: 0.37333rem;
    border-radius: 0.53333rem;
    background-color: #00AF54;
}

html:lang(ar) .compound .item .numcontainer .num .dele[data-v-b37345b8] {
    right: unset;
    left: -0.18667rem;
}

.compound .item .numcontainer .num .dele .icon[data-v-b37345b8] {
    font-size: 0.26667rem;
}

.van-toast[data-v-fdfc55f4] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-fdfc55f4] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-fdfc55f4] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-fdfc55f4] {
    height: 80%;
}

.NewVietnam__C[data-v-fdfc55f4] {
    padding-bottom: 0.34667rem;
    overflow-y: auto;
    background-color: var(--bgDark-4, var(--bg_color_L1));
}

.NewVietnam__C-head[data-v-fdfc55f4] {
    height: 1.25333rem;
    background: var(--main_gradient-color);
    padding: 0 0.34667rem;
    position: relative;
}

.NewVietnam__C-head div[data-v-fdfc55f4] {
    background-repeat: no-repeat;
    background-position: center;
}

.NewVietnam__C-head-bcak[data-v-fdfc55f4] {
    position: absolute;
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/bcakIcon-b7c1d288.png);
    background-size: 0.64rem;
    left: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
}

html:lang(ar) .NewVietnam__C-head-bcak[data-v-fdfc55f4] {
    left: unset;
    right: 0.34667rem;
}

.NewVietnam__C-head-logo[data-v-fdfc55f4] {
    background-size: 2.98667rem 1.12rem;
    height: 1.12rem;
    width: 2.98667rem;
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
}

.NewVietnam__C-head-more[data-v-fdfc55f4] {
    position: absolute;
    width: 1.54667rem;
    height: 0.64rem;
    right: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

html:lang(ar) .NewVietnam__C-head-more[data-v-fdfc55f4] {
    right: unset;
    left: 0.34667rem;
}

.NewVietnam__C-head-more>div[data-v-fdfc55f4] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/kefu-b361c42f.png);
    background-size: 0.64rem;
}

.NewVietnam__C-head-more>div[data-v-fdfc55f4]:last-child {
    background-image: url(/assets/png/voice-62dbf38c.png);
}

.NewVietnam__C-head-more>div:last-child.disableVoice[data-v-fdfc55f4] {
    background-image: url(/assets/png/voice-off-633f5ccc.png);
}

.NewVietnam__C[data-v-fdfc55f4] .driver-close-btn,
.NewVietnam__C[data-v-fdfc55f4] .driver-prev-btn {
    display: none;
}

.popup[data-v-fdfc55f4] {
    overflow-y: visible !important;
    border-radius: 0.13333rem 0.13333rem 0 0;
    width: 100%;
}

.popup[data-v-fdfc55f4] .van-popup {
    overflow-y: visible !important;
    border-radius: 0.26667rem 0.26667rem 0 0;
}

.popup .box[data-v-fdfc55f4] {
    position: relative;
}

.popup .box .close[data-v-fdfc55f4] {
    position: absolute;
    top: -1.06667rem;
    left: 50%;
    -webkit-transform: translate(-50%, 0);
    transform: translate(-50%);
}

.popup .box .close .img[data-v-fdfc55f4] {
    width: 0.8rem;
    height: 0.8rem;
}

.popup .box .title[data-v-fdfc55f4] {
    font-size: 0.42667rem;
    color: var(--text_color_L1);
}

.popup .box .numList[data-v-fdfc55f4] {
    max-height: 5.33333rem;
    overflow-x: auto;
}

.popup .box .numList .item[data-v-fdfc55f4] {
    width: 1.06667rem;
    height: 1.06667rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
    margin: 0 0.13333rem;
}

.popup-info-item[data-v-fdfc55f4] {
    height: 0.8rem;
    line-height: 0.8rem;
    margin-top: 0.26667rem;
}

.popup-info-item .tit[data-v-fdfc55f4] {
    font-size: 0.37333rem;
    color: var(--text_color_L2);
}

.popup-info-item .amount-box .li[data-v-fdfc55f4],
.popup-info-item .multiple-box .li[data-v-fdfc55f4] {
    text-align: center;
    font-size: 0.32rem;
    padding: 0 0.13333rem;
    height: 0.8rem;
    line-height: 0.8rem;
    min-width: 1.33333rem;
    margin-left: 0.13333rem;
    border: 0.01333rem solid var(--gray-color-1);
    border-radius: 0.13333rem;
    color: #00AF54;
}

.popup-info-item .amount-box .li.action[data-v-fdfc55f4],
.popup-info-item .multiple-box .li.action[data-v-fdfc55f4] {
    border: none;
    color: #fff;
    background: var(--main_gradient-color);
}

.popup-info-item .multiple-box .li[data-v-fdfc55f4] {
    padding: 0 0.26667rem;
    min-width: auto;
}

.popup-info-item .stepper-box .digit-box[data-v-fdfc55f4] {
    width: 2.66667rem;
    height: 0.8rem;
    border-radius: 0.8rem;
    padding: 0;
    margin: 0 0.13333rem;
    background-color: var(--walletBgColor-1);
}

.popup-info-item .stepper-box .digit-box[data-v-fdfc55f4] .van-field__control {
    height: 0.74667rem;
    text-align: center;
}

.popup-info-item .stepper-box .li[data-v-fdfc55f4] {
    height: 0.8rem;
    width: 0.8rem;
    font-size: 0.8rem;
    border-radius: 50%;
    background-color: var(--main-color);
    color: #fff;
}

.popup-info-item .stepper-box .li.minus[data-v-fdfc55f4] {
    text-align: center;
    line-height: 0.66667rem;
}

.popup-info-item .txt[data-v-fdfc55f4] {
    color: #00AF54;
}

.popup-info .quantity[data-v-fdfc55f4] {
    margin-top: 0.26667rem;
    padding: 0 0.21333rem;
    height: 1.17333rem;
    background-color: var(--bgDark-2, var(--homeActiveBgColor));
    border-radius: 0.13333rem;
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.popup-info .quantity .line[data-v-fdfc55f4] {
    padding: 0 0.13333rem;
    color: var(--text_color_L2);
}

.popup-info .quantity .num[data-v-fdfc55f4] {
    color: #00AF54;
    font-size: 0.4rem;
}

.popup-info .wallet[data-v-fdfc55f4],
.popup-info .balance[data-v-fdfc55f4] {
    padding: 0 0.21333rem;
    margin-top: 0.26667rem;
    height: 0.8rem;
    background-color: var(--bgDark-2, var(--homeActiveBgColor));
}

.popup-info .wallet .txt[data-v-fdfc55f4],
.popup-info .balance .txt[data-v-fdfc55f4] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.popup-info .wallet .txt img[data-v-fdfc55f4],
.popup-info .balance .txt img[data-v-fdfc55f4] {
    width: 0.4rem;
    height: 0.4rem;
    margin-right: 0.13333rem;
}

.popup-info .wallet .txt .num[data-v-fdfc55f4],
.popup-info .balance .txt .num[data-v-fdfc55f4] {
    font-size: 0.37333rem;
    color: var(--text_color_L1);
    padding-left: 0.26667rem;
}

.popup-info .wallet .txt .num.yellow[data-v-fdfc55f4],
.popup-info .balance .txt .num.yellow[data-v-fdfc55f4] {
    color: var(--norm_secondary-color);
}

.popup-info .wallet .bg333[data-v-fdfc55f4],
.popup-info .balance .bg333[data-v-fdfc55f4] {
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.popup-info .wallet .bg7172[data-v-fdfc55f4],
.popup-info .balance .bg7172[data-v-fdfc55f4] {
    font-size: 0.32rem;
    color: var(--main-color);
}

.popup-info .wallet .bet[data-v-fdfc55f4],
.popup-info .balance .bet[data-v-fdfc55f4] {
    border: 0.01333rem solid #00AF54;
    border-radius: 0.13333rem;
    height: 0.64rem;
    line-height: 0.64rem;
    color: #00AF54;
    padding: 0 0.26667rem;
}

.popup-btn[data-v-fdfc55f4] {
    height: 1.6rem;
}

.popup-btn .left[data-v-fdfc55f4] {
    width: 45%;
}

.popup-btn .left .btn[data-v-fdfc55f4] {
    height: 1.6rem;
    font-size: 0.42667rem;
    border-radius: 0;
    color: var(--text_color_L2);
    background-color: #00AF54;
}

.popup-btn .right[data-v-fdfc55f4] {
    width: 55%;
}

.popup-btn .right .btn[data-v-fdfc55f4] {
    height: 1.6rem;
    font-size: 0.42667rem;
    border-radius: 0;
    color: #fff;
    background-color: #00AF54;
}

.popup-btn .right .noActive[data-v-fdfc55f4] {
    background-color: #00AF54;
    color: var(--text_color_L2);
}

.PreSaleRule[data-v-fdfc55f4] {
    width: 7.04rem;
}

.PreSaleRule .head[data-v-fdfc55f4] {
    height: 1.2rem;
    line-height: 1.2rem;
    color: #fff;
    font-size: 0.4rem;
    text-align: center;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: left center;
    background-image: url(/assets/png/wingoPreSaleBg-6566ea95.png);
}

.PreSaleRule .body[data-v-fdfc55f4] {
    max-height: 8rem;
    overflow-y: auto;
    padding: 0.4rem;
    font-size: 0.32rem;
    line-height: 0.8rem;
}

.PreSaleRule .body[data-v-fdfc55f4] p {
    margin-bottom: 0.2rem;
    line-height: 0.53333rem;
}

.PreSaleRule .foot[data-v-fdfc55f4] {
    height: 1.86667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.PreSaleRule .foot .btn[data-v-fdfc55f4] {
    width: 60%;
    background: var(--main_gradient-color);
    border-radius: 0.53333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    font-size: 0.37333rem;
    color: #fff;
}

.Tips[data-v-fdfc55f4] {
    width: 8rem;
    height: 2.13333rem;
    line-height: 2.13333rem;
    background: var(--bg_color_L2);
    border: 0.01333rem solid var(--borderColor-5);
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.Tips>div[data-v-fdfc55f4] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    overflow-y: hidden;
}

.Tips>div img[data-v-fdfc55f4] {
    width: 1.17333rem;
    height: 1.17333rem;
    margin-top: 0.45333rem;
}

.Tips>div .font36[data-v-fdfc55f4] {
    color: var(--text_color_L1);
    font-weight: 700;
    font-size: 0.48rem;
    margin-left: 0.32rem;
}

.GameList__C-region[data-v-fdfc55f4] {
    height: 1.2rem;
    line-height: 1.2rem;
    overflow: hidden;
    padding: 0 0.26667rem;
    margin: 0.26667rem 0;
}

.GameList__C-region .item[data-v-fdfc55f4] {
    width: calc(33.3% - 0.53333rem);
    position: relative;
    text-align: center;
    font-size: 0.48rem;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

.GameList__C-region .item[data-v-fdfc55f4]:nth-child(1) {
    background: var(--bg_color_L2);
    border-radius: 0.13333rem 0 0 0.13333rem;
}

.GameList__C-region .item[data-v-fdfc55f4]:nth-child(1):after {
    position: absolute;
    top: 0;
    right: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-bottom: 1.2rem solid #fff;
    border-right: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

.GameList__C-region .item[data-v-fdfc55f4]:nth-child(2) {
    background: var(--bg_color_L2);
}

.GameList__C-region .item[data-v-fdfc55f4]:nth-child(2):after {
    position: absolute;
    top: 0;
    right: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-top: 1.2rem solid #fff;
    border-right: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-fdfc55f4]:nth-child(2):after {
    left: -0.66667rem;
    right: unset;
}

.GameList__C-region .item[data-v-fdfc55f4]:nth-child(2):before {
    position: absolute;
    top: 0;
    left: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-top: 1.2rem solid #fff;
    border-left: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-fdfc55f4]:nth-child(2):before {
    right: -0.66667rem;
    left: unset;
}

.GameList__C-region .item[data-v-fdfc55f4]:nth-child(3) {
    background: var(--bg_color_L2);
    border-radius: 0 0.13333rem 0.13333rem 0;
}

.GameList__C-region .item[data-v-fdfc55f4]:nth-child(3):before {
    position: absolute;
    top: 0;
    left: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-bottom: 1.2rem solid #fff;
    border-left: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-fdfc55f4]:nth-child(3):before {
    right: -0.66667rem;
    left: unset;
}

.GameList__C-region .item.action[data-v-fdfc55f4] {
    color: #fff;
}

.GameList__C-region .item.action[data-v-fdfc55f4]:nth-child(1) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-fdfc55f4]:nth-child(1):after {
    border-bottom: 1.2rem solid var(--borderColor-5);
}

.GameList__C-region .item.action[data-v-fdfc55f4]:nth-child(2) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-fdfc55f4]:nth-child(2):after {
    border-top: 1.2rem solid var(--borderColor-5);
}

.GameList__C-region .item.action[data-v-fdfc55f4]:nth-child(2):before {
    border-top: 1.2rem solid #00AF54;
}

.GameList__C-region .item.action[data-v-fdfc55f4]:nth-child(3) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-fdfc55f4]:nth-child(3):before {
    border-bottom: 1.2rem solid #00AF54;
}

.GameList__C-time[data-v-fdfc55f4] {
    padding-left: 0.2rem;
    overflow-y: auto;
    height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameList__C-time .item[data-v-fdfc55f4] {
    position: relative;
    white-space: nowrap;
    background-color: #fff;
    margin: 0 0.10667rem;
    padding: 0.04rem 0.16rem 0;
    text-align: center;
    border-radius: 0.13333rem 0.13333rem 0 0;
}

.GameList__C-time .item .week[data-v-fdfc55f4] {
    font-size: 0.16rem;
    color: var(--text_color_L1);
}

.GameList__C-time .item .time[data-v-fdfc55f4] {
    font-size: 0.16rem;
    color: var(--text_color_L2);
}

.GameList__C-time .item[data-v-fdfc55f4]:after,
.GameList__C-time .item[data-v-fdfc55f4]:before {
    content: "";
    width: 0.4rem;
    height: 0.4rem;
    position: absolute;
    bottom: 0;
    z-index: 9;
}

.GameList__C-time .item[data-v-fdfc55f4]:after {
    background: -webkit-radial-gradient( 100% 0, circle, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    background: radial-gradient( circle at 100% 0, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    right: -0.4rem;
}

html:lang(ar) .GameList__C-time .item[data-v-fdfc55f4]:after {
    left: -0.4rem;
    right: unset;
}

.GameList__C-time .item[data-v-fdfc55f4]:before {
    background: -webkit-radial-gradient( 0 0, circle, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    background: radial-gradient( circle at 0 0, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    left: -0.4rem;
}

html:lang(ar) .GameList__C-time .item[data-v-fdfc55f4]:before {
    right: -0.4rem;
    left: unset;
}

.GameList__C-time .item.active[data-v-fdfc55f4] {
    background-color: var(--main-color);
    color: #fff;
    z-index: 10;
}

.GameList__C-time .item.active .week[data-v-fdfc55f4],
.GameList__C-time .item.active .time[data-v-fdfc55f4] {
    color: #fff;
}

.GameList__C-time .item.active[data-v-fdfc55f4]:before {
    background: -webkit-radial-gradient( 0 0, circle, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    background: radial-gradient( circle at 0 0, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    left: -0.4rem;
    z-index: 10;
}

html:lang(ar) .GameList__C-time .item.active[data-v-fdfc55f4]:before {
    right: -0.4rem;
    left: unset;
}

.GameList__C-time .item.active[data-v-fdfc55f4]:after {
    background: -webkit-radial-gradient( 100% 0, circle, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    background: radial-gradient( circle at 100% 0, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    right: -0.4rem;
    z-index: 10;
}

html:lang(ar) .GameList__C-time .item.active[data-v-fdfc55f4]:after {
    left: -0.4rem;
    right: unset;
}

.GameList__C-city[data-v-fdfc55f4] {
    border-top: 0.02667rem solid #fff;
    overflow-y: auto;
    height: 0.6rem;
    height: 1.17333rem;
    background-color: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameList__C-city .item[data-v-fdfc55f4] {
    height: 0.93333rem;
    line-height: 0.93333rem;
    white-space: nowrap;
    margin: 0.08rem 0.10667rem;
    padding: 0 0.10667rem;
    text-align: center;
    color: #fff;
}

.GameList__C-city .item.action[data-v-fdfc55f4] {
    background-color: #fff;
    color: var(--main-color);
    border-radius: 0.06667rem;
}

.GameList__C-bet[data-v-fdfc55f4] {
    width: 100%;
    margin-top: 0.2rem;
    padding: 0 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 1.06667rem;
    overflow-x: scroll;
}

.GameList__C-bet ul[data-v-fdfc55f4] {
    margin: 0;
    padding: 0;
    list-style: none;
    -webkit-flex-wrap: nowrap;
    flex-wrap: nowrap;
    white-space: nowrap;
}

.GameList__C-bet .item[data-v-fdfc55f4] {
    -webkit-box-flex: 0;
    -webkit-flex: 0 0 auto;
    flex: 0 0 auto;
    height: 0.93333rem;
    padding: 0.25333rem 0.88rem;
    background: var(--bg_color_L2);
    border-radius: 0.16rem;
    margin-right: 0.32rem;
    color: var(--text_color_L2);
}

.GameList__C-bet .item.action[data-v-fdfc55f4] {
    color: #fff;
    background: var(--main_gradient-color2);
}

.Betting__C-mark[data-v-fdfc55f4] {
    width: 100%;
    height: 100%;
    background: var(--bgcolor-32);
    position: fixed;
    z-index: 99;
    top: 0;
    left: 0;
    color: #fff;
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

html:lang(ar) .Betting__C-mark[data-v-fdfc55f4] {
    right: 0;
    left: unset;
    direction: ltr;
}

.Betting__C-mark>div[data-v-fdfc55f4] {
    width: 5.86667rem;
    height: 1.33333rem;
    line-height: 1.33333rem;
    display: inline-block;
    border-radius: 0.26667rem;
    border: 0.01333rem solid #fff;
    font-size: 0.42667rem;
    color: #fff;
    font-weight: 700;
    padding: 0 0.4rem 0 2.08rem;
}

.Betting__C-bet[data-v-fdfc55f4] {
    margin-top: 0.4rem;
    padding: 0 0.26667rem;
}

.Betting__C-bet .tit[data-v-fdfc55f4] {
    height: 0.53333rem;
    line-height: 0.53333rem;
}

.Betting__C-bet .tit-select[data-v-fdfc55f4] {
    padding-left: 0.26667rem;
    font-size: 0.42667rem;
    font-weight: 700;
    border-left: 0.08rem solid var(--main-color);
}

.Betting__C-bet .tit-list .check[data-v-fdfc55f4] {
    padding-left: 0.26667rem;
    color: var(--text_color_L2);
}

.Betting__C-bet .tit-list .check-item[data-v-fdfc55f4] {
    height: 0.42667rem;
    width: 0.42667rem;
    border-radius: 0.42667rem;
    border: 0.02667rem solid #c9c9c9;
    margin-right: 0.10667rem;
}

.Betting__C-bet .tit-list .check.action[data-v-fdfc55f4] {
    color: #00AF54;
}

.Betting__C-bet .tit-list .check.action .check-item[data-v-fdfc55f4] {
    border: 0.01333rem solid #00AF54;
    position: relative;
}

.Betting__C-bet .tit-list .check.action .check-item[data-v-fdfc55f4]:after {
    content: "";
    display: block;
    border-radius: 0.26667rem;
    background-color: #00AF54;
    width: 0.26667rem;
    height: 0.26667rem;
    position: absolute;
    left: 0.05333rem;
    top: 0.05333rem;
}

html:lang(ar) .Betting__C-bet .tit-list .check.action .check-item[data-v-fdfc55f4]:after {
    right: 0.05333rem;
    left: unset;
}

.Betting__C-bet .nList[data-v-fdfc55f4] {
    background: var(--bg_color_L2);
    border-radius: 0.32rem;
    padding: 0.26667rem;
    margin-top: 0.4rem;
}

.Betting__C-bet .nList .Ntit[data-v-fdfc55f4] {
    line-height: 0.74667rem;
    font-size: 0.42667rem;
    color: var(--text_color_L3);
    font-weight: 400;
}

.Betting__C-bet .nList .list[data-v-fdfc55f4] {
    width: 100%;
}

.Betting__C-bet .nList .list .item[data-v-fdfc55f4] {
    width: 20%;
}

.Betting__C-bet .nList .list .item .number[data-v-fdfc55f4] {
    width: 1.06667rem;
    height: 1.06667rem;
    font-size: 0.42667rem;
    font-weight: 700;
    color: var(--text_color_L2);
    background: url(/assets/svg/nbg-dba06970.svg) no-repeat center center;
    background-size: cover;
}

.Betting__C-bet .nList .list .item .number.action[data-v-fdfc55f4] {
    color: #00AF54;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
}

.Footer__C[data-v-fdfc55f4] {
    width: 100%;
    position: fixed;
    left: auto;
    bottom: 0;
    height: 1.6rem;
    z-index: 98;
}

.Footer__C .nav[data-v-fdfc55f4] {
    height: 1.6rem;
    background-color: #fee;
    max-width: 10rem;
}

.Footer__C .nav .left[data-v-fdfc55f4] {
    width: 55%;
}

.Footer__C .nav .left .item[data-v-fdfc55f4] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    padding-left: 0.26667rem;
    color: var(--main-color);
}

.Footer__C .nav .left .item .txt[data-v-fdfc55f4] {
    margin-bottom: 0.08rem;
}

.Footer__C .nav .left .item .num[data-v-fdfc55f4] {
    color: #00AF54;
    font-weight: 600;
}

.Footer__C .bet-btn[data-v-fdfc55f4] {
    width: 40%;
    background-color: #00AF54;
    color: #fff;
    font-size: 0.48rem;
    font-weight: 600;
}

.Footer__C .disabled-btn[data-v-fdfc55f4] {
    width: 40%;
    background-color: var(--button_dis_color);
    color: var(--text_color_L2);
    font-size: 0.48rem;
    font-weight: 400;
    pointer-events: none;
}

.RecordNav__C[data-v-fdfc55f4] {
    width: calc(100% - 0.64rem);
    height: 1.17333rem;
    line-height: 1.17333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    margin: 0.32rem auto 0;
    border-radius: 0.16rem;
    overflow: hidden;
}

.RecordNav__C>div[data-v-fdfc55f4] {
    width: 50%;
    height: 100%;
    background: var(--bgDark-3, var(--bg_color_L2));
    font-size: 0.42667rem;
    color: var(--text_color_L2);
    text-align: center;
    overflow: hidden;
}

.RecordNav__C>div.active[data-v-fdfc55f4] {
    background: var(--dark-linerGradien-91, var(--main_gradient-color2));
    font-weight: 600;
    color: #fff;
}

.GameRecord__C[data-v-fdfc55f4] {
    width: calc(100% - 0.69333rem);
    margin: 0.26667rem auto 1.6rem;
    text-align: center;
    font-size: 0.32rem;
}

.GameRecord__C-head[data-v-fdfc55f4] {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--bgDark-2, var(--main-color));
    border-radius: 0.13333rem 0.13333rem 0 0;
    font-weight: 600;
    font-size: 0.37333rem;
    color: #fff;
}

.GameRecord__C-body[data-v-fdfc55f4] {
    color: var(--text_color_L1);
    font-size: 0.32rem;
    background: var(--darkBg, var(--bg_color_L1));
    border-radius: 0 0 0.13333rem 0.13333rem;
}

.GameRecord__C-body[data-v-fdfc55f4] .van-row {
    min-height: 1.30667rem;
    border-bottom: 0.01333rem solid var(--bgDark-2, var(--saveTextColor-3));
}

.GameRecord__C-body .details[data-v-fdfc55f4] {
    width: 100%;
    border: 0.01333rem solid var(--borderColor-5);
    border-radius: 0.26667rem;
    padding: 0.33333rem;
}

.GameRecord__C-body .details .tit[data-v-fdfc55f4] {
    font-size: 0.4rem;
    color: var(--text_color_L1);
    margin-bottom: 0.26667rem;
    font-weight: 700;
}

.GameRecord__C-body .details .tit img[data-v-fdfc55f4] {
    width: 0.64rem;
    height: 0.64rem;
    position: relative;
    top: 0.13333rem;
}

.GameRecord__C-body .details .tag-read img[data-v-fdfc55f4] {
    width: 0.32rem;
    height: 0.32rem;
}

.GameRecord__C-body .details .detailLi[data-v-fdfc55f4] {
    min-height: 0.66667rem;
    line-height: 0.66667rem;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
}

.GameRecord__C-body .details .detailLi .red[data-v-fdfc55f4] {
    color: var(--main_gradient-color);
}

.GameRecord__C-body .details .detailLi .prize[data-v-fdfc55f4] {
    background: var(--bgDark-4, --walletBgColor-1);
    margin-bottom: 0.16rem;
    padding: 0.26667rem;
    border-radius: 0.26667rem;
}

.GameRecord__C-body .details .detailLi .prize[data-v-fdfc55f4]:last-child {
    margin-bottom: 0;
}

.GameRecord__C-body .details .detailLi .selectItem0[data-v-fdfc55f4],
.GameRecord__C-body .details .detailLi .selectItem1[data-v-fdfc55f4],
.GameRecord__C-body .details .detailLi .selectItem2[data-v-fdfc55f4] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameRecord__C-body .details .detailLi .selectItem0>div[data-v-fdfc55f4]:nth-of-type(1),
.GameRecord__C-body .details .detailLi .selectItem1>div[data-v-fdfc55f4]:nth-of-type(1),
.GameRecord__C-body .details .detailLi .selectItem2>div[data-v-fdfc55f4]:nth-of-type(1) {
    width: 45%;
}

.GameRecord__C-body .details .detailLi .selectItem0>div[data-v-fdfc55f4]:nth-of-type(2),
.GameRecord__C-body .details .detailLi .selectItem1>div[data-v-fdfc55f4]:nth-of-type(2),
.GameRecord__C-body .details .detailLi .selectItem2>div[data-v-fdfc55f4]:nth-of-type(2) {
    width: 0.13333rem;
}

.GameRecord__C-body .details .detailLi .selectItem0 span[data-v-fdfc55f4],
.GameRecord__C-body .details .detailLi .selectItem1 span[data-v-fdfc55f4],
.GameRecord__C-body .details .detailLi .selectItem2 span[data-v-fdfc55f4] {
    font-weight: 700;
    font-size: 0.42667rem;
    color: var(--darkTextW, --text_color_L1);
    padding-left: 0;
    text-align: center;
}

.GameRecord__C-body .details .detailLi .selectItem0 span[data-v-fdfc55f4] {
    color: #00AF54;
}

.GameRecord__C-body .details .detailLi .prize-tit[data-v-fdfc55f4] {
    text-align: left;
    font-size: 0.37333rem;
    color: var(--darkTextW, --text_color_L1);
    padding-left: 0.26667rem;
}

.GameRecord__C-body .details .detailLi .action0[data-v-fdfc55f4] {
    color: #00AF54 !important;
    font-weight: 700;
    font-size: 0.42667rem;
}

.GameRecord__C-body .details .detailLi .action1[data-v-fdfc55f4],
.GameRecord__C-body .details .detailLi .action2[data-v-fdfc55f4] {
    font-weight: 700;
    font-size: 0.42667rem;
}

.GameRecord__C-body .details .detailLi .prize-box[data-v-fdfc55f4] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
}

.GameRecord__C-body .details .detailLi .prize-box-item[data-v-fdfc55f4] {
    text-align: left;
    padding-left: 0.26667rem;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: var(--text_color_L1);
    font-size: 0.37333rem;
    font-weight: 500;
}

.GameRecord__C-body .details .detailLi .c-flex-warp[data-v-fdfc55f4] {
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.GameRecord__C-body .details .detailLi .select[data-v-fdfc55f4] {
    margin-left: 0.53333rem;
}

.GameRecord__C-body .details .detailLi .select .ball[data-v-fdfc55f4] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 0.64rem;
    height: 0.42667rem;
    line-height: 0.42667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-left: 0.13333rem;
    margin-bottom: 0.13333rem;
    background: var(--main-color);
    border-radius: 0.08rem;
    color: #fff;
}

.GameRecord__C-body .details .detailLi .Bet-box.pb[data-v-fdfc55f4] {
    padding-bottom: 0.06667rem;
}

.GameRecord__C-body .details .detailLi .Bet-box ul li[data-v-fdfc55f4] {
    height: 0.26667rem;
    line-height: 0.26667rem;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    margin: 0.02667rem 0.05333rem;
    background-color: var(--gray-color-1);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionViolet[data-v-fdfc55f4] {
    color: #fff;
    background-color: var(--bgcolor-21);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionRed[data-v-fdfc55f4] {
    color: #fff;
    background-color: var(--norm_red-color);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionGreen[data-v-fdfc55f4] {
    color: #fff;
    background-color: var(--bgColor-13);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionRedGreen[data-v-fdfc55f4] {
    color: #fff;
    background-color: var(--norm_red-color);
    background-image: var(--linearGradien-21);
}

.GameRecord__C-body .details .detailLi .Bet-box .actionBtn[data-v-fdfc55f4] {
    height: 0.34667rem;
    line-height: 0.34667rem;
    display: inline-block;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    background-color: var(--norm_red-color);
    color: #fff;
}

.GameRecord__C-body .goItem[data-v-fdfc55f4] {
    height: 1.30667rem;
    line-height: 1.30667rem;
    text-align: center;
    color: var(--darkTextW, --main-color);
    font-size: 0.32rem;
}

.GameRecord__C-body .li[data-v-fdfc55f4] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
    width: 0.4rem;
    height: 0.4rem;
    border-radius: 50%;
    background: var(--walletBgColor-1);
    margin: 0 0.02667rem;
}

.GameRecord__C-body .li .circle-black[data-v-fdfc55f4] {
    background-color: var(--walletBgColor-1);
    color: var(--text_color_L1);
    font-size: 0.32rem;
}

.GameRecord__C-body .time[data-v-fdfc55f4] {
    color: var(--textM3, var(--text_color_L2));
    font-size: 0.32rem;
    height: 100%;
}

.GameRecord__C-body .numList[data-v-fdfc55f4] {
    width: 3rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    position: relative;
    top: 0.4rem;
}

.GameRecord__C-body .numList .numItem[data-v-fdfc55f4] {
    width: 0.4rem;
    height: 0.4rem;
    background: var(--walletBgColor-1);
    color: var(--text_color_L1);
    font-size: 0.32rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    border-radius: 50%;
}

.GameRecord__C-body .redNumItem[data-v-fdfc55f4] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot[data-v-fdfc55f4] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.GameRecord__C-foot-previous[data-v-fdfc55f4],
.GameRecord__C-foot-next[data-v-fdfc55f4] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot-previous.disabled[data-v-fdfc55f4],
.GameRecord__C-foot-next.disabled[data-v-fdfc55f4] {
    background: var(--gray-color-1);
    pointer-events: none;
}

.GameRecord__C-foot-previous.disabled .GameRecord__C-icon[data-v-fdfc55f4],
.GameRecord__C-foot-next.disabled .GameRecord__C-icon[data-v-fdfc55f4] {
    color: var(--saveTextColor-7);
}

.GameRecord__C-foot-previous .GameRecord__C-icon[data-v-fdfc55f4],
.GameRecord__C-foot-next .GameRecord__C-icon[data-v-fdfc55f4] {
    color: #fff;
}

.MyGameRecord__C[data-v-fdfc55f4] {
    width: 100%;
    margin: 0.32rem auto 1.6rem;
}

.MyGameRecord__C-head[data-v-fdfc55f4] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
    background-color: var(--darkBg, var(--bg_color_L2));
    padding: 0.32rem 0.32rem 0;
}

.MyGameRecord__C-head-moreB[data-v-fdfc55f4] {
    border: 0.01333rem solid var(--main-color);
    height: 0.8rem;
    line-height: 0.8rem;
    border-radius: 0.26667rem;
    padding: 0 0.72rem 0 0.24rem;
    color: var(--main-color);
    font-size: 0.32rem;
    position: relative;
    margin-bottom: 0.4rem;
}

.MyGameRecord__C-head-moreB[data-v-fdfc55f4]:after {
    content: "";
    display: block;
    width: 0.4rem;
    height: 0.4rem;
    position: absolute;
    top: 50%;
    right: 0.2rem;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    background-image: url(/assets/jpg/moreBtn-ffccf44d.jpg);
    background-repeat: no-repeat;
    background-size: 0.4rem;
    background-position: center;
}

html:lang(ar) .MyGameRecord__C-head-moreB[data-v-fdfc55f4]:after {
    left: 0.2rem;
    right: unset;
    -webkit-transform: scaleX(-1);
    transform: scaleX(-1);
    top: 25%;
}

.MyGameRecord__C-body[data-v-fdfc55f4] {
    padding: 0 0.32rem;
}

.MyGameRecord__C-body-empty[data-v-fdfc55f4] {
    height: 5.33333rem;
}

.MyGameRecord__C-foot[data-v-fdfc55f4] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecord__C-foot-page[data-v-fdfc55f4] {
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.MyGameRecord__C-foot-previous[data-v-fdfc55f4],
.MyGameRecord__C-foot-next[data-v-fdfc55f4] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.MyGameRecord__C-foot-previous.disabled[data-v-fdfc55f4],
.MyGameRecord__C-foot-next.disabled[data-v-fdfc55f4] {
    background: var(--gray-color-1);
    pointer-events: none;
}

.MyGameRecord__C-foot-previous.disabled .MyGameRecord__C-icon[data-v-fdfc55f4],
.MyGameRecord__C-foot-next.disabled .MyGameRecord__C-icon[data-v-fdfc55f4] {
    color: var(--saveTextColor-7);
}

.MyGameRecord__C-foot-previous .MyGameRecord__C-icon[data-v-fdfc55f4],
.MyGameRecord__C-foot-next .MyGameRecord__C-icon[data-v-fdfc55f4] {
    color: #fff;
}

.list[data-v-fdfc55f4] {
    padding: 0 0.26667rem;
}

.list .hb[data-v-fdfc55f4] {
    background-color: #fff;
    color: var(--colorText-3);
    font-size: 0.37333rem;
}

.list .hb .item[data-v-fdfc55f4] {
    padding: 0.21333rem;
    border-bottom: 0.02667rem solid var(--gray-color-1);
    color: var(--colorText-3);
    font-size: 0.37333rem;
}

.list .hb .item.action[data-v-fdfc55f4] {
    padding: 0.32rem 0.26667rem;
}

.list .hb .item .goItem[data-v-fdfc55f4] {
    height: 0.42667rem;
}

.list .hb .li[data-v-fdfc55f4] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
    width: 0.42667rem !important;
    height: 0.42667rem;
    border: 0.02667rem solid var(--gray-color-1);
    border-radius: 0.42667rem;
    margin-right: 0.10667rem;
    color: var(--gray-color-1);
}

.list .hb .li.action[data-v-fdfc55f4] {
    font-size: 0.32rem;
    border: none;
    color: #fff;
    background-color: var(--norm_red-color);
}

.list .hb .li.circle-black[data-v-fdfc55f4] {
    border: 0.02667rem solid var(--text_color_L1);
    color: var(--text_color_L1);
    background: var(--bgColor-6);
}

.list .hb .li.actionH[data-v-fdfc55f4] {
    border: none;
    color: #fff;
    background-color: var(--borderColor-4);
}

.list .hb .li.actionL[data-v-fdfc55f4] {
    border: 0.01333rem solid var(--borderColor-4);
    color: var(--borderColor-4);
    background-color: #fff;
}

.list .hb .li.actionO[data-v-fdfc55f4] {
    border: none;
    color: #fff;
    background-color: var(--norm_secondary-color);
}

.list .hb .li.actionE[data-v-fdfc55f4] {
    border: 0.01333rem solid var(--norm_secondary-color);
    color: var(--norm_secondary-color);
    background-color: #fff;
}

.list .hb .qiu[data-v-fdfc55f4] {
    width: 3rem;
    position: relative;
}

.list .hb .qiu .line-canvas[data-v-fdfc55f4] {
    position: absolute !important;
    top: 0.12rem;
    left: 0;
    height: 0.73333rem;
    width: 2.61333rem;
    z-index: 99;
}

html:lang(ar) .list .hb .qiu .line-canvas[data-v-fdfc55f4] {
    right: 0.12rem;
    left: unset;
}

.list .hb .red[data-v-fdfc55f4] {
    color: var(--colorText-2);
}

.list .hb .green[data-v-fdfc55f4] {
    color: var(--norm_green-color);
}

.list .hb .blue[data-v-fdfc55f4] {
    color: var(--colorText-7);
}

.list .hb .box .li[data-v-fdfc55f4] {
    display: block;
    height: 0.13333rem;
    width: 0.13333rem;
    border-radius: 0.13333rem;
    margin: 0 0.06667rem;
}

.list .hb .item[data-v-fdfc55f4] {
    padding: 0.53333rem 0.4rem;
}

.list .hb .item .info[data-v-fdfc55f4] {
    width: 100%;
}

.list .hb .item .info .issueName .state[data-v-fdfc55f4] {
    color: #fff;
    padding: 0.10667rem 0.26667rem;
    margin-left: 0.26667rem;
    border-radius: 0.53333rem;
    font-size: 0.32rem;
    display: inline-block;
    text-align: center;
}

.list .hb .item .info .issueName .state.red[data-v-fdfc55f4] {
    background-color: var(--norm_red-color);
}

.list .hb .item .info .issueName .state.green[data-v-fdfc55f4] {
    background-color: var(--norm_green-color);
}

.list .hb .item .info .tiem[data-v-fdfc55f4] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
    margin-top: 0.13333rem;
}

.list .hb .item .info .money[data-v-fdfc55f4] {
    font-weight: 600;
    font-size: 0.42667rem;
}

.list .hb .item .info .money .fail[data-v-fdfc55f4] {
    color: var(--norm_red-color);
}

.list .hb .item .info .money .success[data-v-fdfc55f4] {
    color: var(--bgColor-13);
}

.list .hb .details[data-v-fdfc55f4] {
    padding: 0.4rem;
    border-bottom: 0.01333rem solid var(--gray-color-1);
}

.list .hb .details .tit[data-v-fdfc55f4] {
    font-size: 0.4rem;
    color: var(--text_color_L1);
    margin-bottom: 0.26667rem;
    font-weight: 700;
}

.list .hb .details .tit img[data-v-fdfc55f4] {
    width: 0.64rem;
    height: 0.64rem;
    position: relative;
    top: 0.13333rem;
}

.list .hb .details .tag-read img[data-v-fdfc55f4] {
    width: 0.32rem;
    height: 0.32rem;
}

.list .hb .details .detailLi[data-v-fdfc55f4] {
    min-height: 0.66667rem;
    line-height: 0.66667rem;
    background: var(--bgColor-6);
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
    margin-bottom: 0.21333rem;
}

.list .hb .details .detailLi .red[data-v-fdfc55f4] {
    color: var(--main_gradient-color);
}

.list .hb .details .detailLi .result[data-v-fdfc55f4] {
    height: 0.93333rem;
    line-height: 0.93333rem;
    background: var(--main-color);
    border-radius: 0.13333rem 0.13333rem 0 0;
    color: #fff;
    text-align: left;
    padding: 0 --0.26667rem;
}

.list .hb .details .detailLi .prize-tit[data-v-fdfc55f4] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.list .hb .details .detailLi .prize-box[data-v-fdfc55f4] {
    border-bottom: 0.01333rem solid #fff;
}

.list .hb .details .detailLi .prize-box-item[data-v-fdfc55f4] {
    text-align: center;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.list .hb .details .detailLi .c-flex-warp[data-v-fdfc55f4] {
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.list .hb .details .detailLi .select[data-v-fdfc55f4] {
    margin-left: 0.53333rem;
}

.list .hb .details .detailLi .select .ball[data-v-fdfc55f4] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 0.64rem;
    height: 0.42667rem;
    line-height: 0.42667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-left: 0.13333rem;
    margin-bottom: 0.13333rem;
    background: var(--main-color);
    border-radius: 0.08rem;
    color: #fff;
}

.list .hb .details .detailLi .Bet-box.pb[data-v-fdfc55f4] {
    padding-bottom: 0.06667rem;
}

.list .hb .details .detailLi .Bet-box ul li[data-v-fdfc55f4] {
    height: 0.26667rem;
    line-height: 0.26667rem;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    margin: 0.02667rem 0.05333rem;
    background-color: var(--gray-color-1);
}

.list .hb .details .detailLi .Bet-box ul li.actionViolet[data-v-fdfc55f4] {
    color: #fff;
    background-color: var(--bgcolor-21);
}

.list .hb .details .detailLi .Bet-box ul li.actionRed[data-v-fdfc55f4] {
    color: #fff;
    background-color: var(--norm_red-color);
}

.list .hb .details .detailLi .Bet-box ul li.actionGreen[data-v-fdfc55f4] {
    color: #fff;
    background-color: var(--bgColor-13);
}

.list .hb .details .detailLi .Bet-box ul li.actionRedGreen[data-v-fdfc55f4] {
    color: #fff;
    background-color: var(--norm_red-color);
    background-image: var(--linearGradien-21);
}

.list .hb .details .detailLi .Bet-box .actionBtn[data-v-fdfc55f4] {
    height: 0.34667rem;
    line-height: 0.34667rem;
    display: inline-block;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    background-color: var(--norm_red-color);
    color: #fff;
}

.areList[data-v-fdfc55f4] {
    margin: 0.53333rem;
    position: relative;
}

.areList .close[data-v-fdfc55f4] {
    position: absolute;
    top: -1.6rem;
    left: 50%;
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
    width: 0.8rem;
    height: 0.8rem;
}

.areList .items h1[data-v-fdfc55f4] {
    color: var(--darkTextW, var(--borderColor-26));
    font-size: 0.42667rem;
}

.areList .items .itemsC[data-v-fdfc55f4] {
    margin: 0.26667rem 0 0.4rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    gap: 0.2rem;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.areList .items .itemsC>div[data-v-fdfc55f4] {
    width: calc((100% - 0.53333rem) / 2);
    background: var(--bgDark-3, var(--homeActiveBgColor));
    border-radius: 0.13333rem;
    min-height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
}

.areList .items .itemsC .isActive[data-v-fdfc55f4] {
    background: var(--norm_red-color);
    color: #fff;
}

.titlebets[data-v-fdfc55f4] {
    font-size: 0.29333rem;
    color: var(--main-color);
}

.border60[data-v-fdfc55f4] {
    width: 4.53333rem;
    height: 0.66667rem;
    line-height: 0.66667rem;
    border-radius: 0.8rem;
    border: 0.01333rem solid var(--main-color);
    margin: 0 auto;
    margin-top: 0.30667rem;
}

.bottombg[data-v-fdfc55f4] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/arrowbottom-4eb91cbc.png);
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center;
}

.compound2[data-v-fdfc55f4],
.compound3[data-v-fdfc55f4] {
    padding-top: 0.26667rem;
    max-height: 5.33333rem;
    overflow-y: auto;
}

.compound2 .item[data-v-fdfc55f4],
.compound3 .item[data-v-fdfc55f4] {
    width: 100%;
    margin-bottom: 0.26667rem;
}

.compound2 .item.item0-3 .box .c-row[data-v-fdfc55f4],
.compound3 .item.item0-3 .box .c-row[data-v-fdfc55f4] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.21333rem;
}

.compound2 .item.item0-3 .box .num[data-v-fdfc55f4],
.compound3 .item.item0-3 .box .num[data-v-fdfc55f4] {
    width: calc((100% - 1.28rem) / 7);
    height: 1.13333rem;
    background-size: 1.13333rem 1.13333rem;
}

.compound2 .item.item0-2 .box .c-row[data-v-fdfc55f4],
.compound2 .item.item5-2 .box .c-row[data-v-fdfc55f4],
.compound3 .item.item0-2 .box .c-row[data-v-fdfc55f4],
.compound3 .item.item5-2 .box .c-row[data-v-fdfc55f4] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.21333rem;
}

.compound2 .item.item0-2 .box .num[data-v-fdfc55f4],
.compound2 .item.item5-2 .box .num[data-v-fdfc55f4],
.compound3 .item.item0-2 .box .num[data-v-fdfc55f4],
.compound3 .item.item5-2 .box .num[data-v-fdfc55f4] {
    width: calc((100% - 1.28rem) / 7);
    height: 0.8rem;
    background-size: 0.8rem 0.8rem;
}

.compound2 .item.item4-2 .box .c-row[data-v-fdfc55f4],
.compound3 .item.item4-2 .box .c-row[data-v-fdfc55f4] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item4-2 .box .num[data-v-fdfc55f4],
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-8),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-7),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-6),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-5),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-4),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-2),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-1),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-8),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-7),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-5),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-4),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-2),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-1),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
}

.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-7),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-6),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-4),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-1),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-7),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-4),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-1),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n) {
    margin-left: -0.10667rem;
}

.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-fdfc55f4]:nth-child(9n-6) {
    margin-right: 0.42667rem;
}

.compound2 .item.item3-2 .box .c-row[data-v-fdfc55f4],
.compound3 .item.item3-2 .box .c-row[data-v-fdfc55f4] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item3-2 .box .num[data-v-fdfc55f4],
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-1),
.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-2),
.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-3),
.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-4),
.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-5),
.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-6),
.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-7),
.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-1),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-2),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-3),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-5),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-6),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-7),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
}

.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-6),
.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-5),
.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-4),
.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-2),
.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-1),
.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-6),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-5),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-2),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-1),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n) {
    margin-left: -0.06667rem;
}

.compound2 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-fdfc55f4]:nth-child(8n-4) {
    margin-right: 1.73333rem;
}

.compound2 .item.item2-2 .box .c-row[data-v-fdfc55f4],
.compound3 .item.item2-2 .box .c-row[data-v-fdfc55f4] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item2-2 .box .num[data-v-fdfc55f4],
.compound3 .item.item2-2 .box .num[data-v-fdfc55f4] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-1),
.compound2 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-2),
.compound2 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-3),
.compound2 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-4),
.compound2 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-5),
.compound2 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-6),
.compound2 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-7),
.compound2 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n),
.compound3 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-1),
.compound3 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-2),
.compound3 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-3),
.compound3 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-4),
.compound3 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-5),
.compound3 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-6),
.compound3 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n-7),
.compound3 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
    margin-left: -0.01333rem;
}

.compound2 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n),
.compound3 .item.item2-2 .box .num[data-v-fdfc55f4]:nth-child(8n) {
    margin-right: 1.33333rem;
}

.compound2 .item.item1-2 .box .c-row[data-v-fdfc55f4],
.compound3 .item.item1-2 .box .c-row[data-v-fdfc55f4] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item1-2 .box .num[data-v-fdfc55f4],
.compound3 .item.item1-2 .box .num[data-v-fdfc55f4] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-1),
.compound2 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-2),
.compound2 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-3),
.compound2 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-4),
.compound2 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-5),
.compound2 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-6),
.compound2 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-7),
.compound2 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-8),
.compound2 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-9),
.compound2 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n),
.compound3 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-1),
.compound3 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-2),
.compound3 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-3),
.compound3 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-4),
.compound3 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-5),
.compound3 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-6),
.compound3 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-7),
.compound3 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-8),
.compound3 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n-9),
.compound3 .item.item1-2 .box .num[data-v-fdfc55f4]:nth-child(10n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
    margin-left: -0.09333rem;
}

.compound2 .item .box[data-v-fdfc55f4],
.compound3 .item .box[data-v-fdfc55f4] {
    border-radius: 0.26667rem;
    position: relative;
    width: 100%;
}

.compound2 .item .box .num[data-v-fdfc55f4],
.compound3 .item .box .num[data-v-fdfc55f4] {
    min-width: 0.8rem;
    min-height: 0.8rem;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: 0.8rem 0.8rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
}

.compound2 .item .box .money[data-v-fdfc55f4],
.compound3 .item .box .money[data-v-fdfc55f4] {
    text-align: center;
    background-color: var(--gray-color-1);
    position: relative;
    height: 0.53333rem;
    border-radius: 0 0 0.26667rem 0.26667rem;
}

.compound2 .item .box .money .all[data-v-fdfc55f4],
.compound3 .item .box .money .all[data-v-fdfc55f4] {
    position: relative;
    z-index: 9;
    line-height: 0.8rem;
    font-size: 0.32rem;
    color: #00AF54;
}

.compound2 .item .box .money[data-v-fdfc55f4]:after,
.compound3 .item .box .money[data-v-fdfc55f4]:after {
    position: absolute;
    top: 0;
    left: 0;
    content: "";
    display: block;
    width: 100%;
    height: 0.21333rem;
    background-color: var(--gray-color-1);
    border-radius: 0 0 50% 50%;
}

.compound2 .item .box .dele[data-v-fdfc55f4],
.compound3 .item .box .dele[data-v-fdfc55f4] {
    position: absolute;
    right: -0.18667rem;
    top: -0.18667rem;
    height: 0.37333rem;
    width: 0.37333rem;
    border-radius: 0.53333rem;
    background-color: #00AF54;
}

.compound2 .item .box .dele .icon[data-v-fdfc55f4],
.compound3 .item .box .dele .icon[data-v-fdfc55f4] {
    font-size: 0.26667rem;
}

.compound2 .item.item0-4 .box .c-row[data-v-fdfc55f4] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.53333rem;
}

.compound2 .item.item0-4 .box .num[data-v-fdfc55f4] {
    width: calc((100% - 2.13333rem) / 5);
    background: var(--main_gradient-color);
    color: #fff;
    border-radius: 0.13333rem;
    min-height: 1.06667rem;
    min-width: 1.33333rem;
}

.compound[data-v-fdfc55f4] {
    padding-top: 0.26667rem;
    max-height: 6rem;
    overflow: auto;
}

.compound .item[data-v-fdfc55f4] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 100%;
    margin-bottom: 0.4rem;
}

.compound .item .title[data-v-fdfc55f4] {
    width: 1.38667rem;
    overflow: hidden;
    position: relative;
    text-align: center;
    font-size: 0.42667rem;
    color: var(--text_color_L2);
}

.compound .item .numcontainer[data-v-fdfc55f4] {
    width: 7.94667rem;
    margin-left: 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    justify-content: flex-start;
    gap: 0.13333rem;
}

.compound .item .numcontainer .num[data-v-fdfc55f4] {
    width: calc((100% - 0.85333rem) / 5);
    height: 0.8rem;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: 0.8rem 0.8rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
    position: relative;
    text-align: center;
    line-height: 0.8rem;
}

.compound .item .numcontainer .num .dele[data-v-fdfc55f4] {
    position: absolute;
    right: -0.18667rem;
    top: -0.18667rem;
    height: 0.37333rem;
    width: 0.37333rem;
    border-radius: 0.53333rem;
    background-color: #00AF54;
}

html:lang(ar) .compound .item .numcontainer .num .dele[data-v-fdfc55f4] {
    right: unset;
    left: -0.18667rem;
}

.compound .item .numcontainer .num .dele .icon[data-v-fdfc55f4] {
    font-size: 0.26667rem;
}

.van-toast[data-v-68c3df62] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-68c3df62] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-68c3df62] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-68c3df62] {
    height: 80%;
}

.NewVietnam__C[data-v-68c3df62] {
    padding-bottom: 0.34667rem;
    overflow-y: auto;
    background-color: var(--bgDark-4, var(--bg_color_L1));
}

.NewVietnam__C-head[data-v-68c3df62] {
    height: 1.25333rem;
    background: var(--main_gradient-color);
    padding: 0 0.34667rem;
    position: relative;
}

.NewVietnam__C-head div[data-v-68c3df62] {
    background-repeat: no-repeat;
    background-position: center;
}

.NewVietnam__C-head-bcak[data-v-68c3df62] {
    position: absolute;
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/bcakIcon-b7c1d288.png);
    background-size: 0.64rem;
    left: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
}

html:lang(ar) .NewVietnam__C-head-bcak[data-v-68c3df62] {
    left: unset;
    right: 0.34667rem;
}

.NewVietnam__C-head-logo[data-v-68c3df62] {
    background-size: 2.98667rem 1.12rem;
    height: 1.12rem;
    width: 2.98667rem;
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
}

.NewVietnam__C-head-more[data-v-68c3df62] {
    position: absolute;
    width: 1.54667rem;
    height: 0.64rem;
    right: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

html:lang(ar) .NewVietnam__C-head-more[data-v-68c3df62] {
    right: unset;
    left: 0.34667rem;
}

.NewVietnam__C-head-more>div[data-v-68c3df62] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/kefu-b361c42f.png);
    background-size: 0.64rem;
}

.NewVietnam__C-head-more>div[data-v-68c3df62]:last-child {
    background-image: url(/assets/png/voice-62dbf38c.png);
}

.NewVietnam__C-head-more>div:last-child.disableVoice[data-v-68c3df62] {
    background-image: url(/assets/png/voice-off-633f5ccc.png);
}

.NewVietnam__C[data-v-68c3df62] .driver-close-btn,
.NewVietnam__C[data-v-68c3df62] .driver-prev-btn {
    display: none;
}

.popup[data-v-68c3df62] {
    overflow-y: visible !important;
    border-radius: 0.13333rem 0.13333rem 0 0;
    width: 100%;
}

.popup[data-v-68c3df62] .van-popup {
    overflow-y: visible !important;
    border-radius: 0.26667rem 0.26667rem 0 0;
}

.popup .box[data-v-68c3df62] {
    position: relative;
}

.popup .box .close[data-v-68c3df62] {
    position: absolute;
    top: -1.06667rem;
    left: 50%;
    -webkit-transform: translate(-50%, 0);
    transform: translate(-50%);
}

.popup .box .close .img[data-v-68c3df62] {
    width: 0.8rem;
    height: 0.8rem;
}

.popup .box .title[data-v-68c3df62] {
    font-size: 0.42667rem;
    color: var(--text_color_L1);
}

.popup .box .numList[data-v-68c3df62] {
    max-height: 5.33333rem;
    overflow-x: auto;
}

.popup .box .numList .item[data-v-68c3df62] {
    width: 1.06667rem;
    height: 1.06667rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
    margin: 0 0.13333rem;
}

.popup-info-item[data-v-68c3df62] {
    height: 0.8rem;
    line-height: 0.8rem;
    margin-top: 0.26667rem;
}

.popup-info-item .tit[data-v-68c3df62] {
    font-size: 0.37333rem;
    color: var(--text_color_L2);
}

.popup-info-item .amount-box .li[data-v-68c3df62],
.popup-info-item .multiple-box .li[data-v-68c3df62] {
    text-align: center;
    font-size: 0.32rem;
    padding: 0 0.13333rem;
    height: 0.8rem;
    line-height: 0.8rem;
    min-width: 1.33333rem;
    margin-left: 0.13333rem;
    border: 0.01333rem solid var(--gray-color-1);
    border-radius: 0.13333rem;
    color: #00AF54;
}

.popup-info-item .amount-box .li.action[data-v-68c3df62],
.popup-info-item .multiple-box .li.action[data-v-68c3df62] {
    border: none;
    color: #fff;
    background: var(--main_gradient-color);
}

.popup-info-item .multiple-box .li[data-v-68c3df62] {
    padding: 0 0.26667rem;
    min-width: auto;
}

.popup-info-item .stepper-box .digit-box[data-v-68c3df62] {
    width: 2.66667rem;
    height: 0.8rem;
    border-radius: 0.8rem;
    padding: 0;
    margin: 0 0.13333rem;
    background-color: var(--walletBgColor-1);
}

.popup-info-item .stepper-box .digit-box[data-v-68c3df62] .van-field__control {
    height: 0.74667rem;
    text-align: center;
}

.popup-info-item .stepper-box .li[data-v-68c3df62] {
    height: 0.8rem;
    width: 0.8rem;
    font-size: 0.8rem;
    border-radius: 50%;
    background-color: var(--main-color);
    color: #fff;
}

.popup-info-item .stepper-box .li.minus[data-v-68c3df62] {
    text-align: center;
    line-height: 0.66667rem;
}

.popup-info-item .txt[data-v-68c3df62] {
    color: #00AF54;
}

.popup-info .quantity[data-v-68c3df62] {
    margin-top: 0.26667rem;
    padding: 0 0.21333rem;
    height: 1.17333rem;
    background-color: var(--bgDark-2, var(--homeActiveBgColor));
    border-radius: 0.13333rem;
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.popup-info .quantity .line[data-v-68c3df62] {
    padding: 0 0.13333rem;
    color: var(--text_color_L2);
}

.popup-info .quantity .num[data-v-68c3df62] {
    color: #00AF54;
    font-size: 0.4rem;
}

.popup-info .wallet[data-v-68c3df62],
.popup-info .balance[data-v-68c3df62] {
    padding: 0 0.21333rem;
    margin-top: 0.26667rem;
    height: 0.8rem;
    background-color: var(--bgDark-2, var(--homeActiveBgColor));
}

.popup-info .wallet .txt[data-v-68c3df62],
.popup-info .balance .txt[data-v-68c3df62] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.popup-info .wallet .txt img[data-v-68c3df62],
.popup-info .balance .txt img[data-v-68c3df62] {
    width: 0.4rem;
    height: 0.4rem;
    margin-right: 0.13333rem;
}

.popup-info .wallet .txt .num[data-v-68c3df62],
.popup-info .balance .txt .num[data-v-68c3df62] {
    font-size: 0.37333rem;
    color: var(--text_color_L1);
    padding-left: 0.26667rem;
}

.popup-info .wallet .txt .num.yellow[data-v-68c3df62],
.popup-info .balance .txt .num.yellow[data-v-68c3df62] {
    color: var(--norm_secondary-color);
}

.popup-info .wallet .bg333[data-v-68c3df62],
.popup-info .balance .bg333[data-v-68c3df62] {
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.popup-info .wallet .bg7172[data-v-68c3df62],
.popup-info .balance .bg7172[data-v-68c3df62] {
    font-size: 0.32rem;
    color: var(--main-color);
}

.popup-info .wallet .bet[data-v-68c3df62],
.popup-info .balance .bet[data-v-68c3df62] {
    border: 0.01333rem solid #00AF54;
    border-radius: 0.13333rem;
    height: 0.64rem;
    line-height: 0.64rem;
    color: #00AF54;
    padding: 0 0.26667rem;
}

.popup-btn[data-v-68c3df62] {
    height: 1.6rem;
}

.popup-btn .left[data-v-68c3df62] {
    width: 45%;
}

.popup-btn .left .btn[data-v-68c3df62] {
    height: 1.6rem;
    font-size: 0.42667rem;
    border-radius: 0;
    color: var(--text_color_L2);
    background-color: #00AF54;
}

.popup-btn .right[data-v-68c3df62] {
    width: 55%;
}

.popup-btn .right .btn[data-v-68c3df62] {
    height: 1.6rem;
    font-size: 0.42667rem;
    border-radius: 0;
    color: #fff;
    background-color: #00AF54;
}

.popup-btn .right .noActive[data-v-68c3df62] {
    background-color: #00AF54;
    color: var(--text_color_L2);
}

.PreSaleRule[data-v-68c3df62] {
    width: 7.04rem;
}

.PreSaleRule .head[data-v-68c3df62] {
    height: 1.2rem;
    line-height: 1.2rem;
    color: #fff;
    font-size: 0.4rem;
    text-align: center;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: left center;
    background-image: url(/assets/png/wingoPreSaleBg-6566ea95.png);
}

.PreSaleRule .body[data-v-68c3df62] {
    max-height: 8rem;
    overflow-y: auto;
    padding: 0.4rem;
    font-size: 0.32rem;
    line-height: 0.8rem;
}

.PreSaleRule .body[data-v-68c3df62] p {
    margin-bottom: 0.2rem;
    line-height: 0.53333rem;
}

.PreSaleRule .foot[data-v-68c3df62] {
    height: 1.86667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.PreSaleRule .foot .btn[data-v-68c3df62] {
    width: 60%;
    background: var(--main_gradient-color);
    border-radius: 0.53333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    font-size: 0.37333rem;
    color: #fff;
}

.Tips[data-v-68c3df62] {
    width: 8rem;
    height: 2.13333rem;
    line-height: 2.13333rem;
    background: var(--bg_color_L2);
    border: 0.01333rem solid var(--borderColor-5);
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.Tips>div[data-v-68c3df62] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    overflow-y: hidden;
}

.Tips>div img[data-v-68c3df62] {
    width: 1.17333rem;
    height: 1.17333rem;
    margin-top: 0.45333rem;
}

.Tips>div .font36[data-v-68c3df62] {
    color: var(--text_color_L1);
    font-weight: 700;
    font-size: 0.48rem;
    margin-left: 0.32rem;
}

.GameList__C-region[data-v-68c3df62] {
    height: 1.2rem;
    line-height: 1.2rem;
    overflow: hidden;
    padding: 0 0.26667rem;
    margin: 0.26667rem 0;
}

.GameList__C-region .item[data-v-68c3df62] {
    width: calc(33.3% - 0.53333rem);
    position: relative;
    text-align: center;
    font-size: 0.48rem;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

.GameList__C-region .item[data-v-68c3df62]:nth-child(1) {
    background: var(--bg_color_L2);
    border-radius: 0.13333rem 0 0 0.13333rem;
}

.GameList__C-region .item[data-v-68c3df62]:nth-child(1):after {
    position: absolute;
    top: 0;
    right: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-bottom: 1.2rem solid #fff;
    border-right: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

.GameList__C-region .item[data-v-68c3df62]:nth-child(2) {
    background: var(--bg_color_L2);
}

.GameList__C-region .item[data-v-68c3df62]:nth-child(2):after {
    position: absolute;
    top: 0;
    right: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-top: 1.2rem solid #fff;
    border-right: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-68c3df62]:nth-child(2):after {
    left: -0.66667rem;
    right: unset;
}

.GameList__C-region .item[data-v-68c3df62]:nth-child(2):before {
    position: absolute;
    top: 0;
    left: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-top: 1.2rem solid #fff;
    border-left: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-68c3df62]:nth-child(2):before {
    right: -0.66667rem;
    left: unset;
}

.GameList__C-region .item[data-v-68c3df62]:nth-child(3) {
    background: var(--bg_color_L2);
    border-radius: 0 0.13333rem 0.13333rem 0;
}

.GameList__C-region .item[data-v-68c3df62]:nth-child(3):before {
    position: absolute;
    top: 0;
    left: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-bottom: 1.2rem solid #fff;
    border-left: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-68c3df62]:nth-child(3):before {
    right: -0.66667rem;
    left: unset;
}

.GameList__C-region .item.action[data-v-68c3df62] {
    color: #fff;
}

.GameList__C-region .item.action[data-v-68c3df62]:nth-child(1) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-68c3df62]:nth-child(1):after {
    border-bottom: 1.2rem solid var(--borderColor-5);
}

.GameList__C-region .item.action[data-v-68c3df62]:nth-child(2) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-68c3df62]:nth-child(2):after {
    border-top: 1.2rem solid var(--borderColor-5);
}

.GameList__C-region .item.action[data-v-68c3df62]:nth-child(2):before {
    border-top: 1.2rem solid #00AF54;
}

.GameList__C-region .item.action[data-v-68c3df62]:nth-child(3) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-68c3df62]:nth-child(3):before {
    border-bottom: 1.2rem solid #00AF54;
}

.GameList__C-time[data-v-68c3df62] {
    padding-left: 0.2rem;
    overflow-y: auto;
    height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameList__C-time .item[data-v-68c3df62] {
    position: relative;
    white-space: nowrap;
    background-color: #fff;
    margin: 0 0.10667rem;
    padding: 0.04rem 0.16rem 0;
    text-align: center;
    border-radius: 0.13333rem 0.13333rem 0 0;
}

.GameList__C-time .item .week[data-v-68c3df62] {
    font-size: 0.16rem;
    color: var(--text_color_L1);
}

.GameList__C-time .item .time[data-v-68c3df62] {
    font-size: 0.16rem;
    color: var(--text_color_L2);
}

.GameList__C-time .item[data-v-68c3df62]:after,
.GameList__C-time .item[data-v-68c3df62]:before {
    content: "";
    width: 0.4rem;
    height: 0.4rem;
    position: absolute;
    bottom: 0;
    z-index: 9;
}

.GameList__C-time .item[data-v-68c3df62]:after {
    background: -webkit-radial-gradient( 100% 0, circle, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    background: radial-gradient( circle at 100% 0, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    right: -0.4rem;
}

html:lang(ar) .GameList__C-time .item[data-v-68c3df62]:after {
    left: -0.4rem;
    right: unset;
}

.GameList__C-time .item[data-v-68c3df62]:before {
    background: -webkit-radial-gradient( 0 0, circle, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    background: radial-gradient( circle at 0 0, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    left: -0.4rem;
}

html:lang(ar) .GameList__C-time .item[data-v-68c3df62]:before {
    right: -0.4rem;
    left: unset;
}

.GameList__C-time .item.active[data-v-68c3df62] {
    background-color: var(--main-color);
    color: #fff;
    z-index: 10;
}

.GameList__C-time .item.active .week[data-v-68c3df62],
.GameList__C-time .item.active .time[data-v-68c3df62] {
    color: #fff;
}

.GameList__C-time .item.active[data-v-68c3df62]:before {
    background: -webkit-radial-gradient( 0 0, circle, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    background: radial-gradient( circle at 0 0, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    left: -0.4rem;
    z-index: 10;
}

html:lang(ar) .GameList__C-time .item.active[data-v-68c3df62]:before {
    right: -0.4rem;
    left: unset;
}

.GameList__C-time .item.active[data-v-68c3df62]:after {
    background: -webkit-radial-gradient( 100% 0, circle, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    background: radial-gradient( circle at 100% 0, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    right: -0.4rem;
    z-index: 10;
}

html:lang(ar) .GameList__C-time .item.active[data-v-68c3df62]:after {
    left: -0.4rem;
    right: unset;
}

.GameList__C-city[data-v-68c3df62] {
    border-top: 0.02667rem solid #fff;
    overflow-y: auto;
    height: 0.6rem;
    height: 1.17333rem;
    background-color: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameList__C-city .item[data-v-68c3df62] {
    height: 0.93333rem;
    line-height: 0.93333rem;
    white-space: nowrap;
    margin: 0.08rem 0.10667rem;
    padding: 0 0.10667rem;
    text-align: center;
    color: #fff;
}

.GameList__C-city .item.action[data-v-68c3df62] {
    background-color: #fff;
    color: var(--main-color);
    border-radius: 0.06667rem;
}

.GameList__C-bet[data-v-68c3df62] {
    width: 100%;
    margin-top: 0.2rem;
    padding: 0 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 1.06667rem;
    overflow-x: scroll;
}

.GameList__C-bet ul[data-v-68c3df62] {
    margin: 0;
    padding: 0;
    list-style: none;
    -webkit-flex-wrap: nowrap;
    flex-wrap: nowrap;
    white-space: nowrap;
}

.GameList__C-bet .item[data-v-68c3df62] {
    -webkit-box-flex: 0;
    -webkit-flex: 0 0 auto;
    flex: 0 0 auto;
    height: 0.93333rem;
    padding: 0.25333rem 0.88rem;
    background: var(--bg_color_L2);
    border-radius: 0.16rem;
    margin-right: 0.32rem;
    color: var(--text_color_L2);
}

.GameList__C-bet .item.action[data-v-68c3df62] {
    color: #fff;
    background: var(--main_gradient-color2);
}

.Betting__C-mark[data-v-68c3df62] {
    width: 100%;
    height: 100%;
    background: var(--bgcolor-32);
    position: fixed;
    z-index: 99;
    top: 0;
    left: 0;
    color: #fff;
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

html:lang(ar) .Betting__C-mark[data-v-68c3df62] {
    right: 0;
    left: unset;
    direction: ltr;
}

.Betting__C-mark>div[data-v-68c3df62] {
    width: 5.86667rem;
    height: 1.33333rem;
    line-height: 1.33333rem;
    display: inline-block;
    border-radius: 0.26667rem;
    border: 0.01333rem solid #fff;
    font-size: 0.42667rem;
    color: #fff;
    font-weight: 700;
    padding: 0 0.4rem 0 2.08rem;
}

.Betting__C-bet[data-v-68c3df62] {
    margin-top: 0.4rem;
    padding: 0 0.26667rem;
}

.Betting__C-bet .tit[data-v-68c3df62] {
    height: 0.53333rem;
    line-height: 0.53333rem;
}

.Betting__C-bet .tit-select[data-v-68c3df62] {
    padding-left: 0.26667rem;
    font-size: 0.42667rem;
    font-weight: 700;
    border-left: 0.08rem solid var(--main-color);
}

.Betting__C-bet .tit-list .check[data-v-68c3df62] {
    padding-left: 0.26667rem;
    color: var(--text_color_L2);
}

.Betting__C-bet .tit-list .check-item[data-v-68c3df62] {
    height: 0.42667rem;
    width: 0.42667rem;
    border-radius: 0.42667rem;
    border: 0.02667rem solid #c9c9c9;
    margin-right: 0.10667rem;
}

.Betting__C-bet .tit-list .check.action[data-v-68c3df62] {
    color: #00AF54;
}

.Betting__C-bet .tit-list .check.action .check-item[data-v-68c3df62] {
    border: 0.01333rem solid #00AF54;
    position: relative;
}

.Betting__C-bet .tit-list .check.action .check-item[data-v-68c3df62]:after {
    content: "";
    display: block;
    border-radius: 0.26667rem;
    background-color: #00AF54;
    width: 0.26667rem;
    height: 0.26667rem;
    position: absolute;
    left: 0.05333rem;
    top: 0.05333rem;
}

html:lang(ar) .Betting__C-bet .tit-list .check.action .check-item[data-v-68c3df62]:after {
    right: 0.05333rem;
    left: unset;
}

.Betting__C-bet .nList[data-v-68c3df62] {
    background: var(--bg_color_L2);
    border-radius: 0.32rem;
    padding: 0.26667rem;
    margin-top: 0.4rem;
}

.Betting__C-bet .nList .Ntit[data-v-68c3df62] {
    line-height: 0.74667rem;
    font-size: 0.42667rem;
    color: var(--text_color_L3);
    font-weight: 400;
}

.Betting__C-bet .nList .list[data-v-68c3df62] {
    width: 100%;
}

.Betting__C-bet .nList .list .item[data-v-68c3df62] {
    width: 20%;
}

.Betting__C-bet .nList .list .item .number[data-v-68c3df62] {
    width: 1.06667rem;
    height: 1.06667rem;
    font-size: 0.42667rem;
    font-weight: 700;
    color: var(--text_color_L2);
    background: url(/assets/svg/nbg-dba06970.svg) no-repeat center center;
    background-size: cover;
}

.Betting__C-bet .nList .list .item .number.action[data-v-68c3df62] {
    color: #00AF54;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
}

.Footer__C[data-v-68c3df62] {
    width: 100%;
    position: fixed;
    left: auto;
    bottom: 0;
    height: 1.6rem;
    z-index: 98;
}

.Footer__C .nav[data-v-68c3df62] {
    height: 1.6rem;
    background-color: #fee;
    max-width: 10rem;
}

.Footer__C .nav .left[data-v-68c3df62] {
    width: 55%;
}

.Footer__C .nav .left .item[data-v-68c3df62] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    padding-left: 0.26667rem;
    color: var(--main-color);
}

.Footer__C .nav .left .item .txt[data-v-68c3df62] {
    margin-bottom: 0.08rem;
}

.Footer__C .nav .left .item .num[data-v-68c3df62] {
    color: #00AF54;
    font-weight: 600;
}

.Footer__C .bet-btn[data-v-68c3df62] {
    width: 40%;
    background-color: #00AF54;
    color: #fff;
    font-size: 0.48rem;
    font-weight: 600;
}

.Footer__C .disabled-btn[data-v-68c3df62] {
    width: 40%;
    background-color: var(--button_dis_color);
    color: var(--text_color_L2);
    font-size: 0.48rem;
    font-weight: 400;
    pointer-events: none;
}

.RecordNav__C[data-v-68c3df62] {
    width: calc(100% - 0.64rem);
    height: 1.17333rem;
    line-height: 1.17333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    margin: 0.32rem auto 0;
    border-radius: 0.16rem;
    overflow: hidden;
}

.RecordNav__C>div[data-v-68c3df62] {
    width: 50%;
    height: 100%;
    background: var(--bgDark-3, var(--bg_color_L2));
    font-size: 0.42667rem;
    color: var(--text_color_L2);
    text-align: center;
    overflow: hidden;
}

.RecordNav__C>div.active[data-v-68c3df62] {
    background: var(--dark-linerGradien-91, var(--main_gradient-color2));
    font-weight: 600;
    color: #fff;
}

.GameRecord__C[data-v-68c3df62] {
    width: calc(100% - 0.69333rem);
    margin: 0.26667rem auto 1.6rem;
    text-align: center;
    font-size: 0.32rem;
}

.GameRecord__C-head[data-v-68c3df62] {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--bgDark-2, var(--main-color));
    border-radius: 0.13333rem 0.13333rem 0 0;
    font-weight: 600;
    font-size: 0.37333rem;
    color: #fff;
}

.GameRecord__C-body[data-v-68c3df62] {
    color: var(--text_color_L1);
    font-size: 0.32rem;
    background: var(--darkBg, var(--bg_color_L1));
    border-radius: 0 0 0.13333rem 0.13333rem;
}

.GameRecord__C-body[data-v-68c3df62] .van-row {
    min-height: 1.30667rem;
    border-bottom: 0.01333rem solid var(--bgDark-2, var(--saveTextColor-3));
}

.GameRecord__C-body .details[data-v-68c3df62] {
    width: 100%;
    border: 0.01333rem solid var(--borderColor-5);
    border-radius: 0.26667rem;
    padding: 0.33333rem;
}

.GameRecord__C-body .details .tit[data-v-68c3df62] {
    font-size: 0.4rem;
    color: var(--text_color_L1);
    margin-bottom: 0.26667rem;
    font-weight: 700;
}

.GameRecord__C-body .details .tit img[data-v-68c3df62] {
    width: 0.64rem;
    height: 0.64rem;
    position: relative;
    top: 0.13333rem;
}

.GameRecord__C-body .details .tag-read img[data-v-68c3df62] {
    width: 0.32rem;
    height: 0.32rem;
}

.GameRecord__C-body .details .detailLi[data-v-68c3df62] {
    min-height: 0.66667rem;
    line-height: 0.66667rem;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
}

.GameRecord__C-body .details .detailLi .red[data-v-68c3df62] {
    color: var(--main_gradient-color);
}

.GameRecord__C-body .details .detailLi .prize[data-v-68c3df62] {
    background: var(--bgDark-4, --walletBgColor-1);
    margin-bottom: 0.16rem;
    padding: 0.26667rem;
    border-radius: 0.26667rem;
}

.GameRecord__C-body .details .detailLi .prize[data-v-68c3df62]:last-child {
    margin-bottom: 0;
}

.GameRecord__C-body .details .detailLi .selectItem0[data-v-68c3df62],
.GameRecord__C-body .details .detailLi .selectItem1[data-v-68c3df62],
.GameRecord__C-body .details .detailLi .selectItem2[data-v-68c3df62] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameRecord__C-body .details .detailLi .selectItem0>div[data-v-68c3df62]:nth-of-type(1),
.GameRecord__C-body .details .detailLi .selectItem1>div[data-v-68c3df62]:nth-of-type(1),
.GameRecord__C-body .details .detailLi .selectItem2>div[data-v-68c3df62]:nth-of-type(1) {
    width: 45%;
}

.GameRecord__C-body .details .detailLi .selectItem0>div[data-v-68c3df62]:nth-of-type(2),
.GameRecord__C-body .details .detailLi .selectItem1>div[data-v-68c3df62]:nth-of-type(2),
.GameRecord__C-body .details .detailLi .selectItem2>div[data-v-68c3df62]:nth-of-type(2) {
    width: 0.13333rem;
}

.GameRecord__C-body .details .detailLi .selectItem0 span[data-v-68c3df62],
.GameRecord__C-body .details .detailLi .selectItem1 span[data-v-68c3df62],
.GameRecord__C-body .details .detailLi .selectItem2 span[data-v-68c3df62] {
    font-weight: 700;
    font-size: 0.42667rem;
    color: var(--darkTextW, --text_color_L1);
    padding-left: 0;
    text-align: center;
}

.GameRecord__C-body .details .detailLi .selectItem0 span[data-v-68c3df62] {
    color: #00AF54;
}

.GameRecord__C-body .details .detailLi .prize-tit[data-v-68c3df62] {
    text-align: left;
    font-size: 0.37333rem;
    color: var(--darkTextW, --text_color_L1);
    padding-left: 0.26667rem;
}

.GameRecord__C-body .details .detailLi .action0[data-v-68c3df62] {
    color: #00AF54 !important;
    font-weight: 700;
    font-size: 0.42667rem;
}

.GameRecord__C-body .details .detailLi .action1[data-v-68c3df62],
.GameRecord__C-body .details .detailLi .action2[data-v-68c3df62] {
    font-weight: 700;
    font-size: 0.42667rem;
}

.GameRecord__C-body .details .detailLi .prize-box[data-v-68c3df62] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
}

.GameRecord__C-body .details .detailLi .prize-box-item[data-v-68c3df62] {
    text-align: left;
    padding-left: 0.26667rem;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: var(--text_color_L1);
    font-size: 0.37333rem;
    font-weight: 500;
}

.GameRecord__C-body .details .detailLi .c-flex-warp[data-v-68c3df62] {
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.GameRecord__C-body .details .detailLi .select[data-v-68c3df62] {
    margin-left: 0.53333rem;
}

.GameRecord__C-body .details .detailLi .select .ball[data-v-68c3df62] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 0.64rem;
    height: 0.42667rem;
    line-height: 0.42667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-left: 0.13333rem;
    margin-bottom: 0.13333rem;
    background: var(--main-color);
    border-radius: 0.08rem;
    color: #fff;
}

.GameRecord__C-body .details .detailLi .Bet-box.pb[data-v-68c3df62] {
    padding-bottom: 0.06667rem;
}

.GameRecord__C-body .details .detailLi .Bet-box ul li[data-v-68c3df62] {
    height: 0.26667rem;
    line-height: 0.26667rem;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    margin: 0.02667rem 0.05333rem;
    background-color: var(--gray-color-1);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionViolet[data-v-68c3df62] {
    color: #fff;
    background-color: var(--bgcolor-21);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionRed[data-v-68c3df62] {
    color: #fff;
    background-color: var(--norm_red-color);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionGreen[data-v-68c3df62] {
    color: #fff;
    background-color: var(--bgColor-13);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionRedGreen[data-v-68c3df62] {
    color: #fff;
    background-color: var(--norm_red-color);
    background-image: var(--linearGradien-21);
}

.GameRecord__C-body .details .detailLi .Bet-box .actionBtn[data-v-68c3df62] {
    height: 0.34667rem;
    line-height: 0.34667rem;
    display: inline-block;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    background-color: var(--norm_red-color);
    color: #fff;
}

.GameRecord__C-body .goItem[data-v-68c3df62] {
    height: 1.30667rem;
    line-height: 1.30667rem;
    text-align: center;
    color: var(--darkTextW, --main-color);
    font-size: 0.32rem;
}

.GameRecord__C-body .li[data-v-68c3df62] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
    width: 0.4rem;
    height: 0.4rem;
    border-radius: 50%;
    background: var(--walletBgColor-1);
    margin: 0 0.02667rem;
}

.GameRecord__C-body .li .circle-black[data-v-68c3df62] {
    background-color: var(--walletBgColor-1);
    color: var(--text_color_L1);
    font-size: 0.32rem;
}

.GameRecord__C-body .time[data-v-68c3df62] {
    color: var(--textM3, var(--text_color_L2));
    font-size: 0.32rem;
    height: 100%;
}

.GameRecord__C-body .numList[data-v-68c3df62] {
    width: 3rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    position: relative;
    top: 0.4rem;
}

.GameRecord__C-body .numList .numItem[data-v-68c3df62] {
    width: 0.4rem;
    height: 0.4rem;
    background: var(--walletBgColor-1);
    color: var(--text_color_L1);
    font-size: 0.32rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    border-radius: 50%;
}

.GameRecord__C-body .redNumItem[data-v-68c3df62] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot[data-v-68c3df62] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.GameRecord__C-foot-previous[data-v-68c3df62],
.GameRecord__C-foot-next[data-v-68c3df62] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot-previous.disabled[data-v-68c3df62],
.GameRecord__C-foot-next.disabled[data-v-68c3df62] {
    background: var(--gray-color-1);
    pointer-events: none;
}

.GameRecord__C-foot-previous.disabled .GameRecord__C-icon[data-v-68c3df62],
.GameRecord__C-foot-next.disabled .GameRecord__C-icon[data-v-68c3df62] {
    color: var(--saveTextColor-7);
}

.GameRecord__C-foot-previous .GameRecord__C-icon[data-v-68c3df62],
.GameRecord__C-foot-next .GameRecord__C-icon[data-v-68c3df62] {
    color: #fff;
}

.MyGameRecord__C[data-v-68c3df62] {
    width: 100%;
    margin: 0.32rem auto 1.6rem;
}

.MyGameRecord__C-head[data-v-68c3df62] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
    background-color: var(--darkBg, var(--bg_color_L2));
    padding: 0.32rem 0.32rem 0;
}

.MyGameRecord__C-head-moreB[data-v-68c3df62] {
    border: 0.01333rem solid var(--main-color);
    height: 0.8rem;
    line-height: 0.8rem;
    border-radius: 0.26667rem;
    padding: 0 0.72rem 0 0.24rem;
    color: var(--main-color);
    font-size: 0.32rem;
    position: relative;
    margin-bottom: 0.4rem;
}

.MyGameRecord__C-head-moreB[data-v-68c3df62]:after {
    content: "";
    display: block;
    width: 0.4rem;
    height: 0.4rem;
    position: absolute;
    top: 50%;
    right: 0.2rem;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    background-image: url(/assets/jpg/moreBtn-ffccf44d.jpg);
    background-repeat: no-repeat;
    background-size: 0.4rem;
    background-position: center;
}

html:lang(ar) .MyGameRecord__C-head-moreB[data-v-68c3df62]:after {
    left: 0.2rem;
    right: unset;
    -webkit-transform: scaleX(-1);
    transform: scaleX(-1);
    top: 25%;
}

.MyGameRecord__C-body[data-v-68c3df62] {
    padding: 0 0.32rem;
}

.MyGameRecord__C-body-empty[data-v-68c3df62] {
    height: 5.33333rem;
}

.MyGameRecord__C-foot[data-v-68c3df62] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecord__C-foot-page[data-v-68c3df62] {
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.MyGameRecord__C-foot-previous[data-v-68c3df62],
.MyGameRecord__C-foot-next[data-v-68c3df62] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.MyGameRecord__C-foot-previous.disabled[data-v-68c3df62],
.MyGameRecord__C-foot-next.disabled[data-v-68c3df62] {
    background: var(--gray-color-1);
    pointer-events: none;
}

.MyGameRecord__C-foot-previous.disabled .MyGameRecord__C-icon[data-v-68c3df62],
.MyGameRecord__C-foot-next.disabled .MyGameRecord__C-icon[data-v-68c3df62] {
    color: var(--saveTextColor-7);
}

.MyGameRecord__C-foot-previous .MyGameRecord__C-icon[data-v-68c3df62],
.MyGameRecord__C-foot-next .MyGameRecord__C-icon[data-v-68c3df62] {
    color: #fff;
}

.list[data-v-68c3df62] {
    padding: 0 0.26667rem;
}

.list .hb[data-v-68c3df62] {
    background-color: #fff;
    color: var(--colorText-3);
    font-size: 0.37333rem;
}

.list .hb .item[data-v-68c3df62] {
    padding: 0.21333rem;
    border-bottom: 0.02667rem solid var(--gray-color-1);
    color: var(--colorText-3);
    font-size: 0.37333rem;
}

.list .hb .item.action[data-v-68c3df62] {
    padding: 0.32rem 0.26667rem;
}

.list .hb .item .goItem[data-v-68c3df62] {
    height: 0.42667rem;
}

.list .hb .li[data-v-68c3df62] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
    width: 0.42667rem !important;
    height: 0.42667rem;
    border: 0.02667rem solid var(--gray-color-1);
    border-radius: 0.42667rem;
    margin-right: 0.10667rem;
    color: var(--gray-color-1);
}

.list .hb .li.action[data-v-68c3df62] {
    font-size: 0.32rem;
    border: none;
    color: #fff;
    background-color: var(--norm_red-color);
}

.list .hb .li.circle-black[data-v-68c3df62] {
    border: 0.02667rem solid var(--text_color_L1);
    color: var(--text_color_L1);
    background: var(--bgColor-6);
}

.list .hb .li.actionH[data-v-68c3df62] {
    border: none;
    color: #fff;
    background-color: var(--borderColor-4);
}

.list .hb .li.actionL[data-v-68c3df62] {
    border: 0.01333rem solid var(--borderColor-4);
    color: var(--borderColor-4);
    background-color: #fff;
}

.list .hb .li.actionO[data-v-68c3df62] {
    border: none;
    color: #fff;
    background-color: var(--norm_secondary-color);
}

.list .hb .li.actionE[data-v-68c3df62] {
    border: 0.01333rem solid var(--norm_secondary-color);
    color: var(--norm_secondary-color);
    background-color: #fff;
}

.list .hb .qiu[data-v-68c3df62] {
    width: 3rem;
    position: relative;
}

.list .hb .qiu .line-canvas[data-v-68c3df62] {
    position: absolute !important;
    top: 0.12rem;
    left: 0;
    height: 0.73333rem;
    width: 2.61333rem;
    z-index: 99;
}

html:lang(ar) .list .hb .qiu .line-canvas[data-v-68c3df62] {
    right: 0.12rem;
    left: unset;
}

.list .hb .red[data-v-68c3df62] {
    color: var(--colorText-2);
}

.list .hb .green[data-v-68c3df62] {
    color: var(--norm_green-color);
}

.list .hb .blue[data-v-68c3df62] {
    color: var(--colorText-7);
}

.list .hb .box .li[data-v-68c3df62] {
    display: block;
    height: 0.13333rem;
    width: 0.13333rem;
    border-radius: 0.13333rem;
    margin: 0 0.06667rem;
}

.list .hb .item[data-v-68c3df62] {
    padding: 0.53333rem 0.4rem;
}

.list .hb .item .info[data-v-68c3df62] {
    width: 100%;
}

.list .hb .item .info .issueName .state[data-v-68c3df62] {
    color: #fff;
    padding: 0.10667rem 0.26667rem;
    margin-left: 0.26667rem;
    border-radius: 0.53333rem;
    font-size: 0.32rem;
    display: inline-block;
    text-align: center;
}

.list .hb .item .info .issueName .state.red[data-v-68c3df62] {
    background-color: var(--norm_red-color);
}

.list .hb .item .info .issueName .state.green[data-v-68c3df62] {
    background-color: var(--norm_green-color);
}

.list .hb .item .info .tiem[data-v-68c3df62] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
    margin-top: 0.13333rem;
}

.list .hb .item .info .money[data-v-68c3df62] {
    font-weight: 600;
    font-size: 0.42667rem;
}

.list .hb .item .info .money .fail[data-v-68c3df62] {
    color: var(--norm_red-color);
}

.list .hb .item .info .money .success[data-v-68c3df62] {
    color: var(--bgColor-13);
}

.list .hb .details[data-v-68c3df62] {
    padding: 0.4rem;
    border-bottom: 0.01333rem solid var(--gray-color-1);
}

.list .hb .details .tit[data-v-68c3df62] {
    font-size: 0.4rem;
    color: var(--text_color_L1);
    margin-bottom: 0.26667rem;
    font-weight: 700;
}

.list .hb .details .tit img[data-v-68c3df62] {
    width: 0.64rem;
    height: 0.64rem;
    position: relative;
    top: 0.13333rem;
}

.list .hb .details .tag-read img[data-v-68c3df62] {
    width: 0.32rem;
    height: 0.32rem;
}

.list .hb .details .detailLi[data-v-68c3df62] {
    min-height: 0.66667rem;
    line-height: 0.66667rem;
    background: var(--bgColor-6);
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
    margin-bottom: 0.21333rem;
}

.list .hb .details .detailLi .red[data-v-68c3df62] {
    color: var(--main_gradient-color);
}

.list .hb .details .detailLi .result[data-v-68c3df62] {
    height: 0.93333rem;
    line-height: 0.93333rem;
    background: var(--main-color);
    border-radius: 0.13333rem 0.13333rem 0 0;
    color: #fff;
    text-align: left;
    padding: 0 --0.26667rem;
}

.list .hb .details .detailLi .prize-tit[data-v-68c3df62] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.list .hb .details .detailLi .prize-box[data-v-68c3df62] {
    border-bottom: 0.01333rem solid #fff;
}

.list .hb .details .detailLi .prize-box-item[data-v-68c3df62] {
    text-align: center;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.list .hb .details .detailLi .c-flex-warp[data-v-68c3df62] {
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.list .hb .details .detailLi .select[data-v-68c3df62] {
    margin-left: 0.53333rem;
}

.list .hb .details .detailLi .select .ball[data-v-68c3df62] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 0.64rem;
    height: 0.42667rem;
    line-height: 0.42667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-left: 0.13333rem;
    margin-bottom: 0.13333rem;
    background: var(--main-color);
    border-radius: 0.08rem;
    color: #fff;
}

.list .hb .details .detailLi .Bet-box.pb[data-v-68c3df62] {
    padding-bottom: 0.06667rem;
}

.list .hb .details .detailLi .Bet-box ul li[data-v-68c3df62] {
    height: 0.26667rem;
    line-height: 0.26667rem;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    margin: 0.02667rem 0.05333rem;
    background-color: var(--gray-color-1);
}

.list .hb .details .detailLi .Bet-box ul li.actionViolet[data-v-68c3df62] {
    color: #fff;
    background-color: var(--bgcolor-21);
}

.list .hb .details .detailLi .Bet-box ul li.actionRed[data-v-68c3df62] {
    color: #fff;
    background-color: var(--norm_red-color);
}

.list .hb .details .detailLi .Bet-box ul li.actionGreen[data-v-68c3df62] {
    color: #fff;
    background-color: var(--bgColor-13);
}

.list .hb .details .detailLi .Bet-box ul li.actionRedGreen[data-v-68c3df62] {
    color: #fff;
    background-color: var(--norm_red-color);
    background-image: var(--linearGradien-21);
}

.list .hb .details .detailLi .Bet-box .actionBtn[data-v-68c3df62] {
    height: 0.34667rem;
    line-height: 0.34667rem;
    display: inline-block;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    background-color: var(--norm_red-color);
    color: #fff;
}

.areList[data-v-68c3df62] {
    margin: 0.53333rem;
    position: relative;
}

.areList .close[data-v-68c3df62] {
    position: absolute;
    top: -1.6rem;
    left: 50%;
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
    width: 0.8rem;
    height: 0.8rem;
}

.areList .items h1[data-v-68c3df62] {
    color: var(--darkTextW, var(--borderColor-26));
    font-size: 0.42667rem;
}

.areList .items .itemsC[data-v-68c3df62] {
    margin: 0.26667rem 0 0.4rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    gap: 0.2rem;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.areList .items .itemsC>div[data-v-68c3df62] {
    width: calc((100% - 0.53333rem) / 2);
    background: var(--bgDark-3, var(--homeActiveBgColor));
    border-radius: 0.13333rem;
    min-height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
}

.areList .items .itemsC .isActive[data-v-68c3df62] {
    background: var(--norm_red-color);
    color: #fff;
}

.titlebets[data-v-68c3df62] {
    font-size: 0.29333rem;
    color: var(--main-color);
}

.border60[data-v-68c3df62] {
    width: 4.53333rem;
    height: 0.66667rem;
    line-height: 0.66667rem;
    border-radius: 0.8rem;
    border: 0.01333rem solid var(--main-color);
    margin: 0 auto;
    margin-top: 0.30667rem;
}

.bottombg[data-v-68c3df62] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/arrowbottom-4eb91cbc.png);
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center;
}

.compound2[data-v-68c3df62],
.compound3[data-v-68c3df62] {
    padding-top: 0.26667rem;
    max-height: 5.33333rem;
    overflow-y: auto;
}

.compound2 .item[data-v-68c3df62],
.compound3 .item[data-v-68c3df62] {
    width: 100%;
    margin-bottom: 0.26667rem;
}

.compound2 .item.item0-3 .box .c-row[data-v-68c3df62],
.compound3 .item.item0-3 .box .c-row[data-v-68c3df62] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.21333rem;
}

.compound2 .item.item0-3 .box .num[data-v-68c3df62],
.compound3 .item.item0-3 .box .num[data-v-68c3df62] {
    width: calc((100% - 1.28rem) / 7);
    height: 1.13333rem;
    background-size: 1.13333rem 1.13333rem;
}

.compound2 .item.item0-2 .box .c-row[data-v-68c3df62],
.compound2 .item.item5-2 .box .c-row[data-v-68c3df62],
.compound3 .item.item0-2 .box .c-row[data-v-68c3df62],
.compound3 .item.item5-2 .box .c-row[data-v-68c3df62] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.21333rem;
}

.compound2 .item.item0-2 .box .num[data-v-68c3df62],
.compound2 .item.item5-2 .box .num[data-v-68c3df62],
.compound3 .item.item0-2 .box .num[data-v-68c3df62],
.compound3 .item.item5-2 .box .num[data-v-68c3df62] {
    width: calc((100% - 1.28rem) / 7);
    height: 0.8rem;
    background-size: 0.8rem 0.8rem;
}

.compound2 .item.item4-2 .box .c-row[data-v-68c3df62],
.compound3 .item.item4-2 .box .c-row[data-v-68c3df62] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item4-2 .box .num[data-v-68c3df62],
.compound3 .item.item4-2 .box .num[data-v-68c3df62] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-8),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-7),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-6),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-5),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-4),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-2),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-1),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-8),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-7),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-5),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-4),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-2),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-1),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
}

.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-7),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-6),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-4),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-1),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-7),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-4),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-1),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n) {
    margin-left: -0.10667rem;
}

.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-68c3df62]:nth-child(9n-6) {
    margin-right: 0.42667rem;
}

.compound2 .item.item3-2 .box .c-row[data-v-68c3df62],
.compound3 .item.item3-2 .box .c-row[data-v-68c3df62] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item3-2 .box .num[data-v-68c3df62],
.compound3 .item.item3-2 .box .num[data-v-68c3df62] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-1),
.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-2),
.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-3),
.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-4),
.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-5),
.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-6),
.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-7),
.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-1),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-2),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-3),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-5),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-6),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-7),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
}

.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-6),
.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-5),
.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-4),
.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-2),
.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-1),
.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-6),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-5),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-2),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-1),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n) {
    margin-left: -0.06667rem;
}

.compound2 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-68c3df62]:nth-child(8n-4) {
    margin-right: 1.73333rem;
}

.compound2 .item.item2-2 .box .c-row[data-v-68c3df62],
.compound3 .item.item2-2 .box .c-row[data-v-68c3df62] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item2-2 .box .num[data-v-68c3df62],
.compound3 .item.item2-2 .box .num[data-v-68c3df62] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-1),
.compound2 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-2),
.compound2 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-3),
.compound2 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-4),
.compound2 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-5),
.compound2 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-6),
.compound2 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-7),
.compound2 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n),
.compound3 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-1),
.compound3 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-2),
.compound3 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-3),
.compound3 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-4),
.compound3 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-5),
.compound3 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-6),
.compound3 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n-7),
.compound3 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
    margin-left: -0.01333rem;
}

.compound2 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n),
.compound3 .item.item2-2 .box .num[data-v-68c3df62]:nth-child(8n) {
    margin-right: 1.33333rem;
}

.compound2 .item.item1-2 .box .c-row[data-v-68c3df62],
.compound3 .item.item1-2 .box .c-row[data-v-68c3df62] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item1-2 .box .num[data-v-68c3df62],
.compound3 .item.item1-2 .box .num[data-v-68c3df62] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-1),
.compound2 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-2),
.compound2 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-3),
.compound2 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-4),
.compound2 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-5),
.compound2 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-6),
.compound2 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-7),
.compound2 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-8),
.compound2 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-9),
.compound2 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n),
.compound3 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-1),
.compound3 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-2),
.compound3 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-3),
.compound3 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-4),
.compound3 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-5),
.compound3 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-6),
.compound3 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-7),
.compound3 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-8),
.compound3 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n-9),
.compound3 .item.item1-2 .box .num[data-v-68c3df62]:nth-child(10n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
    margin-left: -0.09333rem;
}

.compound2 .item .box[data-v-68c3df62],
.compound3 .item .box[data-v-68c3df62] {
    border-radius: 0.26667rem;
    position: relative;
    width: 100%;
}

.compound2 .item .box .num[data-v-68c3df62],
.compound3 .item .box .num[data-v-68c3df62] {
    min-width: 0.8rem;
    min-height: 0.8rem;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: 0.8rem 0.8rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
}

.compound2 .item .box .money[data-v-68c3df62],
.compound3 .item .box .money[data-v-68c3df62] {
    text-align: center;
    background-color: var(--gray-color-1);
    position: relative;
    height: 0.53333rem;
    border-radius: 0 0 0.26667rem 0.26667rem;
}

.compound2 .item .box .money .all[data-v-68c3df62],
.compound3 .item .box .money .all[data-v-68c3df62] {
    position: relative;
    z-index: 9;
    line-height: 0.8rem;
    font-size: 0.32rem;
    color: #00AF54;
}

.compound2 .item .box .money[data-v-68c3df62]:after,
.compound3 .item .box .money[data-v-68c3df62]:after {
    position: absolute;
    top: 0;
    left: 0;
    content: "";
    display: block;
    width: 100%;
    height: 0.21333rem;
    background-color: var(--gray-color-1);
    border-radius: 0 0 50% 50%;
}

.compound2 .item .box .dele[data-v-68c3df62],
.compound3 .item .box .dele[data-v-68c3df62] {
    position: absolute;
    right: -0.18667rem;
    top: -0.18667rem;
    height: 0.37333rem;
    width: 0.37333rem;
    border-radius: 0.53333rem;
    background-color: #00AF54;
}

.compound2 .item .box .dele .icon[data-v-68c3df62],
.compound3 .item .box .dele .icon[data-v-68c3df62] {
    font-size: 0.26667rem;
}

.compound2 .item.item0-4 .box .c-row[data-v-68c3df62] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.53333rem;
}

.compound2 .item.item0-4 .box .num[data-v-68c3df62] {
    width: calc((100% - 2.13333rem) / 5);
    background: var(--main_gradient-color);
    color: #fff;
    border-radius: 0.13333rem;
    min-height: 1.06667rem;
    min-width: 1.33333rem;
}

.compound[data-v-68c3df62] {
    padding-top: 0.26667rem;
    max-height: 6rem;
    overflow: auto;
}

.compound .item[data-v-68c3df62] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 100%;
    margin-bottom: 0.4rem;
}

.compound .item .title[data-v-68c3df62] {
    width: 1.38667rem;
    overflow: hidden;
    position: relative;
    text-align: center;
    font-size: 0.42667rem;
    color: var(--text_color_L2);
}

.compound .item .numcontainer[data-v-68c3df62] {
    width: 7.94667rem;
    margin-left: 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    justify-content: flex-start;
    gap: 0.13333rem;
}

.compound .item .numcontainer .num[data-v-68c3df62] {
    width: calc((100% - 0.85333rem) / 5);
    height: 0.8rem;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: 0.8rem 0.8rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
    position: relative;
    text-align: center;
    line-height: 0.8rem;
}

.compound .item .numcontainer .num .dele[data-v-68c3df62] {
    position: absolute;
    right: -0.18667rem;
    top: -0.18667rem;
    height: 0.37333rem;
    width: 0.37333rem;
    border-radius: 0.53333rem;
    background-color: #00AF54;
}

html:lang(ar) .compound .item .numcontainer .num .dele[data-v-68c3df62] {
    right: unset;
    left: -0.18667rem;
}

.compound .item .numcontainer .num .dele .icon[data-v-68c3df62] {
    font-size: 0.26667rem;
}

.van-toast[data-v-56cdb7a2] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-56cdb7a2] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-56cdb7a2] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-56cdb7a2] {
    height: 80%;
}

.state[data-v-56cdb7a2],
.sub[data-v-56cdb7a2] {
    color: var(--text_color_L2);
}

.state.state0[data-v-56cdb7a2],
.sub.state0[data-v-56cdb7a2] {
    color: var(--norm_bule-color);
}

.state.state1[data-v-56cdb7a2],
.sub.state1[data-v-56cdb7a2] {
    color: var(--norm_secondary-color);
}

.state.state2 span[data-v-56cdb7a2],
.sub.state2 span[data-v-56cdb7a2],
.state.state3[data-v-56cdb7a2],
.sub.state3[data-v-56cdb7a2] {
    color: var(--bgcolor-22);
}

.state.state4[data-v-56cdb7a2],
.sub.state4[data-v-56cdb7a2] {
    color: var(--main-color);
}

.MyGameRecordList__C[data-v-56cdb7a2] {
    background-color: var(--darkBg, var(--bg_color_L2));
}

.MyGameRecordList__C .item[data-v-56cdb7a2] {
    padding: 0 0.32rem;
    border-bottom: 0.01333rem solid var(--gray-color-1);
}

.MyGameRecordList__C .item.active[data-v-56cdb7a2] {
    border-radius: 0.13333rem;
    border: 0.01333rem solid var(--bgDark-4, var(--borderColor-5));
}

.MyGameRecordList__C .item.active h4[data-v-56cdb7a2] {
    font-weight: 700;
    font-size: 0.4rem;
}

.MyGameRecordList__C .item.active .box[data-v-56cdb7a2] {
    border-bottom: 0.01333rem solid var(--gray-color-1);
}

.MyGameRecordList__C .item .box[data-v-56cdb7a2] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    padding: 0.34667rem 0;
}

.MyGameRecordList__C .item .box h4[data-v-56cdb7a2] {
    color: var(--darkTextW, var(--text_color_L1));
    font-size: 0.37333rem;
    margin-bottom: 0.06667rem;
}

.MyGameRecordList__C .item .box .time[data-v-56cdb7a2] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.MyGameRecordList__C .item .box .state[data-v-56cdb7a2] {
    font-size: 0.34667rem;
    text-align: right;
}

.MyGameRecordList__C .item .box .state span[data-v-56cdb7a2] {
    display: inline-block;
    margin-top: 0.06667rem;
}

.MyGameRecordList__C .item .info[data-v-56cdb7a2] {
    padding: 0.32rem 0;
}

.MyGameRecordList__C .item .info .order .li[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li[data-v-56cdb7a2] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    min-height: 0.66667rem;
    line-height: 0.66667rem;
    padding-left: 0.53333rem;
}

.MyGameRecordList__C .item .info .order .li.betNum[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li.betNum[data-v-56cdb7a2] {
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.MyGameRecordList__C .item .info .order .li.betNum .lab[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li.betNum .lab[data-v-56cdb7a2] {
    color: var(--text_color_L1);
    font-size: 0.37333rem;
    width: 100%;
}

.MyGameRecordList__C .item .info .order .li.betNum .lab .txt[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li.betNum .lab .txt[data-v-56cdb7a2] {
    font-size: 0.37333rem;
    color: var(--text_color_L2);
}

.MyGameRecordList__C .item .info .order .li.betNum .lab .betList[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li.betNum .lab .betList[data-v-56cdb7a2] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    width: 100%;
}

.MyGameRecordList__C .item .info .order .li.betNum .lab .betList.select[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li.betNum .lab .betList.select[data-v-56cdb7a2] {
    max-height: 5.66667rem;
    overflow-y: auto;
}

.MyGameRecordList__C .item .info .order .li.betNum .lab .betList>span[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li.betNum .lab .betList>span[data-v-56cdb7a2] {
    display: inline-block;
    text-align: center;
    height: 0.64rem;
    line-height: 0.64rem;
    width: 0.64rem;
    color: var(--text_color_L1);
    background-color: var(--bg_color_L3);
    border-radius: 0.64rem;
    font-size: 0.32rem;
    margin-right: 0.2rem;
    margin-bottom: 0.2rem;
}

.MyGameRecordList__C .item .info .order .li.betNum .lab .betList>span.active[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li.betNum .lab .betList>span.active[data-v-56cdb7a2] {
    background-color: var(--main_gradient-color);
    color: #fff;
}

.MyGameRecordList__C .item .info .order .li.betNum .lab .betList>span[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li.betNum .lab .betList>span[data-v-56cdb7a2] {
    width: auto;
    padding: 0 0.16rem;
    border-radius: 0.16rem;
}

.MyGameRecordList__C .item .info .order .li.betNum .lab[data-v-56cdb7a2]:after,
.MyGameRecordList__C .item .info .bet .li.betNum .lab[data-v-56cdb7a2]:after {
    top: 0.26667rem;
}

.MyGameRecordList__C .item .info .order .li.betNum .lab[data-v-56cdb7a2]:before,
.MyGameRecordList__C .item .info .bet .li.betNum .lab[data-v-56cdb7a2]:before {
    top: 0.50667rem;
    height: 97%;
}

.MyGameRecordList__C .item .info .order .li .lab[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li .lab[data-v-56cdb7a2] {
    color: var(--text_color_L2);
    position: relative;
}

.MyGameRecordList__C .item .info .order .li .lab[data-v-56cdb7a2]:after,
.MyGameRecordList__C .item .info .bet .li .lab[data-v-56cdb7a2]:after {
    content: "";
    display: block;
    background: url(/assets/png/before_cire-0951deab.png) no-repeat center center;
    background-size: cover;
    height: 0.26667rem;
    width: 0.26667rem;
    position: absolute;
    top: 50%;
    -webkit-transform: translate(0, -50%);
    transform: translateY(-50%);
    left: -0.53333rem;
}

html:lang(ar) .MyGameRecordList__C .item .info .order .li .lab[data-v-56cdb7a2]:after,
html:lang(ar) .MyGameRecordList__C .item .info .bet .li .lab[data-v-56cdb7a2]:after {
    right: -0.53333rem;
    left: unset;
}

.MyGameRecordList__C .item .info .order .li .lab[data-v-56cdb7a2]:before,
.MyGameRecordList__C .item .info .bet .li .lab[data-v-56cdb7a2]:before {
    content: "";
    display: block;
    height: 35%;
    border-left: 0.01333rem dashed var(--main-color);
    position: absolute;
    left: -0.41333rem;
    top: 0.56rem;
}

html:lang(ar) .MyGameRecordList__C .item .info .order .li .lab[data-v-56cdb7a2]:before,
html:lang(ar) .MyGameRecordList__C .item .info .bet .li .lab[data-v-56cdb7a2]:before {
    right: -0.41333rem;
    left: unset;
}

.MyGameRecordList__C .item .info .order .li:last-child .lab[data-v-56cdb7a2]:before,
.MyGameRecordList__C .item .info .bet .li:last-child .lab[data-v-56cdb7a2]:before {
    content: "";
    display: none;
}

.MyGameRecordList__C .item .info .order .li .sub[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li .sub[data-v-56cdb7a2] {
    color: var(--text_color_L1);
    font-size: 0.32rem;
}

.MyGameRecordList__C .item .info .order .li .sub>img[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li .sub>img[data-v-56cdb7a2] {
    width: 0.4rem;
    vertical-align: -0.06667rem;
}

.MyGameRecordList__C .item .info .order .li .sub.success[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li .sub.success[data-v-56cdb7a2] {
    color: var(--bgcolor-22);
}

.MyGameRecordList__C .item .info .order .li .sub.fail[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .bet .li .sub.fail[data-v-56cdb7a2] {
    color: var(--main-color);
}

.MyGameRecordList__C .item .info .line[data-v-56cdb7a2] {
    margin: 0 -0.36rem;
    background-color: var(--darkBg, var(--bg_color_L2));
    height: 0.57333rem;
    overflow: hidden;
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecordList__C .item .info .line>p[data-v-56cdb7a2] {
    width: 80%;
    border-bottom: 0.01333rem dashed var(--bgDark-4, var(--gray-color-1));
}

.MyGameRecordList__C .item .info .line[data-v-56cdb7a2]:after,
.MyGameRecordList__C .item .info .line[data-v-56cdb7a2]:before {
    content: "";
    display: block;
    width: 0.53333rem;
    height: 0.53333rem;
    border-radius: 0.53333rem;
    border: 0.01333rem solid var(--bgDark-4, var(--borderColor-5));
    position: absolute;
    top: 0;
}

.MyGameRecordList__C .item .info .line[data-v-56cdb7a2]:after {
    left: -0.26667rem;
}

html:lang(ar) .MyGameRecordList__C .item .info .line[data-v-56cdb7a2]:after {
    right: -0.26667rem;
    left: unset;
}

.MyGameRecordList__C .item .info .line[data-v-56cdb7a2]:before {
    right: -0.26667rem;
}

html:lang(ar) .MyGameRecordList__C .item .info .line[data-v-56cdb7a2]:before {
    right: unset;
    left: -0.26667rem;
}

.MyGameRecordList__C .item .info .btn[data-v-56cdb7a2] {
    text-align: center;
    height: 0.93333rem;
    line-height: 0.93333rem;
    border-radius: 0.93333rem;
    font-size: 0.4rem;
    color: #fff;
    background: var(--main_gradient-color2);
    margin: 0.4rem 0;
}

.MyGameRecordList__C .item .info .result-item[data-v-56cdb7a2] {
    min-height: 1.06667rem;
    background-color: var(--bgDark-4, var(--walletBgColor-1));
    margin-top: 0.16rem;
    border-radius: 0.13333rem;
    padding: 0 0.26667rem;
    color: var(--text_color_L1);
    font-size: 0.37333rem;
    padding: 0.26667rem 0.32rem;
}

.MyGameRecordList__C .item .info .result-item .txt[data-v-56cdb7a2] {
    color: var(--text_color_L2);
}

.MyGameRecordList__C .item .info .result-item.jusb[data-v-56cdb7a2] {
    padding: 0 0.32rem;
    line-height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.MyGameRecordList__C .item .info .result-item.jusb .num[data-v-56cdb7a2],
.MyGameRecordList__C .item .info .result-item.jusb .txt[data-v-56cdb7a2] {
    margin-top: 0;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: var(--darkTextW, var(--text_color_L1));
}

.MyGameRecordList__C .item .info .result-item.jusb .num[data-v-56cdb7a2] {
    text-align: center;
    position: relative;
    font-weight: 700;
}

.MyGameRecordList__C .item .info .result-item.jusb .num[data-v-56cdb7a2]:before {
    content: "";
    display: block;
    width: 0.02667rem;
    height: 0.66667rem;
    position: absolute;
    top: 0.2rem;
    left: 0;
    background-color: var(--bgDark-2, --text_color_L2);
}

html:lang(ar) .MyGameRecordList__C .item .info .result-item.jusb .num[data-v-56cdb7a2]:before {
    right: 0;
    left: unset;
}

.MyGameRecordList__C .item .info .result-item.jusb:first-child .num[data-v-56cdb7a2] {
    color: var(--main-color);
}

.MyGameRecordList__C .item .info .result-item .num[data-v-56cdb7a2] {
    margin-top: 0.18667rem;
    font-size: 0.37333rem;
    color: var(--text_color_L1);
}

.van-toast[data-v-44e97c4d] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-44e97c4d] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-44e97c4d] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-44e97c4d] {
    height: 80%;
}

.NewVietnam__C[data-v-44e97c4d] {
    padding-bottom: 0.34667rem;
    overflow-y: auto;
    background-color: var(--bgDark-4, var(--bg_color_L1));
}

.NewVietnam__C-head[data-v-44e97c4d] {
    height: 1.25333rem;
    background: var(--main_gradient-color);
    padding: 0 0.34667rem;
    position: relative;
}

.NewVietnam__C-head div[data-v-44e97c4d] {
    background-repeat: no-repeat;
    background-position: center;
}

.NewVietnam__C-head-bcak[data-v-44e97c4d] {
    position: absolute;
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/bcakIcon-b7c1d288.png);
    background-size: 0.64rem;
    left: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
}

html:lang(ar) .NewVietnam__C-head-bcak[data-v-44e97c4d] {
    left: unset;
    right: 0.34667rem;
}

.NewVietnam__C-head-logo[data-v-44e97c4d] {
    background-size: 2.98667rem 1.12rem;
    height: 1.12rem;
    width: 2.98667rem;
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
}

.NewVietnam__C-head-more[data-v-44e97c4d] {
    position: absolute;
    width: 1.54667rem;
    height: 0.64rem;
    right: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

html:lang(ar) .NewVietnam__C-head-more[data-v-44e97c4d] {
    right: unset;
    left: 0.34667rem;
}

.NewVietnam__C-head-more>div[data-v-44e97c4d] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/kefu-b361c42f.png);
    background-size: 0.64rem;
}

.NewVietnam__C-head-more>div[data-v-44e97c4d]:last-child {
    background-image: url(/assets/png/voice-62dbf38c.png);
}

.NewVietnam__C-head-more>div:last-child.disableVoice[data-v-44e97c4d] {
    background-image: url(/assets/png/voice-off-633f5ccc.png);
}

.NewVietnam__C[data-v-44e97c4d] .driver-close-btn,
.NewVietnam__C[data-v-44e97c4d] .driver-prev-btn {
    display: none;
}

.popup[data-v-44e97c4d] {
    overflow-y: visible !important;
    border-radius: 0.13333rem 0.13333rem 0 0;
    width: 100%;
}

.popup[data-v-44e97c4d] .van-popup {
    overflow-y: visible !important;
    border-radius: 0.26667rem 0.26667rem 0 0;
}

.popup .box[data-v-44e97c4d] {
    position: relative;
}

.popup .box .close[data-v-44e97c4d] {
    position: absolute;
    top: -1.06667rem;
    left: 50%;
    -webkit-transform: translate(-50%, 0);
    transform: translate(-50%);
}

.popup .box .close .img[data-v-44e97c4d] {
    width: 0.8rem;
    height: 0.8rem;
}

.popup .box .title[data-v-44e97c4d] {
    font-size: 0.42667rem;
    color: var(--text_color_L1);
}

.popup .box .numList[data-v-44e97c4d] {
    max-height: 5.33333rem;
    overflow-x: auto;
}

.popup .box .numList .item[data-v-44e97c4d] {
    width: 1.06667rem;
    height: 1.06667rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
    margin: 0 0.13333rem;
}

.popup-info-item[data-v-44e97c4d] {
    height: 0.8rem;
    line-height: 0.8rem;
    margin-top: 0.26667rem;
}

.popup-info-item .tit[data-v-44e97c4d] {
    font-size: 0.37333rem;
    color: var(--text_color_L2);
}

.popup-info-item .amount-box .li[data-v-44e97c4d],
.popup-info-item .multiple-box .li[data-v-44e97c4d] {
    text-align: center;
    font-size: 0.32rem;
    padding: 0 0.13333rem;
    height: 0.8rem;
    line-height: 0.8rem;
    min-width: 1.33333rem;
    margin-left: 0.13333rem;
    border: 0.01333rem solid var(--gray-color-1);
    border-radius: 0.13333rem;
    color: #00AF54;
}

.popup-info-item .amount-box .li.action[data-v-44e97c4d],
.popup-info-item .multiple-box .li.action[data-v-44e97c4d] {
    border: none;
    color: #fff;
    background: var(--main_gradient-color);
}

.popup-info-item .multiple-box .li[data-v-44e97c4d] {
    padding: 0 0.26667rem;
    min-width: auto;
}

.popup-info-item .stepper-box .digit-box[data-v-44e97c4d] {
    width: 2.66667rem;
    height: 0.8rem;
    border-radius: 0.8rem;
    padding: 0;
    margin: 0 0.13333rem;
    background-color: var(--walletBgColor-1);
}

.popup-info-item .stepper-box .digit-box[data-v-44e97c4d] .van-field__control {
    height: 0.74667rem;
    text-align: center;
}

.popup-info-item .stepper-box .li[data-v-44e97c4d] {
    height: 0.8rem;
    width: 0.8rem;
    font-size: 0.8rem;
    border-radius: 50%;
    background-color: var(--main-color);
    color: #fff;
}

.popup-info-item .stepper-box .li.minus[data-v-44e97c4d] {
    text-align: center;
    line-height: 0.66667rem;
}

.popup-info-item .txt[data-v-44e97c4d] {
    color: #00AF54;
}

.popup-info .quantity[data-v-44e97c4d] {
    margin-top: 0.26667rem;
    padding: 0 0.21333rem;
    height: 1.17333rem;
    background-color: var(--bgDark-2, var(--homeActiveBgColor));
    border-radius: 0.13333rem;
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.popup-info .quantity .line[data-v-44e97c4d] {
    padding: 0 0.13333rem;
    color: var(--text_color_L2);
}

.popup-info .quantity .num[data-v-44e97c4d] {
    color: #00AF54;
    font-size: 0.4rem;
}

.popup-info .wallet[data-v-44e97c4d],
.popup-info .balance[data-v-44e97c4d] {
    padding: 0 0.21333rem;
    margin-top: 0.26667rem;
    height: 0.8rem;
    background-color: var(--bgDark-2, var(--homeActiveBgColor));
}

.popup-info .wallet .txt[data-v-44e97c4d],
.popup-info .balance .txt[data-v-44e97c4d] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.popup-info .wallet .txt img[data-v-44e97c4d],
.popup-info .balance .txt img[data-v-44e97c4d] {
    width: 0.4rem;
    height: 0.4rem;
    margin-right: 0.13333rem;
}

.popup-info .wallet .txt .num[data-v-44e97c4d],
.popup-info .balance .txt .num[data-v-44e97c4d] {
    font-size: 0.37333rem;
    color: var(--text_color_L1);
    padding-left: 0.26667rem;
}

.popup-info .wallet .txt .num.yellow[data-v-44e97c4d],
.popup-info .balance .txt .num.yellow[data-v-44e97c4d] {
    color: var(--norm_secondary-color);
}

.popup-info .wallet .bg333[data-v-44e97c4d],
.popup-info .balance .bg333[data-v-44e97c4d] {
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.popup-info .wallet .bg7172[data-v-44e97c4d],
.popup-info .balance .bg7172[data-v-44e97c4d] {
    font-size: 0.32rem;
    color: var(--main-color);
}

.popup-info .wallet .bet[data-v-44e97c4d],
.popup-info .balance .bet[data-v-44e97c4d] {
    border: 0.01333rem solid #00AF54;
    border-radius: 0.13333rem;
    height: 0.64rem;
    line-height: 0.64rem;
    color: #00AF54;
    padding: 0 0.26667rem;
}

.popup-btn[data-v-44e97c4d] {
    height: 1.6rem;
}

.popup-btn .left[data-v-44e97c4d] {
    width: 45%;
}

.popup-btn .left .btn[data-v-44e97c4d] {
    height: 1.6rem;
    font-size: 0.42667rem;
    border-radius: 0;
    color: var(--text_color_L2);
    background-color: #00AF54;
}

.popup-btn .right[data-v-44e97c4d] {
    width: 55%;
}

.popup-btn .right .btn[data-v-44e97c4d] {
    height: 1.6rem;
    font-size: 0.42667rem;
    border-radius: 0;
    color: #fff;
    background-color: #00AF54;
}

.popup-btn .right .noActive[data-v-44e97c4d] {
    background-color: #00AF54;
    color: var(--text_color_L2);
}

.PreSaleRule[data-v-44e97c4d] {
    width: 7.04rem;
}

.PreSaleRule .head[data-v-44e97c4d] {
    height: 1.2rem;
    line-height: 1.2rem;
    color: #fff;
    font-size: 0.4rem;
    text-align: center;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: left center;
    background-image: url(/assets/png/wingoPreSaleBg-6566ea95.png);
}

.PreSaleRule .body[data-v-44e97c4d] {
    max-height: 8rem;
    overflow-y: auto;
    padding: 0.4rem;
    font-size: 0.32rem;
    line-height: 0.8rem;
}

.PreSaleRule .body[data-v-44e97c4d] p {
    margin-bottom: 0.2rem;
    line-height: 0.53333rem;
}

.PreSaleRule .foot[data-v-44e97c4d] {
    height: 1.86667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.PreSaleRule .foot .btn[data-v-44e97c4d] {
    width: 60%;
    background: var(--main_gradient-color);
    border-radius: 0.53333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    font-size: 0.37333rem;
    color: #fff;
}

.Tips[data-v-44e97c4d] {
    width: 8rem;
    height: 2.13333rem;
    line-height: 2.13333rem;
    background: var(--bg_color_L2);
    border: 0.01333rem solid var(--borderColor-5);
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.Tips>div[data-v-44e97c4d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    overflow-y: hidden;
}

.Tips>div img[data-v-44e97c4d] {
    width: 1.17333rem;
    height: 1.17333rem;
    margin-top: 0.45333rem;
}

.Tips>div .font36[data-v-44e97c4d] {
    color: var(--text_color_L1);
    font-weight: 700;
    font-size: 0.48rem;
    margin-left: 0.32rem;
}

.GameList__C-region[data-v-44e97c4d] {
    height: 1.2rem;
    line-height: 1.2rem;
    overflow: hidden;
    padding: 0 0.26667rem;
    margin: 0.26667rem 0;
}

.GameList__C-region .item[data-v-44e97c4d] {
    width: calc(33.3% - 0.53333rem);
    position: relative;
    text-align: center;
    font-size: 0.48rem;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

.GameList__C-region .item[data-v-44e97c4d]:nth-child(1) {
    background: var(--bg_color_L2);
    border-radius: 0.13333rem 0 0 0.13333rem;
}

.GameList__C-region .item[data-v-44e97c4d]:nth-child(1):after {
    position: absolute;
    top: 0;
    right: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-bottom: 1.2rem solid #fff;
    border-right: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

.GameList__C-region .item[data-v-44e97c4d]:nth-child(2) {
    background: var(--bg_color_L2);
}

.GameList__C-region .item[data-v-44e97c4d]:nth-child(2):after {
    position: absolute;
    top: 0;
    right: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-top: 1.2rem solid #fff;
    border-right: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-44e97c4d]:nth-child(2):after {
    left: -0.66667rem;
    right: unset;
}

.GameList__C-region .item[data-v-44e97c4d]:nth-child(2):before {
    position: absolute;
    top: 0;
    left: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-top: 1.2rem solid #fff;
    border-left: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-44e97c4d]:nth-child(2):before {
    right: -0.66667rem;
    left: unset;
}

.GameList__C-region .item[data-v-44e97c4d]:nth-child(3) {
    background: var(--bg_color_L2);
    border-radius: 0 0.13333rem 0.13333rem 0;
}

.GameList__C-region .item[data-v-44e97c4d]:nth-child(3):before {
    position: absolute;
    top: 0;
    left: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-bottom: 1.2rem solid #fff;
    border-left: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-44e97c4d]:nth-child(3):before {
    right: -0.66667rem;
    left: unset;
}

.GameList__C-region .item.action[data-v-44e97c4d] {
    color: #fff;
}

.GameList__C-region .item.action[data-v-44e97c4d]:nth-child(1) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-44e97c4d]:nth-child(1):after {
    border-bottom: 1.2rem solid var(--borderColor-5);
}

.GameList__C-region .item.action[data-v-44e97c4d]:nth-child(2) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-44e97c4d]:nth-child(2):after {
    border-top: 1.2rem solid var(--borderColor-5);
}

.GameList__C-region .item.action[data-v-44e97c4d]:nth-child(2):before {
    border-top: 1.2rem solid #00AF54;
}

.GameList__C-region .item.action[data-v-44e97c4d]:nth-child(3) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-44e97c4d]:nth-child(3):before {
    border-bottom: 1.2rem solid #00AF54;
}

.GameList__C-time[data-v-44e97c4d] {
    padding-left: 0.2rem;
    overflow-y: auto;
    height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameList__C-time .item[data-v-44e97c4d] {
    position: relative;
    white-space: nowrap;
    background-color: #fff;
    margin: 0 0.10667rem;
    padding: 0.04rem 0.16rem 0;
    text-align: center;
    border-radius: 0.13333rem 0.13333rem 0 0;
}

.GameList__C-time .item .week[data-v-44e97c4d] {
    font-size: 0.16rem;
    color: var(--text_color_L1);
}

.GameList__C-time .item .time[data-v-44e97c4d] {
    font-size: 0.16rem;
    color: var(--text_color_L2);
}

.GameList__C-time .item[data-v-44e97c4d]:after,
.GameList__C-time .item[data-v-44e97c4d]:before {
    content: "";
    width: 0.4rem;
    height: 0.4rem;
    position: absolute;
    bottom: 0;
    z-index: 9;
}

.GameList__C-time .item[data-v-44e97c4d]:after {
    background: -webkit-radial-gradient( 100% 0, circle, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    background: radial-gradient( circle at 100% 0, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    right: -0.4rem;
}

html:lang(ar) .GameList__C-time .item[data-v-44e97c4d]:after {
    left: -0.4rem;
    right: unset;
}

.GameList__C-time .item[data-v-44e97c4d]:before {
    background: -webkit-radial-gradient( 0 0, circle, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    background: radial-gradient( circle at 0 0, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    left: -0.4rem;
}

html:lang(ar) .GameList__C-time .item[data-v-44e97c4d]:before {
    right: -0.4rem;
    left: unset;
}

.GameList__C-time .item.active[data-v-44e97c4d] {
    background-color: var(--main-color);
    color: #fff;
    z-index: 10;
}

.GameList__C-time .item.active .week[data-v-44e97c4d],
.GameList__C-time .item.active .time[data-v-44e97c4d] {
    color: #fff;
}

.GameList__C-time .item.active[data-v-44e97c4d]:before {
    background: -webkit-radial-gradient( 0 0, circle, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    background: radial-gradient( circle at 0 0, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    left: -0.4rem;
    z-index: 10;
}

html:lang(ar) .GameList__C-time .item.active[data-v-44e97c4d]:before {
    right: -0.4rem;
    left: unset;
}

.GameList__C-time .item.active[data-v-44e97c4d]:after {
    background: -webkit-radial-gradient( 100% 0, circle, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    background: radial-gradient( circle at 100% 0, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    right: -0.4rem;
    z-index: 10;
}

html:lang(ar) .GameList__C-time .item.active[data-v-44e97c4d]:after {
    left: -0.4rem;
    right: unset;
}

.GameList__C-city[data-v-44e97c4d] {
    border-top: 0.02667rem solid #fff;
    overflow-y: auto;
    height: 0.6rem;
    height: 1.17333rem;
    background-color: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameList__C-city .item[data-v-44e97c4d] {
    height: 0.93333rem;
    line-height: 0.93333rem;
    white-space: nowrap;
    margin: 0.08rem 0.10667rem;
    padding: 0 0.10667rem;
    text-align: center;
    color: #fff;
}

.GameList__C-city .item.action[data-v-44e97c4d] {
    background-color: #fff;
    color: var(--main-color);
    border-radius: 0.06667rem;
}

.GameList__C-bet[data-v-44e97c4d] {
    width: 100%;
    margin-top: 0.2rem;
    padding: 0 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 1.06667rem;
    overflow-x: scroll;
}

.GameList__C-bet ul[data-v-44e97c4d] {
    margin: 0;
    padding: 0;
    list-style: none;
    -webkit-flex-wrap: nowrap;
    flex-wrap: nowrap;
    white-space: nowrap;
}

.GameList__C-bet .item[data-v-44e97c4d] {
    -webkit-box-flex: 0;
    -webkit-flex: 0 0 auto;
    flex: 0 0 auto;
    height: 0.93333rem;
    padding: 0.25333rem 0.88rem;
    background: var(--bg_color_L2);
    border-radius: 0.16rem;
    margin-right: 0.32rem;
    color: var(--text_color_L2);
}

.GameList__C-bet .item.action[data-v-44e97c4d] {
    color: #fff;
    background: var(--main_gradient-color2);
}

.Betting__C-mark[data-v-44e97c4d] {
    width: 100%;
    height: 100%;
    background: var(--bgcolor-32);
    position: fixed;
    z-index: 99;
    top: 0;
    left: 0;
    color: #fff;
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

html:lang(ar) .Betting__C-mark[data-v-44e97c4d] {
    right: 0;
    left: unset;
    direction: ltr;
}

.Betting__C-mark>div[data-v-44e97c4d] {
    width: 5.86667rem;
    height: 1.33333rem;
    line-height: 1.33333rem;
    display: inline-block;
    border-radius: 0.26667rem;
    border: 0.01333rem solid #fff;
    font-size: 0.42667rem;
    color: #fff;
    font-weight: 700;
    padding: 0 0.4rem 0 2.08rem;
}

.Betting__C-bet[data-v-44e97c4d] {
    margin-top: 0.4rem;
    padding: 0 0.26667rem;
}

.Betting__C-bet .tit[data-v-44e97c4d] {
    height: 0.53333rem;
    line-height: 0.53333rem;
}

.Betting__C-bet .tit-select[data-v-44e97c4d] {
    padding-left: 0.26667rem;
    font-size: 0.42667rem;
    font-weight: 700;
    border-left: 0.08rem solid var(--main-color);
}

.Betting__C-bet .tit-list .check[data-v-44e97c4d] {
    padding-left: 0.26667rem;
    color: var(--text_color_L2);
}

.Betting__C-bet .tit-list .check-item[data-v-44e97c4d] {
    height: 0.42667rem;
    width: 0.42667rem;
    border-radius: 0.42667rem;
    border: 0.02667rem solid #c9c9c9;
    margin-right: 0.10667rem;
}

.Betting__C-bet .tit-list .check.action[data-v-44e97c4d] {
    color: #00AF54;
}

.Betting__C-bet .tit-list .check.action .check-item[data-v-44e97c4d] {
    border: 0.01333rem solid #00AF54;
    position: relative;
}

.Betting__C-bet .tit-list .check.action .check-item[data-v-44e97c4d]:after {
    content: "";
    display: block;
    border-radius: 0.26667rem;
    background-color: #00AF54;
    width: 0.26667rem;
    height: 0.26667rem;
    position: absolute;
    left: 0.05333rem;
    top: 0.05333rem;
}

html:lang(ar) .Betting__C-bet .tit-list .check.action .check-item[data-v-44e97c4d]:after {
    right: 0.05333rem;
    left: unset;
}

.Betting__C-bet .nList[data-v-44e97c4d] {
    background: var(--bg_color_L2);
    border-radius: 0.32rem;
    padding: 0.26667rem;
    margin-top: 0.4rem;
}

.Betting__C-bet .nList .Ntit[data-v-44e97c4d] {
    line-height: 0.74667rem;
    font-size: 0.42667rem;
    color: var(--text_color_L3);
    font-weight: 400;
}

.Betting__C-bet .nList .list[data-v-44e97c4d] {
    width: 100%;
}

.Betting__C-bet .nList .list .item[data-v-44e97c4d] {
    width: 20%;
}

.Betting__C-bet .nList .list .item .number[data-v-44e97c4d] {
    width: 1.06667rem;
    height: 1.06667rem;
    font-size: 0.42667rem;
    font-weight: 700;
    color: var(--text_color_L2);
    background: url(/assets/svg/nbg-dba06970.svg) no-repeat center center;
    background-size: cover;
}

.Betting__C-bet .nList .list .item .number.action[data-v-44e97c4d] {
    color: #00AF54;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
}

.Footer__C[data-v-44e97c4d] {
    width: 100%;
    position: fixed;
    left: auto;
    bottom: 0;
    height: 1.6rem;
    z-index: 98;
}

.Footer__C .nav[data-v-44e97c4d] {
    height: 1.6rem;
    background-color: #fee;
    max-width: 10rem;
}

.Footer__C .nav .left[data-v-44e97c4d] {
    width: 55%;
}

.Footer__C .nav .left .item[data-v-44e97c4d] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    padding-left: 0.26667rem;
    color: var(--main-color);
}

.Footer__C .nav .left .item .txt[data-v-44e97c4d] {
    margin-bottom: 0.08rem;
}

.Footer__C .nav .left .item .num[data-v-44e97c4d] {
    color: #00AF54;
    font-weight: 600;
}

.Footer__C .bet-btn[data-v-44e97c4d] {
    width: 40%;
    background-color: #00AF54;
    color: #fff;
    font-size: 0.48rem;
    font-weight: 600;
}

.Footer__C .disabled-btn[data-v-44e97c4d] {
    width: 40%;
    background-color: var(--button_dis_color);
    color: var(--text_color_L2);
    font-size: 0.48rem;
    font-weight: 400;
    pointer-events: none;
}

.RecordNav__C[data-v-44e97c4d] {
    width: calc(100% - 0.64rem);
    height: 1.17333rem;
    line-height: 1.17333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    margin: 0.32rem auto 0;
    border-radius: 0.16rem;
    overflow: hidden;
}

.RecordNav__C>div[data-v-44e97c4d] {
    width: 50%;
    height: 100%;
    background: var(--bgDark-3, var(--bg_color_L2));
    font-size: 0.42667rem;
    color: var(--text_color_L2);
    text-align: center;
    overflow: hidden;
}

.RecordNav__C>div.active[data-v-44e97c4d] {
    background: var(--dark-linerGradien-91, var(--main_gradient-color2));
    font-weight: 600;
    color: #fff;
}

.GameRecord__C[data-v-44e97c4d] {
    width: calc(100% - 0.69333rem);
    margin: 0.26667rem auto 1.6rem;
    text-align: center;
    font-size: 0.32rem;
}

.GameRecord__C-head[data-v-44e97c4d] {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--bgDark-2, var(--main-color));
    border-radius: 0.13333rem 0.13333rem 0 0;
    font-weight: 600;
    font-size: 0.37333rem;
    color: #fff;
}

.GameRecord__C-body[data-v-44e97c4d] {
    color: var(--text_color_L1);
    font-size: 0.32rem;
    background: var(--darkBg, var(--bg_color_L1));
    border-radius: 0 0 0.13333rem 0.13333rem;
}

.GameRecord__C-body[data-v-44e97c4d] .van-row {
    min-height: 1.30667rem;
    border-bottom: 0.01333rem solid var(--bgDark-2, var(--saveTextColor-3));
}

.GameRecord__C-body .details[data-v-44e97c4d] {
    width: 100%;
    border: 0.01333rem solid var(--borderColor-5);
    border-radius: 0.26667rem;
    padding: 0.33333rem;
}

.GameRecord__C-body .details .tit[data-v-44e97c4d] {
    font-size: 0.4rem;
    color: var(--text_color_L1);
    margin-bottom: 0.26667rem;
    font-weight: 700;
}

.GameRecord__C-body .details .tit img[data-v-44e97c4d] {
    width: 0.64rem;
    height: 0.64rem;
    position: relative;
    top: 0.13333rem;
}

.GameRecord__C-body .details .tag-read img[data-v-44e97c4d] {
    width: 0.32rem;
    height: 0.32rem;
}

.GameRecord__C-body .details .detailLi[data-v-44e97c4d] {
    min-height: 0.66667rem;
    line-height: 0.66667rem;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
}

.GameRecord__C-body .details .detailLi .red[data-v-44e97c4d] {
    color: var(--main_gradient-color);
}

.GameRecord__C-body .details .detailLi .prize[data-v-44e97c4d] {
    background: var(--bgDark-4, --walletBgColor-1);
    margin-bottom: 0.16rem;
    padding: 0.26667rem;
    border-radius: 0.26667rem;
}

.GameRecord__C-body .details .detailLi .prize[data-v-44e97c4d]:last-child {
    margin-bottom: 0;
}

.GameRecord__C-body .details .detailLi .selectItem0[data-v-44e97c4d],
.GameRecord__C-body .details .detailLi .selectItem1[data-v-44e97c4d],
.GameRecord__C-body .details .detailLi .selectItem2[data-v-44e97c4d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameRecord__C-body .details .detailLi .selectItem0>div[data-v-44e97c4d]:nth-of-type(1),
.GameRecord__C-body .details .detailLi .selectItem1>div[data-v-44e97c4d]:nth-of-type(1),
.GameRecord__C-body .details .detailLi .selectItem2>div[data-v-44e97c4d]:nth-of-type(1) {
    width: 45%;
}

.GameRecord__C-body .details .detailLi .selectItem0>div[data-v-44e97c4d]:nth-of-type(2),
.GameRecord__C-body .details .detailLi .selectItem1>div[data-v-44e97c4d]:nth-of-type(2),
.GameRecord__C-body .details .detailLi .selectItem2>div[data-v-44e97c4d]:nth-of-type(2) {
    width: 0.13333rem;
}

.GameRecord__C-body .details .detailLi .selectItem0 span[data-v-44e97c4d],
.GameRecord__C-body .details .detailLi .selectItem1 span[data-v-44e97c4d],
.GameRecord__C-body .details .detailLi .selectItem2 span[data-v-44e97c4d] {
    font-weight: 700;
    font-size: 0.42667rem;
    color: var(--darkTextW, --text_color_L1);
    padding-left: 0;
    text-align: center;
}

.GameRecord__C-body .details .detailLi .selectItem0 span[data-v-44e97c4d] {
    color: #00AF54;
}

.GameRecord__C-body .details .detailLi .prize-tit[data-v-44e97c4d] {
    text-align: left;
    font-size: 0.37333rem;
    color: var(--darkTextW, --text_color_L1);
    padding-left: 0.26667rem;
}

.GameRecord__C-body .details .detailLi .action0[data-v-44e97c4d] {
    color: #00AF54 !important;
    font-weight: 700;
    font-size: 0.42667rem;
}

.GameRecord__C-body .details .detailLi .action1[data-v-44e97c4d],
.GameRecord__C-body .details .detailLi .action2[data-v-44e97c4d] {
    font-weight: 700;
    font-size: 0.42667rem;
}

.GameRecord__C-body .details .detailLi .prize-box[data-v-44e97c4d] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
}

.GameRecord__C-body .details .detailLi .prize-box-item[data-v-44e97c4d] {
    text-align: left;
    padding-left: 0.26667rem;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: var(--text_color_L1);
    font-size: 0.37333rem;
    font-weight: 500;
}

.GameRecord__C-body .details .detailLi .c-flex-warp[data-v-44e97c4d] {
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.GameRecord__C-body .details .detailLi .select[data-v-44e97c4d] {
    margin-left: 0.53333rem;
}

.GameRecord__C-body .details .detailLi .select .ball[data-v-44e97c4d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 0.64rem;
    height: 0.42667rem;
    line-height: 0.42667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-left: 0.13333rem;
    margin-bottom: 0.13333rem;
    background: var(--main-color);
    border-radius: 0.08rem;
    color: #fff;
}

.GameRecord__C-body .details .detailLi .Bet-box.pb[data-v-44e97c4d] {
    padding-bottom: 0.06667rem;
}

.GameRecord__C-body .details .detailLi .Bet-box ul li[data-v-44e97c4d] {
    height: 0.26667rem;
    line-height: 0.26667rem;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    margin: 0.02667rem 0.05333rem;
    background-color: var(--gray-color-1);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionViolet[data-v-44e97c4d] {
    color: #fff;
    background-color: var(--bgcolor-21);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionRed[data-v-44e97c4d] {
    color: #fff;
    background-color: var(--norm_red-color);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionGreen[data-v-44e97c4d] {
    color: #fff;
    background-color: var(--bgColor-13);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionRedGreen[data-v-44e97c4d] {
    color: #fff;
    background-color: var(--norm_red-color);
    background-image: var(--linearGradien-21);
}

.GameRecord__C-body .details .detailLi .Bet-box .actionBtn[data-v-44e97c4d] {
    height: 0.34667rem;
    line-height: 0.34667rem;
    display: inline-block;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    background-color: var(--norm_red-color);
    color: #fff;
}

.GameRecord__C-body .goItem[data-v-44e97c4d] {
    height: 1.30667rem;
    line-height: 1.30667rem;
    text-align: center;
    color: var(--darkTextW, --main-color);
    font-size: 0.32rem;
}

.GameRecord__C-body .li[data-v-44e97c4d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
    width: 0.4rem;
    height: 0.4rem;
    border-radius: 50%;
    background: var(--walletBgColor-1);
    margin: 0 0.02667rem;
}

.GameRecord__C-body .li .circle-black[data-v-44e97c4d] {
    background-color: var(--walletBgColor-1);
    color: var(--text_color_L1);
    font-size: 0.32rem;
}

.GameRecord__C-body .time[data-v-44e97c4d] {
    color: var(--textM3, var(--text_color_L2));
    font-size: 0.32rem;
    height: 100%;
}

.GameRecord__C-body .numList[data-v-44e97c4d] {
    width: 3rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    position: relative;
    top: 0.4rem;
}

.GameRecord__C-body .numList .numItem[data-v-44e97c4d] {
    width: 0.4rem;
    height: 0.4rem;
    background: var(--walletBgColor-1);
    color: var(--text_color_L1);
    font-size: 0.32rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    border-radius: 50%;
}

.GameRecord__C-body .redNumItem[data-v-44e97c4d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot[data-v-44e97c4d] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.GameRecord__C-foot-previous[data-v-44e97c4d],
.GameRecord__C-foot-next[data-v-44e97c4d] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot-previous.disabled[data-v-44e97c4d],
.GameRecord__C-foot-next.disabled[data-v-44e97c4d] {
    background: var(--gray-color-1);
    pointer-events: none;
}

.GameRecord__C-foot-previous.disabled .GameRecord__C-icon[data-v-44e97c4d],
.GameRecord__C-foot-next.disabled .GameRecord__C-icon[data-v-44e97c4d] {
    color: var(--saveTextColor-7);
}

.GameRecord__C-foot-previous .GameRecord__C-icon[data-v-44e97c4d],
.GameRecord__C-foot-next .GameRecord__C-icon[data-v-44e97c4d] {
    color: #fff;
}

.MyGameRecord__C[data-v-44e97c4d] {
    width: 100%;
    margin: 0.32rem auto 1.6rem;
}

.MyGameRecord__C-head[data-v-44e97c4d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
    background-color: var(--darkBg, var(--bg_color_L2));
    padding: 0.32rem 0.32rem 0;
}

.MyGameRecord__C-head-moreB[data-v-44e97c4d] {
    border: 0.01333rem solid var(--main-color);
    height: 0.8rem;
    line-height: 0.8rem;
    border-radius: 0.26667rem;
    padding: 0 0.72rem 0 0.24rem;
    color: var(--main-color);
    font-size: 0.32rem;
    position: relative;
    margin-bottom: 0.4rem;
}

.MyGameRecord__C-head-moreB[data-v-44e97c4d]:after {
    content: "";
    display: block;
    width: 0.4rem;
    height: 0.4rem;
    position: absolute;
    top: 50%;
    right: 0.2rem;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    background-image: url(/assets/jpg/moreBtn-ffccf44d.jpg);
    background-repeat: no-repeat;
    background-size: 0.4rem;
    background-position: center;
}

html:lang(ar) .MyGameRecord__C-head-moreB[data-v-44e97c4d]:after {
    left: 0.2rem;
    right: unset;
    -webkit-transform: scaleX(-1);
    transform: scaleX(-1);
    top: 25%;
}

.MyGameRecord__C-body[data-v-44e97c4d] {
    padding: 0 0.32rem;
}

.MyGameRecord__C-body-empty[data-v-44e97c4d] {
    height: 5.33333rem;
}

.MyGameRecord__C-foot[data-v-44e97c4d] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecord__C-foot-page[data-v-44e97c4d] {
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.MyGameRecord__C-foot-previous[data-v-44e97c4d],
.MyGameRecord__C-foot-next[data-v-44e97c4d] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.MyGameRecord__C-foot-previous.disabled[data-v-44e97c4d],
.MyGameRecord__C-foot-next.disabled[data-v-44e97c4d] {
    background: var(--gray-color-1);
    pointer-events: none;
}

.MyGameRecord__C-foot-previous.disabled .MyGameRecord__C-icon[data-v-44e97c4d],
.MyGameRecord__C-foot-next.disabled .MyGameRecord__C-icon[data-v-44e97c4d] {
    color: var(--saveTextColor-7);
}

.MyGameRecord__C-foot-previous .MyGameRecord__C-icon[data-v-44e97c4d],
.MyGameRecord__C-foot-next .MyGameRecord__C-icon[data-v-44e97c4d] {
    color: #fff;
}

.list[data-v-44e97c4d] {
    padding: 0 0.26667rem;
}

.list .hb[data-v-44e97c4d] {
    background-color: #fff;
    color: var(--colorText-3);
    font-size: 0.37333rem;
}

.list .hb .item[data-v-44e97c4d] {
    padding: 0.21333rem;
    border-bottom: 0.02667rem solid var(--gray-color-1);
    color: var(--colorText-3);
    font-size: 0.37333rem;
}

.list .hb .item.action[data-v-44e97c4d] {
    padding: 0.32rem 0.26667rem;
}

.list .hb .item .goItem[data-v-44e97c4d] {
    height: 0.42667rem;
}

.list .hb .li[data-v-44e97c4d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
    width: 0.42667rem !important;
    height: 0.42667rem;
    border: 0.02667rem solid var(--gray-color-1);
    border-radius: 0.42667rem;
    margin-right: 0.10667rem;
    color: var(--gray-color-1);
}

.list .hb .li.action[data-v-44e97c4d] {
    font-size: 0.32rem;
    border: none;
    color: #fff;
    background-color: var(--norm_red-color);
}

.list .hb .li.circle-black[data-v-44e97c4d] {
    border: 0.02667rem solid var(--text_color_L1);
    color: var(--text_color_L1);
    background: var(--bgColor-6);
}

.list .hb .li.actionH[data-v-44e97c4d] {
    border: none;
    color: #fff;
    background-color: var(--borderColor-4);
}

.list .hb .li.actionL[data-v-44e97c4d] {
    border: 0.01333rem solid var(--borderColor-4);
    color: var(--borderColor-4);
    background-color: #fff;
}

.list .hb .li.actionO[data-v-44e97c4d] {
    border: none;
    color: #fff;
    background-color: var(--norm_secondary-color);
}

.list .hb .li.actionE[data-v-44e97c4d] {
    border: 0.01333rem solid var(--norm_secondary-color);
    color: var(--norm_secondary-color);
    background-color: #fff;
}

.list .hb .qiu[data-v-44e97c4d] {
    width: 3rem;
    position: relative;
}

.list .hb .qiu .line-canvas[data-v-44e97c4d] {
    position: absolute !important;
    top: 0.12rem;
    left: 0;
    height: 0.73333rem;
    width: 2.61333rem;
    z-index: 99;
}

html:lang(ar) .list .hb .qiu .line-canvas[data-v-44e97c4d] {
    right: 0.12rem;
    left: unset;
}

.list .hb .red[data-v-44e97c4d] {
    color: var(--colorText-2);
}

.list .hb .green[data-v-44e97c4d] {
    color: var(--norm_green-color);
}

.list .hb .blue[data-v-44e97c4d] {
    color: var(--colorText-7);
}

.list .hb .box .li[data-v-44e97c4d] {
    display: block;
    height: 0.13333rem;
    width: 0.13333rem;
    border-radius: 0.13333rem;
    margin: 0 0.06667rem;
}

.list .hb .item[data-v-44e97c4d] {
    padding: 0.53333rem 0.4rem;
}

.list .hb .item .info[data-v-44e97c4d] {
    width: 100%;
}

.list .hb .item .info .issueName .state[data-v-44e97c4d] {
    color: #fff;
    padding: 0.10667rem 0.26667rem;
    margin-left: 0.26667rem;
    border-radius: 0.53333rem;
    font-size: 0.32rem;
    display: inline-block;
    text-align: center;
}

.list .hb .item .info .issueName .state.red[data-v-44e97c4d] {
    background-color: var(--norm_red-color);
}

.list .hb .item .info .issueName .state.green[data-v-44e97c4d] {
    background-color: var(--norm_green-color);
}

.list .hb .item .info .tiem[data-v-44e97c4d] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
    margin-top: 0.13333rem;
}

.list .hb .item .info .money[data-v-44e97c4d] {
    font-weight: 600;
    font-size: 0.42667rem;
}

.list .hb .item .info .money .fail[data-v-44e97c4d] {
    color: var(--norm_red-color);
}

.list .hb .item .info .money .success[data-v-44e97c4d] {
    color: var(--bgColor-13);
}

.list .hb .details[data-v-44e97c4d] {
    padding: 0.4rem;
    border-bottom: 0.01333rem solid var(--gray-color-1);
}

.list .hb .details .tit[data-v-44e97c4d] {
    font-size: 0.4rem;
    color: var(--text_color_L1);
    margin-bottom: 0.26667rem;
    font-weight: 700;
}

.list .hb .details .tit img[data-v-44e97c4d] {
    width: 0.64rem;
    height: 0.64rem;
    position: relative;
    top: 0.13333rem;
}

.list .hb .details .tag-read img[data-v-44e97c4d] {
    width: 0.32rem;
    height: 0.32rem;
}

.list .hb .details .detailLi[data-v-44e97c4d] {
    min-height: 0.66667rem;
    line-height: 0.66667rem;
    background: var(--bgColor-6);
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
    margin-bottom: 0.21333rem;
}

.list .hb .details .detailLi .red[data-v-44e97c4d] {
    color: var(--main_gradient-color);
}

.list .hb .details .detailLi .result[data-v-44e97c4d] {
    height: 0.93333rem;
    line-height: 0.93333rem;
    background: var(--main-color);
    border-radius: 0.13333rem 0.13333rem 0 0;
    color: #fff;
    text-align: left;
    padding: 0 --0.26667rem;
}

.list .hb .details .detailLi .prize-tit[data-v-44e97c4d] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.list .hb .details .detailLi .prize-box[data-v-44e97c4d] {
    border-bottom: 0.01333rem solid #fff;
}

.list .hb .details .detailLi .prize-box-item[data-v-44e97c4d] {
    text-align: center;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.list .hb .details .detailLi .c-flex-warp[data-v-44e97c4d] {
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.list .hb .details .detailLi .select[data-v-44e97c4d] {
    margin-left: 0.53333rem;
}

.list .hb .details .detailLi .select .ball[data-v-44e97c4d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 0.64rem;
    height: 0.42667rem;
    line-height: 0.42667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-left: 0.13333rem;
    margin-bottom: 0.13333rem;
    background: var(--main-color);
    border-radius: 0.08rem;
    color: #fff;
}

.list .hb .details .detailLi .Bet-box.pb[data-v-44e97c4d] {
    padding-bottom: 0.06667rem;
}

.list .hb .details .detailLi .Bet-box ul li[data-v-44e97c4d] {
    height: 0.26667rem;
    line-height: 0.26667rem;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    margin: 0.02667rem 0.05333rem;
    background-color: var(--gray-color-1);
}

.list .hb .details .detailLi .Bet-box ul li.actionViolet[data-v-44e97c4d] {
    color: #fff;
    background-color: var(--bgcolor-21);
}

.list .hb .details .detailLi .Bet-box ul li.actionRed[data-v-44e97c4d] {
    color: #fff;
    background-color: var(--norm_red-color);
}

.list .hb .details .detailLi .Bet-box ul li.actionGreen[data-v-44e97c4d] {
    color: #fff;
    background-color: var(--bgColor-13);
}

.list .hb .details .detailLi .Bet-box ul li.actionRedGreen[data-v-44e97c4d] {
    color: #fff;
    background-color: var(--norm_red-color);
    background-image: var(--linearGradien-21);
}

.list .hb .details .detailLi .Bet-box .actionBtn[data-v-44e97c4d] {
    height: 0.34667rem;
    line-height: 0.34667rem;
    display: inline-block;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    background-color: var(--norm_red-color);
    color: #fff;
}

.areList[data-v-44e97c4d] {
    margin: 0.53333rem;
    position: relative;
}

.areList .close[data-v-44e97c4d] {
    position: absolute;
    top: -1.6rem;
    left: 50%;
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
    width: 0.8rem;
    height: 0.8rem;
}

.areList .items h1[data-v-44e97c4d] {
    color: var(--darkTextW, var(--borderColor-26));
    font-size: 0.42667rem;
}

.areList .items .itemsC[data-v-44e97c4d] {
    margin: 0.26667rem 0 0.4rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    gap: 0.2rem;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.areList .items .itemsC>div[data-v-44e97c4d] {
    width: calc((100% - 0.53333rem) / 2);
    background: var(--bgDark-3, var(--homeActiveBgColor));
    border-radius: 0.13333rem;
    min-height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
}

.areList .items .itemsC .isActive[data-v-44e97c4d] {
    background: var(--norm_red-color);
    color: #fff;
}

.titlebets[data-v-44e97c4d] {
    font-size: 0.29333rem;
    color: var(--main-color);
}

.border60[data-v-44e97c4d] {
    width: 4.53333rem;
    height: 0.66667rem;
    line-height: 0.66667rem;
    border-radius: 0.8rem;
    border: 0.01333rem solid var(--main-color);
    margin: 0 auto;
    margin-top: 0.30667rem;
}

.bottombg[data-v-44e97c4d] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/arrowbottom-4eb91cbc.png);
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center;
}

.compound2[data-v-44e97c4d],
.compound3[data-v-44e97c4d] {
    padding-top: 0.26667rem;
    max-height: 5.33333rem;
    overflow-y: auto;
}

.compound2 .item[data-v-44e97c4d],
.compound3 .item[data-v-44e97c4d] {
    width: 100%;
    margin-bottom: 0.26667rem;
}

.compound2 .item.item0-3 .box .c-row[data-v-44e97c4d],
.compound3 .item.item0-3 .box .c-row[data-v-44e97c4d] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.21333rem;
}

.compound2 .item.item0-3 .box .num[data-v-44e97c4d],
.compound3 .item.item0-3 .box .num[data-v-44e97c4d] {
    width: calc((100% - 1.28rem) / 7);
    height: 1.13333rem;
    background-size: 1.13333rem 1.13333rem;
}

.compound2 .item.item0-2 .box .c-row[data-v-44e97c4d],
.compound2 .item.item5-2 .box .c-row[data-v-44e97c4d],
.compound3 .item.item0-2 .box .c-row[data-v-44e97c4d],
.compound3 .item.item5-2 .box .c-row[data-v-44e97c4d] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.21333rem;
}

.compound2 .item.item0-2 .box .num[data-v-44e97c4d],
.compound2 .item.item5-2 .box .num[data-v-44e97c4d],
.compound3 .item.item0-2 .box .num[data-v-44e97c4d],
.compound3 .item.item5-2 .box .num[data-v-44e97c4d] {
    width: calc((100% - 1.28rem) / 7);
    height: 0.8rem;
    background-size: 0.8rem 0.8rem;
}

.compound2 .item.item4-2 .box .c-row[data-v-44e97c4d],
.compound3 .item.item4-2 .box .c-row[data-v-44e97c4d] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item4-2 .box .num[data-v-44e97c4d],
.compound3 .item.item4-2 .box .num[data-v-44e97c4d] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-8),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-7),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-6),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-5),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-4),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-2),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-1),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-8),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-7),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-5),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-4),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-2),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-1),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
}

.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-7),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-6),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-4),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-1),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-7),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-4),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-1),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n) {
    margin-left: -0.10667rem;
}

.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-44e97c4d]:nth-child(9n-6) {
    margin-right: 0.42667rem;
}

.compound2 .item.item3-2 .box .c-row[data-v-44e97c4d],
.compound3 .item.item3-2 .box .c-row[data-v-44e97c4d] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item3-2 .box .num[data-v-44e97c4d],
.compound3 .item.item3-2 .box .num[data-v-44e97c4d] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-1),
.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-2),
.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-3),
.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-4),
.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-5),
.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-6),
.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-7),
.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-1),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-2),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-3),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-5),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-6),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-7),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
}

.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-6),
.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-5),
.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-4),
.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-2),
.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-1),
.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-6),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-5),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-2),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-1),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n) {
    margin-left: -0.06667rem;
}

.compound2 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-44e97c4d]:nth-child(8n-4) {
    margin-right: 1.73333rem;
}

.compound2 .item.item2-2 .box .c-row[data-v-44e97c4d],
.compound3 .item.item2-2 .box .c-row[data-v-44e97c4d] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item2-2 .box .num[data-v-44e97c4d],
.compound3 .item.item2-2 .box .num[data-v-44e97c4d] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-1),
.compound2 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-2),
.compound2 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-3),
.compound2 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-4),
.compound2 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-5),
.compound2 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-6),
.compound2 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-7),
.compound2 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n),
.compound3 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-1),
.compound3 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-2),
.compound3 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-3),
.compound3 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-4),
.compound3 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-5),
.compound3 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-6),
.compound3 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n-7),
.compound3 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
    margin-left: -0.01333rem;
}

.compound2 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n),
.compound3 .item.item2-2 .box .num[data-v-44e97c4d]:nth-child(8n) {
    margin-right: 1.33333rem;
}

.compound2 .item.item1-2 .box .c-row[data-v-44e97c4d],
.compound3 .item.item1-2 .box .c-row[data-v-44e97c4d] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item1-2 .box .num[data-v-44e97c4d],
.compound3 .item.item1-2 .box .num[data-v-44e97c4d] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-1),
.compound2 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-2),
.compound2 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-3),
.compound2 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-4),
.compound2 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-5),
.compound2 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-6),
.compound2 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-7),
.compound2 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-8),
.compound2 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-9),
.compound2 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n),
.compound3 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-1),
.compound3 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-2),
.compound3 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-3),
.compound3 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-4),
.compound3 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-5),
.compound3 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-6),
.compound3 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-7),
.compound3 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-8),
.compound3 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n-9),
.compound3 .item.item1-2 .box .num[data-v-44e97c4d]:nth-child(10n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
    margin-left: -0.09333rem;
}

.compound2 .item .box[data-v-44e97c4d],
.compound3 .item .box[data-v-44e97c4d] {
    border-radius: 0.26667rem;
    position: relative;
    width: 100%;
}

.compound2 .item .box .num[data-v-44e97c4d],
.compound3 .item .box .num[data-v-44e97c4d] {
    min-width: 0.8rem;
    min-height: 0.8rem;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: 0.8rem 0.8rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
}

.compound2 .item .box .money[data-v-44e97c4d],
.compound3 .item .box .money[data-v-44e97c4d] {
    text-align: center;
    background-color: var(--gray-color-1);
    position: relative;
    height: 0.53333rem;
    border-radius: 0 0 0.26667rem 0.26667rem;
}

.compound2 .item .box .money .all[data-v-44e97c4d],
.compound3 .item .box .money .all[data-v-44e97c4d] {
    position: relative;
    z-index: 9;
    line-height: 0.8rem;
    font-size: 0.32rem;
    color: #00AF54;
}

.compound2 .item .box .money[data-v-44e97c4d]:after,
.compound3 .item .box .money[data-v-44e97c4d]:after {
    position: absolute;
    top: 0;
    left: 0;
    content: "";
    display: block;
    width: 100%;
    height: 0.21333rem;
    background-color: var(--gray-color-1);
    border-radius: 0 0 50% 50%;
}

.compound2 .item .box .dele[data-v-44e97c4d],
.compound3 .item .box .dele[data-v-44e97c4d] {
    position: absolute;
    right: -0.18667rem;
    top: -0.18667rem;
    height: 0.37333rem;
    width: 0.37333rem;
    border-radius: 0.53333rem;
    background-color: #00AF54;
}

.compound2 .item .box .dele .icon[data-v-44e97c4d],
.compound3 .item .box .dele .icon[data-v-44e97c4d] {
    font-size: 0.26667rem;
}

.compound2 .item.item0-4 .box .c-row[data-v-44e97c4d] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.53333rem;
}

.compound2 .item.item0-4 .box .num[data-v-44e97c4d] {
    width: calc((100% - 2.13333rem) / 5);
    background: var(--main_gradient-color);
    color: #fff;
    border-radius: 0.13333rem;
    min-height: 1.06667rem;
    min-width: 1.33333rem;
}

.compound[data-v-44e97c4d] {
    padding-top: 0.26667rem;
    max-height: 6rem;
    overflow: auto;
}

.compound .item[data-v-44e97c4d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 100%;
    margin-bottom: 0.4rem;
}

.compound .item .title[data-v-44e97c4d] {
    width: 1.38667rem;
    overflow: hidden;
    position: relative;
    text-align: center;
    font-size: 0.42667rem;
    color: var(--text_color_L2);
}

.compound .item .numcontainer[data-v-44e97c4d] {
    width: 7.94667rem;
    margin-left: 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    justify-content: flex-start;
    gap: 0.13333rem;
}

.compound .item .numcontainer .num[data-v-44e97c4d] {
    width: calc((100% - 0.85333rem) / 5);
    height: 0.8rem;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: 0.8rem 0.8rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
    position: relative;
    text-align: center;
    line-height: 0.8rem;
}

.compound .item .numcontainer .num .dele[data-v-44e97c4d] {
    position: absolute;
    right: -0.18667rem;
    top: -0.18667rem;
    height: 0.37333rem;
    width: 0.37333rem;
    border-radius: 0.53333rem;
    background-color: #00AF54;
}

html:lang(ar) .compound .item .numcontainer .num .dele[data-v-44e97c4d] {
    right: unset;
    left: -0.18667rem;
}

.compound .item .numcontainer .num .dele .icon[data-v-44e97c4d] {
    font-size: 0.26667rem;
}

.van-toast[data-v-eb0f5940] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-eb0f5940] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-eb0f5940] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-eb0f5940] {
    height: 80%;
}

.WinningTip__C[data-v-eb0f5940] {
    position: fixed;
    width: 100%;
    height: 100%;
    z-index: 99;
    background-color: var(--bgcolor-32);
    top: 0;
    left: 0;
}

html:lang(ar) .WinningTip__C[data-v-eb0f5940] {
    left: unset;
    right: 0;
}

.WinningTip__C-body[data-v-eb0f5940] {
    position: absolute;
    width: 7.73333rem;
    height: 11.73333rem;
    background-image: url(/assets/png/newmissingviebg-0d3c6b98.png);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
    padding-top: 3.2rem;
}

.WinningTip__C-body.isL[data-v-eb0f5940] {
    background-image: url(/assets/png/newmissingbg-b08ac203.png);
}

.WinningTip__C-body img[data-v-eb0f5940] {
    width: 1.48rem;
    height: 1.48rem;
    margin-top: 0.4rem;
    text-align: center;
}

.WinningTip__C-body .notwinning[data-v-eb0f5940] {
    width: 1.6rem;
    height: 1.6rem;
    background: url(/assets/png/notwinning-7e54c381.png);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    margin: 0 auto;
    margin-top: 0.53333rem;
    margin-bottom: 1.06667rem;
}

.WinningTip__C-body-l1[data-v-eb0f5940] {
    font-weight: 700;
    font-size: 0.64rem;
    text-align: center;
    color: #fff;
    height: 0.77333rem;
    line-height: 0.77333rem;
    margin-bottom: 0.2rem;
}

.WinningTip__C-body-l1.isL[data-v-eb0f5940] {
    color: var(--colorText-38);
}

.WinningTip__C-body-l2[data-v-eb0f5940] {
    height: 0.58667rem;
    line-height: 0.58667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    color: #fff;
    font-size: 0.29333rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-bottom: 0.13333rem;
}

.WinningTip__C-body-l2>div[data-v-eb0f5940] {
    height: 0.58667rem;
    background: var(--norm_red-color);
    border-radius: 0.13333rem;
    padding: 0 0.32rem;
}

.WinningTip__C-body-l2>div[data-v-eb0f5940]:first-child {
    margin-left: 0.32rem;
}

.WinningTip__C-body-l2>div.WinningNum[data-v-eb0f5940] {
    width: 0.53333rem;
    height: 0.53333rem;
    line-height: 0.53333rem;
    margin: 0 0.18667rem;
    padding: 0;
    text-align: center;
    border-radius: 50%;
    background: var(--norm_red-color);
    color: #fff;
    font-size: 0.37333rem;
}

.WinningTip__C-body-l2.type0>div[data-v-eb0f5940] {
    background-image: var(--linearGradien-5);
}

.WinningTip__C-body-l2.type5>div[data-v-eb0f5940] {
    background-image: var(--linearGradien-6);
}

.WinningTip__C-body-l2.type1>div[data-v-eb0f5940],
.WinningTip__C-body-l2.type3>div[data-v-eb0f5940],
.WinningTip__C-body-l2.type7>div[data-v-eb0f5940],
.WinningTip__C-body-l2.type9>div[data-v-eb0f5940] {
    background-color: var(--norm_red-color);
}

.WinningTip__C-body-l2.type2>div[data-v-eb0f5940],
.WinningTip__C-body-l2.type4>div[data-v-eb0f5940],
.WinningTip__C-body-l2.type6>div[data-v-eb0f5940],
.WinningTip__C-body-l2.type8>div[data-v-eb0f5940] {
    background-color: var(--norm_red-color);
}

.WinningTip__C-body-l5[data-v-eb0f5940] {
    height: 1.33333rem;
    margin-top: 0.93333rem;
    margin-bottom: 0.53333rem;
    padding: 0 0.53333rem;
}

.WinningTip__C-body-l5-content[data-v-eb0f5940] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.WinningTip__C-body-l5-content .ball[data-v-eb0f5940] {
    width: 0.93333rem;
    height: 0.8rem;
    line-height: 0.8rem;
    text-align: center;
    font-size: 0.34667rem;
    font-weight: 700;
    color: var(--norm_red-color);
    background: url(/assets/svg/resultanbg-bfa48a61.svg) no-repeat center center;
    background-size: cover;
}

.WinningTip__C-body-l5-content .balltext[data-v-eb0f5940] {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
}

.WinningTip__C-body-l3[data-v-eb0f5940] {
    height: 1.73333rem;
}

.WinningTip__C-body-l3 .isLose[data-v-eb0f5940] {
    font-weight: 700;
    font-size: 0.42667rem;
    line-height: 0.77333rem;
    color: var(--colorText-38);
    text-align: center;
    margin-bottom: 0.34667rem;
    padding-top: 0.4rem;
}

.WinningTip__C-body-l3 .head[data-v-eb0f5940] {
    height: 0.4rem;
    line-height: 0.4rem;
    font-weight: 700;
    font-size: 0.34667rem;
    color: var(--main-color);
    text-align: center;
    margin-bottom: 0.10667rem;
}

.WinningTip__C-body-l3 .bonus[data-v-eb0f5940] {
    height: 0.64rem;
    line-height: 0.64rem;
    font-weight: 700;
    font-size: 0.53333rem;
    color: var(--main-color);
    text-align: center;
    margin-bottom: 0.13333rem;
}

.WinningTip__C-body-l3 .gameDetail[data-v-eb0f5940] {
    height: 0.37333rem;
    line-height: 0.37333rem;
    font-size: 0.29333rem;
    text-align: left;
    padding-left: 1.46667rem;
    color: var(--text_color_L2);
    margin-top: 0.13333rem;
}

.WinningTip__C-body-l4[data-v-eb0f5940] {
    height: 0.64rem;
    line-height: 0.64rem;
    font-size: 0.32rem;
    color: #fff;
    position: absolute;
    left: 0.74667rem;
    bottom: 0.37333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

html:lang(ar) .WinningTip__C-body-l4[data-v-eb0f5940] {
    left: unset;
    right: 0.74667rem;
}

.WinningTip__C-body-l4 .acitveBtn[data-v-eb0f5940] {
    height: 0.56rem;
    width: 0.56rem;
    border-radius: 50%;
    background: var(--winTips);
    border: 0.01333rem solid #fff;
    margin-right: 0.18667rem;
    position: relative;
}

.WinningTip__C-body-l4 .acitveBtn.active[data-v-eb0f5940]:before {
    content: "";
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
    height: 0.24rem;
    width: 0.32rem;
    display: block;
    background-image: url(/assets/png/vector-dc489162.png);
    background-repeat: no-repeat;
    background-size: 0.32rem 0.24rem;
    background-position: center;
}

.WinningTip__C .closeBtn[data-v-eb0f5940] {
    width: 0.8rem;
    height: 0.8rem;
    background-image: url(/assets/png/close-84ce5e6a.png);
    background-repeat: no-repeat;
    background-size: 0.8rem;
    background-position: center;
    position: absolute;
    left: 50%;
    -webkit-transform: translateX(-50%) translateY(100%);
    transform: translate(-50%) translateY(100%);
    bottom: -0.26667rem;
}

.van-toast[data-v-b1e14027] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-b1e14027] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-b1e14027] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-b1e14027] {
    height: 80%;
}

.NewVietnam__C[data-v-b1e14027] {
    padding-bottom: 0.34667rem;
    overflow-y: auto;
    background-color: var(--bgDark-4, var(--bg_color_L1));
}

.NewVietnam__C-head[data-v-b1e14027] {
    height: 1.25333rem;
    background: var(--main_gradient-color);
    padding: 0 0.34667rem;
    position: relative;
}

.NewVietnam__C-head div[data-v-b1e14027] {
    background-repeat: no-repeat;
    background-position: center;
}

.NewVietnam__C-head-bcak[data-v-b1e14027] {
    position: absolute;
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/bcakIcon-b7c1d288.png);
    background-size: 0.64rem;
    left: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
}

html:lang(ar) .NewVietnam__C-head-bcak[data-v-b1e14027] {
    left: unset;
    right: 0.34667rem;
}

.NewVietnam__C-head-logo[data-v-b1e14027] {
    background-size: 2.98667rem 1.12rem;
    height: 1.12rem;
    width: 2.98667rem;
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
}

.NewVietnam__C-head-more[data-v-b1e14027] {
    position: absolute;
    width: 1.54667rem;
    height: 0.64rem;
    right: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

html:lang(ar) .NewVietnam__C-head-more[data-v-b1e14027] {
    right: unset;
    left: 0.34667rem;
}

.NewVietnam__C-head-more>div[data-v-b1e14027] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/kefu-b361c42f.png);
    background-size: 0.64rem;
}

.NewVietnam__C-head-more>div[data-v-b1e14027]:last-child {
    background-image: url(/assets/png/voice-62dbf38c.png);
}

.NewVietnam__C-head-more>div:last-child.disableVoice[data-v-b1e14027] {
    background-image: url(/assets/png/voice-off-633f5ccc.png);
}

.NewVietnam__C[data-v-b1e14027] .driver-close-btn,
.NewVietnam__C[data-v-b1e14027] .driver-prev-btn {
    display: none;
}

.popup[data-v-b1e14027] {
    overflow-y: visible !important;
    border-radius: 0.13333rem 0.13333rem 0 0;
    width: 100%;
}

.popup[data-v-b1e14027] .van-popup {
    overflow-y: visible !important;
    border-radius: 0.26667rem 0.26667rem 0 0;
}

.popup .box[data-v-b1e14027] {
    position: relative;
}

.popup .box .close[data-v-b1e14027] {
    position: absolute;
    top: -1.06667rem;
    left: 50%;
    -webkit-transform: translate(-50%, 0);
    transform: translate(-50%);
}

.popup .box .close .img[data-v-b1e14027] {
    width: 0.8rem;
    height: 0.8rem;
}

.popup .box .title[data-v-b1e14027] {
    font-size: 0.42667rem;
    color: var(--text_color_L1);
}

.popup .box .numList[data-v-b1e14027] {
    max-height: 5.33333rem;
    overflow-x: auto;
}

.popup .box .numList .item[data-v-b1e14027] {
    width: 1.06667rem;
    height: 1.06667rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
    margin: 0 0.13333rem;
}

.popup-info-item[data-v-b1e14027] {
    height: 0.8rem;
    line-height: 0.8rem;
    margin-top: 0.26667rem;
}

.popup-info-item .tit[data-v-b1e14027] {
    font-size: 0.37333rem;
    color: var(--text_color_L2);
}

.popup-info-item .amount-box .li[data-v-b1e14027],
.popup-info-item .multiple-box .li[data-v-b1e14027] {
    text-align: center;
    font-size: 0.32rem;
    padding: 0 0.13333rem;
    height: 0.8rem;
    line-height: 0.8rem;
    min-width: 1.33333rem;
    margin-left: 0.13333rem;
    border: 0.01333rem solid var(--gray-color-1);
    border-radius: 0.13333rem;
    color: #00AF54;
}

.popup-info-item .amount-box .li.action[data-v-b1e14027],
.popup-info-item .multiple-box .li.action[data-v-b1e14027] {
    border: none;
    color: #fff;
    background: var(--main_gradient-color);
}

.popup-info-item .multiple-box .li[data-v-b1e14027] {
    padding: 0 0.26667rem;
    min-width: auto;
}

.popup-info-item .stepper-box .digit-box[data-v-b1e14027] {
    width: 2.66667rem;
    height: 0.8rem;
    border-radius: 0.8rem;
    padding: 0;
    margin: 0 0.13333rem;
    background-color: var(--walletBgColor-1);
}

.popup-info-item .stepper-box .digit-box[data-v-b1e14027] .van-field__control {
    height: 0.74667rem;
    text-align: center;
}

.popup-info-item .stepper-box .li[data-v-b1e14027] {
    height: 0.8rem;
    width: 0.8rem;
    font-size: 0.8rem;
    border-radius: 50%;
    background-color: var(--main-color);
    color: #fff;
}

.popup-info-item .stepper-box .li.minus[data-v-b1e14027] {
    text-align: center;
    line-height: 0.66667rem;
}

.popup-info-item .txt[data-v-b1e14027] {
    color: #00AF54;
}

.popup-info .quantity[data-v-b1e14027] {
    margin-top: 0.26667rem;
    padding: 0 0.21333rem;
    height: 1.17333rem;
    background-color: var(--bgDark-2, var(--homeActiveBgColor));
    border-radius: 0.13333rem;
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.popup-info .quantity .line[data-v-b1e14027] {
    padding: 0 0.13333rem;
    color: var(--text_color_L2);
}

.popup-info .quantity .num[data-v-b1e14027] {
    color: #00AF54;
    font-size: 0.4rem;
}

.popup-info .wallet[data-v-b1e14027],
.popup-info .balance[data-v-b1e14027] {
    padding: 0 0.21333rem;
    margin-top: 0.26667rem;
    height: 0.8rem;
    background-color: var(--bgDark-2, var(--homeActiveBgColor));
}

.popup-info .wallet .txt[data-v-b1e14027],
.popup-info .balance .txt[data-v-b1e14027] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.popup-info .wallet .txt img[data-v-b1e14027],
.popup-info .balance .txt img[data-v-b1e14027] {
    width: 0.4rem;
    height: 0.4rem;
    margin-right: 0.13333rem;
}

.popup-info .wallet .txt .num[data-v-b1e14027],
.popup-info .balance .txt .num[data-v-b1e14027] {
    font-size: 0.37333rem;
    color: var(--text_color_L1);
    padding-left: 0.26667rem;
}

.popup-info .wallet .txt .num.yellow[data-v-b1e14027],
.popup-info .balance .txt .num.yellow[data-v-b1e14027] {
    color: var(--norm_secondary-color);
}

.popup-info .wallet .bg333[data-v-b1e14027],
.popup-info .balance .bg333[data-v-b1e14027] {
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.popup-info .wallet .bg7172[data-v-b1e14027],
.popup-info .balance .bg7172[data-v-b1e14027] {
    font-size: 0.32rem;
    color: var(--main-color);
}

.popup-info .wallet .bet[data-v-b1e14027],
.popup-info .balance .bet[data-v-b1e14027] {
    border: 0.01333rem solid #00AF54;
    border-radius: 0.13333rem;
    height: 0.64rem;
    line-height: 0.64rem;
    color: #00AF54;
    padding: 0 0.26667rem;
}

.popup-btn[data-v-b1e14027] {
    height: 1.6rem;
}

.popup-btn .left[data-v-b1e14027] {
    width: 45%;
}

.popup-btn .left .btn[data-v-b1e14027] {
    height: 1.6rem;
    font-size: 0.42667rem;
    border-radius: 0;
    color: var(--text_color_L2);
    background-color: #00AF54;
}

.popup-btn .right[data-v-b1e14027] {
    width: 55%;
}

.popup-btn .right .btn[data-v-b1e14027] {
    height: 1.6rem;
    font-size: 0.42667rem;
    border-radius: 0;
    color: #fff;
    background-color: #00AF54;
}

.popup-btn .right .noActive[data-v-b1e14027] {
    background-color: #00AF54;
    color: var(--text_color_L2);
}

.PreSaleRule[data-v-b1e14027] {
    width: 7.04rem;
}

.PreSaleRule .head[data-v-b1e14027] {
    height: 1.2rem;
    line-height: 1.2rem;
    color: #fff;
    font-size: 0.4rem;
    text-align: center;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: left center;
    background-image: url(/assets/png/wingoPreSaleBg-6566ea95.png);
}

.PreSaleRule .body[data-v-b1e14027] {
    max-height: 8rem;
    overflow-y: auto;
    padding: 0.4rem;
    font-size: 0.32rem;
    line-height: 0.8rem;
}

.PreSaleRule .body[data-v-b1e14027] p {
    margin-bottom: 0.2rem;
    line-height: 0.53333rem;
}

.PreSaleRule .foot[data-v-b1e14027] {
    height: 1.86667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.PreSaleRule .foot .btn[data-v-b1e14027] {
    width: 60%;
    background: var(--main_gradient-color);
    border-radius: 0.53333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    font-size: 0.37333rem;
    color: #fff;
}

.Tips[data-v-b1e14027] {
    width: 8rem;
    height: 2.13333rem;
    line-height: 2.13333rem;
    background: var(--bg_color_L2);
    border: 0.01333rem solid var(--borderColor-5);
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.Tips>div[data-v-b1e14027] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    overflow-y: hidden;
}

.Tips>div img[data-v-b1e14027] {
    width: 1.17333rem;
    height: 1.17333rem;
    margin-top: 0.45333rem;
}

.Tips>div .font36[data-v-b1e14027] {
    color: var(--text_color_L1);
    font-weight: 700;
    font-size: 0.48rem;
    margin-left: 0.32rem;
}

.GameList__C-region[data-v-b1e14027] {
    height: 1.2rem;
    line-height: 1.2rem;
    overflow: hidden;
    padding: 0 0.26667rem;
    margin: 0.26667rem 0;
}

.GameList__C-region .item[data-v-b1e14027] {
    width: calc(33.3% - 0.53333rem);
    position: relative;
    text-align: center;
    font-size: 0.48rem;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

.GameList__C-region .item[data-v-b1e14027]:nth-child(1) {
    background: var(--bg_color_L2);
    border-radius: 0.13333rem 0 0 0.13333rem;
}

.GameList__C-region .item[data-v-b1e14027]:nth-child(1):after {
    position: absolute;
    top: 0;
    right: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-bottom: 1.2rem solid #fff;
    border-right: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

.GameList__C-region .item[data-v-b1e14027]:nth-child(2) {
    background: var(--bg_color_L2);
}

.GameList__C-region .item[data-v-b1e14027]:nth-child(2):after {
    position: absolute;
    top: 0;
    right: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-top: 1.2rem solid #fff;
    border-right: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-b1e14027]:nth-child(2):after {
    left: -0.66667rem;
    right: unset;
}

.GameList__C-region .item[data-v-b1e14027]:nth-child(2):before {
    position: absolute;
    top: 0;
    left: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-top: 1.2rem solid #fff;
    border-left: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-b1e14027]:nth-child(2):before {
    right: -0.66667rem;
    left: unset;
}

.GameList__C-region .item[data-v-b1e14027]:nth-child(3) {
    background: var(--bg_color_L2);
    border-radius: 0 0.13333rem 0.13333rem 0;
}

.GameList__C-region .item[data-v-b1e14027]:nth-child(3):before {
    position: absolute;
    top: 0;
    left: -0.66667rem;
    content: "";
    width: 0;
    height: 0;
    border-bottom: 1.2rem solid #fff;
    border-left: 0.66667rem solid transparent;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

html:lang(ar) .GameList__C-region .item[data-v-b1e14027]:nth-child(3):before {
    right: -0.66667rem;
    left: unset;
}

.GameList__C-region .item.action[data-v-b1e14027] {
    color: #fff;
}

.GameList__C-region .item.action[data-v-b1e14027]:nth-child(1) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-b1e14027]:nth-child(1):after {
    border-bottom: 1.2rem solid var(--borderColor-5);
}

.GameList__C-region .item.action[data-v-b1e14027]:nth-child(2) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-b1e14027]:nth-child(2):after {
    border-top: 1.2rem solid var(--borderColor-5);
}

.GameList__C-region .item.action[data-v-b1e14027]:nth-child(2):before {
    border-top: 1.2rem solid #00AF54;
}

.GameList__C-region .item.action[data-v-b1e14027]:nth-child(3) {
    background: -webkit-linear-gradient(325deg, #ff8e89 12.38%, #ffc3a2 87.13%);
    background: linear-gradient(125deg, #ff8e89 12.38%, #ffc3a2 87.13%);
}

.GameList__C-region .item.action[data-v-b1e14027]:nth-child(3):before {
    border-bottom: 1.2rem solid #00AF54;
}

.GameList__C-time[data-v-b1e14027] {
    padding-left: 0.2rem;
    overflow-y: auto;
    height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameList__C-time .item[data-v-b1e14027] {
    position: relative;
    white-space: nowrap;
    background-color: #fff;
    margin: 0 0.10667rem;
    padding: 0.04rem 0.16rem 0;
    text-align: center;
    border-radius: 0.13333rem 0.13333rem 0 0;
}

.GameList__C-time .item .week[data-v-b1e14027] {
    font-size: 0.16rem;
    color: var(--text_color_L1);
}

.GameList__C-time .item .time[data-v-b1e14027] {
    font-size: 0.16rem;
    color: var(--text_color_L2);
}

.GameList__C-time .item[data-v-b1e14027]:after,
.GameList__C-time .item[data-v-b1e14027]:before {
    content: "";
    width: 0.4rem;
    height: 0.4rem;
    position: absolute;
    bottom: 0;
    z-index: 9;
}

.GameList__C-time .item[data-v-b1e14027]:after {
    background: -webkit-radial-gradient( 100% 0, circle, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    background: radial-gradient( circle at 100% 0, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    right: -0.4rem;
}

html:lang(ar) .GameList__C-time .item[data-v-b1e14027]:after {
    left: -0.4rem;
    right: unset;
}

.GameList__C-time .item[data-v-b1e14027]:before {
    background: -webkit-radial-gradient( 0 0, circle, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    background: radial-gradient( circle at 0 0, rgba(204, 0, 0, 0) 0.4rem, #ffffff 0.41333rem);
    left: -0.4rem;
}

html:lang(ar) .GameList__C-time .item[data-v-b1e14027]:before {
    right: -0.4rem;
    left: unset;
}

.GameList__C-time .item.active[data-v-b1e14027] {
    background-color: var(--main-color);
    color: #fff;
    z-index: 10;
}

.GameList__C-time .item.active .week[data-v-b1e14027],
.GameList__C-time .item.active .time[data-v-b1e14027] {
    color: #fff;
}

.GameList__C-time .item.active[data-v-b1e14027]:before {
    background: -webkit-radial-gradient( 0 0, circle, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    background: radial-gradient( circle at 0 0, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    left: -0.4rem;
    z-index: 10;
}

html:lang(ar) .GameList__C-time .item.active[data-v-b1e14027]:before {
    right: -0.4rem;
    left: unset;
}

.GameList__C-time .item.active[data-v-b1e14027]:after {
    background: -webkit-radial-gradient( 100% 0, circle, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    background: radial-gradient( circle at 100% 0, rgba(204, 0, 0, 0) 0.4rem, var(--main-color) 0.41333rem);
    right: -0.4rem;
    z-index: 10;
}

html:lang(ar) .GameList__C-time .item.active[data-v-b1e14027]:after {
    left: -0.4rem;
    right: unset;
}

.GameList__C-city[data-v-b1e14027] {
    border-top: 0.02667rem solid #fff;
    overflow-y: auto;
    height: 0.6rem;
    height: 1.17333rem;
    background-color: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameList__C-city .item[data-v-b1e14027] {
    height: 0.93333rem;
    line-height: 0.93333rem;
    white-space: nowrap;
    margin: 0.08rem 0.10667rem;
    padding: 0 0.10667rem;
    text-align: center;
    color: #fff;
}

.GameList__C-city .item.action[data-v-b1e14027] {
    background-color: #fff;
    color: var(--main-color);
    border-radius: 0.06667rem;
}

.GameList__C-bet[data-v-b1e14027] {
    width: 100%;
    margin-top: 0.2rem;
    padding: 0 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 1.06667rem;
    overflow-x: scroll;
}

.GameList__C-bet ul[data-v-b1e14027] {
    margin: 0;
    padding: 0;
    list-style: none;
    -webkit-flex-wrap: nowrap;
    flex-wrap: nowrap;
    white-space: nowrap;
}

.GameList__C-bet .item[data-v-b1e14027] {
    -webkit-box-flex: 0;
    -webkit-flex: 0 0 auto;
    flex: 0 0 auto;
    height: 0.93333rem;
    padding: 0.25333rem 0.88rem;
    background: var(--bg_color_L2);
    border-radius: 0.16rem;
    margin-right: 0.32rem;
    color: var(--text_color_L2);
}

.GameList__C-bet .item.action[data-v-b1e14027] {
    color: #fff;
    background: var(--main_gradient-color2);
}

.Betting__C-mark[data-v-b1e14027] {
    width: 100%;
    height: 100%;
    background: var(--bgcolor-32);
    position: fixed;
    z-index: 99;
    top: 0;
    left: 0;
    color: #fff;
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

html:lang(ar) .Betting__C-mark[data-v-b1e14027] {
    right: 0;
    left: unset;
    direction: ltr;
}

.Betting__C-mark>div[data-v-b1e14027] {
    width: 5.86667rem;
    height: 1.33333rem;
    line-height: 1.33333rem;
    display: inline-block;
    border-radius: 0.26667rem;
    border: 0.01333rem solid #fff;
    font-size: 0.42667rem;
    color: #fff;
    font-weight: 700;
    padding: 0 0.4rem 0 2.08rem;
}

.Betting__C-bet[data-v-b1e14027] {
    margin-top: 0.4rem;
    padding: 0 0.26667rem;
}

.Betting__C-bet .tit[data-v-b1e14027] {
    height: 0.53333rem;
    line-height: 0.53333rem;
}

.Betting__C-bet .tit-select[data-v-b1e14027] {
    padding-left: 0.26667rem;
    font-size: 0.42667rem;
    font-weight: 700;
    border-left: 0.08rem solid var(--main-color);
}

.Betting__C-bet .tit-list .check[data-v-b1e14027] {
    padding-left: 0.26667rem;
    color: var(--text_color_L2);
}

.Betting__C-bet .tit-list .check-item[data-v-b1e14027] {
    height: 0.42667rem;
    width: 0.42667rem;
    border-radius: 0.42667rem;
    border: 0.02667rem solid #c9c9c9;
    margin-right: 0.10667rem;
}

.Betting__C-bet .tit-list .check.action[data-v-b1e14027] {
    color: #00AF54;
}

.Betting__C-bet .tit-list .check.action .check-item[data-v-b1e14027] {
    border: 0.01333rem solid #00AF54;
    position: relative;
}

.Betting__C-bet .tit-list .check.action .check-item[data-v-b1e14027]:after {
    content: "";
    display: block;
    border-radius: 0.26667rem;
    background-color: #00AF54;
    width: 0.26667rem;
    height: 0.26667rem;
    position: absolute;
    left: 0.05333rem;
    top: 0.05333rem;
}

html:lang(ar) .Betting__C-bet .tit-list .check.action .check-item[data-v-b1e14027]:after {
    right: 0.05333rem;
    left: unset;
}

.Betting__C-bet .nList[data-v-b1e14027] {
    background: var(--bg_color_L2);
    border-radius: 0.32rem;
    padding: 0.26667rem;
    margin-top: 0.4rem;
}

.Betting__C-bet .nList .Ntit[data-v-b1e14027] {
    line-height: 0.74667rem;
    font-size: 0.42667rem;
    color: var(--text_color_L3);
    font-weight: 400;
}

.Betting__C-bet .nList .list[data-v-b1e14027] {
    width: 100%;
}

.Betting__C-bet .nList .list .item[data-v-b1e14027] {
    width: 20%;
}

.Betting__C-bet .nList .list .item .number[data-v-b1e14027] {
    width: 1.06667rem;
    height: 1.06667rem;
    font-size: 0.42667rem;
    font-weight: 700;
    color: var(--text_color_L2);
    background: url(/assets/svg/nbg-dba06970.svg) no-repeat center center;
    background-size: cover;
}

.Betting__C-bet .nList .list .item .number.action[data-v-b1e14027] {
    color: #00AF54;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: cover;
}

.Footer__C[data-v-b1e14027] {
    width: 100%;
    position: fixed;
    left: auto;
    bottom: 0;
    height: 1.6rem;
    z-index: 98;
}

.Footer__C .nav[data-v-b1e14027] {
    height: 1.6rem;
    background-color: #fee;
    max-width: 10rem;
}

.Footer__C .nav .left[data-v-b1e14027] {
    width: 55%;
}

.Footer__C .nav .left .item[data-v-b1e14027] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    padding-left: 0.26667rem;
    color: var(--main-color);
}

.Footer__C .nav .left .item .txt[data-v-b1e14027] {
    margin-bottom: 0.08rem;
}

.Footer__C .nav .left .item .num[data-v-b1e14027] {
    color: #00AF54;
    font-weight: 600;
}

.Footer__C .bet-btn[data-v-b1e14027] {
    width: 40%;
    background-color: #00AF54;
    color: #fff;
    font-size: 0.48rem;
    font-weight: 600;
}

.Footer__C .disabled-btn[data-v-b1e14027] {
    width: 40%;
    background-color: var(--button_dis_color);
    color: var(--text_color_L2);
    font-size: 0.48rem;
    font-weight: 400;
    pointer-events: none;
}

.RecordNav__C[data-v-b1e14027] {
    width: calc(100% - 0.64rem);
    height: 1.17333rem;
    line-height: 1.17333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    margin: 0.32rem auto 0;
    border-radius: 0.16rem;
    overflow: hidden;
}

.RecordNav__C>div[data-v-b1e14027] {
    width: 50%;
    height: 100%;
    background: var(--bgDark-3, var(--bg_color_L2));
    font-size: 0.42667rem;
    color: var(--text_color_L2);
    text-align: center;
    overflow: hidden;
}

.RecordNav__C>div.active[data-v-b1e14027] {
    background: var(--dark-linerGradien-91, var(--main_gradient-color2));
    font-weight: 600;
    color: #fff;
}

.GameRecord__C[data-v-b1e14027] {
    width: calc(100% - 0.69333rem);
    margin: 0.26667rem auto 1.6rem;
    text-align: center;
    font-size: 0.32rem;
}

.GameRecord__C-head[data-v-b1e14027] {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--bgDark-2, var(--main-color));
    border-radius: 0.13333rem 0.13333rem 0 0;
    font-weight: 600;
    font-size: 0.37333rem;
    color: #fff;
}

.GameRecord__C-body[data-v-b1e14027] {
    color: var(--text_color_L1);
    font-size: 0.32rem;
    background: var(--darkBg, var(--bg_color_L1));
    border-radius: 0 0 0.13333rem 0.13333rem;
}

.GameRecord__C-body[data-v-b1e14027] .van-row {
    min-height: 1.30667rem;
    border-bottom: 0.01333rem solid var(--bgDark-2, var(--saveTextColor-3));
}

.GameRecord__C-body .details[data-v-b1e14027] {
    width: 100%;
    border: 0.01333rem solid var(--borderColor-5);
    border-radius: 0.26667rem;
    padding: 0.33333rem;
}

.GameRecord__C-body .details .tit[data-v-b1e14027] {
    font-size: 0.4rem;
    color: var(--text_color_L1);
    margin-bottom: 0.26667rem;
    font-weight: 700;
}

.GameRecord__C-body .details .tit img[data-v-b1e14027] {
    width: 0.64rem;
    height: 0.64rem;
    position: relative;
    top: 0.13333rem;
}

.GameRecord__C-body .details .tag-read img[data-v-b1e14027] {
    width: 0.32rem;
    height: 0.32rem;
}

.GameRecord__C-body .details .detailLi[data-v-b1e14027] {
    min-height: 0.66667rem;
    line-height: 0.66667rem;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
}

.GameRecord__C-body .details .detailLi .red[data-v-b1e14027] {
    color: var(--main_gradient-color);
}

.GameRecord__C-body .details .detailLi .prize[data-v-b1e14027] {
    background: var(--bgDark-4, --walletBgColor-1);
    margin-bottom: 0.16rem;
    padding: 0.26667rem;
    border-radius: 0.26667rem;
}

.GameRecord__C-body .details .detailLi .prize[data-v-b1e14027]:last-child {
    margin-bottom: 0;
}

.GameRecord__C-body .details .detailLi .selectItem0[data-v-b1e14027],
.GameRecord__C-body .details .detailLi .selectItem1[data-v-b1e14027],
.GameRecord__C-body .details .detailLi .selectItem2[data-v-b1e14027] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.GameRecord__C-body .details .detailLi .selectItem0>div[data-v-b1e14027]:nth-of-type(1),
.GameRecord__C-body .details .detailLi .selectItem1>div[data-v-b1e14027]:nth-of-type(1),
.GameRecord__C-body .details .detailLi .selectItem2>div[data-v-b1e14027]:nth-of-type(1) {
    width: 45%;
}

.GameRecord__C-body .details .detailLi .selectItem0>div[data-v-b1e14027]:nth-of-type(2),
.GameRecord__C-body .details .detailLi .selectItem1>div[data-v-b1e14027]:nth-of-type(2),
.GameRecord__C-body .details .detailLi .selectItem2>div[data-v-b1e14027]:nth-of-type(2) {
    width: 0.13333rem;
}

.GameRecord__C-body .details .detailLi .selectItem0 span[data-v-b1e14027],
.GameRecord__C-body .details .detailLi .selectItem1 span[data-v-b1e14027],
.GameRecord__C-body .details .detailLi .selectItem2 span[data-v-b1e14027] {
    font-weight: 700;
    font-size: 0.42667rem;
    color: var(--darkTextW, --text_color_L1);
    padding-left: 0;
    text-align: center;
}

.GameRecord__C-body .details .detailLi .selectItem0 span[data-v-b1e14027] {
    color: #00AF54;
}

.GameRecord__C-body .details .detailLi .prize-tit[data-v-b1e14027] {
    text-align: left;
    font-size: 0.37333rem;
    color: var(--darkTextW, --text_color_L1);
    padding-left: 0.26667rem;
}

.GameRecord__C-body .details .detailLi .action0[data-v-b1e14027] {
    color: #00AF54 !important;
    font-weight: 700;
    font-size: 0.42667rem;
}

.GameRecord__C-body .details .detailLi .action1[data-v-b1e14027],
.GameRecord__C-body .details .detailLi .action2[data-v-b1e14027] {
    font-weight: 700;
    font-size: 0.42667rem;
}

.GameRecord__C-body .details .detailLi .prize-box[data-v-b1e14027] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
}

.GameRecord__C-body .details .detailLi .prize-box-item[data-v-b1e14027] {
    text-align: left;
    padding-left: 0.26667rem;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: var(--text_color_L1);
    font-size: 0.37333rem;
    font-weight: 500;
}

.GameRecord__C-body .details .detailLi .c-flex-warp[data-v-b1e14027] {
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.GameRecord__C-body .details .detailLi .select[data-v-b1e14027] {
    margin-left: 0.53333rem;
}

.GameRecord__C-body .details .detailLi .select .ball[data-v-b1e14027] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 0.64rem;
    height: 0.42667rem;
    line-height: 0.42667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-left: 0.13333rem;
    margin-bottom: 0.13333rem;
    background: var(--main-color);
    border-radius: 0.08rem;
    color: #fff;
}

.GameRecord__C-body .details .detailLi .Bet-box.pb[data-v-b1e14027] {
    padding-bottom: 0.06667rem;
}

.GameRecord__C-body .details .detailLi .Bet-box ul li[data-v-b1e14027] {
    height: 0.26667rem;
    line-height: 0.26667rem;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    margin: 0.02667rem 0.05333rem;
    background-color: var(--gray-color-1);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionViolet[data-v-b1e14027] {
    color: #fff;
    background-color: var(--bgcolor-21);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionRed[data-v-b1e14027] {
    color: #fff;
    background-color: var(--norm_red-color);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionGreen[data-v-b1e14027] {
    color: #fff;
    background-color: var(--bgColor-13);
}

.GameRecord__C-body .details .detailLi .Bet-box ul li.actionRedGreen[data-v-b1e14027] {
    color: #fff;
    background-color: var(--norm_red-color);
    background-image: var(--linearGradien-21);
}

.GameRecord__C-body .details .detailLi .Bet-box .actionBtn[data-v-b1e14027] {
    height: 0.34667rem;
    line-height: 0.34667rem;
    display: inline-block;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    background-color: var(--norm_red-color);
    color: #fff;
}

.GameRecord__C-body .goItem[data-v-b1e14027] {
    height: 1.30667rem;
    line-height: 1.30667rem;
    text-align: center;
    color: var(--darkTextW, --main-color);
    font-size: 0.32rem;
}

.GameRecord__C-body .li[data-v-b1e14027] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
    width: 0.4rem;
    height: 0.4rem;
    border-radius: 50%;
    background: var(--walletBgColor-1);
    margin: 0 0.02667rem;
}

.GameRecord__C-body .li .circle-black[data-v-b1e14027] {
    background-color: var(--walletBgColor-1);
    color: var(--text_color_L1);
    font-size: 0.32rem;
}

.GameRecord__C-body .time[data-v-b1e14027] {
    color: var(--textM3, var(--text_color_L2));
    font-size: 0.32rem;
    height: 100%;
}

.GameRecord__C-body .numList[data-v-b1e14027] {
    width: 3rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    position: relative;
    top: 0.4rem;
}

.GameRecord__C-body .numList .numItem[data-v-b1e14027] {
    width: 0.4rem;
    height: 0.4rem;
    background: var(--walletBgColor-1);
    color: var(--text_color_L1);
    font-size: 0.32rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    border-radius: 50%;
}

.GameRecord__C-body .redNumItem[data-v-b1e14027] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot[data-v-b1e14027] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.GameRecord__C-foot-previous[data-v-b1e14027],
.GameRecord__C-foot-next[data-v-b1e14027] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot-previous.disabled[data-v-b1e14027],
.GameRecord__C-foot-next.disabled[data-v-b1e14027] {
    background: var(--gray-color-1);
    pointer-events: none;
}

.GameRecord__C-foot-previous.disabled .GameRecord__C-icon[data-v-b1e14027],
.GameRecord__C-foot-next.disabled .GameRecord__C-icon[data-v-b1e14027] {
    color: var(--saveTextColor-7);
}

.GameRecord__C-foot-previous .GameRecord__C-icon[data-v-b1e14027],
.GameRecord__C-foot-next .GameRecord__C-icon[data-v-b1e14027] {
    color: #fff;
}

.MyGameRecord__C[data-v-b1e14027] {
    width: 100%;
    margin: 0.32rem auto 1.6rem;
}

.MyGameRecord__C-head[data-v-b1e14027] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    justify-content: flex-end;
    background-color: var(--darkBg, var(--bg_color_L2));
    padding: 0.32rem 0.32rem 0;
}

.MyGameRecord__C-head-moreB[data-v-b1e14027] {
    border: 0.01333rem solid var(--main-color);
    height: 0.8rem;
    line-height: 0.8rem;
    border-radius: 0.26667rem;
    padding: 0 0.72rem 0 0.24rem;
    color: var(--main-color);
    font-size: 0.32rem;
    position: relative;
    margin-bottom: 0.4rem;
}

.MyGameRecord__C-head-moreB[data-v-b1e14027]:after {
    content: "";
    display: block;
    width: 0.4rem;
    height: 0.4rem;
    position: absolute;
    top: 50%;
    right: 0.2rem;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    background-image: url(/assets/jpg/moreBtn-ffccf44d.jpg);
    background-repeat: no-repeat;
    background-size: 0.4rem;
    background-position: center;
}

html:lang(ar) .MyGameRecord__C-head-moreB[data-v-b1e14027]:after {
    left: 0.2rem;
    right: unset;
    -webkit-transform: scaleX(-1);
    transform: scaleX(-1);
    top: 25%;
}

.MyGameRecord__C-body[data-v-b1e14027] {
    padding: 0 0.32rem;
}

.MyGameRecord__C-body-empty[data-v-b1e14027] {
    height: 5.33333rem;
}

.MyGameRecord__C-foot[data-v-b1e14027] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.MyGameRecord__C-foot-page[data-v-b1e14027] {
    font-size: 0.32rem;
    color: var(--text_color_L1);
}

.MyGameRecord__C-foot-previous[data-v-b1e14027],
.MyGameRecord__C-foot-next[data-v-b1e14027] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.MyGameRecord__C-foot-previous.disabled[data-v-b1e14027],
.MyGameRecord__C-foot-next.disabled[data-v-b1e14027] {
    background: var(--gray-color-1);
    pointer-events: none;
}

.MyGameRecord__C-foot-previous.disabled .MyGameRecord__C-icon[data-v-b1e14027],
.MyGameRecord__C-foot-next.disabled .MyGameRecord__C-icon[data-v-b1e14027] {
    color: var(--saveTextColor-7);
}

.MyGameRecord__C-foot-previous .MyGameRecord__C-icon[data-v-b1e14027],
.MyGameRecord__C-foot-next .MyGameRecord__C-icon[data-v-b1e14027] {
    color: #fff;
}

.list[data-v-b1e14027] {
    padding: 0 0.26667rem;
}

.list .hb[data-v-b1e14027] {
    background-color: #fff;
    color: var(--colorText-3);
    font-size: 0.37333rem;
}

.list .hb .item[data-v-b1e14027] {
    padding: 0.21333rem;
    border-bottom: 0.02667rem solid var(--gray-color-1);
    color: var(--colorText-3);
    font-size: 0.37333rem;
}

.list .hb .item.action[data-v-b1e14027] {
    padding: 0.32rem 0.26667rem;
}

.list .hb .item .goItem[data-v-b1e14027] {
    height: 0.42667rem;
}

.list .hb .li[data-v-b1e14027] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
    width: 0.42667rem !important;
    height: 0.42667rem;
    border: 0.02667rem solid var(--gray-color-1);
    border-radius: 0.42667rem;
    margin-right: 0.10667rem;
    color: var(--gray-color-1);
}

.list .hb .li.action[data-v-b1e14027] {
    font-size: 0.32rem;
    border: none;
    color: #fff;
    background-color: var(--norm_red-color);
}

.list .hb .li.circle-black[data-v-b1e14027] {
    border: 0.02667rem solid var(--text_color_L1);
    color: var(--text_color_L1);
    background: var(--bgColor-6);
}

.list .hb .li.actionH[data-v-b1e14027] {
    border: none;
    color: #fff;
    background-color: var(--borderColor-4);
}

.list .hb .li.actionL[data-v-b1e14027] {
    border: 0.01333rem solid var(--borderColor-4);
    color: var(--borderColor-4);
    background-color: #fff;
}

.list .hb .li.actionO[data-v-b1e14027] {
    border: none;
    color: #fff;
    background-color: var(--norm_secondary-color);
}

.list .hb .li.actionE[data-v-b1e14027] {
    border: 0.01333rem solid var(--norm_secondary-color);
    color: var(--norm_secondary-color);
    background-color: #fff;
}

.list .hb .qiu[data-v-b1e14027] {
    width: 3rem;
    position: relative;
}

.list .hb .qiu .line-canvas[data-v-b1e14027] {
    position: absolute !important;
    top: 0.12rem;
    left: 0;
    height: 0.73333rem;
    width: 2.61333rem;
    z-index: 99;
}

html:lang(ar) .list .hb .qiu .line-canvas[data-v-b1e14027] {
    right: 0.12rem;
    left: unset;
}

.list .hb .red[data-v-b1e14027] {
    color: var(--colorText-2);
}

.list .hb .green[data-v-b1e14027] {
    color: var(--norm_green-color);
}

.list .hb .blue[data-v-b1e14027] {
    color: var(--colorText-7);
}

.list .hb .box .li[data-v-b1e14027] {
    display: block;
    height: 0.13333rem;
    width: 0.13333rem;
    border-radius: 0.13333rem;
    margin: 0 0.06667rem;
}

.list .hb .item[data-v-b1e14027] {
    padding: 0.53333rem 0.4rem;
}

.list .hb .item .info[data-v-b1e14027] {
    width: 100%;
}

.list .hb .item .info .issueName .state[data-v-b1e14027] {
    color: #fff;
    padding: 0.10667rem 0.26667rem;
    margin-left: 0.26667rem;
    border-radius: 0.53333rem;
    font-size: 0.32rem;
    display: inline-block;
    text-align: center;
}

.list .hb .item .info .issueName .state.red[data-v-b1e14027] {
    background-color: var(--norm_red-color);
}

.list .hb .item .info .issueName .state.green[data-v-b1e14027] {
    background-color: var(--norm_green-color);
}

.list .hb .item .info .tiem[data-v-b1e14027] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
    margin-top: 0.13333rem;
}

.list .hb .item .info .money[data-v-b1e14027] {
    font-weight: 600;
    font-size: 0.42667rem;
}

.list .hb .item .info .money .fail[data-v-b1e14027] {
    color: var(--norm_red-color);
}

.list .hb .item .info .money .success[data-v-b1e14027] {
    color: var(--bgColor-13);
}

.list .hb .details[data-v-b1e14027] {
    padding: 0.4rem;
    border-bottom: 0.01333rem solid var(--gray-color-1);
}

.list .hb .details .tit[data-v-b1e14027] {
    font-size: 0.4rem;
    color: var(--text_color_L1);
    margin-bottom: 0.26667rem;
    font-weight: 700;
}

.list .hb .details .tit img[data-v-b1e14027] {
    width: 0.64rem;
    height: 0.64rem;
    position: relative;
    top: 0.13333rem;
}

.list .hb .details .tag-read img[data-v-b1e14027] {
    width: 0.32rem;
    height: 0.32rem;
}

.list .hb .details .detailLi[data-v-b1e14027] {
    min-height: 0.66667rem;
    line-height: 0.66667rem;
    background: var(--bgColor-6);
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    border-radius: 0.13333rem;
    margin-bottom: 0.21333rem;
}

.list .hb .details .detailLi .red[data-v-b1e14027] {
    color: var(--main_gradient-color);
}

.list .hb .details .detailLi .result[data-v-b1e14027] {
    height: 0.93333rem;
    line-height: 0.93333rem;
    background: var(--main-color);
    border-radius: 0.13333rem 0.13333rem 0 0;
    color: #fff;
    text-align: left;
    padding: 0 --0.26667rem;
}

.list .hb .details .detailLi .prize-tit[data-v-b1e14027] {
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.list .hb .details .detailLi .prize-box[data-v-b1e14027] {
    border-bottom: 0.01333rem solid #fff;
}

.list .hb .details .detailLi .prize-box-item[data-v-b1e14027] {
    text-align: center;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.list .hb .details .detailLi .c-flex-warp[data-v-b1e14027] {
    color: var(--text_color_L3);
    font-size: 0.34667rem;
}

.list .hb .details .detailLi .select[data-v-b1e14027] {
    margin-left: 0.53333rem;
}

.list .hb .details .detailLi .select .ball[data-v-b1e14027] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    width: 0.64rem;
    height: 0.42667rem;
    line-height: 0.42667rem;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-left: 0.13333rem;
    margin-bottom: 0.13333rem;
    background: var(--main-color);
    border-radius: 0.08rem;
    color: #fff;
}

.list .hb .details .detailLi .Bet-box.pb[data-v-b1e14027] {
    padding-bottom: 0.06667rem;
}

.list .hb .details .detailLi .Bet-box ul li[data-v-b1e14027] {
    height: 0.26667rem;
    line-height: 0.26667rem;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    margin: 0.02667rem 0.05333rem;
    background-color: var(--gray-color-1);
}

.list .hb .details .detailLi .Bet-box ul li.actionViolet[data-v-b1e14027] {
    color: #fff;
    background-color: var(--bgcolor-21);
}

.list .hb .details .detailLi .Bet-box ul li.actionRed[data-v-b1e14027] {
    color: #fff;
    background-color: var(--norm_red-color);
}

.list .hb .details .detailLi .Bet-box ul li.actionGreen[data-v-b1e14027] {
    color: #fff;
    background-color: var(--bgColor-13);
}

.list .hb .details .detailLi .Bet-box ul li.actionRedGreen[data-v-b1e14027] {
    color: #fff;
    background-color: var(--norm_red-color);
    background-image: var(--linearGradien-21);
}

.list .hb .details .detailLi .Bet-box .actionBtn[data-v-b1e14027] {
    height: 0.34667rem;
    line-height: 0.34667rem;
    display: inline-block;
    border-radius: 0.04rem;
    padding: 0 0.13333rem;
    font-size: 0.16rem;
    background-color: var(--norm_red-color);
    color: #fff;
}

.areList[data-v-b1e14027] {
    margin: 0.53333rem;
    position: relative;
}

.areList .close[data-v-b1e14027] {
    position: absolute;
    top: -1.6rem;
    left: 50%;
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
    width: 0.8rem;
    height: 0.8rem;
}

.areList .items h1[data-v-b1e14027] {
    color: var(--darkTextW, var(--borderColor-26));
    font-size: 0.42667rem;
}

.areList .items .itemsC[data-v-b1e14027] {
    margin: 0.26667rem 0 0.4rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    gap: 0.2rem;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.areList .items .itemsC>div[data-v-b1e14027] {
    width: calc((100% - 0.53333rem) / 2);
    background: var(--bgDark-3, var(--homeActiveBgColor));
    border-radius: 0.13333rem;
    min-height: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
}

.areList .items .itemsC .isActive[data-v-b1e14027] {
    background: var(--norm_red-color);
    color: #fff;
}

.titlebets[data-v-b1e14027] {
    font-size: 0.29333rem;
    color: var(--main-color);
}

.border60[data-v-b1e14027] {
    width: 4.53333rem;
    height: 0.66667rem;
    line-height: 0.66667rem;
    border-radius: 0.8rem;
    border: 0.01333rem solid var(--main-color);
    margin: 0 auto;
    margin-top: 0.30667rem;
}

.bottombg[data-v-b1e14027] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/arrowbottom-4eb91cbc.png);
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center;
}

.compound2[data-v-b1e14027],
.compound3[data-v-b1e14027] {
    padding-top: 0.26667rem;
    max-height: 5.33333rem;
    overflow-y: auto;
}

.compound2 .item[data-v-b1e14027],
.compound3 .item[data-v-b1e14027] {
    width: 100%;
    margin-bottom: 0.26667rem;
}

.compound2 .item.item0-3 .box .c-row[data-v-b1e14027],
.compound3 .item.item0-3 .box .c-row[data-v-b1e14027] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.21333rem;
}

.compound2 .item.item0-3 .box .num[data-v-b1e14027],
.compound3 .item.item0-3 .box .num[data-v-b1e14027] {
    width: calc((100% - 1.28rem) / 7);
    height: 1.13333rem;
    background-size: 1.13333rem 1.13333rem;
}

.compound2 .item.item0-2 .box .c-row[data-v-b1e14027],
.compound2 .item.item5-2 .box .c-row[data-v-b1e14027],
.compound3 .item.item0-2 .box .c-row[data-v-b1e14027],
.compound3 .item.item5-2 .box .c-row[data-v-b1e14027] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.21333rem;
}

.compound2 .item.item0-2 .box .num[data-v-b1e14027],
.compound2 .item.item5-2 .box .num[data-v-b1e14027],
.compound3 .item.item0-2 .box .num[data-v-b1e14027],
.compound3 .item.item5-2 .box .num[data-v-b1e14027] {
    width: calc((100% - 1.28rem) / 7);
    height: 0.8rem;
    background-size: 0.8rem 0.8rem;
}

.compound2 .item.item4-2 .box .c-row[data-v-b1e14027],
.compound3 .item.item4-2 .box .c-row[data-v-b1e14027] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item4-2 .box .num[data-v-b1e14027],
.compound3 .item.item4-2 .box .num[data-v-b1e14027] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-8),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-7),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-6),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-5),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-4),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-2),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-1),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-8),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-7),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-5),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-4),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-2),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-1),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
}

.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-7),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-6),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-4),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-1),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-7),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-4),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-1),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n) {
    margin-left: -0.10667rem;
}

.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-3),
.compound2 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-6),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-3),
.compound3 .item.item4-2 .box .num[data-v-b1e14027]:nth-child(9n-6) {
    margin-right: 0.42667rem;
}

.compound2 .item.item3-2 .box .c-row[data-v-b1e14027],
.compound3 .item.item3-2 .box .c-row[data-v-b1e14027] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item3-2 .box .num[data-v-b1e14027],
.compound3 .item.item3-2 .box .num[data-v-b1e14027] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-1),
.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-2),
.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-3),
.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-4),
.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-5),
.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-6),
.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-7),
.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-1),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-2),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-3),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-5),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-6),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-7),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
}

.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-6),
.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-5),
.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-4),
.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-2),
.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-1),
.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-6),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-5),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-2),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-1),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n) {
    margin-left: -0.06667rem;
}

.compound2 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-4),
.compound3 .item.item3-2 .box .num[data-v-b1e14027]:nth-child(8n-4) {
    margin-right: 1.73333rem;
}

.compound2 .item.item2-2 .box .c-row[data-v-b1e14027],
.compound3 .item.item2-2 .box .c-row[data-v-b1e14027] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item2-2 .box .num[data-v-b1e14027],
.compound3 .item.item2-2 .box .num[data-v-b1e14027] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-1),
.compound2 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-2),
.compound2 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-3),
.compound2 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-4),
.compound2 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-5),
.compound2 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-6),
.compound2 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-7),
.compound2 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n),
.compound3 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-1),
.compound3 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-2),
.compound3 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-3),
.compound3 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-4),
.compound3 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-5),
.compound3 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-6),
.compound3 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n-7),
.compound3 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
    margin-left: -0.01333rem;
}

.compound2 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n),
.compound3 .item.item2-2 .box .num[data-v-b1e14027]:nth-child(8n) {
    margin-right: 1.33333rem;
}

.compound2 .item.item1-2 .box .c-row[data-v-b1e14027],
.compound3 .item.item1-2 .box .c-row[data-v-b1e14027] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.compound2 .item.item1-2 .box .num[data-v-b1e14027],
.compound3 .item.item1-2 .box .num[data-v-b1e14027] {
    margin-bottom: 0.26667rem;
}

.compound2 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-1),
.compound2 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-2),
.compound2 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-3),
.compound2 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-4),
.compound2 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-5),
.compound2 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-6),
.compound2 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-7),
.compound2 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-8),
.compound2 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-9),
.compound2 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n),
.compound3 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-1),
.compound3 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-2),
.compound3 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-3),
.compound3 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-4),
.compound3 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-5),
.compound3 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-6),
.compound3 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-7),
.compound3 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-8),
.compound3 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n-9),
.compound3 .item.item1-2 .box .num[data-v-b1e14027]:nth-child(10n) {
    background-color: var(--homeActiveBgColor);
    padding: 0.26667rem;
    margin-left: -0.09333rem;
}

.compound2 .item .box[data-v-b1e14027],
.compound3 .item .box[data-v-b1e14027] {
    border-radius: 0.26667rem;
    position: relative;
    width: 100%;
}

.compound2 .item .box .num[data-v-b1e14027],
.compound3 .item .box .num[data-v-b1e14027] {
    min-width: 0.8rem;
    min-height: 0.8rem;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: 0.8rem 0.8rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
}

.compound2 .item .box .money[data-v-b1e14027],
.compound3 .item .box .money[data-v-b1e14027] {
    text-align: center;
    background-color: var(--gray-color-1);
    position: relative;
    height: 0.53333rem;
    border-radius: 0 0 0.26667rem 0.26667rem;
}

.compound2 .item .box .money .all[data-v-b1e14027],
.compound3 .item .box .money .all[data-v-b1e14027] {
    position: relative;
    z-index: 9;
    line-height: 0.8rem;
    font-size: 0.32rem;
    color: #00AF54;
}

.compound2 .item .box .money[data-v-b1e14027]:after,
.compound3 .item .box .money[data-v-b1e14027]:after {
    position: absolute;
    top: 0;
    left: 0;
    content: "";
    display: block;
    width: 100%;
    height: 0.21333rem;
    background-color: var(--gray-color-1);
    border-radius: 0 0 50% 50%;
}

.compound2 .item .box .dele[data-v-b1e14027],
.compound3 .item .box .dele[data-v-b1e14027] {
    position: absolute;
    right: -0.18667rem;
    top: -0.18667rem;
    height: 0.37333rem;
    width: 0.37333rem;
    border-radius: 0.53333rem;
    background-color: #00AF54;
}

.compound2 .item .box .dele .icon[data-v-b1e14027],
.compound3 .item .box .dele .icon[data-v-b1e14027] {
    font-size: 0.26667rem;
}

.compound2 .item.item0-4 .box .c-row[data-v-b1e14027] {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 0.53333rem;
}

.compound2 .item.item0-4 .box .num[data-v-b1e14027] {
    width: calc((100% - 2.13333rem) / 5);
    background: var(--main_gradient-color);
    color: #fff;
    border-radius: 0.13333rem;
    min-height: 1.06667rem;
    min-width: 1.33333rem;
}

.compound[data-v-b1e14027] {
    padding-top: 0.26667rem;
    max-height: 6rem;
    overflow: auto;
}

.compound .item[data-v-b1e14027] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 100%;
    margin-bottom: 0.4rem;
}

.compound .item .title[data-v-b1e14027] {
    width: 1.38667rem;
    overflow: hidden;
    position: relative;
    text-align: center;
    font-size: 0.42667rem;
    color: var(--text_color_L2);
}

.compound .item .numcontainer[data-v-b1e14027] {
    width: 7.94667rem;
    margin-left: 0.13333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    justify-content: flex-start;
    gap: 0.13333rem;
}

.compound .item .numcontainer .num[data-v-b1e14027] {
    width: calc((100% - 0.85333rem) / 5);
    height: 0.8rem;
    background: url(/assets/svg/anbg-2e633fe1.svg) no-repeat center center;
    background-size: 0.8rem 0.8rem;
    font-size: 0.42667rem;
    font-weight: 600;
    color: #00AF54;
    position: relative;
    text-align: center;
    line-height: 0.8rem;
}

.compound .item .numcontainer .num .dele[data-v-b1e14027] {
    position: absolute;
    right: -0.18667rem;
    top: -0.18667rem;
    height: 0.37333rem;
    width: 0.37333rem;
    border-radius: 0.53333rem;
    background-color: #00AF54;
}

html:lang(ar) .compound .item .numcontainer .num .dele[data-v-b1e14027] {
    right: unset;
    left: -0.18667rem;
}

.compound .item .numcontainer .num .dele .icon[data-v-b1e14027] {
    font-size: 0.26667rem;
}

[data-v-b1e14027] .dialog__container-content {
    margin-top: 0.13333rem;
}

[data-v-b1e14027] .dialog__container-content .tipMsg {
    font-size: 0.34667rem;
}

.centercity[data-v-b1e14027] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    font-size: 0.48rem;
    color: var(--textW);
    font-weight: 500;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.van-toast[data-v-b67ec5ce] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-b67ec5ce] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-b67ec5ce] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-b67ec5ce] {
    height: 80%;
}

.Play__C[data-v-b67ec5ce] {
    width: 100%;
}

.Play__C[data-v-b67ec5ce] .van-tab--card {
    min-width: 2.93333rem;
}

.Play__C-Cotent[data-v-b67ec5ce] {
    background-color: var(--darkBg, var(--bg_color_L2));
    box-shadow: var(--BoxShadowColor-9);
    margin: 0 0.4rem 0.4rem;
    border-radius: 0.4rem;
}

.Play__C-Cotent .title[data-v-b67ec5ce] {
    width: 9.36rem;
    height: 0.8rem;
    line-height: 0.8rem;
    background: url(/assets/png/palybg-97711462.png) no-repeat center;
    background-size: auto 100%;
    background-color: #fff;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.Play__C-Cotent .title img[data-v-b67ec5ce] {
    display: block;
    width: 0.56rem;
    height: 0.56rem;
    margin: 0 0.26667rem;
}

.Play__C-Cotent .title>span[data-v-b67ec5ce] {
    color: #fff;
    font-size: 0.42667rem;
    font-weight: 600;
}

.Play__C-Cotent .info[data-v-b67ec5ce] {
    width: 100%;
    background-color: var(--darkBg, var(--bg_color_L2));
    margin-bottom: 0.4rem;
    padding: 0.26667rem 0.26667rem 0.4rem;
    border-radius: 0 0 0.26667rem 0.26667rem;
}

.Play__C-Cotent .info_item[data-v-b67ec5ce] {
    margin-bottom: 0.4rem;
    font-size: 0.34667rem;
    color: var(--text_color_L2);
}

.Play__C-Cotent .info_item>img[data-v-b67ec5ce] {
    width: 0.45333rem;
    height: 0.45333rem;
    display: inline-block;
    vertical-align: -0.05333rem;
    margin-right: 0.16rem;
}

.Play__C-Cotent .info_item .sub[data-v-b67ec5ce] {
    color: var(--darkTextW, var(--main-color));
    font-size: 0.42667rem;
}

.Play__C-Cotent .info_item .text[data-v-b67ec5ce] {
    margin: 0.21333rem 0.56rem 0;
    color: var(--text_color_L2);
    font-size: 0.34667rem;
    line-height: 0.53333rem;
}

.Play__C-Cotent .info_text[data-v-b67ec5ce] {
    border-radius: 0.26667rem;
    border: 0.01333rem solid var(--gray-color-1);
    padding: 0 0.22667rem 0.33333rem 0.68rem;
    color: var(--text_color_L2);
    font-size: 0.32rem;
}

.Play__C-Cotent .info_text>div[data-v-b67ec5ce] {
    margin-top: 0.2rem;
    line-height: 0.53333rem;
}

.van-toast[data-v-33026085] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-33026085] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-33026085] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-33026085] {
    height: 80%;
}

.NorthRule__C[data-v-33026085] {
    width: 100%;
    background-color: var(--bg_color_L2);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.NorthRule__C-title[data-v-33026085] {
    font-size: 0.48rem;
    font-weight: 700;
    color: var(--colorText-26);
    text-align: center;
}

.NorthRule__C-tips[data-v-33026085] {
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    margin-top: 0.2rem;
    margin-bottom: 0.44rem;
    text-align: center;
}

.NorthRule__C-Content[data-v-33026085] {
    position: relative;
    padding: 0.57333rem 0.24rem 0.33333rem;
    border: 0.01333rem solid var(--bgDark-2, var(--main-color));
    border-top-left-radius: 0.26667rem;
    border-top-right-radius: 0.26667rem;
    background: var(--darkBg, var(--bg_color_L2));
    margin-bottom: 0.42667rem;
}

.NorthRule__C-Content .borderTopStyle[data-v-33026085] {
    position: absolute;
    top: 0;
    left: 50%;
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
    width: 100%;
}

.NorthRule__C-Content .borderTopStyle span[data-v-33026085] {
    position: absolute;
    top: 0;
}

.NorthRule__C-Content .borderTopStyle span[data-v-33026085]:first-of-type,
.NorthRule__C-Content .borderTopStyle span[data-v-33026085]:last-of-type {
    width: 0.68rem;
    height: 0.68rem;
    border-top: 0.06667rem solid var(--bgDark-2, var(--main-color));
}

.NorthRule__C-Content .borderTopStyle span[data-v-33026085]:first-of-type:after,
.NorthRule__C-Content .borderTopStyle span[data-v-33026085]:last-of-type:after {
    content: "";
    position: absolute;
    top: 0.29333rem;
    left: 0.2rem;
    width: 0.13333rem;
    height: 0.13333rem;
    background-color: var(--bgDark-2, var(--main-color));
}

html:lang(ar) .NorthRule__C-Content .borderTopStyle span[data-v-33026085]:first-of-type:after,
html:lang(ar) .NorthRule__C-Content .borderTopStyle span[data-v-33026085]:last-of-type:after {
    right: 0.2rem;
    left: unset;
}

.NorthRule__C-Content .borderTopStyle span[data-v-33026085]:first-of-type {
    left: -0.01333rem;
    border-left: 0.06667rem solid var(--bgDark-2, var(--main-color));
    border-top-left-radius: 0.26667rem;
}

html:lang(ar) .NorthRule__C-Content .borderTopStyle span[data-v-33026085]:first-of-type {
    right: -0.01333rem;
    left: unset;
}

.NorthRule__C-Content .borderTopStyle span[data-v-33026085]:first-of-type:after {
    border-radius: 50%;
}

.NorthRule__C-Content .borderTopStyle span[data-v-33026085]:last-of-type {
    right: 0;
    border-right: 0.06667rem solid var(--bgDark-2, var(--main-color));
    border-top-right-radius: 0.26667rem;
}

html:lang(ar) .NorthRule__C-Content .borderTopStyle span[data-v-33026085]:last-of-type {
    right: unset;
    left: 0;
}

.NorthRule__C-Content .borderTopStyle span[data-v-33026085]:last-of-type:after {
    border-radius: 50%;
}

.NorthRule__C-Content[data-v-33026085]:after,
.NorthRule__C-Content[data-v-33026085]:before {
    content: "";
    display: block;
    position: absolute;
    top: -0.26667rem;
    width: 0.26667rem;
    height: 0.53333rem;
    background-color: var(--bgDark-2, var(--main-color));
    -webkit-clip-path: polygon( 50% 0%, 100% 0%, 50% 50%, 100% 100%, 50% 100%, 0% 50%);
    clip-path: polygon(50% 0%, 100% 0%, 50% 50%, 100% 100%, 50% 100%, 0% 50%);
    z-index: 5;
}

.NorthRule__C-Content[data-v-33026085]:after {
    left: calc(50% - 1.2rem);
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
}

.NorthRule__C-Content[data-v-33026085]:before {
    left: calc(50% + 1.2rem);
    -webkit-transform: translateX(-50%) rotate(180deg);
    transform: translate(-50%) rotate(180deg);
}

.NorthRule__C-Content .title[data-v-33026085] {
    position: absolute;
    top: -0.26667rem;
    left: 50%;
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
    width: 2.13333rem;
    height: 0.53333rem;
    color: #fff;
    font-size: 0.32rem;
    text-align: center;
    line-height: 0.53333rem;
    background-color: var(--bgDark-2, var(--main-color));
    -webkit-clip-path: polygon( 7% 0%, 93% 0%, 100% 50%, 93% 100%, 7% 100%, 0% 50%);
    clip-path: polygon(7% 0%, 93% 0%, 100% 50%, 93% 100%, 7% 100%, 0% 50%);
}

.NorthRule__C-Content .text[data-v-33026085] {
    margin: 0 0.26667rem;
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.NorthRule__C .table[data-v-33026085],
.NorthRule__C .table-rule[data-v-33026085] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    margin-bottom: 0.53333rem;
    background-color: var(--darkBg, var(--bg_color_L2));
}

.NorthRule__C .table .table-row[data-v-33026085],
.NorthRule__C .table-rule .table-row[data-v-33026085] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    text-align: center;
    color: var(--text_color_L2);
    font-size: 0.34667rem;
    border-top-left-radius: 0.26667rem;
    border-top-right-radius: 0.26667rem;
}

.NorthRule__C .table .table-row.header-time[data-v-33026085],
.NorthRule__C .table-rule .table-row.header-time[data-v-33026085] {
    height: 1.33333rem;
    line-height: 1.33333rem;
    background: var(--main-color);
    text-align: center;
    color: var(--darkTextW, var(--bg_color_L2)) !important;
    font-size: 0.34667rem;
    border-radius: 0;
}

.NorthRule__C .table .table-row.header-week[data-v-33026085],
.NorthRule__C .table-rule .table-row.header-week[data-v-33026085] {
    height: 0.88rem;
    line-height: 0.88rem;
    background: var(--norm_red-color);
    text-align: center;
    color: var(--darkTextW, var(--bg_color_L2)) !important;
    font-size: 0.34667rem;
    border-radius: 0;
}

.NorthRule__C .table .table-row .table-week-1[data-v-33026085],
.NorthRule__C .table .table-row .table-time-1[data-v-33026085],
.NorthRule__C .table-rule .table-row .table-week-1[data-v-33026085],
.NorthRule__C .table-rule .table-row .table-time-1[data-v-33026085] {
    height: 0.88rem;
    line-height: 0.88rem;
    overflow: hidden;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    text-align: center;
}

.NorthRule__C .table .table-row[data-v-33026085],
.NorthRule__C .table-rule .table-row[data-v-33026085] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    border: 0.01333rem solid var(--bgDark-2, var(--borderColor-5));
    border-top: none;
    margin-bottom: -0.01333rem;
    border-radius: 0;
}

.NorthRule__C .table .table-row .table-cell-1[data-v-33026085],
.NorthRule__C .table-rule .table-row .table-cell-1[data-v-33026085] {
    height: 0.88rem;
    line-height: 0.88rem;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    border-right: 0.01333rem solid var(--bgDark-2, var(--borderColor-5));
}

.NorthRule__C .table .table-row .table-cell-2[data-v-33026085],
.NorthRule__C .table-rule .table-row .table-cell-2[data-v-33026085] {
    -webkit-box-flex: 2;
    -webkit-flex: 2;
    flex: 2;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.NorthRule__C .table .table-row .table-cell-2 .table-column-1[data-v-33026085],
.NorthRule__C .table-rule .table-row .table-cell-2 .table-column-1[data-v-33026085] {
    width: 50%;
    height: 0.90667rem;
    line-height: 0.90667rem;
    border: 0.01333rem solid var(--bgDark-2, var(--borderColor-5));
    margin-left: -0.01333rem;
    margin-bottom: -0.01333rem;
    border-top: none;
}

.NorthRule__C .table .table-row .table-cell-2 .table-column-1[data-v-33026085]:nth-child(2n),
.NorthRule__C .table-rule .table-row .table-cell-2 .table-column-1[data-v-33026085]:nth-child(2n) {
    border-right: none;
}

.NorthRule__C-Rule[data-v-33026085] {
    text-align: center;
    font-size: 0.48rem;
    color: var(--colorText-26);
}

.NorthRule__C-Struct[data-v-33026085] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    text-align: center;
    font-size: 0.4rem;
    color: var(--colorText-26);
    -webkit-box-pack: space-evenly;
    -webkit-justify-content: space-evenly;
    justify-content: space-evenly;
    margin-bottom: 0.4rem;
}

.NorthRule__C-Struct[data-v-33026085]:after,
.NorthRule__C-Struct[data-v-33026085]:before {
    display: block;
    content: "";
    width: 1.46667rem;
    height: 0.02667rem;
    background: -webkit-linear-gradient( left, var(--main-color) -2.73%, rgba(255, 113, 114, 0) 91.36%);
    background: linear-gradient( 90deg, var(--main-color) -2.73%, rgba(255, 113, 114, 0) 91.36%);
    border-radius: 0.26667rem;
    margin-top: 0.26667rem;
}

.NorthRule__C-Struct[data-v-33026085]:before {
    -webkit-transform: matrix(-1, 0, 0, 1, 0, 0);
    transform: scaleX(-1);
}

.NorthRule__C .table-rule[data-v-33026085] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-bottom: 0.53333rem;
    box-shadow: var(--BoxShadowColor-9);
    background-color: #fff;
    border-radius: 0.26667rem 0.26667rem 0 0;
}

.NorthRule__C .table-rule .table-header[data-v-33026085] {
    border-radius: 0.26667rem 0.26667rem 0 0;
    height: 1.01333rem;
    background-color: var(--main-color);
    color: #fff;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
}

.NorthRule__C .table-rule .table-header .table-header-cell[data-v-33026085] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
}

.NorthRule__C .table-rule .table-row[data-v-33026085] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.NorthRule__C .table-rule .table-row .table-cell[data-v-33026085] {
    height: 0.88rem;
    line-height: 0.88rem;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    border-right: 0.01333rem solid var(--bgDark-2, var(--borderColor-5));
}

.NorthRule__C .table-rule .table-box[data-v-33026085] {
    height: 0.88rem;
    line-height: 0.88rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    border: 0.01333rem solid var(--bgDark-2, var(--borderColor-5));
    border-top: none;
    text-align: center;
}

.NorthRule__C .table-rule .table-box.none[data-v-33026085] {
    display: none;
}

.NorthRule__C .table-rule .table-box-title[data-v-33026085] {
    width: 2.4rem;
}

.NorthRule__C .table-rule .table-box-number[data-v-33026085] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    border-left: 0.01333rem solid var(--bgDark-2, var(--borderColor-5));
}

.van-toast[data-v-19e150a9] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-19e150a9] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-19e150a9] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-19e150a9] {
    height: 80%;
}

.Play__C[data-v-19e150a9] {
    width: 100%;
}

.Play__C[data-v-19e150a9] .van-tab--card {
    min-width: 2.93333rem;
}

.Play__C-Cotent[data-v-19e150a9] {
    background-color: var(--darkBg, #fff);
    margin: 0 0.4rem 0.4rem;
    border-radius: 0.4rem;
}

.Play__C-Cotent .title[data-v-19e150a9] {
    width: 9.36rem;
    height: 0.8rem;
    line-height: 0.8rem;
    background: url(/assets/png/palybg-97711462.png) no-repeat center;
    background-size: auto 100%;
    background-color: #fff;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.Play__C-Cotent .title img[data-v-19e150a9] {
    display: block;
    width: 0.56rem;
    height: 0.56rem;
    margin: 0 0.26667rem;
}

.Play__C-Cotent .title>span[data-v-19e150a9] {
    color: #fff;
    font-size: 0.42667rem;
    font-weight: 600;
}

.Play__C-Cotent .info[data-v-19e150a9] {
    width: 100%;
    background-color: var(--darkBg, var(--bg_color_L2));
    margin-bottom: 0.4rem;
    padding: 0.26667rem 0.26667rem 0.4rem;
    border-radius: 0 0 0.26667rem 0.26667rem;
}

.Play__C-Cotent .info_item[data-v-19e150a9] {
    margin-bottom: 0.4rem;
    font-size: 0.34667rem;
    color: var(--text_color_L2);
}

.Play__C-Cotent .info_item>img[data-v-19e150a9] {
    width: 0.45333rem;
    height: 0.45333rem;
    display: inline-block;
    vertical-align: -0.05333rem;
    margin-right: 0.16rem;
}

.Play__C-Cotent .info_item .sub[data-v-19e150a9] {
    color: var(--darkTextW, var(--main-color));
    font-size: 0.42667rem;
}

.Play__C-Cotent .info_item .text[data-v-19e150a9] {
    margin: 0.21333rem 0.56rem 0;
    color: var(--text_color_L2);
    font-size: 0.34667rem;
    line-height: 0.53333rem;
}

.Play__C-Cotent .info_text[data-v-19e150a9] {
    border-radius: 0.26667rem;
    border: 0.01333rem solid var(--gray-color-1);
    padding: 0 0.22667rem 0.33333rem 0.68rem;
    color: var(--text_color_L2);
    font-size: 0.32rem;
}

.Play__C-Cotent .info_text>div[data-v-19e150a9] {
    margin-top: 0.2rem;
    line-height: 0.53333rem;
}

.van-toast[data-v-7bb580e6] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-7bb580e6] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-7bb580e6] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-7bb580e6] {
    height: 80%;
}

.NorthRule__C[data-v-7bb580e6] {
    width: 100%;
    background-color: var(--bg_color_L2);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
}

.NorthRule__C-title[data-v-7bb580e6] {
    font-size: 0.48rem;
    font-weight: 700;
    color: var(--colorText-26);
    text-align: center;
}

.NorthRule__C-tips[data-v-7bb580e6] {
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    margin-top: 0.2rem;
    margin-bottom: 0.44rem;
    text-align: center;
}

.NorthRule__C-Content[data-v-7bb580e6] {
    position: relative;
    padding: 0.57333rem 0.24rem 0.33333rem;
    border: 0.01333rem solid var(--bgDark-2, var(--main-color));
    border-top-left-radius: 0.26667rem;
    border-top-right-radius: 0.26667rem;
    background: var(--bg_color_L2);
    margin-bottom: 0.42667rem;
}

.NorthRule__C-Content .borderTopStyle[data-v-7bb580e6] {
    position: absolute;
    top: 0;
    left: 50%;
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
    width: 100%;
}

.NorthRule__C-Content .borderTopStyle span[data-v-7bb580e6] {
    position: absolute;
    top: 0;
}

.NorthRule__C-Content .borderTopStyle span[data-v-7bb580e6]:first-of-type,
.NorthRule__C-Content .borderTopStyle span[data-v-7bb580e6]:last-of-type {
    width: 0.68rem;
    height: 0.68rem;
    border-top: 0.06667rem solid var(--bgDark-2, var(--main-color));
}

.NorthRule__C-Content .borderTopStyle span[data-v-7bb580e6]:first-of-type:after,
.NorthRule__C-Content .borderTopStyle span[data-v-7bb580e6]:last-of-type:after {
    content: "";
    position: absolute;
    top: 0.29333rem;
    left: 0.2rem;
    width: 0.13333rem;
    height: 0.13333rem;
    background-color: var(--bgDark-2, var(--main-color));
}

html:lang(ar) .NorthRule__C-Content .borderTopStyle span[data-v-7bb580e6]:first-of-type:after,
html:lang(ar) .NorthRule__C-Content .borderTopStyle span[data-v-7bb580e6]:last-of-type:after {
    right: -0.06667rem;
    left: unset;
}

.NorthRule__C-Content .borderTopStyle span[data-v-7bb580e6]:first-of-type {
    left: -0.01333rem;
    border-right: 0.06667rem solid var(--bgDark-2, var(--main-color));
    border-top-left-radius: 0.26667rem;
}

html:lang(ar) .NorthRule__C-Content .borderTopStyle span[data-v-7bb580e6]:first-of-type {
    right: -0.01333rem;
    left: unset;
}

.NorthRule__C-Content .borderTopStyle span[data-v-7bb580e6]:first-of-type:after {
    border-radius: 50%;
}

.NorthRule__C-Content .borderTopStyle span[data-v-7bb580e6]:last-of-type {
    right: 0;
    border-right: 0.06667rem solid var(--bgDark-2, var(--main-color));
    border-top-right-radius: 0.26667rem;
}

.NorthRule__C-Content .borderTopStyle span[data-v-7bb580e6]:last-of-type:after {
    border-radius: 50%;
}

.NorthRule__C-Content[data-v-7bb580e6]:after,
.NorthRule__C-Content[data-v-7bb580e6]:before {
    content: "";
    display: block;
    position: absolute;
    top: -0.26667rem;
    width: 0.26667rem;
    height: 0.53333rem;
    background-color: var(--bgDark-2, var(--main-color));
    -webkit-clip-path: polygon( 50% 0%, 100% 0%, 50% 50%, 100% 100%, 50% 100%, 0% 50%);
    clip-path: polygon(50% 0%, 100% 0%, 50% 50%, 100% 100%, 50% 100%, 0% 50%);
    z-index: 5;
}

.NorthRule__C-Content[data-v-7bb580e6]:after {
    left: calc(50% - 1.2rem);
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
}

.NorthRule__C-Content[data-v-7bb580e6]:before {
    left: calc(50% + 1.2rem);
    -webkit-transform: translateX(-50%) rotate(180deg);
    transform: translate(-50%) rotate(180deg);
}

.NorthRule__C-Content .title[data-v-7bb580e6] {
    position: absolute;
    top: -0.26667rem;
    left: 50%;
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
    width: 2.13333rem;
    height: 0.53333rem;
    color: #fff;
    font-size: 0.32rem;
    text-align: center;
    line-height: 0.53333rem;
    background-color: var(--bgDark-2, var(--main-color));
    -webkit-clip-path: polygon( 7% 0%, 93% 0%, 100% 50%, 93% 100%, 7% 100%, 0% 50%);
    clip-path: polygon(7% 0%, 93% 0%, 100% 50%, 93% 100%, 7% 100%, 0% 50%);
}

.NorthRule__C-Content .text[data-v-7bb580e6] {
    margin: 0 0.26667rem;
    font-size: 0.32rem;
    color: var(--text_color_L2);
}

.NorthRule__C .table[data-v-7bb580e6],
.NorthRule__C .table-rule[data-v-7bb580e6] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    margin-bottom: 0.53333rem;
    background-color: var(--darkBg, var(--bg_color_L2));
}

.NorthRule__C .table .table-row[data-v-7bb580e6],
.NorthRule__C .table-rule .table-row[data-v-7bb580e6] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    text-align: center;
    color: var(--text_color_L2);
    font-size: 0.34667rem;
    border-top-left-radius: 0.26667rem;
    border-top-right-radius: 0.26667rem;
}

.NorthRule__C .table .table-row.header-time[data-v-7bb580e6],
.NorthRule__C .table-rule .table-row.header-time[data-v-7bb580e6] {
    height: 1.33333rem;
    line-height: 1.33333rem;
    background: var(--main-color);
    text-align: center;
    color: #fff;
    font-size: 0.34667rem;
    border-radius: 0;
}

.NorthRule__C .table .table-row.header-week[data-v-7bb580e6],
.NorthRule__C .table-rule .table-row.header-week[data-v-7bb580e6] {
    height: 0.88rem;
    line-height: 0.88rem;
    background: var(--norm_red-color);
    text-align: center;
    color: #fff;
    font-size: 0.34667rem;
    border-radius: 0;
}

.NorthRule__C .table .table-row .table-week-1[data-v-7bb580e6],
.NorthRule__C .table .table-row .table-time-1[data-v-7bb580e6],
.NorthRule__C .table-rule .table-row .table-week-1[data-v-7bb580e6],
.NorthRule__C .table-rule .table-row .table-time-1[data-v-7bb580e6] {
    height: 0.88rem;
    line-height: 0.88rem;
    overflow: hidden;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    text-align: center;
}

.NorthRule__C .table .table-row[data-v-7bb580e6],
.NorthRule__C .table-rule .table-row[data-v-7bb580e6] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    border: 0.01333rem solid var(--bgDark-2, var(--borderColor-5));
    border-top: none;
    margin-bottom: -0.01333rem;
    border-radius: 0;
}

.NorthRule__C .table .table-row .table-cell-1[data-v-7bb580e6],
.NorthRule__C .table-rule .table-row .table-cell-1[data-v-7bb580e6] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
}

.NorthRule__C .table .table-row .table-cell-2[data-v-7bb580e6],
.NorthRule__C .table-rule .table-row .table-cell-2[data-v-7bb580e6] {
    -webkit-box-flex: 2;
    -webkit-flex: 2;
    flex: 2;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
}

.NorthRule__C .table .table-row .table-cell-2 .table-column-1[data-v-7bb580e6],
.NorthRule__C .table-rule .table-row .table-cell-2 .table-column-1[data-v-7bb580e6] {
    width: 50%;
    height: 0.90667rem;
    line-height: 0.90667rem;
    border: 0.01333rem solid var(--bgDark-2, var(--borderColor-5));
    margin-left: -0.01333rem;
    margin-bottom: -0.01333rem;
    border-top: none;
}

.NorthRule__C .table .table-row .table-cell-2 .table-column-1[data-v-7bb580e6]:nth-child(2n),
.NorthRule__C .table-rule .table-row .table-cell-2 .table-column-1[data-v-7bb580e6]:nth-child(2n) {
    border-right: none;
}

.NorthRule__C-Rule[data-v-7bb580e6] {
    text-align: center;
    font-size: 0.48rem;
    color: var(--colorText-26);
}

.NorthRule__C-Struct[data-v-7bb580e6] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    text-align: center;
    font-size: 0.4rem;
    color: var(--colorText-26);
    -webkit-box-pack: space-evenly;
    -webkit-justify-content: space-evenly;
    justify-content: space-evenly;
    margin-bottom: 0.4rem;
}

.NorthRule__C-Struct[data-v-7bb580e6]:after,
.NorthRule__C-Struct[data-v-7bb580e6]:before {
    display: block;
    content: "";
    width: 1.46667rem;
    height: 0.02667rem;
    background: -webkit-linear-gradient( left, var(--main-color) -2.73%, rgba(255, 113, 114, 0) 91.36%);
    background: linear-gradient( 90deg, var(--main-color) -2.73%, rgba(255, 113, 114, 0) 91.36%);
    border-radius: 0.26667rem;
    margin-top: 0.26667rem;
}

.NorthRule__C-Struct[data-v-7bb580e6]:before {
    -webkit-transform: matrix(-1, 0, 0, 1, 0, 0);
    transform: scaleX(-1);
}

.NorthRule__C .table-rule[data-v-7bb580e6] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-bottom: 0.53333rem;
    box-shadow: var(--BoxShadowColor-9);
    background-color: #fff;
    border-radius: 0.26667rem 0.26667rem 0 0;
}

.NorthRule__C .table-rule .table-header[data-v-7bb580e6] {
    border-radius: 0.26667rem 0.26667rem 0 0;
    height: 1.01333rem;
    background-color: var(--main-color);
    color: #fff;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    text-align: center;
}

.NorthRule__C .table-rule .table-header .table-header-cell[data-v-7bb580e6] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
}

.NorthRule__C .table-rule .table-row[data-v-7bb580e6] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.NorthRule__C .table-rule .table-row .table-cell[data-v-7bb580e6] {
    height: 0.88rem;
    line-height: 0.88rem;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    border-right: 0.01333rem solid var(--bgDark-2, var(--borderColor-5));
}

.NorthRule__C .table-rule .table-box[data-v-7bb580e6] {
    height: 0.88rem;
    line-height: 0.88rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    border: 0.01333rem solid var(--bgDark-2, var(--borderColor-5));
    border-top: none;
    text-align: center;
}

.NorthRule__C .table-rule .table-box.none[data-v-7bb580e6] {
    display: none;
}

.NorthRule__C .table-rule .table-box-title[data-v-7bb580e6] {
    width: 2.4rem;
}

.NorthRule__C .table-rule .table-box-number[data-v-7bb580e6] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    border-left: 0.01333rem solid var(--bgDark-2, var(--borderColor-5));
}

.van-toast[data-v-f14c68e9] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-f14c68e9] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-f14c68e9] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-f14c68e9] {
    height: 80%;
}

.vietnamPlay__C[data-v-f14c68e9] {
    width: 100%;
}

.vietnamPlay__C[data-v-f14c68e9] .van-tabs__wrap {
    margin: 0.34667rem 0;
    height: 1.06667rem;
    line-height: 1.06667rem;
}

.vietnamPlay__C[data-v-f14c68e9] .van-tabs__wrap .van-tabs__nav {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--darkBg, var(--bg_color_L2));
    border: 0.01333rem solid var(--darkBg, var(--bg_color_L2));
    border-radius: 0.13333rem;
    overflow: hidden;
}

.vietnamPlay__C[data-v-f14c68e9] .van-tabs__wrap .van-tab--card {
    color: var(--text_color_L2);
    font-size: 0.42667rem;
    border-right: none;
}

.vietnamPlay__C[data-v-f14c68e9] .van-tabs__wrap .van-tab--active {
    border-radius: 0.13333rem;
    background: var(--linerGradien-94, var(--main_gradient-color2));
    border-right: 0.01333rem solid var(--walletBgColor-1);
    color: #fff;
}

.vietnamPlay__C .northrule[data-v-f14c68e9],
.vietnamPlay__C .sorthrule[data-v-f14c68e9] {
    margin: 0.42667rem 0.32rem;
}

.vietnamPlay__C .dis[data-v-f14c68e9]>.van-tabs__wrap:first-of-type {
    display: none;
}

.van-toast[data-v-3e4c6499] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-3e4c6499] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-3e4c6499] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-3e4c6499] {
    height: 80%;
}

.TimeLeft__C[data-v-3e4c6499] {
    width: calc(100% - 0.69333rem);
    height: 2.66667rem;
    margin: 0.48rem auto 0;
    background-image: url(/assets/png/wingoissue-35ba643e.png);
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-position: 0.01333rem center;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    position: relative;
    color: var(--text_color_L4);
}

.TimeLeft__C-rule[data-v-3e4c6499] {
    position: absolute;
    top: 0.29333rem;
    left: 0.29333rem;
    height: 0.61333rem;
    width: 4rem;
    font-size: 0.29333rem;
    text-align: center;
    border: 0.01333rem solid var(--bg_color_L2);
    border-radius: 0.8rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    gap: 0.06667rem;
}

html:lang(ar) .TimeLeft__C-rule[data-v-3e4c6499] {
    left: unset;
    right: 0.29333rem;
}

.TimeLeft__C-rule svg[data-v-3e4c6499] {
    height: 0.48rem;
    width: 0.48rem;
    color: var(--text_color_L4);
}

.TimeLeft__C-name[data-v-3e4c6499] {
    position: absolute;
    top: 0.96rem;
    left: 0.29333rem;
    height: 0.66667rem;
    line-height: 0.66667rem;
    border-radius: 0.13333rem;
    font-size: 0.29333rem;
    padding: 0 0.16rem;
}

html:lang(ar) .TimeLeft__C-name[data-v-3e4c6499] {
    left: unset;
    right: 0.29333rem;
}

.TimeLeft__C-num[data-v-3e4c6499] {
    position: absolute;
    height: 0.66667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    left: 0.29333rem;
    bottom: 0.30667rem;
}

html:lang(ar) .TimeLeft__C-num[data-v-3e4c6499] {
    left: unset;
    right: 0.29333rem;
}

.TimeLeft__C-num>div[data-v-3e4c6499] {
    width: 0.66667rem;
    height: 0.66667rem;
    background-repeat: no-repeat;
    background-size: 0.66667rem;
}

.TimeLeft__C-num>div+div[data-v-3e4c6499] {
    margin-left: 0.16rem;
}

.TimeLeft__C-num>div.n0[data-v-3e4c6499] {
    background-image: url(/assets/png/n0-30bd92d1.png);
}

.TimeLeft__C-num>div.n1[data-v-3e4c6499] {
    background-image: url(/assets/png/n1-dfccbff5.png);
}

.TimeLeft__C-num>div.n2[data-v-3e4c6499] {
    background-image: url(/assets/png/n2-c2913607.png);
}

.TimeLeft__C-num>div.n3[data-v-3e4c6499] {
    background-image: url(/assets/png/n3-f92c313f.png);
}

.TimeLeft__C-num>div.n4[data-v-3e4c6499] {
    background-image: url(/assets/png/n4-cb84933b.png);
}

.TimeLeft__C-num>div.n5[data-v-3e4c6499] {
    background-image: url(/assets/png/n5-49d0e9c5.png);
}

.TimeLeft__C-num>div.n6[data-v-3e4c6499] {
    background-image: url(/assets/png/n6-a56e0b9a.png);
}

.TimeLeft__C-num>div.n7[data-v-3e4c6499] {
    background-image: url(/assets/png/n7-5961a17f.png);
}

.TimeLeft__C-num>div.n8[data-v-3e4c6499] {
    background-image: url(/assets/png/n8-d4d951a4.png);
}

.TimeLeft__C-num>div.n9[data-v-3e4c6499] {
    background-image: url(/assets/png/n9-a20f6f42.png);
}

.TimeLeft__C-id[data-v-3e4c6499] {
    position: absolute;
    bottom: 0.22667rem;
    right: 0.29333rem;
    font-weight: 700;
    font-size: 0.42667rem;
    height: 0.52rem;
    line-height: 0.52rem;
    color: var(--textM3);
}

.TimeLeft__C-text[data-v-3e4c6499] {
    height: 0.4rem;
    line-height: 0.4rem;
    font-weight: 700;
    font-size: 0.32rem;
    position: absolute;
    top: 0.34667rem;
    right: 0.32rem;
}

.TimeLeft__C-time[data-v-3e4c6499] {
    height: 0.8rem;
    line-height: 0.8rem;
    position: absolute;
    bottom: 1.01333rem;
    right: 0.34667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.TimeLeft__C-time>div[data-v-3e4c6499] {
    background-color: var(--darkLight2, var(--bg_color_L2));
    color: var(--text_color_L1);
    font-weight: 700;
    font-size: 0.48rem;
    text-align: center;
    padding: 0 0.10667rem;
}

.TimeLeft__C-time>div+div[data-v-3e4c6499] {
    margin-left: 0.12rem;
}

.TimeLeft__C-time>div[data-v-3e4c6499]:first-child {
    background: var(--bg_color_L1);
}

.TimeLeft__C-time>div[data-v-3e4c6499]:last-child {
    background: var(--bg_color_L1);
}

.van-toast[data-v-7f36fe93] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-7f36fe93] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-7f36fe93] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-7f36fe93] {
    height: 80%;
}

.Betting__Popup-head[data-v-7f36fe93] {
    height: 2.53333rem;
    position: relative;
    padding-top: 0.4rem;
}

.Betting__Popup-head[data-v-7f36fe93]:after {
    content: "";
    position: absolute;
    width: 50%;
    left: 0;
    bottom: 0;
    height: 0.78667rem;
    background-image: -webkit-linear-gradient( 81deg, var(--bg_color_L2) 50%, transparent 50%);
    background-image: linear-gradient( 9deg, var(--bg_color_L2) 50%, transparent 50%);
}

.Betting__Popup-head[data-v-7f36fe93]:before {
    content: "";
    position: absolute;
    right: 0;
    bottom: 0;
    width: 50%;
    height: 0.78667rem;
    background-image: -webkit-linear-gradient( 99deg, var(--bg_color_L2) 50%, transparent 50%);
    background-image: linear-gradient( -9deg, var(--bg_color_L2) 50%, transparent 50%);
}

.Betting__Popup-head-title[data-v-7f36fe93] {
    height: 0.58667rem;
    font-weight: 700;
    font-size: 0.48rem;
    text-align: center;
    color: #fff;
}

.Betting__Popup-head-selectName[data-v-7f36fe93] {
    width: 7.46667rem;
    height: 0.66667rem;
    margin: 0.21333rem auto 0;
    background: #fff;
    border-radius: 0.13333rem;
    text-align: center;
    font-weight: 500;
    font-size: 0.34667rem;
    color: #000;
}

.Betting__Popup-head-selectName>span[data-v-7f36fe93] {
    line-height: 0.66667rem;
}

.Betting__Popup-head-selectName>span+span[data-v-7f36fe93] {
    margin-left: 0.37333rem;
}

.Betting__Popup-body[data-v-7f36fe93] {
    height: 5.2rem;
    padding: 0.76rem 0.34667rem 0.53333rem;
}

.Betting__Popup-body-line[data-v-7f36fe93] {
    font-size: 0.42667rem;
    color: var(--text_color_L1);
    height: 0.74667rem;
    line-height: 0.74667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Betting__Popup-body-line-list[data-v-7f36fe93] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Betting__Popup-body-line-item[data-v-7f36fe93] {
    padding: 0 0.21333rem;
    background: var(--bg_color_L3);
    border-radius: 0.13333rem;
}

.Betting__Popup-body-line-item+div[data-v-7f36fe93] {
    margin-left: 0.16rem;
}

.Betting__Popup-body-line+div[data-v-7f36fe93] {
    margin-top: 0.4rem;
}

.Betting__Popup-body-line-btnL[data-v-7f36fe93] {
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.Betting__Popup-body-line[data-v-7f36fe93]:last-child {
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    justify-content: flex-start;
}

.Betting__Popup-foot[data-v-7f36fe93] {
    height: 0.96rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    text-align: center;
    line-height: 0.96rem;
    font-size: 0.37333rem;
    color: var(--text_color_L1);
}

.Betting__Popup-foot-c[data-v-7f36fe93] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    background: var(--bg_color_L3);
    color: var(--text_color_L2);
}

.Betting__Popup-foot-s[data-v-7f36fe93] {
    -webkit-box-flex: 2;
    -webkit-flex: 2;
    flex: 2;
}

.Betting__Popup-11 .bgcolor[data-v-7f36fe93],
.Betting__Popup-1 .bgcolor[data-v-7f36fe93],
.Betting__Popup-3 .bgcolor[data-v-7f36fe93],
.Betting__Popup-7 .bgcolor[data-v-7f36fe93],
.Betting__Popup-9 .bgcolor[data-v-7f36fe93] {
    background-color: var(--norm_green-color);
}

.Betting__Popup-11 .Betting__Popup-head[data-v-7f36fe93],
.Betting__Popup-1 .Betting__Popup-head[data-v-7f36fe93],
.Betting__Popup-3 .Betting__Popup-head[data-v-7f36fe93],
.Betting__Popup-7 .Betting__Popup-head[data-v-7f36fe93],
.Betting__Popup-9 .Betting__Popup-head[data-v-7f36fe93] {
    background: var(--norm_green-color);
}

.Betting__Popup-10 .bgcolor[data-v-7f36fe93],
.Betting__Popup-2 .bgcolor[data-v-7f36fe93],
.Betting__Popup-4 .bgcolor[data-v-7f36fe93],
.Betting__Popup-6 .bgcolor[data-v-7f36fe93],
.Betting__Popup-8 .bgcolor[data-v-7f36fe93] {
    background-color: var(--norm_red-color);
}

.Betting__Popup-10 .Betting__Popup-head[data-v-7f36fe93],
.Betting__Popup-2 .Betting__Popup-head[data-v-7f36fe93],
.Betting__Popup-4 .Betting__Popup-head[data-v-7f36fe93],
.Betting__Popup-6 .Betting__Popup-head[data-v-7f36fe93],
.Betting__Popup-8 .Betting__Popup-head[data-v-7f36fe93] {
    background: var(--norm_red-color);
}

.Betting__Popup-0 .bgcolor[data-v-7f36fe93] {
    background-color: var(--norm_red-color);
}

.Betting__Popup-0 .Betting__Popup-head[data-v-7f36fe93] {
    background: -webkit-linear-gradient( top left, var(--norm_red-color) 50%, var(--norm_Purple-color) 0);
    background: linear-gradient( to bottom right, var(--norm_red-color) 50%, var(--norm_Purple-color) 0);
}

.Betting__Popup-5 .bgcolor[data-v-7f36fe93] {
    background-color: var(--norm_green-color);
}

.Betting__Popup-5 .Betting__Popup-head[data-v-7f36fe93] {
    background: -webkit-linear-gradient( top left, var(--norm_green-color) 50%, var(--norm_Purple-color) 0);
    background: linear-gradient( to bottom right, var(--norm_green-color) 50%, var(--norm_Purple-color) 0);
}

.Betting__Popup-12 .bgcolor[data-v-7f36fe93] {
    background-color: var(--norm_Purple-color);
}

.Betting__Popup-12 .Betting__Popup-head[data-v-7f36fe93] {
    background: var(--norm_Purple-color);
}

.Betting__Popup-13 .bgcolor[data-v-7f36fe93] {
    background-color: var(--norm_secondary-color);
}

.Betting__Popup-13 .Betting__Popup-head[data-v-7f36fe93] {
    background: var(--norm_secondary-color);
}

.Betting__Popup-14 .bgcolor[data-v-7f36fe93] {
    background-color: var(--norm_bule-color);
}

.Betting__Popup-14 .Betting__Popup-head[data-v-7f36fe93] {
    background: var(--norm_bule-color);
}

.Betting__Popup-btn[data-v-7f36fe93] {
    width: 0.74667rem;
    height: 0.74667rem;
    pointer-events: none;
    text-align: center;
    font-size: 0.66667rem;
    padding: 0;
    background: var(--bg_color_L3);
    color: var(--button_dis_color);
    border-radius: 0.13333rem;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
}

.Betting__Popup-input[data-v-7f36fe93] {
    border: 0.01333rem solid var(--bg_color_L3);
    background-color: var(--bg_color_L1);
    padding: 0.02667rem 0.26667rem;
    width: 2.10667rem;
    margin: 0 0.16rem;
}

.Betting__Popup-input[data-v-7f36fe93] .van-field__control {
    text-align: center;
    font-size: 0.37333rem;
    line-height: 0.72rem;
}

.Betting__Popup-agree[data-v-7f36fe93] {
    padding-left: 0.8rem;
    background-image: url(/assets/png/agree-b-47b8f86d.png);
    background-repeat: no-repeat;
    background-position: left center;
    background-size: 0.64rem;
    font-size: 0.32rem;
    color: var(--colorText-3);
}

html:lang(ar) .Betting__Popup-agree[data-v-7f36fe93] {
    background-position: right center;
}

.Betting__Popup-agree.active[data-v-7f36fe93] {
    background-image: url(/assets/png/agree-a-32b06ce9.png);
}

.Betting__Popup-preSaleShow[data-v-7f36fe93] {
    margin-left: 0.34667rem;
    font-size: 0.32rem;
    color: var(--norm_red-color);
}

.Betting__Popup-PreSale[data-v-7f36fe93] {
    width: 7.04rem;
}

.Betting__Popup-PreSale-head[data-v-7f36fe93] {
    height: 1.2rem;
    line-height: 1.2rem;
    color: var(--text_color_L1);
    font-size: 0.4rem;
    text-align: center;
    background: var(--main_gradient-color);
}

.Betting__Popup-PreSale-body[data-v-7f36fe93] {
    max-height: 8rem;
    overflow-y: auto;
    color: var(--text_color_L1);
    padding: 0.4rem;
    font-size: 0.32rem;
    line-height: 0.8rem;
}

.Betting__Popup-PreSale-body[data-v-7f36fe93] p {
    margin-bottom: 0.2rem;
    line-height: 0.53333rem;
}

.Betting__Popup-PreSale-foot[data-v-7f36fe93] {
    height: 1.86667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.Betting__Popup-PreSale-foot-btn[data-v-7f36fe93] {
    width: 60%;
    background: var(--main_gradient-color);
    border-radius: 0.53333rem;
    height: 0.93333rem;
    line-height: 0.93333rem;
    text-align: center;
    font-size: 0.37333rem;
    color: var(--text_color_L1);
}

.bgcolor[data-v-7f36fe93] {
    pointer-events: all;
    color: #fff;
}

.van-toast[data-v-4aca9bd1] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-4aca9bd1] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-4aca9bd1] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-4aca9bd1] {
    height: 80%;
}

.Betting__C[data-v-4aca9bd1] {
    height: 7.61333rem;
    width: calc(100% - 0.69333rem);
    margin: 0.29333rem auto 0;
    background: var(--darkBg, var(--bg_color_L2));
    box-shadow: var(--boxShadowColor-35);
    border-radius: 0.26667rem;
    padding: 0.18667rem 0.26667rem 0.25333rem 0.18667rem;
    position: relative;
}

.Betting__C-mark[data-v-4aca9bd1] {
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    position: absolute;
    z-index: 99;
    top: 0;
    left: 0;
    color: var(--main-color);
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

html:lang(ar) .Betting__C-mark[data-v-4aca9bd1] {
    left: unset;
    right: 0;
    direction: ltr;
}

.Betting__C-mark>div[data-v-4aca9bd1] {
    display: inline-block;
    border-radius: 0.4rem;
    padding: 0 0.4rem;
    background-color: var(--bg_color_L3);
    font-weight: 700;
    font-size: 3.73333rem;
}

.Betting__C-mark>div+div[data-v-4aca9bd1] {
    margin-left: 1.04rem;
}

.Betting__C-head[data-v-4aca9bd1] {
    height: 0.93333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Betting__C-head>div[data-v-4aca9bd1] {
    width: calc((100% - 0.8rem) / 3);
    height: 0.93333rem;
    line-height: 0.93333rem;
    font-weight: 500;
    font-size: 0.37333rem;
    color: #fff;
    text-align: center;
}

.Betting__C-head-g[data-v-4aca9bd1] {
    background: var(--norm_green-color);
    border-radius: 0 0.26667rem;
    box-shadow: var(--boxShadowColor-48);
}

.Betting__C-head-p[data-v-4aca9bd1] {
    background: var(--norm_Purple-color);
    box-shadow: var(--boxShadowColor-49);
    border-radius: 0.13333rem;
}

.Betting__C-head-r[data-v-4aca9bd1] {
    background: var(--norm_red-color);
    border-radius: 0.26667rem 0;
    box-shadow: var(--boxShadowColor-red);
}

.Betting__C-numC[data-v-4aca9bd1] {
    height: 3.46667rem;
    margin-top: 0.34667rem;
    background: var(--bg_color_L1);
    border-radius: 0.26667rem;
    padding: 0.17333rem 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Betting__C-numC>div[data-v-4aca9bd1] {
    width: 1.46667rem;
    height: 50%;
    border-radius: 50%;
    font-weight: 400;
    text-align: center;
    background-repeat: no-repeat;
    background-size: 1.46667rem;
    background-position: center;
}

.Betting__C-numC>div.active[data-v-4aca9bd1] {
    -webkit-transform: scale(0.9);
    transform: scale(0.9);
}

.Betting__C-numC>div.Betting__C-numC-item0[data-v-4aca9bd1] {
    background-image: url(/assets/png/n0-30bd92d1.png);
}

.Betting__C-numC>div.Betting__C-numC-item1[data-v-4aca9bd1] {
    background-image: url(/assets/png/n1-dfccbff5.png);
}

.Betting__C-numC>div.Betting__C-numC-item2[data-v-4aca9bd1] {
    background-image: url(/assets/png/n2-c2913607.png);
}

.Betting__C-numC>div.Betting__C-numC-item3[data-v-4aca9bd1] {
    background-image: url(/assets/png/n3-f92c313f.png);
}

.Betting__C-numC>div.Betting__C-numC-item4[data-v-4aca9bd1] {
    background-image: url(/assets/png/n4-cb84933b.png);
}

.Betting__C-numC>div.Betting__C-numC-item5[data-v-4aca9bd1] {
    background-image: url(/assets/png/n5-49d0e9c5.png);
}

.Betting__C-numC>div.Betting__C-numC-item6[data-v-4aca9bd1] {
    background-image: url(/assets/png/n6-a56e0b9a.png);
}

.Betting__C-numC>div.Betting__C-numC-item7[data-v-4aca9bd1] {
    background-image: url(/assets/png/n7-5961a17f.png);
}

.Betting__C-numC>div.Betting__C-numC-item8[data-v-4aca9bd1] {
    background-image: url(/assets/png/n8-d4d951a4.png);
}

.Betting__C-numC>div.Betting__C-numC-item9[data-v-4aca9bd1] {
    background-image: url(/assets/png/n9-a20f6f42.png);
}

.Betting__C-multiple[data-v-4aca9bd1] {
    margin-top: 0.29333rem;
    height: 0.90667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Betting__C-multiple-l[data-v-4aca9bd1] {
    width: 2.13333rem;
    height: 0.90667rem;
    line-height: 0.90667rem;
    text-align: center;
    border: 0.02667rem solid var(--darkLight, var(--norm_red-color));
    border-radius: 0.21333rem;
    font-size: 0.37333rem;
    color: var(--darkLight, var(--norm_red-color));
}

.Betting__C-multiple-r[data-v-4aca9bd1] {
    height: 0.8rem;
    width: 0.98667rem;
    line-height: 0.8rem;
    font-size: 0.32rem;
    color: var(--darkTextW, var(--text_color_L2));
    background: var(--bgDark-4, var(--bg_color_L1));
    border-radius: 0.21333rem;
    text-align: center;
}

.Betting__C-multiple-r.active[data-v-4aca9bd1] {
    background: var(--norm_green-color);
    color: #fff;
}

.Betting__C-foot[data-v-4aca9bd1] {
    height: 0.96rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    margin-top: 0.26667rem;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.Betting__C-foot-b[data-v-4aca9bd1],
.Betting__C-foot-s[data-v-4aca9bd1] {
    width: 4.13333rem;
    height: 0.96rem;
    line-height: 0.96rem;
    text-align: center;
    font-size: 0.42667rem;
    color: #fff;
}

.Betting__C-foot-b[data-v-4aca9bd1] {
    background-color: var(--norm_secondary-color);
    border-radius: 0.53333rem 0 0 0.53333rem;
}

.Betting__C-foot-s[data-v-4aca9bd1] {
    background: var(--norm_bule-color);
    border-radius: 0 0.53333rem 0.53333rem 0;
}

.Betting__C .bgcolor[data-v-4aca9bd1] {
    color: var(--text_color_L1) !important;
}

.Betting__C-popup-head[data-v-4aca9bd1] {
    height: 2.53333rem;
    position: relative;
    padding-top: 0.4rem;
}

.Betting__C-popup-head[data-v-4aca9bd1]:after {
    content: "";
    position: absolute;
    width: 50%;
    left: 0;
    bottom: 0;
    height: 0.78667rem;
    background-image: -webkit-linear-gradient( 81deg, var(--bg_color_L2) 50%, transparent 50%);
    background-image: linear-gradient( 9deg, var(--bg_color_L2) 50%, transparent 50%);
}

html:lang(ar) .Betting__C-popup-head[data-v-4aca9bd1]:after {
    left: unset;
    right: 0;
}

.Betting__C-popup-head[data-v-4aca9bd1]:before {
    content: "";
    position: absolute;
    right: 0;
    bottom: 0;
    width: 50%;
    height: 0.78667rem;
    background-image: -webkit-linear-gradient( 99deg, var(--bg_color_L2) 50%, transparent 50%);
    background-image: linear-gradient( -9deg, var(--bg_color_L2) 50%, transparent 50%);
}

html:lang(ar) .Betting__C-popup-head[data-v-4aca9bd1]:before {
    left: 0;
    right: unset;
}

.Betting__C-popup-head-title[data-v-4aca9bd1] {
    height: 0.58667rem;
    font-weight: 700;
    font-size: 0.48rem;
    text-align: center;
    color: var(--text_color_L1);
}

.Betting__C-popup-head-selectName[data-v-4aca9bd1] {
    width: 7.46667rem;
    height: 0.66667rem;
    margin: 0.21333rem auto 0;
    background: var(--bg_color_L2);
    border-radius: 0.13333rem;
    text-align: center;
    font-weight: 500;
    font-size: 0.34667rem;
}

.Betting__C-popup-head-selectName>span[data-v-4aca9bd1] {
    line-height: 0.66667rem;
}

.Betting__C-popup-head-selectName>span+span[data-v-4aca9bd1] {
    margin-left: 0.37333rem;
}

.Betting__C-popup-body[data-v-4aca9bd1] {
    height: 5.2rem;
    padding: 0.76rem 0.34667rem 0.53333rem;
}

.Betting__C-popup-body-line[data-v-4aca9bd1] {
    font-size: 0.42667rem;
    color: var(--colorText-3);
    height: 0.74667rem;
    line-height: 0.74667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Betting__C-popup-body-line-list[data-v-4aca9bd1] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Betting__C-popup-body-line-item[data-v-4aca9bd1] {
    padding: 0 0.21333rem;
    background: var(--gray-color-1);
}

.Betting__C-popup-body-line-item+div[data-v-4aca9bd1] {
    margin-left: 0.16rem;
}

.Betting__C-popup-body-line+div[data-v-4aca9bd1] {
    margin-top: 0.4rem;
}

.Betting__C-popup-body-line-btnL[data-v-4aca9bd1] {
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.Betting__C-popup-body-line[data-v-4aca9bd1]:last-child {
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    justify-content: flex-start;
}

.Betting__C-popup-foot[data-v-4aca9bd1] {
    height: 0.96rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    text-align: center;
    line-height: 0.96rem;
    font-size: 0.37333rem;
    color: var(--text_color_L1);
}

.Betting__C-popup-foot-c[data-v-4aca9bd1] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    background: var(--bgcolor-1);
    color: var(--text_color_L2);
}

.Betting__C-popup-foot-s[data-v-4aca9bd1] {
    -webkit-box-flex: 2;
    -webkit-flex: 2;
    flex: 2;
}

.Betting__C-popup-12 .bgcolor[data-v-4aca9bd1],
.Betting__C-popup-1 .bgcolor[data-v-4aca9bd1],
.Betting__C-popup-3 .bgcolor[data-v-4aca9bd1],
.Betting__C-popup-7 .bgcolor[data-v-4aca9bd1],
.Betting__C-popup-9 .bgcolor[data-v-4aca9bd1] {
    background-color: var(--norm_green-color);
}

.Betting__C-popup-12 .Betting__C-popup-head[data-v-4aca9bd1],
.Betting__C-popup-1 .Betting__C-popup-head[data-v-4aca9bd1],
.Betting__C-popup-3 .Betting__C-popup-head[data-v-4aca9bd1],
.Betting__C-popup-7 .Betting__C-popup-head[data-v-4aca9bd1],
.Betting__C-popup-9 .Betting__C-popup-head[data-v-4aca9bd1] {
    background: var(--linearGradien-1);
}

.Betting__C-popup-10 .bgcolor[data-v-4aca9bd1],
.Betting__C-popup-2 .bgcolor[data-v-4aca9bd1],
.Betting__C-popup-4 .bgcolor[data-v-4aca9bd1],
.Betting__C-popup-6 .bgcolor[data-v-4aca9bd1],
.Betting__C-popup-8 .bgcolor[data-v-4aca9bd1] {
    background-color: var(--norm_red-color);
}

.Betting__C-popup-10 .Betting__C-popup-head[data-v-4aca9bd1],
.Betting__C-popup-2 .Betting__C-popup-head[data-v-4aca9bd1],
.Betting__C-popup-4 .Betting__C-popup-head[data-v-4aca9bd1],
.Betting__C-popup-6 .Betting__C-popup-head[data-v-4aca9bd1],
.Betting__C-popup-8 .Betting__C-popup-head[data-v-4aca9bd1] {
    background: var(--main-color);
}

.Betting__C-popup-0 .bgcolor[data-v-4aca9bd1] {
    background-color: var(--norm_red-color);
}

.Betting__C-popup-0 .Betting__C-popup-head[data-v-4aca9bd1] {
    background: var(--linearGradien-5);
}

.Betting__C-popup-5 .bgcolor[data-v-4aca9bd1] {
    background-color: var(--norm_red-color);
}

.Betting__C-popup-5 .Betting__C-popup-head[data-v-4aca9bd1] {
    background: -webkit-linear-gradient( top left, var(--norm_red-color) 50%, #eb43dd 0);
    background: linear-gradient( to bottom right, var(--norm_red-color) 50%, #eb43dd 0);
}

.Betting__C-popup-11 .bgcolor[data-v-4aca9bd1] {
    background-color: var(--norm_Purple-color);
}

.Betting__C-popup-11 .Betting__C-popup-head[data-v-4aca9bd1] {
    background: var(--norm_Purple-color);
}

.Betting__C-popup-13 .bgcolor[data-v-4aca9bd1] {
    background-color: var(--norm_secondary-color);
}

.Betting__C-popup-13 .Betting__C-popup-head[data-v-4aca9bd1] {
    background: var(--linearGradien-8);
}

.Betting__C-popup-14 .bgcolor[data-v-4aca9bd1] {
    background-color: var(--norm_bule-color);
}

.Betting__C-popup-14 .Betting__C-popup-head[data-v-4aca9bd1] {
    background: var(--linearGradien-9);
}

.Betting__C-popup-btn[data-v-4aca9bd1] {
    width: 0.74667rem;
    height: 0.74667rem;
    pointer-events: none;
    text-align: center;
    font-size: 0.66667rem;
    padding: 0;
    color: var(--gray-color-1);
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
}

.Betting__C-popup .bgcolor[data-v-4aca9bd1] {
    pointer-events: all;
    color: var(--text_color_L1);
}

.Betting__C-popup-input[data-v-4aca9bd1] {
    border: 0.01333rem solid var(--gray-color-1);
    padding: 0.02667rem 0.26667rem;
    width: 2.10667rem;
}

.Betting__C-popup-input[data-v-4aca9bd1] .van-field__control {
    text-align: center;
    font-size: 0.37333rem;
    line-height: 0.72rem;
}

.van-toast[data-v-481307ec] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-481307ec] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-481307ec] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-481307ec] {
    height: 80%;
}

.GameRecord__C[data-v-481307ec] {
    width: calc(100% - 0.69333rem);
    margin: 0.48rem auto 0;
    text-align: center;
    font-size: 0.32rem;
}

.GameRecord__C-head[data-v-481307ec] {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--bgDark-2, var(--sheet_nva_color));
    border-radius: 0.13333rem 0.13333rem 0 0;
    font-weight: 700;
    font-size: 0.34667rem;
    color: #fff;
}

.GameRecord__C-body[data-v-481307ec] {
    line-height: 1.06667rem;
}

.GameRecord__C-body-redC[data-v-481307ec] {
    color: var(--sheet_nva_color);
    width: 100%;
    height: 100%;
    background-size: 0.66667rem;
    background-repeat: no-repeat;
    background-position: center;
}

.GameRecord__C-body .numcenter[data-v-481307ec] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.GameRecord__C-body-num[data-v-481307ec] {
    height: 0.8rem;
    line-height: 0.8rem;
    width: 0.8rem;
    font-size: 0.53333rem;
    font-weight: 700;
    font-size: 0.66667rem;
}

.GameRecord__C-body .mixedColor0[data-v-481307ec] {
    background: -webkit-linear-gradient( top, var(--norm_red-color) 50.96%, rgb(182, 89, 254) 50.97%);
    background: linear-gradient( 180deg, var(--norm_red-color) 50.96%, rgb(182, 89, 254) 50.97%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.GameRecord__C-body .mixedColor5[data-v-481307ec] {
    background: -webkit-linear-gradient( top, var(--norm_green-color) 51.48%, rgb(182, 89, 254) 51.49%);
    background: linear-gradient( 180deg, var(--norm_green-color) 51.48%, rgb(182, 89, 254) 51.49%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.GameRecord__C-body .greenColor[data-v-481307ec] {
    color: var(--norm_green-color);
}

.GameRecord__C-body .defaultColor[data-v-481307ec] {
    color: var(--norm_red-color);
}

.GameRecord__C-body-greenC[data-v-481307ec] {
    color: var(--bgcolor-22);
}

.GameRecord__C-body-empty[data-v-481307ec] {
    height: 5.33333rem;
}

.GameRecord__C-body>div[data-v-481307ec] {
    background: var(--darkBg, var(--bg_color_L2));
    color: var(--darkTextW, var(--text_color_L1));
}

.GameRecord__C-body>div+div[data-v-481307ec] {
    border-top: 0.01333rem solid var(--gray-color-1);
}

.GameRecord__C-origin[data-v-481307ec] {
    width: 100%;
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-origin>div+div[data-v-481307ec] {
    margin-left: 0.26667rem;
}

.GameRecord__C-origin-I[data-v-481307ec] {
    width: 0.26667rem;
    height: 0.26667rem;
    border-radius: 50%;
}

.GameRecord__C-origin-I.violet[data-v-481307ec] {
    background-color: var(--norm_Purple-color);
}

.GameRecord__C-origin-I.red[data-v-481307ec] {
    background: var(--norm_red-color);
}

.GameRecord__C-origin-I.green[data-v-481307ec] {
    background: var(--norm_green-color);
}

.GameRecord__C-foot[data-v-481307ec] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    color: var(--text_color_L2);
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.GameRecord__C-foot-previous[data-v-481307ec],
.GameRecord__C-foot-next[data-v-481307ec] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    color: var(--text_color_L4);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot-previous.disabled[data-v-481307ec],
.GameRecord__C-foot-next.disabled[data-v-481307ec] {
    background: var(--bg_color_L3);
    pointer-events: none;
    color: var(--text_color_L2);
}

.van-toast[data-v-d485a39d] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-d485a39d] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-d485a39d] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-d485a39d] {
    height: 80%;
}

.Trend__C[data-v-d485a39d] {
    width: calc(100% - 0.69333rem);
    margin: 0.48rem auto 0;
    text-align: center;
    font-size: 0.32rem;
}

.Trend__C-head[data-v-d485a39d] {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--sheet_nva_color);
    border-radius: 0.13333rem 0.13333rem 0 0;
    font-weight: 700;
    font-size: 0.34667rem;
    color: #fff;
}

.Trend__C-body1[data-v-d485a39d] {
    background: var(--bgDark-2, var(--bg_color_L2));
    padding-bottom: 0.37333rem;
}

.Trend__C-body1-line[data-v-d485a39d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    font-size: 0.34667rem;
    color: var(--text_color_L1);
    height: 0.41333rem;
}

.Trend__C-body1-line>div[data-v-d485a39d]:first-child {
    width: 3.70667rem;
    padding-left: 0.26667rem;
    text-align: left;
}

.Trend__C-body1-line-num[data-v-d485a39d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    padding-right: 0.2rem;
}

.Trend__C-body1-line-num>div[data-v-d485a39d] {
    width: 0.48rem;
    height: 0.48rem;
    line-height: 0.48rem;
    font-size: 0.34667rem;
    color: var(--text_color_L3);
    text-align: center;
}

.Trend__C-body1-line.lottery .Trend__C-body1-line-num>div[data-v-d485a39d] {
    border-radius: 50%;
    width: 0.48rem;
    height: 0.48rem;
    font-size: 0.34667rem;
    font-weight: 400;
    text-align: center;
    font-family: Roboto;
    border: 0.01333rem solid var(--norm_red-color);
    color: var(--norm_red-color) !important;
}

.Trend__C-body1-line+.Trend__C-body1-line[data-v-d485a39d] {
    margin-top: 0.26667rem;
}

.Trend__C-body1-line[data-v-d485a39d]:first-child {
    padding-top: 0.34667rem;
    height: 0.76rem;
    padding-left: 0.26667rem;
}

.Trend__C-body1-line-lottery[data-v-d485a39d] {
    height: 0.48rem;
}

.Trend__C-body2[data-v-d485a39d] {
    font-size: 0.32rem;
    background-color: var(--bg_color_L2, var(--text_color_L1));
}

.Trend__C-body2>div[data-v-d485a39d] {
    height: 1.33333rem;
    padding: 0.45333rem 0.26667rem;
    border-top: 0.01333rem solid var(--text_color_L3);
}

.Trend__C-body2>div.Trend__C-body2-empty[data-v-d485a39d] {
    height: 5.33333rem;
}

.Trend__C-body2-IssueNumber[data-v-d485a39d] {
    color: var(--text_color_L1);
    text-align: left;
}

.Trend__C-body2-Num[data-v-d485a39d] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    position: relative;
    height: 0.42667rem;
}

.Trend__C-body2-Num>div[data-v-d485a39d] {
    width: 0.4rem;
    height: 0.4rem;
    line-height: 0.4rem;
    text-align: center;
    border-radius: 50%;
}

.Trend__C-body2-Num-item[data-v-d485a39d] {
    border: 0.01333rem solid var(--text_color_L3);
    color: var(--text_color_L3);
    margin-right: 0.10667rem;
}

.Trend__C-body2-Num-item.action0[data-v-d485a39d] {
    position: relative;
    z-index: 10;
    border: none;
    color: #fff;
    background-image: -webkit-linear-gradient( 315deg, var(--norm_red-color) 0%, var(--norm_red-color) 50.37%, var(--norm_Purple-color) 50.38%, var(--norm_Purple-color) 100%) !important;
    background-image: linear-gradient( 135deg, var(--norm_red-color) 0%, var(--norm_red-color) 50.37%, var(--norm_Purple-color) 50.38%, var(--norm_Purple-color) 100%) !important;
}

.Trend__C-body2-Num-item.actionB[data-v-d485a39d] {
    border: none;
    color: #fff;
    background-color: var(--norm_secondary-color);
}

.Trend__C-body2-Num-item.actionS[data-v-d485a39d] {
    border: none;
    color: #fff;
    background-color: var(--bgColor-13);
}

.Trend__C-body2-Num-item.action5[data-v-d485a39d] {
    border: none;
    color: #fff;
    background-image: -webkit-linear-gradient( top left, var(--norm_green-color) 50%, var(--norm_Purple-color) 0) !important;
    background-image: linear-gradient( to bottom right, var(--norm_green-color) 50%, var(--norm_Purple-color) 0) !important;
    position: relative;
    z-index: 10;
}

.Trend__C-body2-Num-item.action1[data-v-d485a39d],
.Trend__C-body2-Num-item.action3[data-v-d485a39d],
.Trend__C-body2-Num-item.action7[data-v-d485a39d],
.Trend__C-body2-Num-item.action9[data-v-d485a39d] {
    border: none;
    color: #fff;
    background-color: var(--norm_green-color);
    position: relative;
    z-index: 10;
}

.Trend__C-body2-Num-item.action2[data-v-d485a39d],
.Trend__C-body2-Num-item.action4[data-v-d485a39d],
.Trend__C-body2-Num-item.action6[data-v-d485a39d],
.Trend__C-body2-Num-item.action8[data-v-d485a39d] {
    border: none;
    color: #fff;
    background-color: var(--norm_red-color);
    position: relative;
    z-index: 10;
}

.Trend__C-body2-Num-BS[data-v-d485a39d] {
    color: #fff;
    background: var(--norm_bule-color);
    margin-left: 0.24rem;
}

.Trend__C-body2-Num-BS.isB[data-v-d485a39d] {
    background: var(--norm_secondary-color);
}

.Trend__C-body2 .line-canvas[data-v-d485a39d] {
    position: absolute;
    top: 50%;
    left: 0;
    height: 1.33333rem;
    width: calc(100% - 0.64rem);
    z-index: 9;
}

html:lang(ar) .Trend__C-body2 .line-canvas[data-v-d485a39d] {
    left: unset;
    right: 0;
    -webkit-transform: scaleX(-1);
    transform: scaleX(-1);
}

.Trend__C-origin[data-v-d485a39d] {
    width: 100%;
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.Trend__C-origin-I[data-v-d485a39d] {
    width: 0.26667rem;
    height: 0.26667rem;
    border-radius: 50%;
}

.Trend__C-origin-I.violet[data-v-d485a39d] {
    background-color: var(--bgcolor-21);
}

.Trend__C-origin-I.red[data-v-d485a39d] {
    background: var(--norm_red-color);
}

.Trend__C-origin-I.green[data-v-d485a39d] {
    background: var(--bgcolor-22);
}

.Trend__C-foot[data-v-d485a39d] {
    height: 1.86667rem;
    background: var(--drakBg, var(--bg_color_L2));
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.Trend__C-foot-previous[data-v-d485a39d],
.Trend__C-foot-next[data-v-d485a39d] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.Trend__C-foot-previous.disabled[data-v-d485a39d],
.Trend__C-foot-next.disabled[data-v-d485a39d] {
    background: var(--bg_color_L3);
    pointer-events: none;
}

.Trend__C-foot-previous.disabled .Trend__C-icon[data-v-d485a39d],
.Trend__C-foot-next.disabled .Trend__C-icon[data-v-d485a39d] {
    color: var(--text_color_L2);
}

.Trend__C-foot-previous .Trend__C-icon[data-v-d485a39d],
.Trend__C-foot-next .Trend__C-icon[data-v-d485a39d] {
    color: var(--text_color_L4);
}

.Trend__C-foot-page[data-v-d485a39d] {
    color: var(--darkTextW, var(--text_color_L2));
}

.van-toast[data-v-e44179e3] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-e44179e3] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-e44179e3] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-e44179e3] {
    height: 80%;
}

.WinningTip__C[data-v-e44179e3] {
    position: fixed;
    width: 100%;
    height: 100%;
    z-index: 99;
    background-color: #00000080;
    top: 0;
    left: 0;
}

html:lang(ar) .WinningTip__C[data-v-e44179e3] {
    right: 0;
    left: unset;
}

.WinningTip__C-body[data-v-e44179e3] {
    position: absolute;
    width: 7.73333rem;
    height: 10.93333rem;
    background-image: url(/assets/png/missningBg-c1f02bcd.png);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
    padding-top: 3.33333rem;
}

.WinningTip__C-body.isL[data-v-e44179e3] {
    background-image: url(/assets/png/missningLBg-ca049a47.png);
}

.WinningTip__C-body.isL .WinningTip__C-body-l1[data-v-e44179e3],
.WinningTip__C-body.isL .WinningTip__C-body-l2[data-v-e44179e3],
.WinningTip__C-body.isL .WinningTip__C-body-l3[data-v-e44179e3],
.WinningTip__C-body.isL .WinningTip__C-body-l4[data-v-e44179e3] {
    color: #7190b4;
}

.WinningTip__C-body.isL .WinningTip__C-body-l2>div[data-v-e44179e3] {
    background-color: #6889b1;
}

.WinningTip__C-body-l1[data-v-e44179e3] {
    font-weight: 700;
    font-size: 0.64rem;
    text-align: center;
    color: #fff;
    height: 0.77333rem;
    line-height: 0.77333rem;
    margin-bottom: 0.90667rem;
}

.WinningTip__C-body-l2[data-v-e44179e3] {
    height: 0.58667rem;
    line-height: 0.58667rem;
    display: -webkit-box;
    display: -webkit-flex;
    color: #fff;
    font-size: 0.29333rem;
    padding-left: 0.72rem;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.90667rem;
}

.WinningTip__C-body-l2>div[data-v-e44179e3] {
    height: 0.58667rem;
    background: #fdac32;
    color: var(--text_color_L1);
    border-radius: 0.13333rem;
    padding: 0 0.32rem;
}

.WinningTip__C-body-l2>div[data-v-e44179e3]:first-child {
    margin-left: 0.32rem;
}

.WinningTip__C-body-l2>div.WinningNum[data-v-e44179e3] {
    width: 0.53333rem;
    height: 0.53333rem;
    line-height: 0.53333rem;
    margin: 0 0.18667rem;
    padding: 0;
    text-align: center;
    border-radius: 50%;
}

.WinningTip__C-body-l2.type0>div[data-v-e44179e3] {
    background-image: var(--linearGradien-5);
}

.WinningTip__C-body-l2.type5>div[data-v-e44179e3] {
    background-image: var(--linearGradien-6);
}

.WinningTip__C-body-l3[data-v-e44179e3] {
    height: 1.73333rem;
}

.WinningTip__C-body-l3 .isLose[data-v-e44179e3] {
    font-weight: 700;
    font-size: 0.64rem;
    line-height: 0.77333rem;
    color: #7190b4;
    text-align: center;
    margin-bottom: 0.34667rem;
    padding-top: 0.4rem;
}

.WinningTip__C-body-l3 .head[data-v-e44179e3] {
    height: 0.4rem;
    line-height: 0.4rem;
    font-weight: 700;
    font-size: 0.34667rem;
    color: #fb5b5b;
    text-align: center;
    margin-bottom: 0.10667rem;
}

.WinningTip__C-body-l3 .bonus[data-v-e44179e3] {
    height: 0.64rem;
    line-height: 0.64rem;
    font-weight: 700;
    font-size: 0.53333rem;
    color: #fb5b5b;
    text-align: center;
    margin-bottom: 0.26667rem;
}

.WinningTip__C-body-l3 .gameDetail[data-v-e44179e3] {
    height: 0.37333rem;
    line-height: 0.37333rem;
    font-size: 0.29333rem;
    text-align: center;
    color: var(--text_color_L2);
}

.WinningTip__C-body-l4[data-v-e44179e3] {
    height: 0.64rem;
    line-height: 0.64rem;
    font-size: 0.32rem;
    color: #fff;
    position: absolute;
    left: 0.74667rem;
    bottom: 0.74667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

html:lang(ar) .WinningTip__C-body-l4[data-v-e44179e3] {
    left: unset;
    right: 0.74667rem;
}

.WinningTip__C-body-l4 .acitveBtn[data-v-e44179e3] {
    height: 0.56rem;
    width: 0.56rem;
    border-radius: 50%;
    background: var(--winTips);
    border: 0.01333rem solid var(--text_color_L1);
    margin-right: 0.18667rem;
    position: relative;
}

.WinningTip__C-body-l4 .acitveBtn.active[data-v-e44179e3]:before {
    content: "";
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
    height: 0.24rem;
    width: 0.32rem;
    display: block;
    background-image: url(/assets/png/vector-dc489162.png);
    background-repeat: no-repeat;
    background-size: 0.32rem 0.24rem;
    background-position: center;
}

.WinningTip__C .closeBtn[data-v-e44179e3] {
    width: 0.8rem;
    height: 0.8rem;
    background-image: url(/assets/png/close-84ce5e6a.png);
    background-repeat: no-repeat;
    background-size: 0.8rem;
    background-position: center;
    position: absolute;
    left: 50%;
    -webkit-transform: translateX(-50%) translateY(100%);
    transform: translate(-50%) translateY(100%);
    bottom: -0.26667rem;
}

.van-toast[data-v-5d71c3fd] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-5d71c3fd] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-5d71c3fd] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-5d71c3fd] {
    height: 80%;
}

.WinGo__C[data-v-5d71c3fd] {
    padding-bottom: 0.34667rem;
}

.WinGo__C-head[data-v-5d71c3fd] {
    height: 1.25333rem;
    background: -webkit-linear-gradient(left, #de2325 0%, #ff504a 100%);
    background: linear-gradient(90deg, #de2325 0%, #ff504a 100%);
    padding: 0 0.34667rem;
    position: relative;
}

.WinGo__C-head div[data-v-5d71c3fd] {
    background-repeat: no-repeat;
    background-position: center;
}

.WinGo__C-head-bcak[data-v-5d71c3fd] {
    position: absolute;
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/bcakIcon-b7c1d288.png);
    background-size: 0.64rem;
    left: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
}

.WinGo__C-head-logo[data-v-5d71c3fd] {
    background-size: 2.98667rem 1.12rem;
    height: 1.12rem;
    width: 2.98667rem;
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
}

.WinGo__C-head-more[data-v-5d71c3fd] {
    position: absolute;
    width: 1.54667rem;
    height: 0.64rem;
    right: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

html:lang(ar) .WinGo__C-head-more[data-v-5d71c3fd] {
    right: unset;
    left: 0.34667rem;
}

.WinGo__C-head-more>div[data-v-5d71c3fd] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/kefu-b361c42f.png);
    background-size: 0.64rem;
}

.WinGo__C-head-more>div[data-v-5d71c3fd]:last-child {
    background-image: url(/assets/png/voice-62dbf38c.png);
}

.WinGo__C-head-more>div:last-child.disableVoice[data-v-5d71c3fd] {
    background-image: url(/assets/png/voice-off-633f5ccc.png);
}

.WinGo__C[data-v-5d71c3fd] .noticeBar__container {
    width: calc(100% - 0.69333rem) !important;
    margin: 0.45333rem auto;
    position: relative;
    z-index: 1;
    top: 0;
}

.van-toast[data-v-3c1bee29] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-3c1bee29] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-3c1bee29] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-3c1bee29] {
    height: 80%;
}

.TimeLeft__C[data-v-3c1bee29] {
    width: calc(100% - 0.69333rem);
    height: 5rem;
    margin: 0.48rem auto 0;
    background-image: url(/assets/png/trxbg-38af3973.png);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: 0.01333rem center;
    color: var(--text_color_L4);
    padding: 0.42667rem 0.29333rem;
}

.TimeLeft__C-l1[data-v-3c1bee29] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    height: 0.66667rem;
    line-height: 0.66667rem;
}

.TimeLeft__C-l1-l[data-v-3c1bee29] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.TimeLeft__C-l1-no[data-v-3c1bee29] {
    height: 0.66667rem;
    border: 0.01333rem solid var(--text_color_L4);
    border-radius: 0.13333rem;
    padding: 0 0.29333rem;
    margin-right: 0.13333rem;
    font-size: 0.29333rem;
}

.TimeLeft__C-l1-tip[data-v-3c1bee29],
.TimeLeft__C-l1-r[data-v-3c1bee29] {
    height: 0.66667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background: var(--darkLight, var(--bg_color_L2));
    border-radius: 0.8rem;
    font-size: 0.29333rem;
    gap: 0.06667rem;
    color: var(--darkTextW, var(--main-color));
    padding: 0 0.24rem;
}

.TimeLeft__C-l1-tip svg[data-v-3c1bee29],
.TimeLeft__C-l1-r svg[data-v-3c1bee29] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    color: var(--darkTextW, var(--main-color));
    height: 0.48rem;
    width: 0.48rem;
}

.TimeLeft__C-l2[data-v-3c1bee29] {
    height: 0.66667rem;
    line-height: 0.66667rem;
    margin-top: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    font-size: 0.37333rem;
}

.TimeLeft__C-l3[data-v-3c1bee29] {
    height: 1.46667rem;
    margin-top: 1.04rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.TimeLeft__C-l3 .num0[data-v-3c1bee29] {
    background-image: url(/assets/png/num0-d3a30585.png);
}

.TimeLeft__C-l3 .num0.prize0[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prize0-96a81e16.png);
}

.TimeLeft__C-l3 .num1[data-v-3c1bee29] {
    background-image: url(/assets/png/num1-fdab1e12.png);
}

.TimeLeft__C-l3 .num1.prize1[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prize1-fe15d69b.png);
}

.TimeLeft__C-l3 .num2[data-v-3c1bee29] {
    background-image: url(/assets/png/num2-b18f079a.png);
}

.TimeLeft__C-l3 .num2.prize2[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prize2-28af3286.png);
}

.TimeLeft__C-l3 .num3[data-v-3c1bee29] {
    background-image: url(/assets/png/num3-8254ed13.png);
}

.TimeLeft__C-l3 .num3.prize3[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prize3-6700769f.png);
}

.TimeLeft__C-l3 .num4[data-v-3c1bee29] {
    background-image: url(/assets/png/num4-5f2d81c5.png);
}

.TimeLeft__C-l3 .num4.prize4[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prize4-5a5999aa.png);
}

.TimeLeft__C-l3 .num5[data-v-3c1bee29] {
    background-image: url(/assets/png/num5-fd2837e8.png);
}

.TimeLeft__C-l3 .num5.prize5[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prize5-82f7fa61.png);
}

.TimeLeft__C-l3 .num6[data-v-3c1bee29] {
    background-image: url(/assets/png/num6-0cbd3b10.png);
}

.TimeLeft__C-l3 .num6.prize6[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prize6-57181440.png);
}

.TimeLeft__C-l3 .num7[data-v-3c1bee29] {
    background-image: url(/assets/png/num7-05973970.png);
}

.TimeLeft__C-l3 .num7.prize7[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prize7-ca1d24be.png);
}

.TimeLeft__C-l3 .num8[data-v-3c1bee29] {
    background-image: url(/assets/png/num8-41b2260f.png);
}

.TimeLeft__C-l3 .num8.prize8[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prize8-3ffac79f.png);
}

.TimeLeft__C-l3 .num9[data-v-3c1bee29] {
    background-image: url(/assets/png/num9-310d63e2.png);
}

.TimeLeft__C-l3 .num9.prize9[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prize9-63d3f3f8.png);
}

.TimeLeft__C-l3 .numA[data-v-3c1bee29] {
    background-image: url(/assets/png/numA-594afa89.png);
}

.TimeLeft__C-l3 .numA.prizeA[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prizeA-7217212f.png);
}

.TimeLeft__C-l3 .numB[data-v-3c1bee29] {
    background-image: url(/assets/png/numB-cad56304.png);
}

.TimeLeft__C-l3 .numB.prizeB[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prizeB-6c3c2497.png);
}

.TimeLeft__C-l3 .numC[data-v-3c1bee29] {
    background-image: url(/assets/png/numC-8d88d857.png);
}

.TimeLeft__C-l3 .numC.prizeC[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prizeC-bbf8b83c.png);
}

.TimeLeft__C-l3 .numD[data-v-3c1bee29] {
    background-image: url(/assets/png/numD-06e782e9.png);
}

.TimeLeft__C-l3 .numD.prizeD[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prizeD-46a95e2f.png);
}

.TimeLeft__C-l3 .numE[data-v-3c1bee29] {
    background-image: url(/assets/png/numE-f70da99f.png);
}

.TimeLeft__C-l3 .numE.prizeE[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prizeE-90087f02.png);
}

.TimeLeft__C-l3 .numF[data-v-3c1bee29] {
    background-image: url(/assets/png/numF-956f8923.png);
}

.TimeLeft__C-l3 .numF.prizeF[data-v-3c1bee29]:last-of-type {
    background-image: url(/assets/png/prizeF-46aeece0.png);
}

.TimeLeft__C-l3>div[data-v-3c1bee29],
.TimeLeft__C-l3>p[data-v-3c1bee29] {
    width: 1.46667rem;
    height: 1.46667rem;
    line-height: 1.46667rem;
    text-align: center;
    font-weight: 700;
    font-size: 0.64rem;
    background-position: center;
    background-size: 100% 100%;
    background-repeat: no-repeat;
}

.TimeLeft__C-time[data-v-3c1bee29] {
    height: 0.66667rem;
    line-height: 0.66667rem;
    bottom: 0.29333rem;
    right: 0.32rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.TimeLeft__C-time>span[data-v-3c1bee29] {
    display: block;
    margin-right: 0.24rem;
    font-weight: 700;
    font-size: 0.29333rem;
    line-height: 0.33333rem;
}

.TimeLeft__C-time>div[data-v-3c1bee29] {
    background: var(--darkLight2, var(--winTips));
    color: var(--text_color_L4);
    font-weight: 700;
    font-size: 0.48rem;
    text-align: center;
    padding: 0 0.13333rem;
    border: 0.01333rem solid var(--text_color_L4);
    border-radius: 0.06667rem;
    background-position: center;
    background-size: 100% 100%;
    background-repeat: no-repeat;
}

.TimeLeft__C-time>div+div[data-v-3c1bee29] {
    margin-left: 0.12rem;
}

.van-toast[data-v-7a795a91] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-7a795a91] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-7a795a91] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-7a795a91] {
    height: 80%;
}

.GameRecord__C[data-v-7a795a91] {
    width: calc(100% - 0.69333rem);
    margin: 0.48rem auto 0;
    text-align: center;
    font-size: 0.32rem;
}

.GameRecord__C-head[data-v-7a795a91] {
    height: 1.06667rem;
    line-height: 1.06667rem;
    background: var(--sheet_nva_color);
    border-radius: 0.13333rem 0.13333rem 0 0;
    font-weight: 700;
    font-size: 0.34667rem;
    color: #fff;
}

.GameRecord__C-body[data-v-7a795a91] {
    line-height: 1.06667rem;
}

.GameRecord__C-body-redC[data-v-7a795a91] {
    color: var(--main-color);
}

.GameRecord__C-body-greenC[data-v-7a795a91] {
    color: var(--bgcolor-22);
}

.GameRecord__C-body-empty[data-v-7a795a91] {
    height: 5.33333rem;
}

.GameRecord__C-body[data-v-7a795a91] .van-col {
    position: relative;
    height: 1.33333rem;
    line-height: 1.33333rem;
}

.GameRecord__C-body>div[data-v-7a795a91] {
    background: var(--darkBg, var(--bg_color_L2));
    color: var(--darkTextW, var(--text_color_L1));
}

.GameRecord__C-body>div+div[data-v-7a795a91] {
    border-top: 0.01333rem solid var(--gray-color-1);
}

.GameRecord__C-body .numberC[data-v-7a795a91] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 100%;
}

.GameRecord__C-body .numberC>div[data-v-7a795a91] {
    width: 0.48rem;
    height: 0.48rem;
    font-size: 0.32rem;
    line-height: 0.48rem;
}

.GameRecord__C-body .small[data-v-7a795a91],
.GameRecord__C-body .big[data-v-7a795a91] {
    margin-left: 0.13333rem;
}

.GameRecord__C-body .big[data-v-7a795a91] {
    color: var(--norm_secondary-color);
}

.GameRecord__C-body .small[data-v-7a795a91] {
    color: var(--norm_bule-color);
}

.GameRecord__C-body .number[data-v-7a795a91] {
    color: #fff;
    border-radius: 50%;
}

.GameRecord__C-body .number.num1[data-v-7a795a91],
.GameRecord__C-body .number.num3[data-v-7a795a91],
.GameRecord__C-body .number.num7[data-v-7a795a91],
.GameRecord__C-body .number.num9[data-v-7a795a91] {
    background-color: var(--norm_green-color);
}

.GameRecord__C-body .number.num2[data-v-7a795a91],
.GameRecord__C-body .number.num4[data-v-7a795a91],
.GameRecord__C-body .number.num6[data-v-7a795a91],
.GameRecord__C-body .number.num8[data-v-7a795a91] {
    background-color: var(--norm_red-color);
}

.GameRecord__C-body .number.num0[data-v-7a795a91] {
    background-image: -webkit-linear-gradient( top left, var(--norm_green-color) 50%, var(--norm_Purple-color) 0);
    background-image: linear-gradient( to bottom right, var(--norm_green-color) 50%, var(--norm_Purple-color) 0);
}

.GameRecord__C-body .number.num5[data-v-7a795a91] {
    background-image: -webkit-linear-gradient( top left, var(--norm_red-color) 50%, var(--norm_Purple-color) 0);
    background-image: linear-gradient( to bottom right, var(--norm_red-color) 50%, var(--norm_Purple-color) 0);
}

.GameRecord__C-body .Binquire[data-v-7a795a91] {
    width: 0.42667rem;
    height: 0.42667rem;
    background-image: url(/assets/png/icon-question-de9a9185.png);
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    position: absolute;
    top: 0;
    left: 50%;
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
}

.GameRecord__C-origin[data-v-7a795a91] {
    width: 100%;
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-origin>div+div[data-v-7a795a91] {
    margin-left: 0.26667rem;
}

.GameRecord__C-origin-I[data-v-7a795a91] {
    width: 0.26667rem;
    height: 0.26667rem;
    border-radius: 50%;
}

.GameRecord__C-origin-I.violet[data-v-7a795a91] {
    background-color: var(--bgcolor-21);
}

.GameRecord__C-origin-I.red[data-v-7a795a91] {
    background: var(--norm_red-color);
}

.GameRecord__C-origin-I.green[data-v-7a795a91] {
    background: var(--bgcolor-22);
}

.GameRecord__C-foot[data-v-7a795a91] {
    height: 1.86667rem;
    background: var(--darkBg, var(--bg_color_L2));
    color: var(--text_color_L1);
    padding: 0.46667rem 2.37333rem;
    margin-top: 0.48rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.GameRecord__C-foot-previous[data-v-7a795a91],
.GameRecord__C-foot-next[data-v-7a795a91] {
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 0.13333rem;
    background: var(--main-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
}

.GameRecord__C-foot-previous.disabled[data-v-7a795a91],
.GameRecord__C-foot-next.disabled[data-v-7a795a91] {
    background: var(--bg_color_L1);
    pointer-events: none;
}

.GameRecord__C-foot-previous.disabled .GameRecord__C-icon[data-v-7a795a91],
.GameRecord__C-foot-next.disabled .GameRecord__C-icon[data-v-7a795a91] {
    color: var(--saveTextColor-7);
}

.GameRecord__C-foot-previous .GameRecord__C-icon[data-v-7a795a91],
.GameRecord__C-foot-next .GameRecord__C-icon[data-v-7a795a91] {
    color: var(--text_color_L4);
}

.van-toast[data-v-ac90c264] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-ac90c264] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-ac90c264] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-ac90c264] {
    height: 80%;
}

.WinTrx__C[data-v-ac90c264] {
    padding-bottom: 0.34667rem;
}

.WinTrx__C-head[data-v-ac90c264] {
    height: 1.25333rem;
    background: -webkit-linear-gradient(left, #de2325 0%, #ff504a 100%);
    background: linear-gradient(90deg, #de2325 0%, #ff504a 100%);
    padding: 0 0.34667rem;
    position: relative;
}

.WinTrx__C-head div[data-v-ac90c264] {
    background-repeat: no-repeat;
    background-position: center;
}

.WinTrx__C-head-bcak[data-v-ac90c264] {
    position: absolute;
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/bcakIcon-b7c1d288.png);
    background-size: 0.64rem;
    left: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
}

.WinTrx__C-head-logo[data-v-ac90c264] {
    background: url(/assets/png/headlogo-56515a97.png);
    background-size: 2.98667rem 1.12rem;
    height: 1.12rem;
    width: 2.98667rem;
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translate(-50%) translateY(-50%);
}

.WinTrx__C-head-more[data-v-ac90c264] {
    position: absolute;
    width: 1.54667rem;
    height: 0.64rem;
    right: 0.34667rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

html:lang(ar) .WinTrx__C-head-more[data-v-ac90c264] {
    left: 0.34667rem;
    right: unset;
}

.WinTrx__C-head-more>div[data-v-ac90c264] {
    width: 0.64rem;
    height: 0.64rem;
    background-image: url(/assets/png/kefu-b361c42f.png);
    background-size: 0.64rem;
}

.WinTrx__C-head-more>div[data-v-ac90c264]:last-child {
    background-image: url(/assets/png/voice-62dbf38c.png);
}

.WinTrx__C-head-more>div:last-child.disableVoice[data-v-ac90c264] {
    background-image: url(/assets/png/voice-off-633f5ccc.png);
}

.WinTrx__C[data-v-ac90c264] .noticeBar__container {
    width: calc(100% - 0.69333rem) !important;
    margin: 0.45333rem auto;
    position: relative;
    z-index: 1;
    top: 0;
}

.van-toast[data-v-5930c2be] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-5930c2be] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-5930c2be] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-5930c2be] {
    height: 80%;
}

.WinTrxIfram__C[data-v-5930c2be] .navbar__content .van-icon,
.WinTrxIfram__C[data-v-5930c2be] .navbar__content .navbar__content-center {
    color: var(--textW);
}

.WinTrxIfram__C .iframe[data-v-5930c2be] {
    position: relative;
    overflow: hidden;
    width: 100%;
    height: 100vh;
    background: #eee;
}

.van-toast[data-v-d965c53a] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-d965c53a] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-d965c53a] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-d965c53a] {
    height: 80%;
}

.Xoso[data-v-d965c53a] {
    padding: 0 0.32rem;
}

.Xoso[data-v-d965c53a] .van-sticky {
    padding-top: 0.26667rem;
    background-color: var(--bg_color_L2);
}

.Xoso[data-v-d965c53a] .van-sticky .tabs {
    background-color: var(--bg_color_L2);
    height: 1.73333rem;
}

.Xoso[data-v-d965c53a] .van-sticky .tabs .fun-tab-item {
    min-width: 2.93333rem;
    height: 1.46667rem;
    padding: 0 0.53333rem;
    color: var(--bgDark, var(--text_color_L2));
    background-size: 100%;
    border-radius: 0.16rem;
    background: var(--darkBg, var(--bg_color_L2));
    font-size: 0.34667rem;
    margin-right: 0.16rem;
}

.Xoso[data-v-d965c53a] .van-sticky .tabs .fun-tab-item p {
    margin-top: 0.06667rem;
}

.Xoso[data-v-d965c53a] .van-sticky .tabs .fun-tab-item.activeClassName {
    background: var(--linerGradien-94, var(--main_gradient-color2));
    color: #fff !important;
    background-size: 100%;
    z-index: 2;
}

.Xoso-page[data-v-d965c53a] {
    margin-top: 0.26667rem;
}

.Xoso-page-box .title[data-v-d965c53a] {
    height: 0.4rem;
    line-height: 0.4rem;
    position: relative;
    padding-left: 0.34667rem;
    font-size: 0.4rem;
    color: var(--darkTextW, var(--text_color_L1));
    font-weight: 700;
    margin-bottom: 0.26667rem;
}

.Xoso-page-box .title[data-v-d965c53a]:after {
    content: "";
    display: block;
    width: 0.08rem;
    height: 100%;
    background-color: var(--darkLight, var(--main-color));
    position: absolute;
    left: 0;
    top: 0;
}

.Xoso-page-box .list[data-v-d965c53a] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
}

.Xoso-page-box .list .item[data-v-d965c53a] {
    width: calc(50% - 0.29333rem);
    margin-bottom: 0.26667rem;
}

.Xoso-page-box .list .item>h4[data-v-d965c53a] {
    height: 1.33333rem;
    border-radius: 0.13333rem 0.13333rem 0 0;
    padding: 0 0.18667rem;
    background: var(--main_gradient-color);
    font-size: 0.42667rem;
    color: #fff;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.Xoso-page-box .list .item>h4 .img[data-v-d965c53a] {
    width: 0.64rem;
    display: block;
}

.Xoso-page-box .list .item .info[data-v-d965c53a] {
    padding: 0.18667rem;
    background-color: var(--darkBg, var(--bg_color_L2));
    border-radius: 0 0 0.13333rem 0.13333rem;
}

.Xoso-page-box .list .item .info .issue[data-v-d965c53a] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    color: var(--darkTextW, var(--main-color));
    font-size: 0.37333rem;
    border-bottom: 0.01333rem solid var(--gray-color-1);
    padding: 0.13333rem 0;
}

.Xoso-page-box .list .item .info .issue img[data-v-d965c53a] {
    width: 0.64rem;
    display: block;
    margin-right: 0.06667rem;
}

.Xoso-page-box .list .item .info p[data-v-d965c53a] {
    color: var(--bgDark, var(--text_color_L2));
    font-size: 0.29333rem;
    text-align: center;
    height: 0.8rem;
    line-height: 0.66667rem;
}

.Xoso-page-box .list .item .info .time[data-v-d965c53a] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    color: var(--textM3, var(--text_color_L2));
    background-color: var(--bgDark-2, var(--LotteryXosoTimeBg));
    border-top: 0.13333rem solid var(--darkLight, var(--LotteryXosoTimeColor));
    border-radius: 0.13333rem;
    text-align: center;
    line-height: 0.69333rem;
    position: relative;
}

.Xoso-page-box .list .item .info .time[data-v-d965c53a]:after,
.Xoso-page-box .list .item .info .time[data-v-d965c53a]:before {
    content: "";
    display: block;
    height: 0.24rem;
    width: 0.13333rem;
    background-color: var(--darkLight, var(--LotteryXosoTimeColor));
    border: 0.02667rem solid var(--darkBg, var(--bg_color_L2));
    border-radius: 0.18667rem;
    position: absolute;
    top: -0.26667rem;
}

.Xoso-page-box .list .item .info .time[data-v-d965c53a]:after {
    left: 35%;
}

.Xoso-page-box .list .item .info .time[data-v-d965c53a]:before {
    right: 35%;
}

.Xoso-page-box .list .item .info .time>div[data-v-d965c53a] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    height: 0.69333rem;
    font-size: 0.37333rem;
    font-weight: 500;
    position: relative;
}

.Xoso-page-box .list .item .info .time>div[data-v-d965c53a]:after {
    content: "";
    display: block;
    width: 0.01333rem;
    height: 0.4rem;
    background-color: #d2d2d2;
    position: absolute;
    right: 0;
    top: 50%;
    margin-top: -0.2rem;
}

.Xoso-page-box .list .item .info .time>div[data-v-d965c53a]:last-child:after {
    display: none;
}

.van-toast[data-v-b328b529] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-b328b529] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-b328b529] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-b328b529] {
    height: 80%;
}

[data-v-b328b529] .MyGameRecord__C {
    margin-top: 0;
}

[data-v-b328b529] .MyGameRecord__C .MyGameRecordList__C {
    margin: 0 -0.32rem;
}

[data-v-b328b529] .ar-searchbar__selector>div {
    padding: 0;
    box-shadow: none;
}

[data-v-b328b529] .ar-searchbar__selector>div span {
    color: var(--text_color_L2);
}

.TeamReport__C[data-v-b328b529] {
    padding: 0 0.32rem 0.53333rem;
}

.TeamReport__C-head[data-v-b328b529] {
    height: 2.93333rem;
}

.TeamReport__C-head-fixed[data-v-b328b529] {
    height: 2.86667rem;
    position: fixed;
    top: 1.22667rem;
    width: 100%;
    left: 50%;
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
    max-width: 10rem;
    background-color: var(--bgDark-4, var(--bg_color_L2));
    padding: 0 0.32rem;
    z-index: 9;
}

.TeamReport__C-head-line1[data-v-b328b529],
.TeamReport__C-head-line2[data-v-b328b529] {
    height: 1.06667rem;
    width: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    margin-top: 0.26667rem;
}

.TeamReport__C-head-line1>div[data-v-b328b529],
.TeamReport__C-head-line2>div[data-v-b328b529] {
    border-radius: 0.13333rem;
    line-height: 1.06667rem;
    width: calc(100% - 0.13333rem);
    padding: 0 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background-color: var(--darkBg, var(--bg_color_L2));
}

.TeamReport__C-head-line1>div+div[data-v-b328b529],
.TeamReport__C-head-line2>div+div[data-v-b328b529] {
    margin-left: 0.26667rem;
}

.TeamReport__C-head-line1 .default[data-v-b328b529],
.TeamReport__C-head-line2 .default[data-v-b328b529] {
    color: var(--text_color_L2);
}

.TeamReport__C-head-line1>div[data-v-b328b529] {
    width: 100%;
}

.TeamReport__C-list[data-v-b328b529] {
    background-color: var(--darkBg, var(--bg_color_L2));
    border-radius: 0.13333rem;
}

.van-toast[data-v-24e1bb6f] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-24e1bb6f] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-24e1bb6f] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-24e1bb6f] {
    height: 80%;
}

[data-v-24e1bb6f] .MyGameRecord__C {
    margin-top: 0;
}

[data-v-24e1bb6f] .MyGameRecord__C .MyGameRecordList__C {
    margin: 0 -0.32rem;
}

.TeamReport__C[data-v-24e1bb6f] {
    padding: 0 0.32rem 0.53333rem;
}

.TeamReport__C-head[data-v-24e1bb6f] {
    height: 2.93333rem;
}

.TeamReport__C-head-fixed[data-v-24e1bb6f] {
    height: 2.86667rem;
    position: fixed;
    top: 1.22667rem;
    width: 100%;
    left: 50%;
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
    max-width: 10rem;
    background-color: var(--bg_color_L2);
    padding: 0 0.32rem;
    z-index: 9;
}

.TeamReport__C-head-line1[data-v-24e1bb6f],
.TeamReport__C-head-line2[data-v-24e1bb6f] {
    height: 1.06667rem;
    width: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    color: var(--text_color_L2);
    font-size: 0.37333rem;
    margin-top: 0.26667rem;
}

.TeamReport__C-head-line1>div[data-v-24e1bb6f],
.TeamReport__C-head-line2>div[data-v-24e1bb6f] {
    border-radius: 0.13333rem;
    line-height: 1.06667rem;
    width: calc(100% - 0.13333rem);
    padding: 0 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    background-color: var(--textW);
}

.TeamReport__C-head-line1>div+div[data-v-24e1bb6f],
.TeamReport__C-head-line2>div+div[data-v-24e1bb6f] {
    margin-left: 0.26667rem;
}

.TeamReport__C-head-line1 .default[data-v-24e1bb6f],
.TeamReport__C-head-line2 .default[data-v-24e1bb6f] {
    color: var(--text_color_L2);
}

.TeamReport__C-head-line1>div[data-v-24e1bb6f] {
    width: 100%;
}

.TeamReport__C-list[data-v-24e1bb6f] {
    background-color: var(--darkBg, var(--bg_color_L2));
    border-radius: 0.13333rem;
}

[data-v-24e1bb6f] .van-sticky {
    padding-top: 0.26667rem;
    background-color: var(--bg_color_L2);
}

[data-v-24e1bb6f] .van-sticky .tabs {
    background-color: var(--bg_color_L2);
    height: 1.73333rem;
}

[data-v-24e1bb6f] .van-sticky .tabs .fun-tab-item {
    min-width: 2.93333rem;
    min-height: 1.17333rem;
    padding: 0 0.53333rem;
    color: var(--text_color_L2);
    background-size: 100%;
    border-radius: 0.16rem;
    background: var(--bgDark-2, var(--bg_color_L2));
    box-shadow: var(--BoxShadowColor-25);
    font-size: 0.34667rem;
    margin-right: 0.16rem;
}

[data-v-24e1bb6f] .van-sticky .tabs .fun-tab-item p {
    margin-top: 0.06667rem;
}

[data-v-24e1bb6f] .van-sticky .tabs .fun-tab-item.activeClassName {
    background: var(--main_gradient-color2);
    box-shadow: var(--BoxShadowColor-20);
    box-shadow: var(--BoxShadowColor-25);
    color: var(--textW) !important;
    background-size: 100%;
    z-index: 2;
}

[data-v-24e1bb6f] .van-sticky .tabs .funtab_item {
    color: var(--text_color_L2) !important;
}

.van-toast[data-v-1aca5679] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-1aca5679] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-1aca5679] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-1aca5679] {
    height: 80%;
}

.header[data-v-1aca5679] {
    padding: 0.13333rem 0.21333rem;
    background: #141b26;
}

.header>div[data-v-1aca5679] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.header>div .searchIcon[data-v-1aca5679] {
    background-image: url(/assets/svg/search-e8c2aae9.svg);
    background-repeat: no-repeat;
    background-position: center;
    width: 0.64rem;
    height: 0.64rem;
}

.header>div.l2[data-v-1aca5679] {
    height: 1.22667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.header>div.l2 .inputDom[data-v-1aca5679] {
    height: 100%;
    background-color: #4c607f1f;
    border-radius: 0.21333rem 0 0 0.21333rem;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    background-image: url(/assets/svg/search-e8c2aae9.svg);
    background-repeat: no-repeat;
    background-position: 0.26667rem center;
    padding-left: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.header>div.l2 .inputDom input[data-v-1aca5679] {
    height: 0.53333rem;
    width: 100%;
    outline: 0;
    border: 0;
    font-size: 0.4rem;
    background: transparent;
    padding: 0 0.32rem;
    color: #dbe3ed;
    border-left: 0.01333rem solid #48586d;
}

.header>div.l2 .inputDom input[data-v-1aca5679]::-webkit-input-placeholder {
    color: #48586d;
}

.header>div.l2 .inputDom input[data-v-1aca5679]::placeholder {
    color: #48586d;
}

.header>div.l2 .close[data-v-1aca5679] {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    width: 1.6rem;
    line-height: 1.22667rem;
    background-color: #4c607f1f;
    height: 100%;
    color: #48586d;
    text-align: center;
    border-radius: 0 0.21333rem 0.21333rem 0;
    position: relative;
}

.header>div.l2 .close[data-v-1aca5679]:before {
    content: "";
    position: absolute;
    width: 0.53333rem;
    height: 100%;
    top: 0;
    left: 0;
    background: -webkit-linear-gradient( 25deg, transparent 0 40%, #141b26 40% 60%, transparent 60% 100%), -webkit-linear-gradient(155deg, transparent 0 40%, #141b26 40% 60%, transparent 60% 100%);
    background: linear-gradient( 65deg, transparent 0 40%, #141b26 40% 60%, transparent 60% 100%), linear-gradient( -65deg, transparent 0 40%, #141b26 40% 60%, transparent 60% 100%);
    background-size: 0.42667rem 50%;
    background-repeat: no-repeat;
    background-position: 0 bottom, 0 top;
}

.header .backSvg[data-v-1aca5679] {
    background-image: url(/assets/svg/backButton-eadf8686.svg);
    background-repeat: no-repeat;
    background-position: center;
    width: 1.12rem;
    height: 0.69333rem;
}

.header_title[data-v-1aca5679] {
    padding: 0.13333rem;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    letter-spacing: -0.0048rem;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
}

.van-toast[data-v-5df4fc2f] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-5df4fc2f] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-5df4fc2f] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-5df4fc2f] {
    height: 80%;
}

.header[data-v-5df4fc2f] {
    padding: 0.13333rem 0.21333rem;
    background: #141b26;
}

.header>div[data-v-5df4fc2f] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.header>div .searchIcon[data-v-5df4fc2f] {
    background-image: url(/assets/svg/search-e8c2aae9.svg);
    background-repeat: no-repeat;
    background-position: center;
    width: 0.64rem;
    height: 0.64rem;
}

.header>div.l2[data-v-5df4fc2f] {
    height: 1.22667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}

.header>div.l2 .inputDom[data-v-5df4fc2f] {
    height: 100%;
    background-color: #4c607f1f;
    border-radius: 0.21333rem 0 0 0.21333rem;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    background-image: url(/assets/svg/search-e8c2aae9.svg);
    background-repeat: no-repeat;
    background-position: 0.26667rem center;
    padding-left: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.header>div.l2 .inputDom input[data-v-5df4fc2f] {
    height: 0.53333rem;
    width: 100%;
    outline: 0;
    border: 0;
    font-size: 0.4rem;
    background: transparent;
    padding: 0 0.32rem;
    color: #dbe3ed;
    border-left: 0.01333rem solid #48586d;
}

.header>div.l2 .inputDom input[data-v-5df4fc2f]::-webkit-input-placeholder {
    color: #48586d;
}

.header>div.l2 .inputDom input[data-v-5df4fc2f]::placeholder {
    color: #48586d;
}

.header>div.l2 .close[data-v-5df4fc2f] {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    width: 1.6rem;
    line-height: 1.22667rem;
    background-color: #4c607f1f;
    height: 100%;
    color: #48586d;
    text-align: center;
    border-radius: 0 0.21333rem 0.21333rem 0;
    position: relative;
}

.header>div.l2 .close[data-v-5df4fc2f]:before {
    content: "";
    position: absolute;
    width: 0.53333rem;
    height: 100%;
    top: 0;
    left: 0;
    background: -webkit-linear-gradient( 25deg, transparent 0 40%, #141b26 40% 60%, transparent 60% 100%), -webkit-linear-gradient(155deg, transparent 0 40%, #141b26 40% 60%, transparent 60% 100%);
    background: linear-gradient( 65deg, transparent 0 40%, #141b26 40% 60%, transparent 60% 100%), linear-gradient( -65deg, transparent 0 40%, #141b26 40% 60%, transparent 60% 100%);
    background-size: 0.42667rem 50%;
    background-repeat: no-repeat;
    background-position: 0 bottom, 0 top;
}

.header .backSvg[data-v-5df4fc2f] {
    background-image: url(/assets/svg/backButton-eadf8686.svg);
    background-repeat: no-repeat;
    background-position: center;
    width: 1.12rem;
    height: 0.69333rem;
}

.header_title[data-v-5df4fc2f] {
    padding: 0.13333rem;
    font-family: Inter;
    font-size: 0.48rem;
    font-style: italic;
    font-weight: 700;
    letter-spacing: -0.0048rem;
    background: -webkit-linear-gradient( top, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background: linear-gradient( 180deg, #f5f6ff -2.72%, rgba(245, 246, 255, 0) 219.64%);
    background-clip: text;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
}

.van-toast[data-v-e5380132] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-e5380132] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-e5380132] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-e5380132] {
    height: 80%;
}

.messageDetail__container[data-v-e5380132] {
    padding-bottom: 0;
}

.messageDetail__container-wrapper[data-v-e5380132] {
    padding: 0.26667rem 0.16rem 0.66667rem;
    border-radius: 0.13333rem;
    background: var(--bg_color_L2);
}

.messageDetail__container-title[data-v-e5380132] {
    width: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    margin-bottom: 0.5rem;
    padding-bottom: 0.5rem;
    border-bottom: 0.01333rem solid var(--gray-color-1);
}

.messageDetail__container-title>div[data-v-e5380132] {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: start;
    -webkit-align-items: flex-start;
    align-items: flex-start;
    margin-left: 0.5rem;
}

.messageDetail__container-title>div>div[data-v-e5380132] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    margin-bottom: 0.10667rem;
    font-size: 0.4rem;
    font-weight: 600;
}

.messageDetail__container-title>div>div svg[data-v-e5380132] {
    width: 0.64rem;
    height: 0.64rem;
    margin-right: 0.09333rem;
}

.messageDetail__container-title>div>span[data-v-e5380132] {
    color: var(--text_color_L2);
    font-size: 0.32rem;
    font-weight: 400;
}

.messageDetail__container-title>svg[data-v-e5380132] {
    width: 0.48rem;
    height: 0.48rem;
}

.messageDetail__container-content[data-v-e5380132] {
    color: var(--text_color_L2);
    font-size: 0.32rem;
    line-height: 0.53333rem;
}

.van-toast[data-v-c0caae78] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-c0caae78] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-c0caae78] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-c0caae78] {
    height: 80%;
}

.dialog[data-v-c0caae78] {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    background: var(--bgcolor-32);
    -webkit-transition: opacity 0.15s ease-in-out, visibility 0.15s ease-in-out;
    transition: opacity 0.15s ease-in-out, visibility 0.15s ease-in-out;
    z-index: 2004;
}

.dialog.active[data-v-c0caae78] {
    opacity: 1;
    visibility: visible;
}

.dialog.active .dialog__container[data-v-c0caae78] {
    -webkit-transform: scale(1);
    transform: scale(1);
    opacity: 1;
}

.dialog.inactive[data-v-c0caae78] {
    opacity: 0;
    visibility: hidden;
}

.dialog.inactive .dialog__container[data-v-c0caae78] {
    -webkit-transform: scale(0.3);
    transform: scale(0.3);
    opacity: 0;
}

.dialog__container[data-v-c0caae78] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 8rem;
    min-height: 6.66667rem;
    border-radius: 0.26667rem;
    background: var(--bg_color_L2);
    -webkit-transition: opacity 0.3s, -webkit-transform 0.3s ease-in-out;
    transition: opacity 0.3s, -webkit-transform 0.3s ease-in-out;
    transition: opacity 0.3s, transform 0.3s ease-in-out;
    transition: opacity 0.3s, transform 0.3s ease-in-out, -webkit-transform 0.3s ease-in-out;
    z-index: 2003;
    padding: 0.53333rem 0.26667rem;
    border-radius: 20px;
}

.dialog__container-img[data-v-c0caae78] {
    width: 3.73333rem;
    height: 2.4rem;
    margin-top: -1.06667rem;
}

.dialog__container-img img[data-v-c0caae78] {
    width: 100%;
    height: 100%;
}

.dialog__container-title[data-v-c0caae78] {
    margin-top: 0.34667rem;
    font-size: 0.48rem;
    font-weight: 700;
    color: var(--text_color_L1);
}

.dialog__container-content[data-v-c0caae78] {
    margin-top: 0.24rem;
    color: var(--text_color_L2);
    font-size: 0.32rem;
    font-weight: 400;
}

.dialog__container-footer[data-v-c0caae78] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    gap: 0.28rem;
    width: 100%;
    height: 1.06667rem;
    margin-top: 2rem;
    padding: 0 0.26667rem;
}

.dialog__container-footer button[data-v-c0caae78] {
    width: 3.12rem;
    height: 1.06667rem;
    color: var(--main-color);
    font-size: 0.42667rem;
    text-align: center;
    border-radius: 9rem;
    border: 0.01333rem solid var(--main-color);
    background: transparent;
}

.dialog__container-footer button[data-v-c0caae78]:last-of-type {
    width: 4.34667rem;
    color: var(--text_color_L4);
    background: var(--main_gradient-color);
}

.dialog__outside[data-v-c0caae78] {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    cursor: default;
    z-index: 2002;
    background: rgba(0, 0, 0, 0.6);
}

.van-toast[data-v-c10b67fb] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-c10b67fb] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-c10b67fb] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-c10b67fb] {
    height: 80%;
}

.point[data-v-c10b67fb] {
    width: 0.13333rem;
    height: 0.13333rem;
    background-color: var(--norm_red-color);
    position: relative;
    border-radius: 50%;
}

.point-flicker[data-v-c10b67fb]:after {
    background-color: var(--norm_red-color);
}

.point-flicker[data-v-c10b67fb]:before {
    background-color: #00a8fd33;
}

.point-flicker[data-v-c10b67fb]:before,
.point-flicker[data-v-c10b67fb]:after {
    content: "";
    width: 0.21333rem;
    height: 0.21333rem;
    position: absolute;
    left: 50%;
    top: 50%;
    margin-left: -0.10667rem;
    margin-top: -0.10667rem;
    border-radius: 50%;
    -webkit-animation: warn-c10b67fb 1.5s ease-out 0s infinite;
    animation: warn-c10b67fb 1.5s ease-out 0s infinite;
}

html:lang(ar) .point-flicker[data-v-c10b67fb]:before,
html:lang(ar) .point-flicker[data-v-c10b67fb]:after {
    left: unset;
    right: 50%;
}

@-webkit-keyframes warn-c10b67fb {
    0% {
        -webkit-transform: scale(0.5);
        transform: scale(0.5);
        opacity: 1;
    }
    30% {
        opacity: 1;
    }
    to {
        -webkit-transform: scale(1.4);
        transform: scale(1.4);
        opacity: 0;
    }
}

@keyframes warn-c10b67fb {
    0% {
        -webkit-transform: scale(0.5);
        transform: scale(0.5);
        opacity: 1;
    }
    30% {
        opacity: 1;
    }
    to {
        -webkit-transform: scale(1.4);
        transform: scale(1.4);
        opacity: 0;
    }
}

.van-toast[data-v-254f4c39] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-254f4c39] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-254f4c39] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-254f4c39] {
    height: 80%;
}

.dailyProfitRank .title[data-v-254f4c39] {
    color: #171717;
    text-align: center;
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    margin-bottom: 0.48rem;
}

.dailyProfitRank .driver[data-v-254f4c39] {
    width: 100%;
    height: 0.04rem;
    position: relative;
    background-color: #fb716c;
    margin-bottom: 0.4rem;
}

.dailyProfitRank .driver[data-v-254f4c39]:before,
.dailyProfitRank .driver[data-v-254f4c39]:after {
    content: "";
    position: absolute;
    width: 0.21333rem;
    height: 0.21333rem;
    border-radius: 50%;
    background-color: #fb716c;
}

.dailyProfitRank .driver[data-v-254f4c39]:before {
    left: -0.10667rem;
    top: -0.10667rem;
}

html:lang(ar) .dailyProfitRank .driver[data-v-254f4c39]:before {
    left: unset;
    right: -0.10667rem;
}

.dailyProfitRank .driver[data-v-254f4c39]:after {
    right: -0.10667rem;
    top: -0.10667rem;
}

html:lang(ar) .dailyProfitRank .driver[data-v-254f4c39]:after {
    left: -0.10667rem;
    right: unset;
}

.dailyProfitRank .rank_list[data-v-254f4c39] {
    padding: 0 0.26667rem;
    border-radius: 0.4rem;
    background: #e5e8f5;
}

.dailyProfitRank .rank_list .daily_item[data-v-254f4c39] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    height: 1.6rem;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    border-bottom: 0.01333rem solid #eceef6;
}

.dailyProfitRank .rank_list .daily_item .amount[data-v-254f4c39] {
    color: #171717;
    text-align: right;
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
}

.dailyProfitRank .rank_list .daily_item .left[data-v-254f4c39] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.dailyProfitRank .rank_list .daily_item .left .avatar_img[data-v-254f4c39] {
    border: 0.02667rem solid transparent;
    background-clip: padding-box, border-box;
    background-origin: padding-box, border-box;
    background-image: -webkit-linear-gradient(left, #f0f0f5, #f0f0f5), -webkit-linear-gradient(top, #ffd89d, #b9730c);
    background-image: linear-gradient(to right, #f0f0f5, #f0f0f5), linear-gradient(to bottom, #ffd89d, #b9730c);
    border-radius: 50%;
    width: 0.98667rem;
    height: 0.98667rem;
    margin-right: 0.32rem;
}

.dailyProfitRank .rank_list .daily_item .left .avatar_img img[data-v-254f4c39] {
    margin-top: 0.01333rem;
    width: 0.93333rem;
    height: 0.93333rem;
    border-radius: 50%;
}

.dailyProfitRank .rank_list .daily_item .left .avatar_img1[data-v-254f4c39] {
    background-image: -webkit-linear-gradient(left, #f0f0f5, #f0f0f5), -webkit-linear-gradient(top, #ffd89d, #b9730c);
    background-image: linear-gradient(to right, #f0f0f5, #f0f0f5), linear-gradient(to bottom, #ffd89d, #b9730c);
}

.dailyProfitRank .rank_list .daily_item .left .avatar_img2[data-v-254f4c39] {
    background-image: -webkit-linear-gradient(left, #f0f0f5, #f0f0f5), -webkit-linear-gradient(top, #e7eced, #237286);
    background-image: linear-gradient(to right, #f0f0f5, #f0f0f5), linear-gradient(to bottom, #e7eced, #237286);
}

.dailyProfitRank .rank_list .daily_item .left .avatar_img3[data-v-254f4c39] {
    background-image: -webkit-linear-gradient(left, #f0f0f5, #f0f0f5), -webkit-linear-gradient(top, #fecab3, #d05824);
    background-image: linear-gradient(to right, #f0f0f5, #f0f0f5), linear-gradient(to bottom, #fecab3, #d05824);
}

.dailyProfitRank .rank_list .daily_item .left .info .tit[data-v-254f4c39] {
    color: #171717;
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    margin-bottom: 0.08rem;
}

.dailyProfitRank .rank_list .daily_item .left .info .ranking[data-v-254f4c39] {
    color: #707070;
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
}

.dailyProfitRank .rank_list .daily_item .left .info .ranking1[data-v-254f4c39],
.dailyProfitRank .rank_list .daily_item .left .info .ranking2[data-v-254f4c39],
.dailyProfitRank .rank_list .daily_item .left .info .ranking3[data-v-254f4c39] {
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    padding-left: 0.48rem;
}

.dailyProfitRank .rank_list .daily_item .left .info .ranking1[data-v-254f4c39] {
    color: #fbae3b;
    background: url(/assets/png/top1-573e2e29.png) no-repeat left center;
    background-size: 0.32rem 100%;
}

.dailyProfitRank .rank_list .daily_item .left .info .ranking2[data-v-254f4c39] {
    color: #508e9e;
    background: url(/assets/png/top2-40f62dc7.png) no-repeat left center;
    background-size: 0.32rem 100%;
}

.dailyProfitRank .rank_list .daily_item .left .info .ranking3[data-v-254f4c39] {
    color: #f59369;
    background: url(/assets/png/top3-31e06806.png) no-repeat left center;
    background-size: 0.32rem 100%;
}

.dailyProfitRank .rank_list .daily_item[data-v-254f4c39]:last-child {
    border-bottom: none;
}

.van-toast[data-v-84514e8e] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-84514e8e] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-84514e8e] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-84514e8e] {
    height: 80%;
}

.dailyProfitRank[data-v-84514e8e] {
    color: var(--text_color_L1);
    margin-top: 0.53333rem;
}

.dailyProfitRank .title[data-v-84514e8e] {
    height: 0.56rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    font-size: 0.4rem;
    font-weight: 500;
    margin-bottom: 1.33333rem;
}

.dailyProfitRank .title b[data-v-84514e8e] {
    display: block;
    height: 0.34667rem;
    width: 0.10667rem;
    border-radius: 0.05333rem;
    background-color: var(--main-color);
    -webkit-margin-end: 0.13333rem;
    margin-inline-end: 0.13333rem;
}

.dailyProfitRank__content[data-v-84514e8e] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.dailyProfitRank__content-topThree[data-v-84514e8e] {
    position: relative;
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    justify-items: center;
    width: 100%;
    height: 3.33333rem;
    z-index: 1;
    background: url(/assets/png/DailyProfitRankStage-ce00a6d6.png) no-repeat center center/100% 100%;
}

.dailyProfitRank__content-topThree__item[data-v-84514e8e] {
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 3rem;
    height: 3.46667rem;
}

.dailyProfitRank__content-topThree__item[data-v-84514e8e]:nth-child(2) {
    right: 0.10667rem;
}

.dailyProfitRank__content-topThree__item[data-v-84514e8e]:nth-child(3) {
    left: 0.16rem;
}

.dailyProfitRank__content-topThree__item>div[data-v-84514e8e]:first-of-type {
    position: relative;
    display: grid;
    place-items: center;
    width: 1.6rem;
    min-width: 1.6rem;
    height: 1.6rem;
    min-height: 1.6rem;
    border-radius: 50%;
    overflow: hidden;
}

.dailyProfitRank__content-topThree__item>div:first-of-type>img[data-v-84514e8e] {
    width: calc(100% - 0.06667rem);
    height: calc(100% - 0.06667rem);
}

.dailyProfitRank__content-topThree__item>div[data-v-84514e8e]:last-of-type {
    position: absolute;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    width: 1.78667rem;
    height: 1.82667rem;
}

.dailyProfitRank__content-topThree__item>div:last-of-type img[data-v-84514e8e]:first-of-type {
    position: relative;
    top: -0.33333rem;
    left: -0.25333rem;
    width: 1.14667rem;
}

.dailyProfitRank__content-topThree__item>div:last-of-type img[data-v-84514e8e]:last-of-type {
    width: 1.78667rem;
    height: 0.42667rem;
}

.dailyProfitRank__content-topThree__item>span[data-v-84514e8e] {
    color: #fff;
    padding: 0 0.13333rem;
    text-align: center;
}

.dailyProfitRank__content-topThree__item>span[data-v-84514e8e]:first-of-type {
    margin-block: 18% 8%;
    font-size: 0.32rem;
    width: 2.66667rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.dailyProfitRank__content-topThree__item>span[data-v-84514e8e]:last-of-type {
    width: 2.66667rem;
    height: 0.66667rem;
    padding: 0.17333rem 0.18667rem;
    font-size: 0.32rem;
    line-height: 0.32rem;
    text-align: center;
    border-radius: 9rem;
    background: var(--bgDark, rgba(255, 255, 255, 0.3));
}

.dailyProfitRank__content-list[data-v-84514e8e] {
    position: relative;
    z-index: 2;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    gap: 0.21333rem;
    width: 100%;
}

.dailyProfitRank__content-list__item[data-v-84514e8e] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    width: 100%;
    height: 1.36rem;
    padding: 0.14667rem 0.25333rem 0.14667rem 0.44rem;
    background: var(--darkBg, var(--bg_color_L2));
    border-radius: 0.13333rem;
}

.dailyProfitRank__content-list__item span.left-rank[data-v-84514e8e] {
    margin-right: 0.41333rem;
    color: var(--text_color_L2);
    font-size: 0.48rem;
    font-weight: 500;
}

.dailyProfitRank__content-list__item span.middle-name[data-v-84514e8e] {
    color: var(--text_color_L2);
    font-size: 0.32rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 2.66667rem;
}

.dailyProfitRank__content-list__item span.right-box[data-v-84514e8e] {
    line-height: 0.66667rem;
    width: 3.46667rem;
    height: 0.66667rem;
    margin-left: auto;
    color: #fff;
    font-size: 0.4rem;
    text-align: center;
    border-radius: 9rem;
    background: var(--main_gradient-color);
}

.dailyProfitRank__content-list__item img[data-v-84514e8e] {
    width: 1.06667rem;
    height: 1.06667rem;
    margin-right: 0.17333rem;
    border-radius: 50%;
}

.van-toast[data-v-b9ec896b] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-b9ec896b] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-b9ec896b] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-b9ec896b] {
    height: 80%;
}

.noticeBar__container[data-v-b9ec896b] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    height: 0.98667rem;
    padding-inline: 0.26667rem;
    color: #303a4c;
    font-size: 0.32rem;
    border-radius: 99rem;
    background: #fff;
    margin-bottom: 0.53333rem;
}

.noticeBar__container span.notify[data-v-b9ec896b] {
    background: url(/assets/png/notify-59345247.png) no-repeat center center;
    background-size: 0.53333rem;
    width: 0.64rem;
    height: 0.64rem;
}

.noticeBar__container-body[data-v-b9ec896b] {
    width: 9.33333rem;
    height: 100%;
    overflow: hidden;
    position: relative;
    height: 0.8rem;
    line-height: 0.98667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.noticeBar__container-body-text[data-v-b9ec896b] {
    width: 100%;
    height: -webkit-fit-content;
    height: fit-content;
    max-height: 0.98667rem;
    line-height: 0.49333rem;
    -webkit-animation: marquee-b9ec896b 7s linear infinite;
    animation: marquee-b9ec896b 7s linear infinite;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: column;
    -webkit-justify-content: column;
    justify-content: column;
    overflow: hidden;
    text-overflow: ellipsis;
    word-wrap: break-word;
    word-break: break-all;
}

@-webkit-keyframes marquee-b9ec896b {
    0% {
        -webkit-transform: translateY(100%);
        transform: translateY(100%);
    }
    10% {
        -webkit-transform: translateY(0);
        transform: translateY(0);
    }
    90% {
        -webkit-transform: translateY(0);
        transform: translateY(0);
    }
    to {
        -webkit-transform: translateY(-100%);
        transform: translateY(-100%);
    }
}

@keyframes marquee-b9ec896b {
    0% {
        -webkit-transform: translateY(100%);
        transform: translateY(100%);
    }
    10% {
        -webkit-transform: translateY(0);
        transform: translateY(0);
    }
    90% {
        -webkit-transform: translateY(0);
        transform: translateY(0);
    }
    to {
        -webkit-transform: translateY(-100%);
        transform: translateY(-100%);
    }
}

.noticeBar__container>svg[data-v-b9ec896b] {
    width: 0.42667rem;
    -webkit-flex-shrink: 0;
    flex-shrink: 0;
    height: auto;
    margin-right: 0.22667rem;
}

.noticeBar__container button[data-v-b9ec896b] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-flex-shrink: 0;
    flex-shrink: 0;
    gap: 0.06667rem;
    width: 2rem;
    height: 0.66667rem;
    margin-left: auto;
    color: #fff;
    border: none;
    border-radius: 0.53333rem;
    background: -webkit-linear-gradient(bottom, #f54545 20.19%, #fe6868 100%);
    background: linear-gradient(360deg, #f54545 20.19%, #fe6868 100%);
}

.noticeBar__container button svg[data-v-b9ec896b] {
    width: 0.32rem;
    height: auto;
}

.van-toast[data-v-3ad7aed7] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-3ad7aed7] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-3ad7aed7] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-3ad7aed7] {
    height: 80%;
}

.swiper_box[data-v-3ad7aed7] {
    position: relative;
    padding: 0 0.34667rem;
}

.swiper_box .swiper-button[data-v-3ad7aed7] {
    padding-top: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.swiper_box .swiper-button span[data-v-3ad7aed7] {
    position: relative;
    display: inline-block;
    width: 0.10667rem;
    height: 0.10667rem;
    border-radius: 0.10667rem;
    background-color: #656565;
    margin: 0 0.2rem;
    -webkit-transition: all 0.5s ease;
    transition: all 0.5s ease;
}

.swiper_box .swiper-button .active[data-v-3ad7aed7] {
    background-color: var(--main-color);
    width: 0.26667rem;
    height: 0.10667rem;
    -webkit-transition: all 0.3s ease;
    transition: all 0.3s ease;
}

.swiper_box .my-swipe[data-v-3ad7aed7] {
    height: 4.26667rem;
    box-sizing: border-box;
}

.swiper_box .my-swipe img[data-v-3ad7aed7] {
    width: 100%;
    height: 100%;
    border-radius: 0.26667rem;
    -webkit-filter: var(--BoxShadowColor-35);
    filter: var(--BoxShadowColor-35);
}

.van-toast {
    word-break: break-word !important;
}

.cg-default.van-button {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img {
    height: 80%;
}

.turntable {
    position: fixed;
    bottom: 6.13333rem;
    right: 0.2rem;
    width: 1.86667rem;
    height: 1.86667rem;
    border-radius: 50%;
    z-index: 100;
    touch-action: none;
    background: url(/assets/png/turntable_icon-04916ea0.png) no-repeat center/cover;
}

.turntable-lottery {
    position: fixed;
    bottom: 6.13333rem;
    right: 0.2rem;
    width: 1.86667rem;
    height: 1.86667rem;
    border-radius: 50%;
    z-index: 100;
    touch-action: none;
    background: url(/assets/png/turntable-b345db9e.png) no-repeat center/cover;
}

.turntable-lottery.lottery-bottom {
    bottom: 8.26667rem;
}

.van-toast[data-v-b3bd7e49] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-b3bd7e49] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-b3bd7e49] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-b3bd7e49] {
    height: 80%;
}

.btn[data-v-b3bd7e49] {
    position: fixed;
    left: 50%;
    bottom: 2.4rem;
    -webkit-transform: translateX(-50%);
    transform: translate(-50%);
    width: 4.88rem;
    height: 1.06667rem;
    background: var(--downBg, var(--main_gradient-color2));
    border-radius: 1.06667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    padding-left: 0.26667rem;
    padding-right: 1.06667rem;
    z-index: 2;
}

.btn .line[data-v-b3bd7e49] {
    position: absolute;
    top: 0.13333rem;
    right: 1rem;
    height: 0.8rem;
}

.btn .close[data-v-b3bd7e49] {
    position: absolute;
    top: 0.06667rem;
    right: 0.06667rem;
    font-size: 0.66667rem;
    margin: 0.13333rem;
}

.btn .icon[data-v-b3bd7e49] {
    width: 0.64rem;
    height: 0.64rem;
}

.btn .text[data-v-b3bd7e49] {
    font-weight: 700;
    font-size: 0.32rem;
    line-height: 0.32rem;
    color: var(--text_color_L4);
    text-shadow: 0 0.02667rem 0.01333rem rgba(71, 129, 255, 0.5);
    margin-left: 0.13333rem;
    max-width: 2.88rem;
}

.van-toast[data-v-c0149d4b] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-c0149d4b] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-c0149d4b] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-c0149d4b] {
    height: 80%;
}

.game_menu[data-v-c0149d4b] {
    margin-bottom: 0.4rem;
}

.slidebar_ske[data-v-c0149d4b] {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    grid-gap: 0.4rem 1.06667rem;
    margin: auto;
}

.slidebar_ske div[data-v-c0149d4b] {
    width: 1.57333rem;
    height: 1.92rem;
}

[data-v-c0149d4b] .van-skeleton {
    padding: 0;
}

.game_menu_list[data-v-c0149d4b] {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    grid-gap: 0.4rem 1.06667rem;
    margin: auto;
}

.game_menu_list .gamen_item[data-v-c0149d4b] {
    width: 1.57333rem;
    height: 1.92rem;
    background-position: center top;
    background-repeat: no-repeat;
    background-size: 100%;
    position: relative;
}

.game_menu_list .gamen_item span[data-v-c0149d4b] {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    text-align: center;
    color: #707070;
}

html:lang(ar) .game_menu_list .gamen_item span[data-v-c0149d4b] {
    left: unset;
    right: 0;
}

.game_menu_list .active span[data-v-c0149d4b] {
    color: #171717;
}

.van-toast[data-v-c2791131] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-c2791131] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-c2791131] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-c2791131] {
    height: 80%;
}

.other_box[data-v-c2791131] {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 0.32rem;
}

.other_box .other_item[data-v-c2791131] {
    width: 4.53333rem;
    height: 4.61333rem;
    border-radius: 0.64rem;
    background: -webkit-linear-gradient(left, #ffc59a 0%, #ff8580 100%);
    background: linear-gradient(90deg, #ffc59a 0%, #ff8580 100%);
}

.other_box .other_item img[data-v-c2791131] {
    width: 100%;
    height: 4.61333rem;
    border-radius: 0.21333rem;
}

.van-toast[data-v-a28fe468] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-a28fe468] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-a28fe468] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-a28fe468] {
    height: 80%;
}

.hot_container[data-v-a28fe468] {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 0.32rem;
}

.hot_container-item[data-v-a28fe468] {
    width: 2.90667rem;
}

.hot_container img[data-v-a28fe468] {
    width: 2.90667rem;
    height: 2.90667rem;
}

.hot_container .win-odds[data-v-a28fe468] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    height: 0.48rem;
    background: #e6e6e6;
    color: #333;
    width: 100%;
    border-radius: 0.13333rem;
    font-size: 0.29333rem;
    overflow: hidden;
    margin-top: 0.08rem;
    margin-bottom: 0.13333rem;
    position: relative;
}

.hot_container .win-odds span[data-v-a28fe468] {
    position: relative;
    z-index: 1;
    display: block;
    height: 100%;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    line-height: 0.53333rem;
}

.hot_container .win-odds span[data-v-a28fe468]:first-child {
    padding-left: 0.13333rem;
}

.hot_container .win-odds span[data-v-a28fe468]:last-child {
    text-align: right;
    padding-right: 0.13333rem;
}

.hot_container .win-odds .win-p[data-v-a28fe468] {
    background: -webkit-linear-gradient(left, #ff8e8a 15.38%, #ffbfa1 86.26%);
    background: linear-gradient(90deg, #ff8e8a 15.38%, #ffbfa1 86.26%);
    position: absolute;
    left: 0;
    height: 100%;
}

.van-toast[data-v-13364130] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-13364130] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-13364130] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-13364130] {
    height: 80%;
}

.lottery_container[data-v-13364130] {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 0.32rem;
}

.lottery_container .lotterySlotItem[data-v-13364130] {
    width: 2.90667rem;
    height: 2.90667rem;
    border-radius: 0.4rem;
    text-align: center;
    position: relative;
    background: -webkit-linear-gradient(left, #00AF54 0%, #008000 100%);
    background: linear-gradient(90deg, #00AF54 0%, #008000 100%);
}

.lottery_container .lotterySlotItem div[data-v-13364130] {
    position: absolute;
    bottom: 0.2rem;
    left: 0;
    width: 100%;
    color: #171717;
    text-align: center;
    font-size: 0.26667rem;
    font-style: normal;
    font-weight: 400;
    letter-spacing: 0.01893rem;
}

html:lang(ar) .lottery_container .lotterySlotItem div[data-v-13364130] {
    left: unset;
    right: 0;
}

.lottery_container .lotterySlotItem img[data-v-13364130] {
    width: 2.29333rem;
    height: 2.29333rem;
}

.van-toast[data-v-dcf8cd53] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-dcf8cd53] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-dcf8cd53] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-dcf8cd53] {
    height: 80%;
}

.WinRate[data-v-dcf8cd53] {
    width: 100%;
    min-height: 1.70667rem;
    margin-bottom: 0.4rem;
}

.WinRate img[data-v-dcf8cd53] {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.van-toast[data-v-f52c66fe] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-f52c66fe] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-f52c66fe] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-f52c66fe] {
    height: 80%;
}

.game_container[data-v-f52c66fe] {
    padding-top: 0.4rem;
    border-top: 0.02667rem solid #e5e8f5;
    margin-bottom: 0.4rem;
}

.game_container .game_title[data-v-f52c66fe] {
    text-align: center;
    font-size: 0.4rem;
    font-style: normal;
    font-weight: 400;
    margin-bottom: 0.32rem;
}

.game_container .driver[data-v-f52c66fe] {
    width: 100%;
    height: 0.04rem;
    position: relative;
    background-color: #fb716c;
    margin-bottom: 0.4rem;
}

.game_container .driver[data-v-f52c66fe]:before,
.game_container .driver[data-v-f52c66fe]:after {
    content: "";
    position: absolute;
    width: 0.21333rem;
    height: 0.21333rem;
    border-radius: 50%;
    background-color: #fb716c;
}

.game_container .driver[data-v-f52c66fe]:before {
    left: -0.10667rem;
    top: -0.08rem;
}

html:lang(ar) .game_container .driver[data-v-f52c66fe]:before {
    left: unset;
    right: -0.10667rem;
}

.game_container .driver[data-v-f52c66fe]:after {
    right: -0.10667rem;
    top: -0.08rem;
}

html:lang(ar) .game_container .driver[data-v-f52c66fe]:after {
    left: -0.10667rem;
    right: unset;
}

.slidebar_other[data-v-f52c66fe] {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 0.32rem;
}

.slidebar_other div[data-v-f52c66fe] {
    width: 4.53333rem;
    height: 4.61333rem;
    border-radius: 0.64rem;
    background: #e9f3ff;
}

.slidebar_hot[data-v-f52c66fe] {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 0.32rem;
}

.slidebar_hot div[data-v-f52c66fe] {
    width: 2.90667rem;
    height: 2.90667rem;
    background: #e9f3ff;
}

.slidebar_lottery[data-v-f52c66fe] {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 0.32rem;
}

.slidebar_lottery div[data-v-f52c66fe] {
    width: 2.90667rem;
    height: 2.90667rem;
    border-radius: 0.50667rem;
    background: #e9f3ff;
}

.slidebar_title[data-v-f52c66fe] {
    width: 1.6rem;
    height: 0.56rem;
    background: #f0f0f5;
    margin: auto;
    margin-bottom: 0.32rem;
}

[data-v-f52c66fe] .van-skeleton {
    padding: 0;
}

.lottery_tabbar[data-v-f52c66fe] {
    border-radius: 0.72rem;
    background: #fff;
    border-color: transparent;
    margin-bottom: 0.4rem;
    height: 1.06667rem;
}

[data-v-f52c66fe] .van-tabs__nav--card {
    height: 1.06667rem;
    border: none;
    background: -webkit-linear-gradient(top, #f0f0f5 0%, #e5e8f5 100%);
    background: linear-gradient(180deg, #f0f0f5 0%, #e5e8f5 100%);
}

[data-v-f52c66fe] .van-tabs__nav--card .van-tab--card {
    border: none;
    font-size: 0.26667rem;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    color: #707070 !important;
}

[data-v-f52c66fe] .van-tabs__nav--card .van-tab--active {
    color: #171717 !important;
    background-color: transparent;
}

.van-toast[data-v-cbf8511f] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-cbf8511f] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-cbf8511f] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-cbf8511f] {
    height: 80%;
}

.login_tip[data-v-cbf8511f] {
    padding: 0.32rem;
}

.login_tip .tip[data-v-cbf8511f] {
    margin-bottom: 0.29333rem;
}

.login_tip .tip div[data-v-cbf8511f] {
    color: #171717;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    font-size: 0.32rem;
}

.login_tip .tip div[data-v-cbf8511f]:first-child {
    font-size: 0.4rem;
}

.login_tip .btn_box[data-v-cbf8511f] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-align-self: center;
    align-self: center;
}

.login_tip .btn_box div[data-v-cbf8511f] {
    width: 4.48rem;
    height: 0.90667rem;
    text-align: center;
    border-radius: 0.45333rem;
    color: #00AF54;
    font-size: 0.32rem;
    font-style: normal;
    font-weight: 400;
    line-height: 0.90667rem;
}

.login_tip .btn_box div[data-v-cbf8511f]:first-child {
    color: var(--main-color);
    border: 0.02667rem solid var(--main-color);
}

.login_tip .btn_box div[data-v-cbf8511f]:last-child {
    color: #fff;
    background: var(--main_gradient-color);
}

.van-toast[data-v-17ed3a84] {
    word-break: break-word !important;
}

.cg-default.van-button[data-v-17ed3a84] {
    font-weight: 700;
    font-size: 0.4rem;
}

.cg-default.van-button .van-button__icon[data-v-17ed3a84] {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
}

.cg-default.van-button .van-button__icon>img[data-v-17ed3a84] {
    height: 80%;
}

.content[data-v-17ed3a84] {
    font-family: bahnschrift;
    gap: 0.13333rem;
    padding: 0;
    padding-bottom: 2.4rem;
    background: #f7f8ff !important;
}

.content__right[data-v-17ed3a84] {
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -webkit-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    gap: 0.26667rem;
}

.content__right svg[data-v-17ed3a84] {
    position: relative;
    width: 0.69333rem;
    height: 0.69333rem;
}

.content__right .message[data-v-17ed3a84] {
    position: relative;
}

.content__right .message svg[data-v-17ed3a84] {
    width: 0.74667rem;
    height: 0.74667rem;
    color: var(--main-color);
}

.content__right .point[data-v-17ed3a84] {
    position: absolute;
    top: 0.02667rem;
    right: 0;
}

.content__right .down[data-v-17ed3a84] {
    color: var(--main-color);
    font-size: 0.82667rem;
    margin-top: -0.13333rem;
}

[data-v-17ed3a84] .navbar-fixed {
    box-shadow: 0 0.05333rem 0.13333rem #d9d9d9ad;
}

.navbar[data-v-17ed3a84] {
    background: #fff;
}

.navbar__content-left img[data-v-17ed3a84] {
    height: 80%;
}

.navbar__content-right svg[data-v-17ed3a84] {
    width: 0.77333rem;
}

.customer[data-v-17ed3a84] {
    position: fixed;
    bottom: 2.4rem;
    right: 0.4rem;
    width: 1.49333rem;
    height: 1.49333rem;
    border-radius: 50%;
    z-index: 99;
}

.customer img[data-v-17ed3a84] {
    width: 100%;
    height: 100%;
    border-radius: 50%;
}

[data-v-17ed3a84] .van-dialog {
    width: 8.29333rem;
    border-radius: 0.26667rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    justify-content: flex-start;
    overflow: hidden;
    background: #fff;
    padding-bottom: 0.29333rem;
}

[data-v-17ed3a84] .van-dialog__content {
    position: relative;
    width: 100%;
}

[data-v-17ed3a84] .van-dialog__content .promptHeader {
    text-align: center;
    height: 1.17333rem;
    line-height: 1.17333rem;
    color: #fff;
    font-weight: 700;
    font-size: 0.48rem;
    position: relative;
    background: var(--main_gradient-color);
}

[data-v-17ed3a84] .van-dialog__content .promptContent {
    width: 8.8rem;
    margin: auto;
    min-height: 9.33333rem;
    padding: 0.4rem 0.26667rem;
    overflow-y: auto;
}

[data-v-17ed3a84] .van-dialog__content .promptContent img {
    max-width: 7.73333rem;
}

[data-v-17ed3a84] .van-dialog .promptBtn {
    margin: 0.26667rem auto;
    width: 4rem;
    height: 1.06667rem;
    border-radius: 1.06667rem;
    background: var(--main_gradient-color);
    line-height: 1.06667rem;
    text-align: center;
    color: #fff;
}

[data-v-17ed3a84] .van-dialog__footer {
    z-index: 100;
    position: fixed;
    bottom: 0.4rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-flex: 1;
    -webkit-flex-grow: 1;
    flex-grow: 1;
    gap: 0.26667rem;
    width: 90%;
}

[data-v-17ed3a84] .van-dialog .van-button--default {
    background-color: transparent;
}

[data-v-17ed3a84] .van-dialog .van-button__text {
    color: #fff;
    width: 80%;
    height: 0.93333rem;
    text-align: center;
    line-height: 0.93333rem;
    background: var(--main_gradient-color);
    -webkit-filter: drop-shadow(0 0.05333rem 0 #00AF54);
    filter: drop-shadow(0 0.05333rem 0 #00AF54);
    border-radius: 1.06667rem;
    z-index: 100;
    font-weight: 700;
    font-size: 0.42667rem;
    font-family: Inter;
    font-style: normal;
    letter-spacing: 0.06667rem;
}

.Laundry-Con .Laundry-Con_tip[data-v-17ed3a84] {
    font-size: 0.48rem;
    font-weight: 700;
    color: #151515;
    text-align: center;
}

.Laundry-Con .Landty-Con-tips[data-v-17ed3a84] {
    font-size: 0.32rem;
    font-weight: 400;
    color: #666;
    margin-top: 0.42667rem;
}

.box1[data-v-17ed3a84] {
    padding: 0 0.32rem;
}

.message_icon[data-v-17ed3a84] {
    width: 0.69333rem;
    height: 0.69333rem;
    background: url(/assets/png/notify-59345247.png) no-repeat center;
    background-size: contain;
    display: inline-block;
}

.whiteGLing[data-v-17ed3a84] {
    border-bottom: 0.01333rem solid #e5e8f5;
}

.whiteGLing.mb[data-v-17ed3a84] {
    margin-bottom: 0.26667rem;
}

[data-v-17ed3a84] .noticeBar__container {
    margin-bottom: 0;
    margin: 0 0.32rem;
    width: calc(100% - 0.64rem);
}